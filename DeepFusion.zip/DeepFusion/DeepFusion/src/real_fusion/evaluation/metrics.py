from __future__ import annotations
from collections import Counter, defaultdict
from typing import Dict
import numpy as np
from real_fusion.pipeline import ExperimentResult

def _numeric_summary(values) -> Dict[str, object]:
    numbers = np.asarray([float(value) for value in values if value is not None and np.isfinite(float(value))], dtype=float)
    if not len(numbers):
        return {'count': 0, 'mean': None, 'median': None, 'p95': None, 'maximum': None}
    return {'count': int(len(numbers)), 'mean': float(np.mean(numbers)), 'median': float(np.median(numbers)), 'p95': float(np.percentile(numbers, 95)), 'maximum': float(np.max(numbers))}

def compute_metrics(result: ExperimentResult) -> Dict[str, object]:
    window_s = float(result.config['scenario']['window_s'])
    lifecycle_counts = Counter((item.lifecycle_state for item in result.estimates))
    source_counts = Counter((str(source['sensor_id']) for estimate in result.estimates for source in estimate.associated_sources))
    estimates_by_track = defaultdict(list)
    for estimate in result.estimates:
        estimates_by_track[estimate.track_id].append(estimate)
    target_base_times = {}
    for detection in result.raw_detections:
        current = target_base_times.get(detection.target_id)
        if current is None or detection.measurement_time_s < current:
            target_base_times[detection.target_id] = detection.measurement_time_s
    active_target_values = sorted(target_base_times)
    track_metrics = []
    availabilities = []
    for track_id in sorted(estimates_by_track):
        track_estimates = estimates_by_track[track_id]
        first_time = track_estimates[0].event_time_s
        last_time = track_estimates[-1].event_time_s
        expected = max(1, int(round((last_time - first_time) / window_s)) + 1)
        availability = float(len(track_estimates) / expected)
        availabilities.append(availability)
        target_id = track_estimates[0].target_id
        track_source_counts = Counter((str(source['sensor_id']) for estimate in track_estimates for source in estimate.associated_sources))
        track_metrics.append({'track_id': track_id, 'target_id': target_id, 'estimate_count': len(track_estimates), 'first_track_delay_s': float(first_time - target_base_times[target_id]), 'output_availability': availability, 'mean_existence_probability': float(np.mean([item.existence_probability for item in track_estimates])), 'lifecycle_counts': dict(Counter((item.lifecycle_state for item in track_estimates))), 'associated_report_count_by_sensor': dict(track_source_counts)})
    source_paths = result.sw_read.source_paths or [result.sw_read.path]
    metrics: Dict[str, object] = {'scenario': result.config['scenario']['name'], 'input': {'path': str(source_paths[0]) if len(source_paths) == 1 else None, 'file_count': len(source_paths), 'paths': [str(path) for path in source_paths], 'files': result.sw_read.file_summaries, 'total_rows': result.sw_read.total_rows, 'valid_rows': result.sw_read.valid_rows, 'quality_valid_rows': result.sw_read.quality_valid_rows, 'rejected_rows': result.sw_read.rejected_rows, 'time_filtered_rows': result.sw_read.time_filtered_rows, 'time_range': {'start_inclusive': result.sw_read.time_range_start, 'end_inclusive': result.sw_read.time_range_end, 'applied': bool(result.sw_read.time_range_start or result.sw_read.time_range_end)}, 'column_count': len(result.sw_read.input_columns), 'columns': result.sw_read.input_columns, 'target_count': len(active_target_values), 'target_values': active_target_values, 'raw_mby_value_count': len(result.sw_read.target_values), 'raw_mby_values': result.sw_read.target_values, 'device_count': len(result.sw_read.device_values), 'device_values': result.sw_read.device_values, 'source_track_count': len(result.source_tracks.summaries), 'local_track_count': len(result.global_track_memberships), 'active_target_count': len(active_target_values), 'schema': {'config_path': str(result.sw_read.input_config_path) if result.sw_read.input_config_path is not None else None, 'schema_name': result.sw_read.schema_name, 'validation_mode': result.sw_read.schema_validation_mode, 'automatically_resolved_core_columns': result.config['sw'].get('_core_columns', {}), 'expected_column_count': len(result.sw_read.expected_columns), 'missing_columns': result.sw_read.schema_missing_columns, 'extra_columns': result.sw_read.schema_extra_columns, 'header_order_matches': result.sw_read.header_order_matches}}, 'source_tracks': [item.to_record() for item in result.source_tracks.summaries], 'global_identity': {'mby_scope': 'per_sensor', 'rule': 'MBY只在同一装备内部有效；跨装备身份完全由时间和运动学证据确定', 'global_target_count': len(active_target_values), 'local_track_membership_count': len(result.global_track_memberships), 'multi_sensor_global_target_count': len({item.global_target_id for item in result.global_track_memberships if item.association_mode == 'multi_sensor_birth'}), 'single_source_global_target_count': len({item.global_target_id for item in result.global_track_memberships if item.association_mode == 'single_source'}), 'memberships': [item.to_record() for item in result.global_track_memberships], 'compatible_pair_count': sum((item.compatible for item in result.identity_pair_diagnostics)), 'incompatible_pair_count': sum((not item.compatible for item in result.identity_pair_diagnostics)), 'pair_diagnostics': [item.to_record() for item in result.identity_pair_diagnostics]}, 'fusion': {'track_ids': sorted({item.track_id for item in result.estimates}), 'target_track_ids': result.config['scenario'].get('target_track_ids', {}), 'target_count': len(active_target_values), 'estimate_count': len(result.estimates), 'tracks': track_metrics, 'target_fusion_modes': dict(result.target_fusion_modes), 'target_statuses': {target_id: status.to_record() for (target_id, status) in sorted(result.target_statuses.items())}, 'target_status_counts': dict(Counter((status.classification for status in result.target_statuses.values()))), 'over_gate_target_ids': sorted((target_id for (target_id, status) in result.target_statuses.items() if status.classification == 'cross_sensor_over_gate')), 'unformed_target_ids': sorted((target_id for (target_id, status) in result.target_statuses.items() if status.classification == 'unformed_false_alarm')), 'output_availability': float(np.mean(availabilities)) if availabilities else 0.0, 'late_drop_count': result.late_drop_count, 'released_window_count': result.released_window_count, 'mean_existence_probability': float(np.mean([item.existence_probability for item in result.estimates])) if result.estimates else 0.0, 'lifecycle_counts': dict(lifecycle_counts), 'associated_report_count_by_sensor': dict(source_counts), 'sparse_handling': {'minimum_points_per_device': int(result.config['sw'].get('minimum_points_per_device', 3)), 'sparse_group_count': len(result.source_tracks.sparse_groups), 'sparse_groups': [item.to_record() for item in result.source_tracks.sparse_groups], 'ignored_sparse_device_group_count': 0, 'false_alarm_target_ids': sorted({item.target_id for item in result.source_tracks.sparse_groups}), 'report_row_count': len(result.source_tracks.false_alarm_records)}}}
    if result.identity_learning_audits:
        audit_records = [item.to_record() for item in result.identity_learning_audits]
        proposals = [item.decision.learned_proposal for item in result.identity_learning_audits if item.decision.learned_proposal is not None]
        scored_records = [record for record in audit_records if record.get('learned_decision') is not None]
        metrics['global_identity']['learning'] = {'mode': 'shadow', 'authoritative_result_changed': False, 'candidate_count': len(audit_records), 'scored_count': len(proposals), 'abstain_count': sum((bool(item.abstain) for item in proposals)), 'fallback_count': sum((item.decision.authoritative_path == 'fallback' for item in result.identity_learning_audits)), 'disagreement_count': sum((bool(record['learned_decision']) != bool(record['baseline_decision']) for record in scored_records)), 'fallback_reason_counts': dict(Counter((str(item.decision.fallback_reason) for item in result.identity_learning_audits if item.decision.fallback_reason not in {None, 'shadow_only'}))), 'latency_ms': _numeric_summary((item.latency_ms for item in proposals)), 'model_ids': sorted({item.model_id for item in proposals}), 'feature_schema_versions': sorted({item.feature_schema_version for item in result.identity_learning_audits})}
    if result.ew_read is not None:
        kind_counts = Counter((item.kind for item in result.ew_measurements))
        association_counts = Counter((item.status for item in result.ew_associations))
        matched = [item for item in result.ew_associations if item.status == 'associated']
        measurement_by_id = {item.measurement_id: item for item in result.ew_measurements}
        sw_zbb_by_target = defaultdict(set)
        for membership in result.global_track_memberships:
            sw_zbb_by_target[str(membership.global_target_id)].add(str(membership.zbb))
        device_frequency = []
        for (zbb, group) in result.ew_read.frame.groupby('_zbb', sort=True):
            times = np.sort(group['_epoch_s'].dropna().unique().astype(float))
            intervals = np.diff(times)
            intervals = intervals[intervals > 0.0]
            median_interval = float(np.median(intervals)) if len(intervals) else None
            device_frequency.append({'zbb': str(zbb), 'row_count': int(len(group)), 'unique_timestamp_count': int(len(times)), 'median_interval_s': median_interval, 'estimated_frequency_hz': None if median_interval is None or median_interval <= 0.0 else 1.0 / median_interval})
        association_by_kind = []
        for measurement_kind in sorted(kind_counts):
            relevant = [item for item in result.ew_associations if measurement_by_id.get(item.measurement_id) is not None and measurement_by_id[item.measurement_id].kind == measurement_kind]
            successful = sum((item.status == 'associated' for item in relevant))
            association_by_kind.append({'measurement_kind': measurement_kind, 'report_count': len(relevant), 'associated_count': successful, 'association_rate': float(successful / len(relevant)) if relevant else 0.0})
        association_by_device = []
        for zbb in sorted(result.ew_read.device_values):
            relevant = [item for item in result.ew_associations if str(item.zbb) == str(zbb)]
            successful = [item for item in relevant if item.status == 'associated']
            association_by_device.append({'zbb': str(zbb), 'report_count': len(relevant), 'associated_count': len(successful), 'association_rate': float(len(successful) / len(relevant)) if relevant else 0.0, 'history_prior_associated_count': sum((item.local_track_history_match is True for item in successful))})
        identity_buckets = defaultdict(list)
        for item in matched:
            identity_buckets[str(item.ew_target_id), str(item.zbb), str(item.matched_target_id), str(item.matched_track_id), bool(item.local_track_history_match)].append(item)
        identity_links = []
        for ((ew_target, ew_zbb, sw_target, track_id, history_match), items) in sorted(identity_buckets.items()):
            identity_links.append({'ew_target_id': ew_target, 'ew_zbb': ew_zbb, 'matched_sw_target_id': sw_target, 'matched_joint_track_id': track_id, 'sw_source_zbb_values': sorted(sw_zbb_by_target.get(sw_target, set())), 'local_track_history_match': history_match, 'association_count': len(items), 'mean_association_probability': float(np.mean([value.association_probability for value in items])), 'median_abs_azimuth_residual_deg': float(np.median([abs(value.azimuth_residual_deg) for value in items if value.azimuth_residual_deg is not None])), 'source_files': sorted({value.source_file for value in items}), 'association_basis': '同一EW装备内局部航迹历史RF软先验+异步几何门控' if history_match else '首次/无历史关联；仅依靠异步时刻方位、俯仰和可选斜距几何门控'})
        joint_by_track = defaultdict(list)
        for estimate in result.joint_estimates:
            joint_by_track[estimate.track_id].append(estimate)
        metrics['ew'] = {'file_count': len(result.ew_read.source_paths), 'paths': [str(path) for path in result.ew_read.source_paths], 'files': result.ew_read.file_summaries, 'total_rows': result.ew_read.total_rows, 'valid_rows': result.ew_read.valid_rows, 'rejected_rows': result.ew_read.rejected_rows, 'time_filtered_rows': result.ew_read.time_filtered_rows, 'target_count': len(result.ew_read.target_values), 'target_values': result.ew_read.target_values, 'device_count': len(result.ew_read.device_values), 'device_values': result.ew_read.device_values, 'measurement_kind_counts': dict(kind_counts), 'used_positioned_sensor_ids': sorted(result.ew_sensor_positions), 'unpositioned_used_sensor_ids': sorted(set(map(str, result.ew_read.device_values)) - set(result.ew_sensor_positions)), 'configured_sensor_positions': sorted(result.ew_sensor_positions), 'device_frequency': device_frequency}
        metrics['joint_fusion'] = {'association_status_counts': dict(association_counts), 'association_report_count': len(result.ew_associations), 'associated_count': len(matched), 'unassociated_count': len(result.ew_associations) - len(matched), 'association_rate': float(len(matched) / len(result.ew_associations)) if result.ew_associations else 0.0, 'same_mby_associated_count': 0, 'different_mby_associated_count': 0, 'mby_cross_sensor_comparison_disabled': True, 'history_prior_associated_count': sum((item.local_track_history_match is True for item in matched)), 'geometry_only_associated_count': sum((item.local_track_history_match is not True for item in matched)), 'mean_association_probability': float(np.mean([item.association_probability for item in matched])) if matched else 0.0, 'association_probability_summary': _numeric_summary((item.association_probability for item in matched)), 'absolute_azimuth_residual_deg_summary': _numeric_summary((abs(item.azimuth_residual_deg) if item.azimuth_residual_deg is not None else None for item in matched)), 'absolute_elevation_residual_deg_summary': _numeric_summary((abs(item.elevation_residual_deg) if item.elevation_residual_deg is not None else None for item in matched)), 'absolute_range_residual_m_summary': _numeric_summary((abs(item.range_residual_m) if item.range_residual_m is not None else None for item in matched)), 'absolute_altitude_residual_m_summary': _numeric_summary((abs(item.altitude_residual_m) if item.altitude_residual_m is not None else None for item in matched)), 'nis_gate_ratio_summary': _numeric_summary((item.nis_gate_ratio for item in matched)), 'association_by_measurement_kind': association_by_kind, 'association_by_ew_device': association_by_device, 'cross_device_identity_links': identity_links, 'track_ids': sorted(joint_by_track), 'track_count': len(joint_by_track), 'estimate_count': len(result.joint_estimates), 'tracks': [{'track_id': track_id, 'target_id': estimates[0].target_id, 'estimate_count': len(estimates), 'ew_update_count': sum((bool(item.associated_detection_ids) and item.lifecycle_state == 'joint_confirmed' for item in estimates))} for (track_id, estimates) in sorted(joint_by_track.items())]}
    return metrics
