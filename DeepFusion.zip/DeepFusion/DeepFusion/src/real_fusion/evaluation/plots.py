from __future__ import annotations
from pathlib import Path
from typing import Optional
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from real_fusion.pipeline import ExperimentResult
from real_fusion.geometry import GeodeticConverter
from real_fusion.font_support import configure_matplotlib_fonts
from real_fusion.visualization.bounds import adaptive_axis_bounds, adaptive_axes_settings
from real_fusion.visualization.colors import FUSED_TRACK_COLOR, build_source_color_map
configure_matplotlib_fonts()
MAX_STATIC_POINTS_PER_SERIES = 5000
MAX_STATIC_TOTAL_POINTS = 80000
MAX_TARGET_PANELS_PER_PAGE = 8
START_MARKER_COLOR = '#16a34a'
END_MARKER_COLOR = '#dc2626'

def _create_ew_plots(result: ExperimentResult, output: Path) -> None:
    if result.ew_read is None:
        return
    ew_config = result.config['ew']['joint_fusion']
    maximum = int(ew_config.get('maximum_visualized_ew_reports', 5000))
    measurements = _sample_items(result.ew_measurements, maximum)
    association_by_id = {item.measurement_id: item for item in result.ew_associations}
    association_target_by_measurement = {item.measurement_id: str(item.matched_target_id) if item.status == 'associated' and item.matched_target_id else None for item in result.ew_associations}
    ew_source_tokens = {(str(association_target_by_measurement.get(item.measurement_id) or item.target_id), str(item.zbb), str(item.target_id)): f'EW::{association_target_by_measurement.get(item.measurement_id) or item.target_id}::{item.zbb}::{item.target_id}' for item in result.ew_measurements}
    ew_source_colors = build_source_color_map(ew_source_tokens.values())
    (padding, minimum) = adaptive_axes_settings(result.config)
    sw_points = np.asarray([item.state_enu[:3] for item in result.estimates], dtype=float)
    if len(sw_points):
        sw_span = np.maximum(np.ptp(sw_points, axis=0), 1.0)
        combined_ray_length = min(float(ew_config.get('ray_display_length_m', 5000.0)), max(200.0, float(np.linalg.norm(sw_span)) * 0.65))
    else:
        combined_ray_length = float(ew_config.get('ray_display_length_m', 5000.0))

    def draw_rays(axis, fallback_length: float, include_legend: bool=True) -> list:
        visible = []
        labelled = set()
        for measurement in measurements:
            if measurement.sensor_enu is None:
                continue
            endpoint = measurement.endpoint_enu(fallback_length)
            association = association_by_id.get(measurement.measurement_id)
            target_id = association.matched_target_id if association and association.status == 'associated' else None
            source_key = (str(target_id or measurement.target_id), str(measurement.zbb), str(measurement.target_id))
            color = ew_source_colors[ew_source_tokens[source_key]]
            label = f'EW关联｜目标={target_id}' if target_id is not None else 'EW未关联/未配置门内航迹'
            label = ('实测斜距线｜' if measurement.range_m is not None else '方向射线｜') + label
            axis.plot([measurement.sensor_enu[0], endpoint[0]], [measurement.sensor_enu[1], endpoint[1]], [measurement.sensor_enu[2], endpoint[2]], color=color, linewidth=0.9, alpha=0.3, linestyle='-' if measurement.range_m is not None else ':', label=label if include_legend and label not in labelled else None)
            labelled.add(label)
            visible.extend([measurement.sensor_enu, endpoint])
        for (zbb, position) in sorted(result.ew_sensor_positions.items()):
            axis.scatter([position[0]], [position[1]], [position[2]], marker='s', s=48, color='#111827', depthshade=False, label=f'共享装备={zbb}（本区间含EW数据）' if include_legend else None)
            visible.append(position)
        return visible
    figure = plt.figure(figsize=(12, 9))
    axis = figure.add_subplot(111, projection='3d')
    visible = draw_rays(axis, float(ew_config.get('ray_display_length_m', 5000.0)))
    bounds = adaptive_axis_bounds(visible, padding_ratio=padding, minimum_span=minimum)
    axis.set_xlim(*bounds[0])
    axis.set_ylim(*bounds[1])
    axis.set_zlim(*bounds[2])
    axis.set_box_aspect((1.25, 1.35, 0.82))
    axis.view_init(elev=24, azim=-58)
    axis.set_xlabel('东向 E / m')
    axis.set_ylabel('北向 N / m')
    axis.set_zlabel('高度 U / m')
    axis.set_title('EW 单独展示：实线=实测斜距，点线=仅方向约束（显示长度不代表距离）')
    (handles, labels) = axis.get_legend_handles_labels()
    if handles:
        axis.legend(handles, labels, loc='upper left', fontsize=8)
    figure.tight_layout()
    figure.savefig(output / 'ew_standalone_3d.png', dpi=180, bbox_inches='tight')
    plt.close(figure)
    figure = plt.figure(figsize=(12, 9))
    axis = figure.add_subplot(111, projection='3d')
    visible = draw_rays(axis, combined_ray_length, include_legend=True)
    baseline_by_track = {}
    for item in result.estimates:
        baseline_by_track.setdefault(item.track_id, []).append(item)
    for (track_id, items) in sorted(baseline_by_track.items()):
        values = np.asarray([item.state_enu for item in sorted(items, key=lambda x: x.event_time_s)])
        target_id = items[0].target_id
        axis.plot(values[:, 0], values[:, 1], values[:, 2], linestyle='--', linewidth=1.5, color=FUSED_TRACK_COLOR, alpha=0.6, label=f'SW主航迹｜{target_id}')
        visible.extend(values[:, :3])
    joint_by_track = {}
    for item in result.joint_estimates:
        joint_by_track.setdefault(item.track_id, []).append(item)
    for (track_id, items) in sorted(joint_by_track.items()):
        items = sorted(items, key=lambda x: x.event_time_s)
        values = np.asarray([item.state_enu for item in items])
        target_id = items[0].target_id
        axis.plot(values[:, 0], values[:, 1], values[:, 2], linewidth=3.0, color=FUSED_TRACK_COLOR, label=f'SW+EW联合｜{target_id}')
        ew_updates = np.asarray([item.state_enu[:3] for item in items if item.lifecycle_state == 'joint_confirmed' and item.associated_detection_ids], dtype=float)
        if len(ew_updates):
            axis.scatter(ew_updates[:, 0], ew_updates[:, 1], ew_updates[:, 2], marker='o', s=24, color=FUSED_TRACK_COLOR, edgecolors='white', linewidths=0.7, depthshade=False, label=f'EW更新状态点｜{target_id}')
        _mark_endpoints_3d(axis, values[:, :3])
        visible.extend(values[:, :3])
    bounds = adaptive_axis_bounds(visible, padding_ratio=padding, minimum_span=minimum)
    axis.set_xlim(*bounds[0])
    axis.set_ylim(*bounds[1])
    axis.set_zlim(*bounds[2])
    axis.set_box_aspect((1.25, 1.35, 0.82))
    axis.view_init(elev=24, azim=-58)
    axis.set_xlabel('东向 E / m')
    axis.set_ylabel('北向 N / m')
    axis.set_zlabel('高度 U / m')
    axis.set_title('SW 主航迹与 EW 异步角度约束联合融合')
    (handles, labels) = axis.get_legend_handles_labels()
    if handles:
        axis.legend(handles, labels, loc='upper left', fontsize=8)
    figure.tight_layout()
    figure.savefig(output / 'sw_ew_joint_3d.png', dpi=180, bbox_inches='tight')
    plt.close(figure)

def _relative(times: np.ndarray, base: float) -> np.ndarray:
    return times - base

def _sample_items(items: list, maximum: int=MAX_STATIC_POINTS_PER_SERIES) -> list:
    if len(items) <= maximum:
        return items
    indices = np.unique(np.linspace(0, len(items) - 1, maximum, dtype=int))
    return [items[index] for index in indices]

def _mark_endpoints_3d(axis, points: np.ndarray) -> None:
    if not len(points):
        return
    (start, end) = (points[0], points[-1])
    axis.scatter([start[0]], [start[1]], [start[2]], marker='^', s=54, c=START_MARKER_COLOR, edgecolors='#14532d', linewidths=0.8, depthshade=False, zorder=20)
    axis.scatter([end[0]], [end[1]], [end[2]], marker='X', s=60, c=END_MARKER_COLOR, edgecolors='#7f1d1d', linewidths=0.8, depthshade=False, zorder=21)

def _mark_endpoints_2d(axis, points: np.ndarray) -> None:
    if not len(points):
        return
    (start, end) = (points[0], points[-1])
    axis.scatter([start[0]], [start[1]], marker='^', s=48, c=START_MARKER_COLOR, edgecolors='#14532d', linewidths=0.8, zorder=20)
    axis.scatter([end[0]], [end[1]], marker='X', s=54, c=END_MARKER_COLOR, edgecolors='#7f1d1d', linewidths=0.8, zorder=21)

def _add_endpoint_legend_3d(axis) -> None:
    axis.scatter([], [], [], marker='^', s=44, c=START_MARKER_COLOR, label='起点')
    axis.scatter([], [], [], marker='X', s=48, c=END_MARKER_COLOR, label='终点')

def _add_endpoint_legend_2d(axis) -> None:
    axis.scatter([], [], marker='^', s=40, c=START_MARKER_COLOR, label='起点')
    axis.scatter([], [], marker='X', s=44, c=END_MARKER_COLOR, label='终点')

def create_plots(result: ExperimentResult, output_directory: str | Path) -> None:
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    base = float(result.config['scenario']['base_epoch_s'])
    target_order = sorted(result.config['scenario'].get('input_target_values', []))
    line_styles = ('--', '-.', ':', (0, (5, 2, 1, 2)))
    detections_by_series = {}
    for detection in result.normalized_detections:
        detections_by_series.setdefault((detection.target_id, detection.sensor_id), []).append(detection)
    source_color_tokens = {(str(target_id), str(sensor_id)): f'SW::{target_id}::{sensor_id}' for (target_id, sensor_id) in detections_by_series}
    sparse_color_tokens = {(str(item.target_id), str(item.zbb)): f'SW-SPARSE::{item.target_id}::{item.zbb}::{item.local_target_id}' for item in result.source_tracks.sparse_groups}
    source_color_palette = build_source_color_map([*source_color_tokens.values(), *sparse_color_tokens.values()])

    def source_color(target_id: object, sensor_id: object) -> str:
        return source_color_palette[source_color_tokens[str(target_id), str(sensor_id)]]

    def sparse_color(target_id: object, zbb: object) -> str:
        return source_color_palette[sparse_color_tokens[str(target_id), str(zbb)]]
    source_series_limit = min(MAX_STATIC_POINTS_PER_SERIES, max(1, MAX_STATIC_TOTAL_POINTS // max(len(detections_by_series), 1)))
    displayed_detections = {key: _sample_items(sorted(items, key=lambda item: (item.corrected_time_s, item.detection_id)), source_series_limit) for (key, items) in detections_by_series.items()}
    estimates_by_track = {}
    for estimate in result.estimates:
        estimates_by_track.setdefault(estimate.track_id, []).append(estimate)
    fused_series_limit = min(MAX_STATIC_POINTS_PER_SERIES, max(1, MAX_STATIC_TOTAL_POINTS // max(len(estimates_by_track), 1)))
    displayed_estimates_by_track = {track_id: _sample_items(sorted(items, key=lambda item: item.event_time_s), fused_series_limit) for (track_id, items) in estimates_by_track.items()}
    reference = result.config['scenario']['reference']
    converter = GeodeticConverter(float(reference['longitude_deg']), float(reference['latitude_deg']), float(reference['altitude_m']))
    sparse_points_by_series = {}
    raw_group_indices = result.sw_read.frame.groupby(['_mby', '_zbb'], sort=False).groups
    for sparse in result.source_tracks.sparse_groups:
        indices = raw_group_indices.get((sparse.local_target_id, sparse.zbb), [])
        group = result.sw_read.frame.loc[indices].sort_values('_jdsc', kind='stable')
        if group.empty:
            continue
        group = group.iloc[np.unique(np.linspace(0, len(group) - 1, min(len(group), MAX_STATIC_POINTS_PER_SERIES), dtype=int))]
        sparse_points_by_series[sparse.target_id, sparse.zbb] = (converter.geodetic_many_to_enu(group['_mbj'].to_numpy(dtype=float), group['_mbw'].to_numpy(dtype=float), group['_mbg'].to_numpy(dtype=float)), sparse.classification)

    def source_label(target_id: str, sensor_id: str) -> str:
        sensor = result.config['sensors'][sensor_id]
        local_batches = sorted({str(item.local_target_id) for item in result.normalized_detections if item.target_id == target_id and item.sensor_id == sensor_id and (item.local_target_id is not None)})
        return f"全局目标={target_id}｜局部MBY={'/'.join(local_batches)}｜{sensor['label']}"
    (padding_ratio, minimum_span) = adaptive_axes_settings(result.config)

    def draw_3d_tracks(axis_3d, target_filter: Optional[str]=None) -> None:
        visible_points = []
        for (index, ((target_id, sensor_id), detections)) in enumerate(sorted(displayed_detections.items())):
            if target_filter is not None and target_id != target_filter:
                continue
            states = np.asarray([item.state_enu for item in detections])
            visible_points.extend(states[:, :3])
            axis_3d.plot(states[:, 0], states[:, 1], states[:, 2], color=source_color(target_id, sensor_id), linestyle=line_styles[index % len(line_styles)], linewidth=1.0, alpha=0.48, label=source_label(target_id, sensor_id))
            axis_3d.scatter(states[:, 0], states[:, 1], states[:, 2], color=source_color(target_id, sensor_id), s=6, alpha=0.16)
            _mark_endpoints_3d(axis_3d, states[:, :3])
        for (track_id, estimates) in sorted(displayed_estimates_by_track.items()):
            target_id = estimates[0].target_id
            if target_filter is not None and target_id != target_filter:
                continue
            fused = np.asarray([item.state_enu for item in estimates])
            visible_points.extend(fused[:, :3])
            axis_3d.plot(fused[:, 0], fused[:, 1], fused[:, 2], color=FUSED_TRACK_COLOR, linewidth=3.4, label=f'融合 {track_id}｜目标={target_id}')
            _mark_endpoints_3d(axis_3d, fused[:, :3])
        for ((target_id, zbb), (points, classification)) in sorted(sparse_points_by_series.items()):
            if target_filter is not None and target_id != target_filter:
                continue
            visible_points.extend(points)
            if len(points) > 1:
                axis_3d.plot(points[:, 0], points[:, 1], points[:, 2], color=sparse_color(target_id, zbb), linestyle=(0, (1, 3)), linewidth=0.9, alpha=0.48)
            axis_3d.scatter(points[:, 0], points[:, 1], points[:, 2], color=sparse_color(target_id, zbb), marker='x', s=34, alpha=0.9, label=f'未成轨/虚警候选｜局部航迹={target_id}｜装备={zbb}')
        if visible_points:
            _add_endpoint_legend_3d(axis_3d)
        (east_bounds, north_bounds, up_bounds) = adaptive_axis_bounds(visible_points, padding_ratio=padding_ratio, minimum_span=minimum_span)
        axis_3d.set_xlim(*east_bounds)
        axis_3d.set_ylim(*north_bounds)
        axis_3d.set_zlim(*up_bounds)
        axis_3d.set_box_aspect((1.25, 1.35, 0.82))
        axis_3d.view_init(elev=24, azim=-58)
        axis_3d.set_xlabel('东向 E / m', labelpad=9)
        axis_3d.set_ylabel('北向 N / m', labelpad=9)
        axis_3d.set_zlabel('高度 U / m', labelpad=7)
        axis_3d.grid(alpha=0.22)
    (figure, axis) = plt.subplots(figsize=(11, 8))
    for (index, ((target_id, sensor_id), detections)) in enumerate(sorted(displayed_detections.items())):
        states = np.asarray([item.state_enu for item in detections])
        axis.plot(states[:, 0], states[:, 1], color=source_color(target_id, sensor_id), linestyle=line_styles[index % len(line_styles)], linewidth=1.0, alpha=0.55, label=source_label(target_id, sensor_id))
        axis.scatter(states[:, 0], states[:, 1], color=source_color(target_id, sensor_id), s=7, alpha=0.2)
        _mark_endpoints_2d(axis, states[:, :2])
    for (track_id, estimates) in sorted(displayed_estimates_by_track.items()):
        fused = np.asarray([item.state_enu for item in estimates])
        target_id = estimates[0].target_id
        axis.plot(fused[:, 0], fused[:, 1], color=FUSED_TRACK_COLOR, linewidth=3.0, label=f'融合 {track_id}｜目标={target_id}')
        _mark_endpoints_2d(axis, fused[:, :2])
    for ((target_id, zbb), (points, classification)) in sorted(sparse_points_by_series.items()):
        if len(points) > 1:
            axis.plot(points[:, 0], points[:, 1], color=sparse_color(target_id, zbb), linestyle=(0, (1, 3)), linewidth=0.9, alpha=0.48)
        axis.scatter(points[:, 0], points[:, 1], color=sparse_color(target_id, zbb), marker='x', s=30, alpha=0.9, label=f'未成轨/虚警候选｜局部航迹={target_id}｜装备={zbb}')
    if displayed_detections or displayed_estimates_by_track:
        _add_endpoint_legend_2d(axis)
    axis.set_xlabel('东向 E / m')
    axis.set_ylabel('北向 N / m')
    axis.set_title('多目标、多装备源航迹与融合航迹（俯视）')
    axis.axis('equal')
    axis.grid(alpha=0.22)
    (handles, labels) = axis.get_legend_handles_labels()
    if handles:
        axis.legend(handles, labels, loc='best', ncol=2)
    else:
        axis.text(0.5, 0.5, '当前区间没有可成轨目标；请查看 false_alarm_report.csv', transform=axis.transAxes, ha='center', va='center', color='#b45309')
    figure.tight_layout()
    figure.savefig(output / 'track_xy.png', dpi=170)
    plt.close(figure)
    figure = plt.figure(figsize=(12, 9))
    axis_3d = figure.add_subplot(111, projection='3d')
    draw_3d_tracks(axis_3d)
    axis_3d.set_title('全部目标总览（三维 E-N-U，保留目标间相对位置）', pad=18)
    (handles, labels) = axis_3d.get_legend_handles_labels()
    if handles:
        axis_3d.legend(handles, labels, loc='upper left', ncol=2)
    figure.tight_layout()
    figure.savefig(output / 'track_3d_overview.png', dpi=180, bbox_inches='tight')
    plt.close(figure)
    target_pages = [target_order[start:start + MAX_TARGET_PANELS_PER_PAGE] for start in range(0, len(target_order), MAX_TARGET_PANELS_PER_PAGE)] if target_order else [[]]
    for (page_index, page_targets) in enumerate(target_pages, start=1):
        panel_count = max(len(page_targets), 1)
        column_count = 1 if panel_count == 1 else 2
        row_count = int(np.ceil(panel_count / column_count))
        figure = plt.figure(figsize=(10.5 if column_count == 1 else 15.5, 7.2 * row_count), constrained_layout=True)
        if page_targets:
            for (panel_index, target_id) in enumerate(page_targets, start=1):
                target_axis = figure.add_subplot(row_count, column_count, panel_index, projection='3d')
                draw_3d_tracks(target_axis, target_filter=target_id)
                target_axis.set_title(f'目标={target_id}｜坐标轴按当前目标自动聚焦', pad=12)
                (handles, labels) = target_axis.get_legend_handles_labels()
                if handles:
                    target_axis.legend(handles, labels, loc='upper left', fontsize=8)
        else:
            target_axis = figure.add_subplot(111, projection='3d')
            draw_3d_tracks(target_axis)
            target_axis.set_title('当前区间没有可显示目标', pad=12)
        page_suffix = '' if len(target_pages) == 1 else f'｜第{page_index}/{len(target_pages)}页'
        figure.suptitle('多目标、多装备源航迹与融合航迹（分目标自适应三维视图）' + page_suffix, fontsize=16)
        filename = 'track_3d.png' if page_index == 1 else f'track_3d_page_{page_index:03d}.png'
        figure.savefig(output / filename, dpi=180, bbox_inches='tight')
        plt.close(figure)
    (figure, axes) = plt.subplots(2, 1, figsize=(11, 8), sharex=True)
    for (index, ((target_id, sensor_id), detections)) in enumerate(sorted(displayed_detections.items())):
        times = np.asarray([item.corrected_time_s for item in detections])
        states = np.asarray([item.state_enu for item in detections])
        axes[0].plot(_relative(times, base), states[:, 2], color=source_color(target_id, sensor_id), linestyle=line_styles[index % len(line_styles)], linewidth=1.0, alpha=0.55, label=source_label(target_id, sensor_id))
        axes[1].plot(_relative(times, base), np.linalg.norm(states[:, 3:], axis=1), color=source_color(target_id, sensor_id), linestyle=line_styles[index % len(line_styles)], linewidth=1.0, alpha=0.55)
    for (track_id, estimates) in sorted(displayed_estimates_by_track.items()):
        fused = np.asarray([item.state_enu for item in estimates])
        estimate_times = np.asarray([item.event_time_s for item in estimates])
        target_id = estimates[0].target_id
        axes[0].plot(_relative(estimate_times, base), fused[:, 2], color=FUSED_TRACK_COLOR, linewidth=2.7, label=f'融合 {track_id}｜目标={target_id}')
        axes[1].plot(_relative(estimate_times, base), np.linalg.norm(fused[:, 3:], axis=1), color=FUSED_TRACK_COLOR, linewidth=2.7)
    axes[0].set_ylabel('高度 U / m')
    axes[1].set_ylabel('速度 / (m/s)')
    axes[1].set_xlabel('相对绝对时戳 / s')
    axes[0].set_title('不同检测频率下的高度与速度估计')
    (handles, labels) = axes[0].get_legend_handles_labels()
    if handles:
        axes[0].legend(handles, labels, loc='best', ncol=3)
    for axis in axes:
        axis.grid(alpha=0.22)
    figure.tight_layout()
    figure.savefig(output / 'altitude_speed.png', dpi=170)
    plt.close(figure)
    _create_ew_plots(result, output)
