from __future__ import annotations
from html import escape
from pathlib import Path
from typing import Dict, Iterable, Mapping, Sequence
from real_fusion.pipeline import ExperimentResult, TargetFusionStatus
STATUS_DESCRIPTIONS = {'multi_source_fused': '多装备源航迹通过融合门控，形成融合航迹。', 'single_source_passthrough': '只有一个装备形成有效源航迹，按单源直通规则发布。', 'cross_sensor_over_gate': '各装备均已成轨，但跨装备点迹超过出生融合门控，保留源航迹而不强行融合。', 'unformed_false_alarm': '该装备内局部MBY未达到源航迹点数阈值，作为未成轨虚警候选。', 'source_time_not_overlapping': '各装备均已成轨，但探测时段没有在出生时间窗内重叠。', 'fusion_not_formed': '存在部分门内证据，但未满足完整出生条件，保留源航迹供复核。'}
MAX_EW_ASSOCIATION_ROWS_IN_SUMMARY = 500
MAX_IDENTITY_PAIR_ROWS_IN_SUMMARY = 500

def _text(value: object) -> str:
    if value is None:
        return '—'
    if isinstance(value, float):
        return f'{value:.6g}'
    if isinstance(value, (list, tuple, set)):
        return '、'.join((str(item) for item in value)) if value else '—'
    return str(value)

def _markdown_table(headers: Sequence[str], rows: Iterable[Sequence[object]]) -> str:
    values = list(rows)
    lines = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(('---' for _ in headers)) + ' |']
    for row in values:
        lines.append('| ' + ' | '.join((_text(value).replace('|', '\\|').replace('\n', ' ') for value in row)) + ' |')
    if not values:
        lines.append('| ' + ' | '.join(['无'] + ['—'] * (len(headers) - 1)) + ' |')
    return '\n'.join(lines)

def _html_table(headers: Sequence[str], rows: Iterable[Sequence[object]], row_classes=None) -> str:
    values = list(rows)
    classes = list(row_classes or [''] * len(values))
    head = ''.join((f'<th>{escape(header)}</th>' for header in headers))
    body = []
    for (index, row) in enumerate(values):
        class_name = escape(classes[index]) if index < len(classes) else ''
        cells = ''.join((f'<td>{escape(_text(value))}</td>' for value in row))
        body.append(f'<tr class="{class_name}">{cells}</tr>')
    if not body:
        body.append(f'<tr><td colspan="{len(headers)}" class="muted">无</td></tr>')
    return f"""<div class="table-wrap"><table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table></div>"""

def _status_rows(result: ExperimentResult):
    for (target_id, status) in sorted(result.target_statuses.items()):
        yield (target_id, status.display_status, status.track_id, status.member_local_target_ids, status.member_local_track_keys, status.input_point_count, status.valid_zbb_values, status.sparse_zbb_values, status.fused_estimate_count, status.source_files, status.reason)

def target_status_report_records(result: ExperimentResult) -> list[Dict[str, object]]:
    records = []
    for (target_id, status) in sorted(result.target_statuses.items()):
        diagnostic = status.diagnostic
        records.append({'target_id': target_id, 'classification': status.classification, 'display_status': status.display_status, 'fusion_track_id': status.track_id, 'input_point_count': status.input_point_count, 'valid_track_point_count': status.valid_track_point_count, 'sparse_point_count': status.sparse_point_count, 'valid_sensor_ids': '、'.join(status.valid_sensor_ids), 'valid_zbb_values': '、'.join(status.valid_zbb_values), 'sparse_sensor_ids': '、'.join(status.sparse_sensor_ids), 'sparse_zbb_values': '、'.join(status.sparse_zbb_values), 'fused_estimate_count': status.fused_estimate_count, 'source_files': '；'.join(status.source_files), 'member_local_track_keys': '、'.join(status.member_local_track_keys), 'member_local_target_ids': '、'.join(status.member_local_target_ids), 'minimum_cross_sensor_distance_m': diagnostic.get('minimum_cross_sensor_distance_m'), 'minimum_cross_sensor_mahalanobis_sq': diagnostic.get('minimum_cross_sensor_mahalanobis_sq'), 'birth_gate_mahalanobis_sq_threshold': diagnostic.get('birth_gate_mahalanobis_sq_threshold'), 'closest_zbb_pair': '、'.join(diagnostic.get('closest_zbb_pair', [])), 'reason': status.reason})
    return records

def gate_conflict_report_records(result: ExperimentResult) -> list[Dict[str, object]]:
    return [record for record in target_status_report_records(result) if record['classification'] == 'cross_sensor_over_gate']

def create_fusion_summary(result: ExperimentResult, metrics: Mapping[str, object], output_directory: str | Path) -> tuple[Path, Path]:
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    input_metrics = metrics['input']
    fusion_metrics = metrics['fusion']
    identity_metrics = metrics.get('global_identity', {})
    files = input_metrics.get('files', [])
    statuses = list(sorted(result.target_statuses.values(), key=lambda item: item.target_id))
    status_counts: Dict[str, int] = dict(fusion_metrics.get('target_status_counts', {}))
    file_rows = [(item.get('source_file'), item.get('read_rows'), item.get('valid_rows'), item.get('time_filtered_rows'), item.get('rejected_rows'), item.get('target_values'), item.get('zbb_values')) for item in files]
    source_rows = [(item.target_id, item.zbb, item.sensor_id, item.input_rows, item.output_reports, f'{item.estimated_frequency_hz:.3f}', f'{item.median_interval_s:.3f}', item.source_track_id) for item in sorted(result.source_tracks.summaries, key=lambda value: (value.target_id, value.zbb))]
    sparse_rows = [(item.target_id, item.local_target_id, item.zbb, item.sensor_id, item.input_rows, item.unique_timestamp_count, item.minimum_required_points, '未成轨虚警候选', item.reason) for item in sorted(result.source_tracks.sparse_groups, key=lambda value: (value.target_id, value.zbb))]
    conflict_statuses = [item for item in statuses if item.classification == 'cross_sensor_over_gate']
    conflict_rows = [(item.target_id, item.valid_zbb_values, item.diagnostic.get('closest_zbb_pair', []), item.diagnostic.get('minimum_cross_sensor_distance_m'), item.diagnostic.get('minimum_cross_sensor_mahalanobis_sq'), item.diagnostic.get('birth_gate_mahalanobis_sq_threshold'), item.source_files, item.reason) for item in conflict_statuses]
    track_rows = [(item.get('track_id'), item.get('target_id'), item.get('estimate_count'), item.get('output_availability'), item.get('mean_existence_probability'), item.get('associated_report_count_by_sensor')) for item in fusion_metrics.get('tracks', [])]
    membership_rows = [(item.global_target_id, item.fusion_track_id, item.zbb, item.local_target_id, item.local_track_key, item.report_count, item.association_mode, item.supporting_local_track_keys) for item in sorted(result.global_track_memberships, key=lambda value: (value.global_target_id, value.zbb, value.local_target_id))]
    incompatible_pairs = [item for item in result.identity_pair_diagnostics if not item.compatible]
    identity_conflict_rows = [(item.left_zbb, item.left_local_target_id, item.left_local_track_key, item.right_zbb, item.right_local_target_id, item.right_local_track_key, item.temporal_pair_count, item.compatible_pair_count, item.compatible_time_bin_count, item.minimum_position_distance_m, item.median_position_mahalanobis_sq, item.position_gate_threshold, item.median_velocity_mahalanobis_sq, item.velocity_gate_threshold, item.reason) for item in incompatible_pairs[:MAX_IDENTITY_PAIR_ROWS_IN_SUMMARY]]
    omitted_identity_conflicts = max(0, len(incompatible_pairs) - MAX_IDENTITY_PAIR_ROWS_IN_SUMMARY)
    headline = f"输入 {input_metrics['file_count']} 个文件、区间内 {input_metrics['valid_rows']} 条有效数据；分析 {input_metrics['target_count']} 个目标和 {input_metrics['device_count']} 种装备；输出 {len(fusion_metrics['track_ids'])} 条融合/直通航迹、{fusion_metrics['estimate_count']} 个航迹状态。"
    ew_markdown = ''
    ew_html = ''
    if result.ew_read is not None:
        ew_metrics = metrics.get('ew', {})
        joint_metrics = metrics.get('joint_fusion', {})
        measurement_by_id = {item.measurement_id: item for item in result.ew_measurements}
        association_rows = [(item.measurement_id, item.ew_target_id, item.zbb, item.status, item.matched_target_id, item.association_probability, item.nis, item.nis_gate_ratio, item.azimuth_residual_deg, item.elevation_residual_deg, item.range_residual_m, item.altitude_residual_m, measurement_by_id[item.measurement_id].kind if item.measurement_id in measurement_by_id else None, item.local_track_history_match, item.source_file, item.source_excel_row, item.reason) for item in result.ew_associations[:MAX_EW_ASSOCIATION_ROWS_IN_SUMMARY]]
        omitted_associations = max(0, len(result.ew_associations) - MAX_EW_ASSOCIATION_ROWS_IN_SUMMARY)
        frequency_rows = [(item.get('zbb'), item.get('row_count'), item.get('unique_timestamp_count'), item.get('median_interval_s'), item.get('estimated_frequency_hz')) for item in ew_metrics.get('device_frequency', [])]
        kind_rows = [(item.get('measurement_kind'), item.get('report_count'), item.get('associated_count'), item.get('association_rate')) for item in joint_metrics.get('association_by_measurement_kind', [])]
        device_association_rows = [(item.get('zbb'), item.get('report_count'), item.get('associated_count'), item.get('association_rate'), item.get('history_prior_associated_count')) for item in joint_metrics.get('association_by_ew_device', [])]
        identity_rows = [(item.get('ew_target_id'), item.get('ew_zbb'), item.get('matched_sw_target_id'), item.get('sw_source_zbb_values'), item.get('matched_joint_track_id'), item.get('local_track_history_match'), item.get('association_count'), item.get('mean_association_probability'), item.get('median_abs_azimuth_residual_deg'), item.get('association_basis')) for item in joint_metrics.get('cross_device_identity_links', [])]
        probability = joint_metrics.get('association_probability_summary', {})
        azimuth_quality = joint_metrics.get('absolute_azimuth_residual_deg_summary', {})
        elevation_quality = joint_metrics.get('absolute_elevation_residual_deg_summary', {})
        range_quality = joint_metrics.get('absolute_range_residual_m_summary', {})
        altitude_quality = joint_metrics.get('absolute_altitude_residual_m_summary', {})
        gate_quality = joint_metrics.get('nis_gate_ratio_summary', {})
        quality_rows = [('关联概率', probability.get('count'), probability.get('mean'), probability.get('median'), probability.get('p95'), probability.get('maximum')), ('|方位残差|/°', azimuth_quality.get('count'), azimuth_quality.get('mean'), azimuth_quality.get('median'), azimuth_quality.get('p95'), azimuth_quality.get('maximum')), ('|俯仰残差|/°', elevation_quality.get('count'), elevation_quality.get('mean'), elevation_quality.get('median'), elevation_quality.get('p95'), elevation_quality.get('maximum')), ('|斜距残差|/m', range_quality.get('count'), range_quality.get('mean'), range_quality.get('median'), range_quality.get('p95'), range_quality.get('maximum')), ('|海拔残差|/m', altitude_quality.get('count'), altitude_quality.get('mean'), altitude_quality.get('median'), altitude_quality.get('p95'), altitude_quality.get('maximum')), ('NIS/门限', gate_quality.get('count'), gate_quality.get('mean'), gate_quality.get('median'), gate_quality.get('p95'), gate_quality.get('maximum'))]
        ew_headline = f"EW 输入 {ew_metrics.get('file_count', 0)} 个文件、有效 {ew_metrics.get('valid_rows', 0)} 行；成功关联 {joint_metrics.get('associated_count', 0)} 条，关联率 {_text(joint_metrics.get('association_rate', 0.0))}；其中使用同一EW装备内局部航迹历史先验 {joint_metrics.get('history_prior_associated_count', 0)} 条；联合输出 {joint_metrics.get('track_count', 0)} 条航迹。"
        headline += ew_headline
        ew_markdown = f"\n\n## 九、EW 输入与 SW+EW 联合融合\n\n{ew_headline}\n\nEW 保留原始量测时刻，系统把 SW 主航迹预测到该 EW 时刻，再按“正北0°、顺时针方位、水平0°且向上为正的俯仰”计算理论角度。斜距为0按未提供处理，不伪造空间点；Hb有效时作为目标海拔量测参与门控、NIS和联合滤波，缺失时自动退化为现有角度/可选斜距融合。EW 与 SW 的装备编号不用于相等匹配：EW装备编号用于查找固定量测原点，SW装备编号用于追溯三维航迹来源。MBY只在同一装备内部有效，首次归属仅由异步几何一致性确定；成功后才把同一(EW装备,局部MBY)到RF的历史作为软先验。\n\n{_markdown_table(['EW装备', '有效行', '唯一时戳', '中位间隔s', '估计频率Hz'], frequency_rows)}\n\n### 8.1 直观融合质量\n\n{_markdown_table(['指标', '样本数', '平均', '中位数', 'P95', '最大'], quality_rows)}\n\n其中 `NIS/门限 < 1` 表示关联量测位于统计门内，越小代表与 SW 预测航迹越一致；角度、斜距和海拔残差越接近0越好。关联概率用于表达多条候选航迹之间的相对归属可信度。\n\n{_markdown_table(['量测类型', '报告数', '关联数', '关联率'], kind_rows)}\n\n{_markdown_table(['EW装备', '报告数', '关联数', '关联率', '使用局部航迹历史先验'], device_association_rows)}\n\n### 8.2 EW—SW 跨编号身份关联证据链\n\n{_markdown_table(['EW局部MBY', 'EW装备', '关联全局目标', 'SW来源装备', '联合航迹', '命中历史RF', '关联数', '平均概率', '方位残差中位数°', '判定依据'], identity_rows)}\n\n### 8.3 逐条关联审计（最多显示{MAX_EW_ASSOCIATION_ROWS_IN_SUMMARY}条）\n\n{_markdown_table(['EW量测', 'EW局部MBY', '装备', '状态', '关联全局目标', '关联概率', 'NIS', 'NIS/门限', '方位残差°', '俯仰残差°', '斜距残差m', '海拔残差m', '量测类型', '命中历史RF', '来源文件', 'Excel行', '说明'], association_rows)}\n\n本节另有 {omitted_associations} 条未在总结中展开；完整逐条结果见 `ew_association_report.csv`。\n"
        ew_html = f"""\n<h2>EW 输入与 SW+EW 联合融合</h2><p class="lead">{escape(ew_headline)}</p>\n<p class="note">EW 保留原始时刻，SW 主航迹预测到 EW 时刻后进行角度/可选距离门控。斜距0视为未提供；Hb有效时作为目标海拔量测参与门控、NIS和联合滤波，缺失时自动退化。MBY只在同一装备内部有效，首次归属只依靠异步几何一致性；成功后才使用同一EW装备内局部航迹到RF的历史软先验。</p>\n{_html_table(['EW装备', '有效行', '唯一时戳', '中位间隔s', '估计频率Hz'], frequency_rows)}\n<h3>直观融合质量</h3>\n{_html_table(['指标', '样本数', '平均', '中位数', 'P95', '最大'], quality_rows)}\n<p class="note">NIS/门限小于1表示量测位于统计门内；角度、斜距和海拔残差越接近0越好。关联概率反映多候选航迹间的相对归属可信度。</p>\n{_html_table(['量测类型', '报告数', '关联数', '关联率'], kind_rows)}\n{_html_table(['EW装备', '报告数', '关联数', '关联率', '使用局部航迹历史先验'], device_association_rows)}\n<h3>EW—SW 跨编号身份关联证据链</h3>\n{_html_table(['EW局部MBY', 'EW装备', '关联全局目标', 'SW来源装备', '联合航迹', '命中历史RF', '关联数', '平均概率', '方位残差中位数°', '判定依据'], identity_rows)}\n<h3>逐条关联审计（最多显示{MAX_EW_ASSOCIATION_ROWS_IN_SUMMARY}条）</h3>\n{_html_table(['EW量测', 'EW局部MBY', '装备', '状态', '关联全局目标', '关联概率', 'NIS', 'NIS/门限', '方位残差°', '俯仰残差°', '斜距残差m', '海拔残差m', '量测类型', '命中历史RF', '来源文件', 'Excel行', '说明'], association_rows)}\n<p class="note">另有 {omitted_associations} 条未在总结中展开；完整结果见 ew_association_report.csv。</p>\n"""
    status_summary = '；'.join((f'{STATUS_DESCRIPTIONS.get(code, code)} 数量={count}' for (code, count) in sorted(status_counts.items()))) or '无目标状态'
    markdown = f"# RealFusion 融合总结\n\n## 一、运行结论\n\n{headline}\n\n{status_summary}\n\n本报告中的“过远”不是按固定米数猜测，而是按本次配置的出生时间窗、量测协方差和三维马氏门控计算；门外目标不强行融合，也不会中断其他目标。\n\n## 二、文件概览\n\n{_markdown_table(['文件', '原始行', '区间内有效行', '区间外行', '拒绝行', '目标编号', '装备编号'], file_rows)}\n\n## 三、全局目标身份解析\n\nMBY 只在同一装备内部表示局部批号。系统先按 `(装备编号, MBY)` 构建局部源航迹，再依据时间重叠、位置/速度马氏门和多时间片连续性生成 `GT-xxxx`；MBY 文本相等或不等都不参与跨装备身份评分。本次共有 {identity_metrics.get('local_track_membership_count', 0)} 条局部航迹，解析为 {identity_metrics.get('global_target_count', 0)} 个全局目标；兼容局部航迹对 {identity_metrics.get('compatible_pair_count', 0)} 对，不兼容 {identity_metrics.get('incompatible_pair_count', 0)} 对。完整两两诊断见 `identity_pair_diagnostics.csv`。\n\n{_markdown_table(['全局目标', '融合航迹', '装备', '局部MBY', '局部航迹键', '报告数', '归属方式', '支持局部航迹'], membership_rows)}\n\n### 3.1 已成局部航迹但不支持同一全局目标的证据\n\n{_markdown_table(['左装备', '左局部MBY', '左局部航迹', '右装备', '右局部MBY', '右局部航迹', '时间邻近对', '门内对', '门内时间片', '最近距离m', '位置NIS中位数', '位置门限', '速度NIS中位数', '速度门限', '说明'], identity_conflict_rows)}\n\n本节另有 {omitted_identity_conflicts} 对未展开；完整结果见 `identity_pair_diagnostics.csv`。这些局部航迹各自可以成轨，但证据不足时会保持为不同GT，不能把它们表述成“同一目标融合失败”的既定事实。\n\n## 四、逐全局目标处理结果\n\n{_markdown_table(['全局/局部目标', '状态', '融合航迹', '成员局部MBY', '成员局部航迹键', '输入点', '已成轨装备', '未成轨装备', '融合点', '来源文件', '说明'], _status_rows(result))}\n\n## 五、装备内局部源航迹与探测频率\n\n{_markdown_table(['局部MBY', '装备编号', '内部设备ID', '输入点', '源航迹点', '频率Hz', '时戳中位间隔s', '源航迹ID'], source_rows)}\n\n## 六、融合指标\n\n- 融合/直通航迹数量：{len(fusion_metrics['track_ids'])}\n- 融合状态点数量：{fusion_metrics['estimate_count']}\n- 平均输出可用率：{_text(fusion_metrics['output_availability'])}\n- 平均存在概率：{_text(fusion_metrics['mean_existence_probability'])}\n- 晚到丢弃数量：{fusion_metrics['late_drop_count']}\n\n{_markdown_table(['航迹ID', '目标', '状态点', '输出可用率', '平均存在概率', '关联装备计数'], track_rows)}\n\n## 七、未成轨点迹与虚警\n\n{_markdown_table(['显示ID', '局部MBY', '装备编号', '内部设备ID', '输入点', '唯一时戳', '成轨阈值', '判定', '说明'], sparse_rows)}\n\n## 八、已成轨但超过融合门控\n\n{_markdown_table(['目标', '已成轨装备', '最近装备对', '最近距离m', '最小马氏距离²', '门限²', '来源文件', '说明'], conflict_rows)}\n{ew_markdown}\n"
    status_classes = ['warn' if item.classification == 'cross_sensor_over_gate' else 'danger' if item.classification == 'unformed_false_alarm' else 'ok' if item.classification in {'multi_source_fused', 'single_source_passthrough'} else 'neutral' for item in statuses]
    html = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>RealFusion 融合总结</title><style>\nbody{{font-family:"Noto Sans CJK SC","Microsoft YaHei UI","Microsoft YaHei",sans-serif;font-weight:400;margin:0;background:#f6f8fb;color:#172033}}\nmain{{max-width:1480px;margin:auto;padding:24px}}h1{{margin:0 0 8px}}h2{{margin-top:28px;border-left:5px solid #2563eb;padding-left:10px}}\n.lead,.note{{background:white;border:1px solid #dce3ed;border-radius:10px;padding:14px 16px;line-height:1.7}}\n.note{{border-left:5px solid #f59e0b}}.table-wrap{{overflow:auto;background:white;border:1px solid #dce3ed;border-radius:9px}}\ntable{{border-collapse:collapse;min-width:100%;font-size:13px}}th,td{{padding:9px 10px;border-bottom:1px solid #e7ebf1;text-align:left;vertical-align:top;white-space:nowrap}}\nth{{position:sticky;top:0;background:#edf3fb}}tr.ok td:first-child{{border-left:5px solid #16a34a}}tr.warn{{background:#fff7df}}tr.warn td:first-child{{border-left:5px solid #f59e0b}}\ntr.danger{{background:#fff0f0}}tr.danger td:first-child{{border-left:5px solid #dc2626}}tr.neutral td:first-child{{border-left:5px solid #64748b}}\n.muted{{color:#64748b;text-align:center}}code{{background:#edf0f5;padding:2px 5px;border-radius:4px}}\n</style></head><body><main><h1>RealFusion 融合总结</h1><p class="lead">{escape(headline)}</p>\n<p class="note">“过远”按本次出生时间窗、量测协方差和三维马氏门控判定；门外目标保留源航迹，不强行融合，也不阻断整批运行。</p>\n<h2>文件概览</h2>{_html_table(['文件', '原始行', '区间内有效行', '区间外行', '拒绝行', '目标编号', '装备编号'], file_rows)}\n<h2>全局目标身份解析</h2><p class="note">MBY只在同一装备内部表示局部批号。系统依据时间、位置、速度和多时间片连续性，把装备内局部航迹解析为GT；MBY文本不参与跨装备评分。本次局部航迹={identity_metrics.get('local_track_membership_count', 0)}，全局目标={identity_metrics.get('global_target_count', 0)}，兼容对={identity_metrics.get('compatible_pair_count', 0)}，不兼容对={identity_metrics.get('incompatible_pair_count', 0)}。</p>\n{_html_table(['全局目标', '融合航迹', '装备', '局部MBY', '局部航迹键', '报告数', '归属方式', '支持局部航迹'], membership_rows)}\n<h3>已成局部航迹但不支持同一全局目标的证据</h3>\n{_html_table(['左装备', '左局部MBY', '左局部航迹', '右装备', '右局部MBY', '右局部航迹', '时间邻近对', '门内对', '门内时间片', '最近距离m', '位置NIS中位数', '位置门限', '速度NIS中位数', '速度门限', '说明'], identity_conflict_rows)}\n<p class="note">另有 {omitted_identity_conflicts} 对未展开；完整结果见 identity_pair_diagnostics.csv。证据不足的局部航迹保持为不同GT。</p>\n<h2>逐全局目标处理结果</h2>{_html_table(['全局/局部目标', '状态', '融合航迹', '成员局部MBY', '成员局部航迹键', '输入点', '已成轨装备', '未成轨装备', '融合点', '来源文件', '说明'], _status_rows(result), status_classes)}\n<h2>装备内局部源航迹与探测频率</h2>{_html_table(['局部MBY', '装备编号', '内部设备ID', '输入点', '源航迹点', '频率Hz', '时戳中位间隔s', '源航迹ID'], source_rows)}\n<h2>融合指标</h2><p class="lead">航迹数={len(fusion_metrics['track_ids'])}；状态点={fusion_metrics['estimate_count']}；平均输出可用率={escape(_text(fusion_metrics['output_availability']))}；平均存在概率={escape(_text(fusion_metrics['mean_existence_probability']))}；晚到丢弃={fusion_metrics['late_drop_count']}。</p>\n{_html_table(['航迹ID', '目标', '状态点', '输出可用率', '平均存在概率', '关联装备计数'], track_rows)}\n<h2>未成轨点迹与虚警</h2>{_html_table(['显示ID', '局部MBY', '装备编号', '内部设备ID', '输入点', '唯一时戳', '成轨阈值', '判定', '说明'], sparse_rows)}\n<h2>已成轨但超过融合门控</h2>{_html_table(['目标', '已成轨装备', '最近装备对', '最近距离m', '最小马氏距离²', '门限²', '来源文件', '说明'], conflict_rows)}\n{ew_html}\n</main></body></html>"""
    markdown_path = output / 'fusion_summary.md'
    html_path = output / 'fusion_summary.html'
    markdown_path.write_text(markdown, encoding='utf-8')
    html_path.write_text(html, encoding='utf-8')
    return (markdown_path, html_path)
