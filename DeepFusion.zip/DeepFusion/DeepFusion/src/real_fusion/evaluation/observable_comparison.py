from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import platform
from pathlib import Path
import sys
from typing import Dict, Iterable, Mapping, Sequence
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from real_fusion.font_support import configure_matplotlib_fonts
from real_fusion.io.artifacts import write_csv, write_json
from real_fusion.pipeline import ExperimentResult
configure_matplotlib_fonts()
REPORT_SCHEMA_VERSION = 'deepfusion.observable-publication-report.v2'
BOOTSTRAP_SEED = 20260923
BOOTSTRAP_REPLICATES = 5000
MINIMUM_TARGETS_FOR_INTERVAL = 5
FIGURE_DPI = 360
BASELINE_COLOR = '#6B7280'
DEEPFUSION_COLOR = '#0072B2'
ACCENT_COLOR = '#D55E00'
POSITIVE_COLOR = '#009E73'
NEGATIVE_COLOR = '#CC79A7'
METRIC_DEFINITIONS = (('temporal_coverage', '时间覆盖率', 'higher', '比例'), ('interval_regularity', '更新间隔规则度', 'higher', '比例'), ('normalized_maximum_gap', '归一化最大断点', 'lower', '倍'), ('velocity_change_p95_mps2', '速度变化粗糙度P95', 'lower', 'm/s²'), ('reported_position_sigma_m', '模型报告位置标准差', 'descriptive', 'm'), ('state_count', '状态点数', 'descriptive', '点'))
plt.rcParams.update({'figure.facecolor': 'white', 'axes.facecolor': 'white', 'axes.edgecolor': '#374151', 'axes.labelcolor': '#111827', 'axes.titleweight': 'bold', 'axes.titlesize': 11, 'axes.labelsize': 9.5, 'xtick.labelsize': 8.5, 'ytick.labelsize': 8.5, 'legend.fontsize': 8, 'grid.color': '#D1D5DB', 'grid.alpha': 0.32, 'grid.linewidth': 0.7, 'lines.linewidth': 1.6, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})

def _finite(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if np.isfinite(number) else None

def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda : handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def _input_file_records(result: ExperimentResult) -> list[dict]:
    sw_paths = result.sw_read.source_paths or [result.sw_read.path]
    ew_paths = result.ew_read.source_paths if result.ew_read is not None else []
    records: list[dict] = []
    for (kind, paths) in (('SW', sw_paths), ('EW', ew_paths)):
        for value in paths:
            path = Path(value).resolve()
            records.append({'stream': kind, 'path': str(path), 'size_bytes': path.stat().st_size if path.is_file() else None, 'sha256': _sha256_file(path) if path.is_file() else None})
    return records

def _style_axis(axis, *, grid_axis: str='y') -> None:
    axis.grid(axis=grid_axis)
    axis.spines[['top', 'right']].set_visible(False)

def _empty_axis(axis, message: str) -> None:
    axis.set_axis_off()
    axis.text(0.5, 0.5, message, transform=axis.transAxes, ha='center', va='center', color='#4B5563', fontsize=10, bbox={'boxstyle': 'round,pad=.55', 'facecolor': '#F9FAFB', 'edgecolor': '#D1D5DB'})

def _paired_values(rows: Sequence[Mapping[str, object]], metric: str) -> tuple[np.ndarray, np.ndarray]:
    baseline: list[float] = []
    optimized: list[float] = []
    for row in rows:
        left = _finite(row['baseline'][metric])
        right = _finite(row['deepfusion'][metric])
        if left is not None and right is not None:
            baseline.append(left)
            optimized.append(right)
    return (np.asarray(baseline, dtype=float), np.asarray(optimized, dtype=float))

def _favourable_change(baseline: np.ndarray, optimized: np.ndarray, direction: str) -> np.ndarray:
    if direction == 'higher':
        return optimized - baseline
    if direction == 'lower':
        return baseline - optimized
    return optimized - baseline

def _descriptive_bootstrap(rows: Sequence[Mapping[str, object]], metric: str, direction: str) -> dict:
    (baseline, optimized) = _paired_values(rows, metric)
    changes = _favourable_change(baseline, optimized, direction)
    record = {'metric_key': metric, 'direction': direction, 'paired_target_count': int(changes.size), 'favourable_change_definition': 'deepfusion_minus_baseline' if direction == 'higher' else 'baseline_minus_deepfusion', 'median_favourable_change': float(np.median(changes)) if changes.size else None, 'mean_favourable_change': float(np.mean(changes)) if changes.size else None, 'confidence_level': 0.95, 'bootstrap_replicates': BOOTSTRAP_REPLICATES, 'bootstrap_seed': BOOTSTRAP_SEED, 'ci_lower': None, 'ci_upper': None, 'interval_status': 'blocked_insufficient_targets', 'inference_scope': 'within_run_target_descriptive_only'}
    if changes.size < MINIMUM_TARGETS_FOR_INTERVAL:
        return record
    metric_offset = sum(((index + 1) * ord(char) for (index, char) in enumerate(metric)))
    generator = np.random.default_rng(BOOTSTRAP_SEED + metric_offset)
    estimates = np.empty(BOOTSTRAP_REPLICATES, dtype=float)
    for index in range(BOOTSTRAP_REPLICATES):
        sampled = generator.integers(0, changes.size, size=changes.size)
        estimates[index] = float(np.median(changes[sampled]))
    (lower, upper) = np.quantile(estimates, [0.025, 0.975])
    record.update({'ci_lower': float(lower), 'ci_upper': float(upper), 'interval_status': 'available_descriptive_not_scenario_inference'})
    return record

def _series_metrics(times: Sequence[float], states: Sequence[np.ndarray], covariances: Sequence[np.ndarray], union_start: float, union_stop: float) -> Dict[str, float]:
    order = np.argsort(np.asarray(times, dtype=float), kind='stable')
    ordered_times = np.asarray(times, dtype=float)[order]
    ordered_states = np.asarray([states[index] for index in order], dtype=float)
    ordered_covariances = [np.asarray(covariances[index], dtype=float) for index in order]
    keep = np.r_[np.diff(ordered_times) > 1e-09, True]
    ordered_times = ordered_times[keep]
    ordered_states = ordered_states[keep]
    ordered_covariances = [value for (value, selected) in zip(ordered_covariances, keep) if selected]
    intervals = np.diff(ordered_times)
    intervals = intervals[np.isfinite(intervals) & (intervals > 1e-09)]
    duration = float(max(0.0, ordered_times[-1] - ordered_times[0]))
    union_duration = max(0.0, float(union_stop - union_start))
    coverage = 1.0 if union_duration <= 1e-09 else min(1.0, duration / union_duration)
    if len(intervals):
        median_interval = float(np.median(intervals))
        p95_interval = float(np.percentile(intervals, 95))
        max_gap = float(np.max(intervals))
        regularity = float(np.clip(median_interval / max(p95_interval, 1e-09), 0.0, 1.0))
        normalized_max_gap = float(max_gap / max(median_interval, 1e-09))
    else:
        median_interval = 0.0
        max_gap = 0.0
        regularity = 1.0 if len(ordered_times) == 1 else 0.0
        normalized_max_gap = 1.0 if len(ordered_times) == 1 else 0.0
    acceleration = []
    if len(ordered_states) >= 2 and ordered_states.shape[1] >= 6:
        for (index, delta_t) in enumerate(np.diff(ordered_times), start=1):
            if delta_t > 1e-09:
                acceleration.append(float(np.linalg.norm(ordered_states[index, 3:6] - ordered_states[index - 1, 3:6]) / delta_t))
    roughness = float(np.percentile(acceleration, 95)) if acceleration else 0.0
    position_sigmas = []
    for covariance in ordered_covariances:
        if covariance.ndim == 2 and covariance.shape[0] >= 3 and (covariance.shape[1] >= 3):
            variance = float(np.trace(covariance[:3, :3]) / 3.0)
            if np.isfinite(variance) and variance >= 0.0:
                position_sigmas.append(float(np.sqrt(variance)))
    return {'state_count': float(len(ordered_times)), 'duration_s': duration, 'temporal_coverage': coverage, 'median_interval_s': median_interval, 'interval_regularity': regularity, 'maximum_gap_s': max_gap, 'normalized_maximum_gap': normalized_max_gap, 'velocity_change_p95_mps2': roughness, 'reported_position_sigma_m': float(np.median(position_sigmas)) if position_sigmas else float('nan')}

def _best_source_series(result: ExperimentResult) -> Dict[str, tuple[list, list, list]]:
    grouped: dict[tuple[str, str], list] = defaultdict(list)
    for item in result.normalized_detections:
        grouped[str(item.target_id), str(item.source_track_id)].append(item)
    candidates: dict[str, list[tuple[str, list]]] = defaultdict(list)
    for ((target_id, source_track_id), items) in grouped.items():
        candidates[target_id].append((source_track_id, items))
    selected: Dict[str, tuple[list, list, list]] = {}
    for (target_id, options) in candidates.items():
        (_, items) = max(options, key=lambda option: (max((item.corrected_time_s for item in option[1])) - min((item.corrected_time_s for item in option[1])), len(option[1]), option[0]))
        selected[target_id] = ([float(item.corrected_time_s) for item in items], [np.asarray(item.state_enu, dtype=float) for item in items], [np.asarray(item.covariance, dtype=float) for item in items])
    return selected

def _estimate_series(estimates: Iterable[object]) -> Dict[str, tuple[list, list, list]]:
    grouped: dict[str, list] = defaultdict(list)
    for item in estimates:
        grouped[str(item.target_id)].append(item)
    return {target_id: ([float(item.event_time_s) for item in items], [np.asarray(item.state_enu, dtype=float) for item in items], [np.asarray(item.covariance, dtype=float) for item in items]) for (target_id, items) in grouped.items()}

def _paired_metrics(result: ExperimentResult) -> tuple[str, str, list[dict]]:
    if result.ew_read is not None:
        baseline_label = 'SW融合基线'
        deepfusion_label = 'DeepFusion SW/EW联合融合'
        baseline = _estimate_series(result.estimates)
        optimized = _estimate_series(result.joint_estimates)
    else:
        baseline_label = '最佳覆盖单源航迹基线'
        deepfusion_label = 'DeepFusion SW多源融合'
        baseline = _best_source_series(result)
        optimized = _estimate_series(result.estimates)
    rows = []
    for target_id in sorted(set(baseline) & set(optimized)):
        (baseline_times, baseline_states, baseline_covariances) = baseline[target_id]
        (optimized_times, optimized_states, optimized_covariances) = optimized[target_id]
        union_start = min(min(baseline_times), min(optimized_times))
        union_stop = max(max(baseline_times), max(optimized_times))
        baseline_metrics = _series_metrics(baseline_times, baseline_states, baseline_covariances, union_start, union_stop)
        optimized_metrics = _series_metrics(optimized_times, optimized_states, optimized_covariances, union_start, union_stop)
        rows.append({'target_id': target_id, 'baseline': baseline_metrics, 'deepfusion': optimized_metrics})
    return (baseline_label, deepfusion_label, rows)

def _aggregate(rows: Sequence[Mapping[str, object]], side: str, metric: str) -> float | None:
    values = []
    for row in rows:
        value = _finite(row[side][metric])
        if value is not None:
            values.append(value)
    return float(np.median(values)) if values else None

def _draw_paired_metric(axis, rows: Sequence[Mapping[str, object]], metric: str, title: str, unit: str, direction: str) -> None:
    (baseline, optimized) = _paired_values(rows, metric)
    if not baseline.size:
        _empty_axis(axis, f'{title}\n无可配对目标')
        return
    x_left = np.zeros(baseline.size)
    x_right = np.ones(optimized.size)
    for (left, right) in zip(baseline, optimized):
        colour = POSITIVE_COLOR if _favourable_change(np.asarray([left]), np.asarray([right]), direction)[0] >= 0 else NEGATIVE_COLOR
        axis.plot([0, 1], [left, right], color=colour, alpha=0.22, linewidth=0.8)
    axis.scatter(x_left, baseline, s=20, color=BASELINE_COLOR, marker='o', alpha=0.72, edgecolors='white', linewidths=0.35, zorder=3)
    axis.scatter(x_right, optimized, s=24, color=DEEPFUSION_COLOR, marker='D', alpha=0.78, edgecolors='white', linewidths=0.35, zorder=3)
    medians = [float(np.median(baseline)), float(np.median(optimized))]
    axis.plot([0, 1], medians, color='#111827', linewidth=2.2, zorder=4)
    axis.scatter([0, 1], medians, color='#111827', marker='_', s=240, linewidths=3, zorder=5)
    favourable = _favourable_change(baseline, optimized, direction)
    axis.text(0.5, 0.985, f'n={baseline.size}｜有利方向中位变化={np.median(favourable):+.3g}', transform=axis.transAxes, ha='center', va='top', fontsize=8, color='#374151')
    axis.set_xticks([0, 1], ['基线', 'DeepFusion'])
    axis.set_xlim(-0.35, 1.35)
    axis.set_title(title)
    axis.set_ylabel(unit)
    _style_axis(axis)

def _draw_change_distribution(axis, rows: Sequence[Mapping[str, object]], metric: str, title: str, unit: str, direction: str, interval: Mapping[str, object]) -> None:
    (baseline, optimized) = _paired_values(rows, metric)
    changes = _favourable_change(baseline, optimized, direction)
    if not changes.size:
        _empty_axis(axis, f'{title}\n无可配对目标')
        return
    if changes.size >= 10 and np.unique(np.round(changes, decimals=12)).size >= 4 and (not np.allclose(changes, changes[0])):
        violin = axis.violinplot(changes, positions=[0.0], widths=0.68, showmeans=False, showmedians=False, showextrema=False)
        for body in violin['bodies']:
            body.set_facecolor(DEEPFUSION_COLOR)
            body.set_edgecolor(DEEPFUSION_COLOR)
            body.set_alpha(0.16)
    jitter = np.linspace(-0.16, 0.16, changes.size) if changes.size > 1 else np.zeros(1)
    point_colours = [POSITIVE_COLOR if value >= 0 else NEGATIVE_COLOR for value in changes]
    axis.scatter(jitter, changes, s=23, c=point_colours, alpha=0.78, zorder=3)
    median = float(np.median(changes))
    axis.scatter([0.0], [median], marker='D', s=52, color='#111827', zorder=4, label='中位数')
    lower = _finite(interval.get('ci_lower'))
    upper = _finite(interval.get('ci_upper'))
    if lower is not None and upper is not None:
        axis.plot([0.0, 0.0], [lower, upper], color='#111827', linewidth=2.5, zorder=4)
        axis.scatter([0.0, 0.0], [lower, upper], marker='_', s=90, color='#111827', zorder=4)
        interval_text = f'目标级描述bootstrap 95%区间 [{lower:+.3g}, {upper:+.3g}]'
    else:
        interval_text = f'n={changes.size}<5，不计算区间'
    axis.axhline(0.0, color='#374151', linestyle='--', linewidth=1.0)
    axis.set_xticks([0.0], [f'n={changes.size}'])
    axis.set_xlim(-0.55, 0.55)
    axis.set_title(title)
    axis.set_ylabel(f'有利方向变化 / {unit}')
    axis.text(0.5, 0.985, interval_text, transform=axis.transAxes, ha='center', va='top', fontsize=7.5, color='#4B5563')
    _style_axis(axis)

def _ecdf(values: Sequence[float]) -> tuple[np.ndarray, np.ndarray]:
    array = np.sort(np.asarray([value for value in values if np.isfinite(value)], dtype=float))
    if not array.size:
        return (array, array)
    return (array, np.arange(1, array.size + 1, dtype=float) / array.size)

def _save_figure(figure, stem: Path) -> list[str]:
    outputs = []
    for (suffix, kwargs) in (('.png', {'dpi': FIGURE_DPI}), ('.svg', {}), ('.pdf', {})):
        path = stem.with_suffix(suffix)
        figure.savefig(path, bbox_inches='tight', facecolor='white', **kwargs)
        outputs.append(path.name)
    plt.close(figure)
    return outputs

def _plot_level_comparison(paired_rows: Sequence[Mapping[str, object]], baseline_label: str, deepfusion_label: str, output: Path) -> list[str]:
    (figure, axes) = plt.subplots(2, 2, figsize=(11.2, 8.2), constrained_layout=True)
    panels = (('temporal_coverage', 'A  时间覆盖', '比例', 'higher'), ('interval_regularity', 'B  更新规则度', '比例', 'higher'), ('normalized_maximum_gap', 'C  最大断点', '相对中位间隔 / 倍', 'lower'), ('state_count', 'D  输出状态点数（描述性）', '点', 'descriptive'))
    for (axis, (metric, title, unit, direction)) in zip(axes.ravel(), panels):
        _draw_paired_metric(axis, paired_rows, metric, title, unit, direction)
    figure.suptitle('本次真实输入的轨迹连续性：逐目标成对比较', fontsize=15, fontweight='bold')
    figure.text(0.5, -0.015, f'基线：{baseline_label}；比较方法：{deepfusion_label}。每条细线是一项共同目标，粗线连接两侧中位数；无独立真值，不代表定位精度。', ha='center', fontsize=8.5, color='#4B5563')
    return _save_figure(figure, output / '01_本次数据基线与融合连续性对比')

def _plot_internal_behaviour(result: ExperimentResult, paired_rows: Sequence[Mapping[str, object]], metrics: Mapping[str, object], output: Path) -> list[str]:
    (figure, axes) = plt.subplots(1, 3, figsize=(13.2, 4.45), constrained_layout=True)
    _draw_paired_metric(axes[0], paired_rows, 'velocity_change_p95_mps2', 'A  速度变化粗糙度P95', 'm/s²', 'lower')
    _draw_paired_metric(axes[1], paired_rows, 'reported_position_sigma_m', 'B  模型报告位置标准差', 'm（非真实误差）', 'descriptive')
    if result.ew_read is not None:
        probabilities = [float(item.association_probability) for item in result.ew_associations if item.status == 'associated' and np.isfinite(item.association_probability)]
        if probabilities:
            bins = np.linspace(0.0, 1.0, 11)
            axes[2].hist(probabilities, bins=bins, color='#7C3AED', alpha=0.78, edgecolor='white', linewidth=0.7)
            joint = metrics.get('joint_fusion', {})
            rate = _finite(joint.get('association_rate')) if isinstance(joint, Mapping) else None
            axes[2].text(0.03, 0.96, f"成功关联 n={len(probabilities)}\n全量关联率={('N/A' if rate is None else f'{rate:.1%}')}", transform=axes[2].transAxes, ha='left', va='top', fontsize=8, bbox={'boxstyle': 'round,pad=.35', 'facecolor': 'white', 'edgecolor': '#D1D5DB'})
            axes[2].set_xlim(0.0, 1.0)
            axes[2].set_xlabel('模型报告关联概率')
            axes[2].set_ylabel('EW量测数')
            axes[2].set_title('C  SW/EW关联概率分布（无真值）')
            _style_axis(axes[2])
        else:
            _empty_axis(axes[2], 'C  本次没有成功关联的EW量测')
    else:
        support = [len(status.valid_sensor_ids) for status in result.target_statuses.values() if status.valid_sensor_ids]
        if support:
            (unique, counts) = np.unique(support, return_counts=True)
            axes[2].bar(unique, counts, color='#7C3AED', width=0.65)
            axes[2].set_xticks(unique)
            axes[2].set_xlabel('每个全局目标的有效SW装备数')
            axes[2].set_ylabel('目标数')
            axes[2].set_title('C  多源支持度分布')
            _style_axis(axes[2])
        else:
            _empty_axis(axes[2], 'C  本次没有形成有效SW目标')
    figure.suptitle('本次真实输入的平滑性、不确定性与异构关联观测', fontsize=15, fontweight='bold')
    figure.text(0.5, -0.025, '粗糙度、模型协方差与关联概率是内部行为量；没有外部真值时不得改写为真实误差、Precision或Recall。', ha='center', fontsize=8.5, color='#4B5563')
    return _save_figure(figure, output / '02_本次数据平滑性与不确定性对比')

def _plot_change_intervals(paired_rows: Sequence[Mapping[str, object]], bootstrap_rows: Sequence[Mapping[str, object]], output: Path) -> list[str]:
    by_metric = {str(row['metric_key']): row for row in bootstrap_rows}
    (figure, axes) = plt.subplots(2, 2, figsize=(10.8, 8.0), constrained_layout=True)
    panels = (('temporal_coverage', 'A  时间覆盖率收益', '比例', 'higher'), ('interval_regularity', 'B  更新规则度收益', '比例', 'higher'), ('normalized_maximum_gap', 'C  最大断点下降', '倍', 'lower'), ('velocity_change_p95_mps2', 'D  速度粗糙度下降', 'm/s²', 'lower'))
    for (axis, (metric, title, unit, direction)) in zip(axes.ravel(), panels):
        _draw_change_distribution(axis, paired_rows, metric, title, unit, direction, by_metric[metric])
    figure.suptitle('逐目标有利方向变化及本次运行内描述区间', fontsize=15, fontweight='bold')
    figure.text(0.5, -0.02, '正值代表DeepFusion方向更优。区间按目标重采样、固定种子生成，只描述单次运行内目标差异；目标不是独立架次，不能据此宣称跨场景统计显著。', ha='center', fontsize=8.5, color='#4B5563')
    return _save_figure(figure, output / '03_逐目标收益分布与描述区间')

def _plot_diagnostics(result: ExperimentResult, output: Path) -> list[str]:
    (figure, axes) = plt.subplots(2, 2, figsize=(11.2, 8.0), constrained_layout=True)
    if result.ew_read is not None:
        statuses = [str(item.status) for item in result.ew_associations]
        if statuses:
            (labels, counts) = np.unique(statuses, return_counts=True)
            order = np.argsort(-counts)
            axes[0, 0].bar(np.arange(len(labels)), counts[order], color='#7C3AED')
            axes[0, 0].set_xticks(np.arange(len(labels)), labels[order], rotation=22, ha='right')
            axes[0, 0].set_ylabel('EW量测数')
            axes[0, 0].set_title('A  EW关联状态')
            _style_axis(axes[0, 0])
        else:
            _empty_axis(axes[0, 0], 'A  没有EW关联记录')
        probabilities = [float(item.association_probability) for item in result.ew_associations if np.isfinite(item.association_probability)]
        (x_values, y_values) = _ecdf(probabilities)
        if x_values.size:
            axes[0, 1].step(x_values, y_values, where='post', color='#7C3AED')
            axes[0, 1].set_xlim(0.0, 1.0)
            axes[0, 1].set_ylim(0.0, 1.02)
            axes[0, 1].set_xlabel('关联概率')
            axes[0, 1].set_ylabel('经验累积分布')
            axes[0, 1].set_title('B  关联概率ECDF')
            _style_axis(axes[0, 1], grid_axis='both')
        else:
            _empty_axis(axes[0, 1], 'B  无有效关联概率')
        gate_ratios = [float(item.nis_gate_ratio) for item in result.ew_associations if item.nis_gate_ratio is not None and np.isfinite(item.nis_gate_ratio)]
        (x_values, y_values) = _ecdf(gate_ratios)
        if x_values.size:
            axes[1, 0].step(x_values, y_values, where='post', color=ACCENT_COLOR)
            axes[1, 0].axvline(1.0, color='#B91C1C', linestyle='--', label='门限')
            axes[1, 0].set_xlabel('NIS / 门限')
            axes[1, 0].set_ylabel('经验累积分布')
            axes[1, 0].set_title('C  归一化门控统计量')
            axes[1, 0].legend(frameon=False)
            _style_axis(axes[1, 0], grid_axis='both')
        else:
            _empty_axis(axes[1, 0], 'C  无有效NIS/门限记录')
        residual_series = (('方位', [abs(float(item.azimuth_residual_deg)) for item in result.ew_associations if item.azimuth_residual_deg is not None and np.isfinite(item.azimuth_residual_deg)], DEEPFUSION_COLOR), ('俯仰', [abs(float(item.elevation_residual_deg)) for item in result.ew_associations if item.elevation_residual_deg is not None and np.isfinite(item.elevation_residual_deg)], ACCENT_COLOR))
        plotted = False
        for (label, values, colour) in residual_series:
            (x_values, y_values) = _ecdf(values)
            if x_values.size:
                axes[1, 1].step(x_values, y_values, where='post', label=label, color=colour)
                plotted = True
        if plotted:
            axes[1, 1].set_xlabel('绝对角度残差 / °')
            axes[1, 1].set_ylabel('经验累积分布')
            axes[1, 1].set_title('D  角度残差ECDF')
            axes[1, 1].legend(frameon=False)
            _style_axis(axes[1, 1], grid_axis='both')
        else:
            _empty_axis(axes[1, 1], 'D  无有效角度残差')
        title = 'SW/EW真实数据关联与门控诊断'
        note = '关联率和残差描述本次运行的内部一致性；没有人工身份真值时不等于关联准确率。'
    else:
        classification_labels = {'multi_source_fused': '多源融合', 'single_source_passthrough': '单源直通', 'cross_sensor_over_gate': '跨源过门限', 'source_time_not_overlapping': '时段不重叠', 'fusion_not_formed': '未形成融合航迹', 'unformed_false_alarm': '未成轨/虚警候选'}
        classifications = [classification_labels.get(status.classification, status.classification) for status in result.target_statuses.values()]
        if classifications:
            (labels, counts) = np.unique(classifications, return_counts=True)
            order = np.argsort(-counts)
            axes[0, 0].bar(np.arange(len(labels)), counts[order], color=DEEPFUSION_COLOR)
            axes[0, 0].set_xticks(np.arange(len(labels)), labels[order], rotation=22, ha='right')
            axes[0, 0].set_ylabel('目标数')
            axes[0, 0].set_title('A  目标成轨/融合状态')
            _style_axis(axes[0, 0])
        else:
            _empty_axis(axes[0, 0], 'A  没有目标状态')
        source_counts = [len(status.valid_sensor_ids) for status in result.target_statuses.values()]
        if source_counts:
            (labels, counts) = np.unique(source_counts, return_counts=True)
            axes[0, 1].bar(labels, counts, color='#7C3AED', width=0.65)
            axes[0, 1].set_xticks(labels)
            axes[0, 1].set_xlabel('有效装备数')
            axes[0, 1].set_ylabel('目标数')
            axes[0, 1].set_title('B  每目标多源支持度')
            _style_axis(axes[0, 1])
        else:
            _empty_axis(axes[0, 1], 'B  没有多源支持记录')
        compatible = np.asarray([item.compatible_fraction for item in result.identity_pair_diagnostics if np.isfinite(item.compatible_fraction)], dtype=float)
        if compatible.size:
            axes[1, 0].hist(compatible, bins=np.linspace(0.0, 1.0, 11), color=ACCENT_COLOR, alpha=0.78, edgecolor='white', linewidth=0.7)
            axes[1, 0].set_xlim(0.0, 1.0)
            axes[1, 0].set_xlabel('跨装备候选对兼容时间片比例')
            axes[1, 0].set_ylabel('候选局部航迹对数')
            axes[1, 0].set_title('C  身份候选运动学兼容度分布')
            _style_axis(axes[1, 0])
        else:
            _empty_axis(axes[1, 0], 'C  没有跨装备候选对')
        frequencies = [float(item.estimated_frequency_hz) for item in result.source_tracks.summaries if np.isfinite(item.estimated_frequency_hz)]
        (x_values, y_values) = _ecdf(frequencies)
        if x_values.size:
            centre = float(np.median(x_values))
            span = float(np.ptp(x_values))
            near_constant = span <= max(1e-06, abs(centre) * 0.01)
            if near_constant:
                padding = max(0.1, abs(centre) * 0.05)
                axes[1, 1].set_xlim(centre - padding, centre + padding)
                axes[1, 1].plot(np.full_like(y_values, centre), y_values, color=POSITIVE_COLOR, marker='o', markersize=3.5)
                ticks = [centre - padding, centre, centre + padding]
                axes[1, 1].set_xticks(ticks, [f'{value:.2f}' for value in ticks])
                axes[1, 1].text(0.03, 0.96, f'n={x_values.size}｜中位数={centre:.3f} Hz｜近恒定输入', transform=axes[1, 1].transAxes, ha='left', va='top', fontsize=8, color='#374151')
                axes[1, 1].set_title('D  输入更新频率（近恒定）')
            else:
                axes[1, 1].step(x_values, y_values, where='post', color=POSITIVE_COLOR)
                axes[1, 1].ticklabel_format(axis='x', style='plain', useOffset=False)
                axes[1, 1].set_title('D  输入更新频率ECDF')
            axes[1, 1].set_xlabel('源航迹实测频率 / Hz')
            axes[1, 1].set_ylabel('经验累积分布')
            _style_axis(axes[1, 1], grid_axis='both')
        else:
            _empty_axis(axes[1, 1], 'D  没有有效源航迹频率')
        title = 'SW真实数据的成轨、身份候选与采样质量诊断'
        note = '本图用于暴露数据覆盖和候选门问题；它不使用MBY文本跨装备充当身份真值。'
    figure.suptitle(title, fontsize=15, fontweight='bold')
    figure.text(0.5, -0.015, note, ha='center', fontsize=8.5, color='#4B5563')
    return _save_figure(figure, output / '04_数据质量与关联诊断')

def create_observable_comparison(result: ExperimentResult, metrics: Mapping[str, object], output_directory: str | Path) -> Dict[str, object]:
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    (baseline_label, deepfusion_label, paired_rows) = _paired_metrics(result)
    metric_rows: list[dict] = []
    aggregate: dict[str, dict[str, float | None]] = {}
    for (key, label, direction, unit) in METRIC_DEFINITIONS:
        baseline = _aggregate(paired_rows, 'baseline', key)
        optimized = _aggregate(paired_rows, 'deepfusion', key)
        change = None if baseline is None or optimized is None else optimized - baseline
        improvement = None
        if change is not None and abs(baseline) > 1e-12 and (direction in {'higher', 'lower'}):
            improvement = change / abs(baseline) * 100.0 if direction == 'higher' else -change / abs(baseline) * 100.0
        aggregate[key] = {'baseline': baseline, 'deepfusion': optimized}
        metric_rows.append({'metric_key': key, 'metric_label': label, 'direction': direction, 'unit': unit, 'baseline_label': baseline_label, 'baseline_value': baseline, 'deepfusion_label': deepfusion_label, 'deepfusion_value': optimized, 'deepfusion_minus_baseline': change, 'observable_improvement_percent': improvement, 'truth_boundary': '无独立真值；不得解释为定位精度或关联准确率提升'})
    write_csv(metric_rows, output / 'comparison_metrics.csv')
    per_target_records: list[dict] = []
    difference_records: list[dict] = []
    for row in paired_rows:
        for (side, label) in (('baseline', baseline_label), ('deepfusion', deepfusion_label)):
            per_target_records.append({'target_id': row['target_id'], 'method': side, 'method_label': label, **row[side]})
        for (key, label, direction, unit) in METRIC_DEFINITIONS:
            baseline = _finite(row['baseline'][key])
            optimized = _finite(row['deepfusion'][key])
            if baseline is None or optimized is None:
                continue
            difference_records.append({'target_id': row['target_id'], 'metric_key': key, 'metric_label': label, 'direction': direction, 'unit': unit, 'baseline_value': baseline, 'deepfusion_value': optimized, 'deepfusion_minus_baseline': optimized - baseline, 'favourable_direction_change': float(_favourable_change(np.asarray([baseline]), np.asarray([optimized]), direction)[0]), 'positive_means_better': direction in {'higher', 'lower'}})
    write_csv(per_target_records, output / 'per_target_observable_metrics.csv', fieldnames=['target_id', 'method', 'method_label', 'state_count', 'duration_s', 'temporal_coverage', 'median_interval_s', 'interval_regularity', 'maximum_gap_s', 'normalized_maximum_gap', 'velocity_change_p95_mps2', 'reported_position_sigma_m'])
    write_csv(difference_records, output / 'paired_target_differences.csv', fieldnames=['target_id', 'metric_key', 'metric_label', 'direction', 'unit', 'baseline_value', 'deepfusion_value', 'deepfusion_minus_baseline', 'favourable_direction_change', 'positive_means_better'])
    bootstrap_rows = [_descriptive_bootstrap(paired_rows, key, direction) for (key, _, direction, _) in METRIC_DEFINITIONS if direction in {'higher', 'lower'}]
    write_csv(bootstrap_rows, output / 'descriptive_bootstrap_intervals.csv')
    generated_figures: list[str] = []
    generated_figures.extend(_plot_level_comparison(paired_rows, baseline_label, deepfusion_label, output))
    generated_figures.extend(_plot_internal_behaviour(result, paired_rows, metrics, output))
    generated_figures.extend(_plot_change_intervals(paired_rows, bootstrap_rows, output))
    generated_figures.extend(_plot_diagnostics(result, output))
    input_files = _input_file_records(result)
    input_hash_binding = hashlib.sha256('\n'.join((f"{item['stream']}|{item['size_bytes']}|{item['sha256']}" for item in input_files)).encode('utf-8')).hexdigest()
    config_sha256 = hashlib.sha256(json.dumps(result.config, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode('utf-8')).hexdigest()
    summary: Dict[str, object] = {'schema_version': REPORT_SCHEMA_VERSION, 'generated_at_utc': datetime.now(timezone.utc).isoformat(), 'input_mode': 'sw_ew' if result.ew_read is not None else 'sw_only', 'input_files': input_files, 'input_hash_binding_sha256': input_hash_binding, 'config_sha256': config_sha256, 'baseline_label': baseline_label, 'deepfusion_label': deepfusion_label, 'comparison_definition': 'best_coverage_single_source_vs_sw_multisource_fusion' if result.ew_read is None else 'sw_fusion_vs_sw_ew_joint_fusion', 'paired_target_count': len(paired_rows), 'aggregate_medians': aggregate, 'descriptive_bootstrap': bootstrap_rows, 'reproducibility': {'random_seed': BOOTSTRAP_SEED, 'bootstrap_replicates': BOOTSTRAP_REPLICATES, 'minimum_paired_targets_for_interval': MINIMUM_TARGETS_FOR_INTERVAL, 'figure_png_dpi': FIGURE_DPI, 'figure_formats': ['png', 'svg', 'pdf'], 'generator_source_sha256': _sha256_file(Path(__file__).resolve()), 'python_version': platform.python_version(), 'python_executable': str(Path(sys.executable).resolve()), 'numpy_version': np.__version__, 'matplotlib_version': matplotlib.__version__}, 'generated_figures': generated_figures, 'figure_data_sources': {'01_本次数据基线与融合连续性对比': ['per_target_observable_metrics.csv', 'paired_target_differences.csv'], '02_本次数据平滑性与不确定性对比': ['per_target_observable_metrics.csv', '../ew_association_report.csv' if result.ew_read is not None else '../target_status_report.csv'], '03_逐目标收益分布与描述区间': ['paired_target_differences.csv', 'descriptive_bootstrap_intervals.csv'], '04_数据质量与关联诊断': ['../ew_association_report.csv' if result.ew_read is not None else '../target_status_report.csv', '../identity_pair_diagnostics.csv', '../device_frequency_summary.csv']}, 'evidence_level': 'observable_without_independent_ground_truth', 'can_claim_accuracy_improvement': False, 'can_claim_neural_method_improvement': False, 'required_for_accuracy_claims': {'identity_metrics': '冻结且不参与调参的same/different或完整目标分区真值', 'state_metrics': '时间对齐的独立位置/速度参考真值及其精度说明', 'statistical_inference': '按架次/场景划分的独立任务组，而不是把同一架次目标当独立重复'}, 'interpretation': '图表由本次选择的Excel数据重新计算，不是固定图片。它可以比较连续性、规则度、平滑性、模型报告不确定性和EW关联覆盖；没有独立真值时，不能据此宣称定位精度、关联Precision/Recall/F1或目标识别准确率提升。'}
    write_json(summary, output / 'comparison_summary.json')
    readme = f"# 本次数据的基线—DeepFusion科研图表\n\n- 输入模式：{('SW+EW' if result.ew_read is not None else '仅SW')}\n- 基线：{baseline_label}\n- 当前输出：{deepfusion_label}\n- 共同可配对目标数：{len(paired_rows)}\n- 输入哈希绑定：`{input_hash_binding}`\n- 图表会随每次输入数据重新计算，并非固定示意图。\n\n## 生成的图\n\n1. `01_本次数据基线与融合连续性对比`：每条线代表同一目标从基线到融合输出的变化，避免总体中位数掩盖退化目标。\n2. `02_本次数据平滑性与不确定性对比`：速度变化、模型报告协方差，以及EW关联概率或SW多源支持度。\n3. `03_逐目标收益分布与描述区间`：正值统一表示有利变化；至少5个目标时给出固定种子的目标级描述bootstrap区间。\n4. `04_数据质量与关联诊断`：SW模式展示成轨、候选兼容度和输入频率；SW+EW模式展示关联状态、NIS门控和角度残差。\n\n每张图同时提供 `PNG({FIGURE_DPI} dpi)`、`SVG` 和 `PDF`。PNG用于预览，论文排版优先使用SVG/PDF。\n\n## 科学边界\n\n本次输入未声明独立真值，因此这里只比较时间覆盖、间隔规则度、最大断点、\n速度变化粗糙度、模型报告协方差和（若有EW）异步关联覆盖。上述指标不能写成\n“真实定位精度提高”或“关联准确率提高”。要给出RMSE、Precision、Recall、F1、\nNLL/ECE等论文结论，必须另行提供不参与调参的真实目标身份和真实轨迹标注。\n\n本报告的目标级bootstrap只描述一次运行内部不同目标的变化范围。多个目标可能处于\n同一架次和同一环境，不能当成独立场景重复，不能据此写“统计显著”。\n\n## 基线含义\n\n{('- 仅SW：每个目标中时间覆盖最长的单源航迹，与SW多源融合结果成对比较。' if result.ew_read is None else '- SW+EW：SW融合结果，与加入EW异步量测后的联合融合结果成对比较。')}\n\n这不是“当前独立演进RealFusion目录”与“神经网络M8”的直接跑分。神经方法论文主结论\n仍需在同一S0候选域、同一真实身份真值、冻结模型与冻结划分上比较B0和M8。\n\n## 文件\n\n- `01_本次数据基线与融合连续性对比.png/.svg/.pdf`\n- `02_本次数据平滑性与不确定性对比.png/.svg/.pdf`\n- `03_逐目标收益分布与描述区间.png/.svg/.pdf`\n- `04_数据质量与关联诊断.png/.svg/.pdf`\n- `comparison_metrics.csv`\n- `per_target_observable_metrics.csv`\n- `paired_target_differences.csv`\n- `descriptive_bootstrap_intervals.csv`\n- `comparison_summary.json`\n"
    (output / 'README.md').write_text(readme, encoding='utf-8')
    return summary
