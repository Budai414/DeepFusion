from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence
import numpy as np
import pandas as pd
from real_fusion.sw.reader import SUPPORTED_EXTENSIONS, normalize_zbb, parse_time_range

@dataclass(frozen=True)
class EwReadResult:
    path: Path
    frame: pd.DataFrame
    total_rows: int
    valid_rows: int
    rejected_rows: int
    rejected_examples: List[Dict[str, object]]
    device_values: List[str] = field(default_factory=list)
    target_values: List[str] = field(default_factory=list)
    input_columns: List[str] = field(default_factory=list)
    expected_columns: List[str] = field(default_factory=list)
    source_paths: List[Path] = field(default_factory=list)
    file_summaries: List[Dict[str, object]] = field(default_factory=list)
    quality_valid_rows: int = 0
    time_filtered_rows: int = 0
    time_range_start: Optional[str] = None
    time_range_end: Optional[str] = None
    schema_missing_columns: List[str] = field(default_factory=list)
    schema_extra_columns: List[str] = field(default_factory=list)
    header_order_matches: bool = True

def _read_excel(path: Path, config: dict) -> pd.DataFrame:
    if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError(f'EW 输入只支持 .xls/.xlsx/.xlsm，实际为: {path.suffix}')
    engine = 'xlrd' if path.suffix.lower() == '.xls' else 'openpyxl'
    return pd.read_excel(path, sheet_name=config.get('sheet_name', 0), header=int(config.get('header_row', 1)) - 1, engine=engine, dtype=object)

def _normalize_headers(frame: pd.DataFrame, config: dict) -> pd.DataFrame:
    trim = bool(config.get('trim_header_whitespace', True))

    def clean(value: object) -> str:
        text = str(value)
        return text.strip() if trim else text
    result = frame.copy()
    result.columns = [clean(value) for value in result.columns]
    aliases = {clean(key): clean(value) for (key, value) in config.get('header_aliases', {}).items()}
    if aliases:
        result = result.rename(columns=aliases)
    duplicates = result.columns[result.columns.duplicated()].tolist()
    if duplicates:
        raise ValueError(f'EW 表头清理后出现重复列: {duplicates}')
    return result

def _schema(frame: pd.DataFrame, path: Path, config: dict) -> Dict[str, object]:
    actual = [str(value) for value in frame.columns]
    expected = [str(value) for value in config.get('expected_columns', [])]
    missing = [value for value in expected if value not in actual]
    extra = [value for value in actual if value not in expected]
    order_matches = actual == expected
    violation = bool(missing or (extra and (not bool(config.get('allow_extra_columns', False)))) or (bool(config.get('require_exact_header_order', False)) and (not order_matches)))
    if str(config.get('schema_validation', 'strict')).lower() == 'strict' and violation:
        raise ValueError(f"EW 文件不符合统一55列表头：期望55列，实际{len(actual)}列；缺少={missing or '无'}；多余={extra or '无'}。文件: {path}")
    return {'actual': actual, 'expected': expected, 'missing': missing, 'extra': extra, 'order': order_matches}

def read_ew_file(path: str | Path, ew_config: dict, start_time: object=None, end_time: object=None) -> EwReadResult:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f'EW 文件不存在: {source}')
    frame = _normalize_headers(_read_excel(source, ew_config), ew_config)
    schema = _schema(frame, source, ew_config)
    core = {str(key): str(value) for (key, value) in ew_config.get('_core_columns', {}).items()}
    missing_core = [role for role in ('MBY', 'ZBB', 'HB', 'JDSC', 'FW') if core.get(role) not in frame.columns]
    if missing_core:
        raise ValueError(f'EW 文件缺少核心语义列: {missing_core}')
    total = len(frame)
    working = frame.copy()
    working['_source_file'] = str(source)
    working['_excel_row'] = np.arange(total, dtype=int) + int(ew_config.get('header_row', 1)) + 1
    working['_mby'] = working[core['MBY']].map(normalize_zbb)
    working['_zbb'] = working[core['ZBB']].map(normalize_zbb)
    working['_jdsc'] = pd.to_datetime(working[core['JDSC']], errors='coerce')
    if getattr(working['_jdsc'].dt, 'tz', None) is not None:
        working['_jdsc'] = working['_jdsc'].dt.tz_localize(None)
    measurement = ew_config.get('measurement', {})
    working['_azimuth_raw'] = pd.to_numeric(working[core['FW']], errors='coerce')
    working['_elevation_raw'] = pd.to_numeric(working[core['FY']], errors='coerce')
    working['_azimuth_rate_raw'] = pd.to_numeric(working[core['FW_RATE']], errors='coerce')
    working['_elevation_rate_raw'] = pd.to_numeric(working[core['FY_RATE']], errors='coerce')
    working['_range_raw'] = pd.to_numeric(working[core['XJ']], errors='coerce')
    working['_azimuth_deg'] = working['_azimuth_raw'] * float(measurement.get('azimuth_scale_deg_per_unit', 0.01))
    working['_elevation_deg'] = working['_elevation_raw'] * float(measurement.get('elevation_scale_deg_per_unit', 0.01))
    working['_azimuth_rate_deg_s'] = working['_azimuth_rate_raw'] * float(measurement.get('azimuth_rate_scale_deg_s_per_unit', 0.01))
    working['_elevation_rate_deg_s'] = working['_elevation_rate_raw'] * float(measurement.get('elevation_rate_scale_deg_s_per_unit', 0.01))
    working['_range_m'] = working['_range_raw'] * float(measurement.get('range_scale_m_per_unit', 1.0))
    if bool(ew_config.get('range_zero_is_missing', True)):
        epsilon = float(ew_config.get('range_zero_epsilon_m', 1e-09))
        working.loc[working['_range_m'].abs() <= epsilon, '_range_m'] = np.nan
    working.loc[working['_range_m'] < 0.0, '_range_m'] = np.nan
    working['_hb'] = pd.to_numeric(working[core['HB']], errors='coerce')
    working.loc[~np.isfinite(working['_hb'].to_numpy(dtype=float)), '_hb'] = np.nan
    rcs_column = core.get('RCS')
    working['_rcs'] = pd.to_numeric(working[rcs_column], errors='coerce') if rcs_column in working.columns else np.nan
    azimuth = working['_azimuth_deg'].to_numpy(dtype=float)
    elevation = working['_elevation_deg'].to_numpy(dtype=float)
    azimuth_rate = working['_azimuth_rate_deg_s'].to_numpy(dtype=float)
    elevation_rate = working['_elevation_rate_deg_s'].to_numpy(dtype=float)
    azimuth_range = measurement.get('azimuth_range_deg', [0.0, 360.0])
    elevation_range = measurement.get('elevation_range_deg', [-90.0, 90.0])
    azimuth_rate_range = measurement.get('azimuth_rate_range_deg_s', [-20.0, 20.0])
    elevation_rate_range = measurement.get('elevation_rate_range_deg_s', [-20.0, 20.0])
    invalid_mby = working['_mby'].eq('').to_numpy(dtype=bool)
    invalid_zbb = working['_zbb'].eq('').to_numpy(dtype=bool)
    invalid_time = working['_jdsc'].isna().to_numpy(dtype=bool)
    invalid_azimuth = ~np.isfinite(azimuth) | (azimuth < float(azimuth_range[0])) | (azimuth > float(azimuth_range[1]))
    invalid_elevation = np.isfinite(elevation) & ((elevation < float(elevation_range[0])) | (elevation > float(elevation_range[1])))
    invalid_azimuth_rate = np.isfinite(azimuth_rate) & ((azimuth_rate < float(azimuth_rate_range[0])) | (azimuth_rate > float(azimuth_rate_range[1])))
    invalid_elevation_rate = np.isfinite(elevation_rate) & ((elevation_rate < float(elevation_rate_range[0])) | (elevation_rate > float(elevation_rate_range[1])))
    invalid = invalid_mby | invalid_zbb | invalid_time | invalid_azimuth | invalid_elevation | invalid_azimuth_rate | invalid_elevation_rate
    working['_azimuth_deg'] = np.mod(working['_azimuth_deg'], 360.0)
    working['_measurement_kind'] = np.where(working['_range_m'].notna() & working['_elevation_deg'].notna(), 'bearing_elevation_range', np.where(working['_elevation_deg'].notna(), 'bearing_elevation', 'bearing_only'))
    rejected_examples: List[Dict[str, object]] = []
    for position in np.flatnonzero(invalid)[:int(ew_config.get('max_rejected_examples', 20))]:
        row = working.iloc[int(position)]
        reasons = []
        if invalid_mby[position]:
            reasons.append('目标编号为空')
        if invalid_zbb[position]:
            reasons.append('装备编号为空')
        if invalid_time[position]:
            reasons.append('绝对时戳不能解析')
        if invalid_azimuth[position]:
            reasons.append('方位缺失或换算后超出[0,360]度')
        if invalid_elevation[position]:
            reasons.append('俯仰换算后超出[-90,90]度')
        if invalid_azimuth_rate[position]:
            reasons.append('方位角速度换算后超出[-20,20]度/秒')
        if invalid_elevation_rate[position]:
            reasons.append('俯仰角速度换算后超出[-20,20]度/秒')
        rejected_examples.append({'source_file': str(source), 'excel_row': int(row['_excel_row']), 'target_id': row['_mby'] or None, 'zbb': row['_zbb'] or None, 'reason': '；'.join(reasons)})
    valid = working.loc[~invalid].copy()
    quality_valid_rows = len(valid)
    timezone_name = str(ew_config.get('timezone', 'Asia/Shanghai'))
    (range_start, range_end) = parse_time_range(start_time, end_time, timezone_name)
    mask = np.ones(len(valid), dtype=bool)
    if range_start is not None:
        mask &= valid['_jdsc'].ge(range_start).to_numpy(dtype=bool)
    if range_end is not None:
        mask &= valid['_jdsc'].le(range_end).to_numpy(dtype=bool)
    valid = valid.loc[mask].copy()
    if not valid.empty:
        valid['_epoch_s'] = valid['_jdsc'].dt.tz_localize(timezone_name).astype('int64') / 1000000000.0
        valid = valid.sort_values(['_jdsc', '_mby', '_zbb', '_excel_row'], kind='stable').reset_index(drop=True)
    else:
        valid['_epoch_s'] = pd.Series(dtype=float)
    targets = list(dict.fromkeys(valid['_mby'].tolist()))
    devices = list(dict.fromkeys(valid['_zbb'].tolist()))
    rejected_rows = int(invalid.sum())
    if rejected_rows and str(ew_config.get('invalid_row_policy', 'drop')).lower() == 'error':
        raise ValueError(f'EW 文件存在 {rejected_rows} 条非法关键行，示例: {rejected_examples}')
    summary = {'source_file': source.name, 'source_path': str(source), 'read_rows': total, 'valid_rows': len(valid), 'quality_valid_rows': quality_valid_rows, 'time_filtered_rows': quality_valid_rows - len(valid), 'rejected_rows': rejected_rows, 'target_count': len(targets), 'target_values': '、'.join(sorted(targets)), 'zbb_count': len(devices), 'zbb_values': '、'.join(sorted(devices)), 'bearing_only_rows': int((valid['_measurement_kind'] == 'bearing_only').sum()), 'bearing_elevation_rows': int((valid['_measurement_kind'] == 'bearing_elevation').sum()), 'ranged_rows': int((valid['_measurement_kind'] == 'bearing_elevation_range').sum()), 'reported_altitude_rows': int(valid['_hb'].notna().sum()), 'reported_altitude_missing_rows': int(valid['_hb'].isna().sum()), 'azimuth_rate_rows': int(valid['_azimuth_rate_deg_s'].notna().sum()), 'elevation_rate_rows': int(valid['_elevation_rate_deg_s'].notna().sum())}
    return EwReadResult(path=source, frame=valid, total_rows=total, valid_rows=len(valid), rejected_rows=rejected_rows, rejected_examples=rejected_examples, device_values=devices, target_values=targets, input_columns=list(schema['actual']), expected_columns=list(schema['expected']), source_paths=[source], file_summaries=[summary], quality_valid_rows=quality_valid_rows, time_filtered_rows=quality_valid_rows - len(valid), time_range_start=range_start.isoformat(sep=' ') if range_start is not None else None, time_range_end=range_end.isoformat(sep=' ') if range_end is not None else None, schema_missing_columns=list(schema['missing']), schema_extra_columns=list(schema['extra']), header_order_matches=bool(schema['order']))

def read_ew_files(paths: Sequence[str | Path], ew_config: dict, start_time=None, end_time=None) -> List[EwReadResult]:
    unique: List[Path] = []
    seen = set()
    for value in paths:
        path = Path(value).expanduser().resolve()
        key = str(path).casefold()
        if key not in seen:
            seen.add(key)
            unique.append(path)
    if not unique:
        raise ValueError('至少需要选择一个 EW 文件。')
    return [read_ew_file(path, ew_config, start_time, end_time) for path in unique]

def combine_ew_read_results(results: Sequence[EwReadResult], max_rejected_examples: int=20) -> EwReadResult:
    items = list(results)
    if not items:
        raise ValueError('至少需要一个已读取的 EW 分卷结果。')
    first = items[0]
    for item in items[1:]:
        if item.input_columns != first.input_columns:
            raise ValueError(f'多个 EW 分卷的表头或列顺序不一致: {first.path.name} 与 {item.path.name}。')
        if item.time_range_start != first.time_range_start or item.time_range_end != first.time_range_end:
            raise ValueError('多个 EW 分卷的绝对时戳过滤区间不一致。')
    frame = pd.concat([item.frame for item in items], ignore_index=True, copy=False)
    if not frame.empty:
        frame = frame.sort_values(['_jdsc', '_mby', '_zbb', '_source_file', '_excel_row'], kind='stable').reset_index(drop=True)
    targets = list(dict.fromkeys(frame['_mby'].tolist())) if not frame.empty else []
    devices = list(dict.fromkeys(frame['_zbb'].tolist())) if not frame.empty else []
    return EwReadResult(path=first.path, frame=frame, total_rows=sum((x.total_rows for x in items)), valid_rows=sum((x.valid_rows for x in items)), rejected_rows=sum((x.rejected_rows for x in items)), rejected_examples=[row for x in items for row in x.rejected_examples][:max_rejected_examples], device_values=devices, target_values=targets, input_columns=list(first.input_columns), expected_columns=list(first.expected_columns), source_paths=[p for x in items for p in x.source_paths], file_summaries=[s for x in items for s in x.file_summaries], quality_valid_rows=sum((x.quality_valid_rows for x in items)), time_filtered_rows=sum((x.time_filtered_rows for x in items)), time_range_start=first.time_range_start, time_range_end=first.time_range_end, schema_missing_columns=list(first.schema_missing_columns), schema_extra_columns=list(first.schema_extra_columns), header_order_matches=all((x.header_order_matches for x in items)))

def read_and_combine_ew_files(paths: Sequence[str | Path], ew_config: dict, start_time=None, end_time=None) -> EwReadResult:
    return combine_ew_read_results(read_ew_files(paths, ew_config, start_time, end_time), int(ew_config.get('max_rejected_examples', 20)))
