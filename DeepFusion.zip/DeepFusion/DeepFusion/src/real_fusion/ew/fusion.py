from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, TYPE_CHECKING
import numpy as np
from scipy.special import logsumexp
from scipy.stats import chi2
from real_fusion.geometry import GeodeticConverter
from real_fusion.models import TrackEstimate
from real_fusion.tracking.imm import IMMFilter
if TYPE_CHECKING:
    from real_fusion.ew.reader import EwReadResult
    from real_fusion.pipeline import ExperimentResult

def wrap_angle_rad(value: np.ndarray | float) -> np.ndarray | float:
    return (np.asarray(value) + np.pi) % (2.0 * np.pi) - np.pi

@dataclass(frozen=True)
class EwMeasurement:
    measurement_id: str
    target_id: str
    zbb: str
    sensor_id: str
    event_time_s: float
    azimuth_rad: float
    elevation_rad: Optional[float]
    range_m: Optional[float]
    kind: str
    covariance: np.ndarray
    sensor_enu: Optional[np.ndarray]
    source_file: str
    source_excel_row: int
    rcs_dbsm: Optional[float]
    reported_altitude_m: Optional[float]
    azimuth_rate_deg_s: Optional[float]
    elevation_rate_deg_s: Optional[float]
    azimuth_raw: float
    elevation_raw: Optional[float]
    range_raw: Optional[float]
    azimuth_rate_raw: Optional[float]
    elevation_rate_raw: Optional[float]

    @property
    def vector(self) -> np.ndarray:
        values = [self.azimuth_rad]
        if self.elevation_rad is not None:
            values.append(self.elevation_rad)
        if self.range_m is not None and self.elevation_rad is not None:
            values.append(self.range_m)
        if self.reported_altitude_m is not None:
            values.append(self.reported_altitude_m)
        return np.asarray(values, dtype=float)

    @property
    def angle_dimension(self) -> int:
        return 2 if self.elevation_rad is not None else 1

    @property
    def range_index(self) -> Optional[int]:
        return self.angle_dimension if self.range_m is not None and self.elevation_rad is not None else None

    @property
    def altitude_index(self) -> Optional[int]:
        return self.vector.size - 1 if self.reported_altitude_m is not None else None

    def direction_enu(self) -> np.ndarray:
        elevation = self.elevation_rad or 0.0
        horizontal = np.cos(elevation)
        return np.asarray([np.sin(self.azimuth_rad) * horizontal, np.cos(self.azimuth_rad) * horizontal, np.sin(elevation)])

    def endpoint_enu(self, fallback_length_m: float) -> Optional[np.ndarray]:
        if self.sensor_enu is None:
            return None
        distance = self.range_m if self.range_m is not None else fallback_length_m
        return self.sensor_enu + self.direction_enu() * float(distance)

    def to_record(self) -> Dict[str, object]:
        endpoint = self.endpoint_enu(float('nan')) if self.range_m is not None else None
        return {'ew_measurement_id': self.measurement_id, 'ew_target_id': self.target_id, 'zbb': self.zbb, 'sensor_id': self.sensor_id, 'event_time_s': self.event_time_s, 'measurement_kind': self.kind, 'azimuth_raw': self.azimuth_raw, 'azimuth_deg': float(np.rad2deg(self.azimuth_rad)), 'elevation_raw': self.elevation_raw, 'elevation_deg': None if self.elevation_rad is None else float(np.rad2deg(self.elevation_rad)), 'range_raw': self.range_raw, 'range_m': self.range_m, 'azimuth_rate_raw': self.azimuth_rate_raw, 'azimuth_rate_deg_s': self.azimuth_rate_deg_s, 'elevation_rate_raw': self.elevation_rate_raw, 'elevation_rate_deg_s': self.elevation_rate_deg_s, 'sensor_east_m': None if self.sensor_enu is None else float(self.sensor_enu[0]), 'sensor_north_m': None if self.sensor_enu is None else float(self.sensor_enu[1]), 'sensor_up_m': None if self.sensor_enu is None else float(self.sensor_enu[2]), 'endpoint_east_m': None if endpoint is None else float(endpoint[0]), 'endpoint_north_m': None if endpoint is None else float(endpoint[1]), 'endpoint_up_m': None if endpoint is None else float(endpoint[2]), 'rcs_dbsm': self.rcs_dbsm, 'reported_altitude_m': self.reported_altitude_m, 'source_file': self.source_file, 'source_excel_row': self.source_excel_row, 'sensor_position_configured': self.sensor_enu is not None}

@dataclass(frozen=True)
class EwAssociation:
    measurement_id: str
    ew_target_id: str
    zbb: str
    event_time_s: float
    status: str
    matched_track_id: Optional[str]
    matched_target_id: Optional[str]
    association_probability: float
    nis: Optional[float]
    gate_threshold: Optional[float]
    mby_equal: Optional[bool]
    azimuth_residual_deg: Optional[float]
    elevation_residual_deg: Optional[float]
    reason: str
    source_file: str
    source_excel_row: int
    range_residual_m: Optional[float] = None
    nis_gate_ratio: Optional[float] = None
    local_track_history_match: Optional[bool] = None
    altitude_residual_m: Optional[float] = None

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

def _measurement_tools(measurement: EwMeasurement, converter: GeodeticConverter):
    sensor = np.asarray(measurement.sensor_enu, dtype=float)
    has_elevation = measurement.elevation_rad is not None
    has_range = measurement.range_m is not None and has_elevation
    has_altitude = measurement.reported_altitude_m is not None

    def function(state: np.ndarray) -> np.ndarray:
        relative = np.asarray(state[:3], dtype=float) - sensor
        (east, north, up) = relative
        horizontal = max(float(np.hypot(east, north)), 1e-09)
        values = [float(np.arctan2(east, north))]
        if has_elevation:
            values.append(float(np.arctan2(up, horizontal)))
        if has_range:
            values.append(float(np.linalg.norm(relative)))
        if has_altitude:
            values.append(float(converter.enu_to_geodetic(state[:3])[2]))
        return np.asarray(values, dtype=float)
    angle_dimension = 2 if has_elevation else 1

    def mean(points: np.ndarray, weights: np.ndarray) -> np.ndarray:
        result = np.sum(weights[:, None] * points, axis=0)
        for index in range(angle_dimension):
            result[index] = np.arctan2(np.sum(weights * np.sin(points[:, index])), np.sum(weights * np.cos(points[:, index])))
        return result

    def residual(left: np.ndarray, right: np.ndarray) -> np.ndarray:
        difference = np.asarray(left, dtype=float) - np.asarray(right, dtype=float)
        difference[:angle_dimension] = wrap_angle_rad(difference[:angle_dimension])
        return difference
    return (function, mean, residual)

def build_ew_measurements(ew_read: 'EwReadResult', config: dict, converter: GeodeticConverter) -> tuple[List[EwMeasurement], Dict[str, np.ndarray]]:
    ew_config = config['ew']
    default = ew_config.get('measurement', {})
    raw_sensors = {str(key): value for (key, value) in ew_config.get('sensors', {}).items()}
    used_zbb = set(ew_read.frame['_zbb'].astype(str)) if not ew_read.frame.empty else set()
    sensor_positions: Dict[str, np.ndarray] = {}
    for (zbb, sensor) in raw_sensors.items():
        if zbb not in used_zbb:
            continue
        sensor_positions[zbb] = converter.geodetic_to_enu(float(sensor['longitude_deg']), float(sensor['latitude_deg']), float(sensor['altitude_m']))
    measurements: List[EwMeasurement] = []
    for (index, row) in ew_read.frame.iterrows():
        zbb = str(row['_zbb'])
        sensor_config = raw_sensors.get(zbb, {})
        azimuth_std = float(sensor_config.get('azimuth_std_deg', default.get('azimuth_std_deg', 1.5)))
        elevation_std = float(sensor_config.get('elevation_std_deg', default.get('elevation_std_deg', 1.5)))
        range_std = float(sensor_config.get('range_std_m', default.get('range_std_m', 120.0)))
        altitude_std = float(sensor_config.get('altitude_std_m', default.get('altitude_std_m', 150.0)))
        azimuth = float(row['_azimuth_deg']) + float(sensor_config.get('azimuth_bias_deg', default.get('azimuth_bias_deg', 0.0)))
        elevation_value = row['_elevation_deg']
        elevation = None if not np.isfinite(float(elevation_value)) else float(elevation_value) + float(sensor_config.get('elevation_bias_deg', default.get('elevation_bias_deg', 0.0)))
        range_value = row['_range_m']
        distance = None if not np.isfinite(float(range_value)) else float(range_value) + float(sensor_config.get('range_bias_m', default.get('range_bias_m', 0.0)))
        if elevation is None:
            distance = None
        variances = [np.deg2rad(azimuth_std) ** 2]
        if elevation is not None:
            variances.append(np.deg2rad(elevation_std) ** 2)
        if distance is not None:
            variances.append(range_std ** 2)
        correction = float(sensor_config.get('configured_time_correction_s', default.get('configured_time_correction_s', 0.0)))
        rcs_value = row.get('_rcs', np.nan)
        altitude_value = row.get('_hb', np.nan)
        reported_altitude = None if not np.isfinite(float(altitude_value)) else float(altitude_value)
        if reported_altitude is not None:
            variances.append(altitude_std ** 2)
        azimuth_rate_value = row.get('_azimuth_rate_deg_s', np.nan)
        elevation_rate_value = row.get('_elevation_rate_deg_s', np.nan)
        elevation_raw = row.get('_elevation_raw', np.nan)
        range_raw = row.get('_range_raw', np.nan)
        azimuth_rate_raw = row.get('_azimuth_rate_raw', np.nan)
        elevation_rate_raw = row.get('_elevation_rate_raw', np.nan)
        measurements.append(EwMeasurement(measurement_id=f'EW-{index + 1:08d}', target_id=str(row['_mby']), zbb=zbb, sensor_id=f'EW-{zbb}', event_time_s=float(row['_epoch_s']) + correction, azimuth_rad=float(np.deg2rad(azimuth % 360.0)), elevation_rad=None if elevation is None else float(np.deg2rad(elevation)), range_m=distance, kind=str(row['_measurement_kind']) + '_altitude' if reported_altitude is not None else str(row['_measurement_kind']), covariance=np.diag(variances), sensor_enu=sensor_positions.get(zbb), source_file=str(row['_source_file']), source_excel_row=int(row['_excel_row']), rcs_dbsm=None if not np.isfinite(float(rcs_value)) else float(rcs_value), reported_altitude_m=reported_altitude, azimuth_rate_deg_s=None if not np.isfinite(float(azimuth_rate_value)) else float(azimuth_rate_value), elevation_rate_deg_s=None if not np.isfinite(float(elevation_rate_value)) else float(elevation_rate_value), azimuth_raw=float(row['_azimuth_raw']), elevation_raw=None if not np.isfinite(float(elevation_raw)) else float(elevation_raw), range_raw=None if not np.isfinite(float(range_raw)) else float(range_raw), azimuth_rate_raw=None if not np.isfinite(float(azimuth_rate_raw)) else float(azimuth_rate_raw), elevation_rate_raw=None if not np.isfinite(float(elevation_rate_raw)) else float(elevation_rate_raw)))
    return (measurements, sensor_positions)

def _estimate(track_id: str, target_id: str, event_time: float, imm: IMMFilter, converter: GeodeticConverter, source: Optional[EwMeasurement]=None, probability: float=0.0) -> TrackEstimate:
    (state, covariance) = imm.fused_state()
    (longitude, latitude, altitude) = converter.enu_to_geodetic(state[:3])
    sources = []
    ids: List[str] = []
    probabilities: Dict[str, float] = {}
    if source is not None:
        ids = [source.measurement_id]
        probabilities = {source.measurement_id: float(probability)}
        sources = [{'sensor_id': source.sensor_id, 'zbb': source.zbb, 'target_id': source.target_id, 'measurement_kind': source.kind, 'reported_altitude_m': source.reported_altitude_m, 'source_file': source.source_file, 'source_excel_row': source.source_excel_row}]
    return TrackEstimate(track_id=track_id, target_id=target_id, event_time_s=float(event_time), state_enu=state.copy(), covariance=covariance.copy(), lifecycle_state='joint_confirmed', existence_probability=1.0, model_probabilities=imm.probability_dict(), associated_detection_ids=ids, association_probabilities=probabilities, associated_sources=sources, longitude_deg=longitude, latitude_deg=latitude, altitude_m=altitude)

def run_ew_joint_fusion(result: 'ExperimentResult', ew_read: 'EwReadResult', converter: GeodeticConverter) -> 'ExperimentResult':
    (measurements, sensor_positions) = build_ew_measurements(ew_read, result.config, converter)
    config = result.config['ew']['joint_fusion']
    gating_probability = float(config.get('gating_probability', 0.995))
    max_gap = float(config.get('maximum_sw_prediction_gap_s', 6.0))
    history_prior = float(config.get('local_track_history_prior_multiplier', 3.0))
    clutter = float(config.get('clutter_weight', 0.08))
    minimum_beta = float(config.get('minimum_association_probability', 0.08))
    coarse_azimuth = float(np.deg2rad(config.get('coarse_azimuth_gate_deg', 25.0)))
    coarse_elevation = float(np.deg2rad(config.get('coarse_elevation_gate_deg', 20.0)))
    coarse_range = float(config.get('coarse_range_gate_m', 15000.0))
    coarse_altitude = float(config.get('coarse_altitude_gate_m', 1500.0))
    maximum_candidates = max(1, int(config.get('maximum_geometry_candidates', 8)))
    baseline_by_time = sorted(result.estimates, key=lambda item: (item.event_time_s, item.track_id))
    events = [(item.event_time_s, 0, 'sw', item) for item in baseline_by_time]
    events.extend(((item.event_time_s, 1, 'ew', item) for item in measurements))
    events.sort(key=lambda item: (item[0], item[1]))
    joint_id = {track_id: f'J{track_id}' for track_id in sorted({x.track_id for x in baseline_by_time})}
    runtimes: Dict[str, IMMFilter] = {}
    targets: Dict[str, str] = {}
    last_sw_time: Dict[str, float] = {}
    joint_estimates: List[TrackEstimate] = []
    associations: List[EwAssociation] = []
    local_track_history: Dict[tuple[str, str], str] = {}
    for (event_time, _, kind, payload) in events:
        if kind == 'sw':
            sw: TrackEstimate = payload
            if sw.track_id not in runtimes:
                runtimes[sw.track_id] = IMMFilter(sw.state_enu, sw.covariance, event_time, result.config['tracker'])
            else:
                runtime = runtimes[sw.track_id]
                for filt in runtime.filters:
                    filt.state = sw.state_enu.copy()
                    filt.covariance = sw.covariance.copy()
                runtime.event_time_s = float(event_time)
                runtime.model_probabilities = np.asarray([sw.model_probabilities.get(name, 0.0) for name in runtime.model_names], dtype=float)
                if runtime.model_probabilities.sum() <= 0:
                    runtime.model_probabilities[:] = 1.0 / len(runtime.model_probabilities)
                else:
                    runtime.model_probabilities /= runtime.model_probabilities.sum()
            targets[sw.track_id] = sw.target_id
            last_sw_time[sw.track_id] = float(event_time)
            runtime = runtimes[sw.track_id]
            (longitude, latitude, altitude) = converter.enu_to_geodetic(sw.state_enu[:3])
            joint_estimates.append(TrackEstimate(track_id=joint_id[sw.track_id], target_id=sw.target_id, event_time_s=sw.event_time_s, state_enu=sw.state_enu.copy(), covariance=sw.covariance.copy(), lifecycle_state='sw_anchor', existence_probability=sw.existence_probability, model_probabilities=dict(sw.model_probabilities), associated_detection_ids=list(sw.associated_detection_ids), association_probabilities=dict(sw.association_probabilities), associated_sources=list(sw.associated_sources), longitude_deg=longitude, latitude_deg=latitude, altitude_m=altitude))
            continue
        measurement: EwMeasurement = payload
        if measurement.sensor_enu is None:
            associations.append(EwAssociation(measurement.measurement_id, measurement.target_id, measurement.zbb, event_time, 'sensor_position_missing', None, None, 0.0, None, None, None, None, None, '该装备未在 ew.sensors 中配置固定经纬度和海拔，未参与空间关联。', measurement.source_file, measurement.source_excel_row))
            continue
        (function, mean, residual) = _measurement_tools(measurement, converter)
        local_history_key = (measurement.zbb, measurement.target_id)
        historical_track_id = local_track_history.get(local_history_key)
        coarse_candidates = []
        for (track_id, runtime) in runtimes.items():
            if event_time < runtime.event_time_s - 1e-07:
                continue
            if event_time - last_sw_time.get(track_id, event_time) > max_gap:
                continue
            (coarse_state, _) = runtime.fused_state()
            dt = max(0.0, float(event_time - runtime.event_time_s))
            coarse_state = coarse_state.copy()
            coarse_state[:3] += coarse_state[3:] * dt
            coarse_prediction = function(coarse_state)
            coarse_residual = residual(measurement.vector, coarse_prediction)
            history_match = historical_track_id == track_id
            if abs(coarse_residual[0]) > coarse_azimuth:
                continue
            if measurement.angle_dimension > 1 and abs(coarse_residual[1]) > coarse_elevation:
                continue
            if measurement.range_index is not None and abs(coarse_residual[measurement.range_index]) > coarse_range:
                continue
            if measurement.altitude_index is not None and abs(coarse_residual[measurement.altitude_index]) > coarse_altitude:
                continue
            normalized_score = (coarse_residual[0] / max(coarse_azimuth, 1e-09)) ** 2
            if measurement.angle_dimension > 1:
                normalized_score += (coarse_residual[1] / max(coarse_elevation, 1e-09)) ** 2
            if measurement.range_index is not None:
                normalized_score += (coarse_residual[measurement.range_index] / max(coarse_range, 1e-09)) ** 2
            if measurement.altitude_index is not None:
                normalized_score += (coarse_residual[measurement.altitude_index] / max(coarse_altitude, 1e-09)) ** 2
            coarse_candidates.append((float(normalized_score), not history_match, track_id, runtime, history_match))
        coarse_candidates.sort(key=lambda item: (item[1], item[0], item[2]))
        candidates = []
        for (_, _, track_id, runtime, history_match) in coarse_candidates[:maximum_candidates]:
            runtime.predict_to(event_time)
            model_updates = [filt.conditional_update(measurement.vector, measurement.covariance, function, mean, residual) for filt in runtime.filters]
            model_logs = np.asarray([item.log_likelihood for item in model_updates])
            log_likelihood = float(logsumexp(np.log(np.maximum(runtime.model_probabilities, 1e-15)) + model_logs))
            nis = float(sum((p * update.nis for (p, update) in zip(runtime.model_probabilities, model_updates))))
            threshold = float(chi2.ppf(gating_probability, measurement.vector.size))
            if nis <= threshold:
                prior = history_prior if history_match else 1.0
                candidates.append((track_id, runtime, nis, threshold, log_likelihood, prior, history_match))
        if not candidates:
            associations.append(EwAssociation(measurement.measurement_id, measurement.target_id, measurement.zbb, event_time, 'outside_gate_or_no_sw', None, None, 0.0, None, float(chi2.ppf(gating_probability, measurement.vector.size)), None, None, None, '没有处于有效预测时段且通过角度/距离/海拔门控的 SW 航迹。', measurement.source_file, measurement.source_excel_row))
            continue
        log_weights = np.asarray([np.log(max(item[5], 1e-15)) - 0.5 * item[2] for item in candidates])
        maximum = float(np.max(log_weights))
        weights = np.exp(log_weights - maximum)
        clutter_scaled = clutter * np.exp(-maximum)
        probabilities = weights / (float(weights.sum()) + clutter_scaled)
        best_index = int(np.argmax(probabilities))
        best = candidates[best_index]
        best_probability = float(probabilities[best_index])
        predicted = function(best[1].fused_state()[0])
        angle_residual = residual(measurement.vector, predicted)
        for (probability, (track_id, runtime, *_rest)) in zip(probabilities, candidates):
            beta = float(probability)
            if beta < minimum_beta:
                continue
            runtime.update_generic(measurement.vector, measurement.covariance, beta, function, mean, residual)
            joint_estimates.append(_estimate(joint_id[track_id], targets[track_id], event_time, runtime, converter, measurement, beta))
        if best_probability >= minimum_beta:
            local_track_history[local_history_key] = best[0]
        associations.append(EwAssociation(measurement.measurement_id, measurement.target_id, measurement.zbb, event_time, 'associated' if best_probability >= minimum_beta else 'low_probability', joint_id[best[0]], targets[best[0]], best_probability, best[2], best[3], None, float(np.rad2deg(angle_residual[0])), float(np.rad2deg(angle_residual[1])) if measurement.angle_dimension > 1 else None, 'EW装备编号用于确定量测原点；EW局部MBY不与SW局部MBY或GT比较。首次按异步时刻角度/距离/可选Hb海拔几何关联，后续仅使用同一EW装备内局部航迹的历史RF软先验。', measurement.source_file, measurement.source_excel_row, float(angle_residual[measurement.range_index]) if measurement.range_index is not None else None, float(best[2] / best[3]) if best[3] > 0.0 else None, bool(best[6]), float(angle_residual[measurement.altitude_index]) if measurement.altitude_index is not None else None))
    result.ew_read = ew_read
    result.ew_measurements = measurements
    result.ew_associations = associations
    result.joint_estimates = sorted(joint_estimates, key=lambda item: (item.event_time_s, item.track_id))
    result.ew_sensor_positions = sensor_positions
    return result
