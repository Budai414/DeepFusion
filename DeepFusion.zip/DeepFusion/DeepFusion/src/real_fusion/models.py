from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import numpy as np
Array = np.ndarray

@dataclass(frozen=True)
class RawDetection:
    detection_id: str
    frame_id: str
    sensor_id: str
    target_id: str
    source_track_id: str
    measurement_time_s: float
    arrival_time_s: float
    longitude_deg: float
    latitude_deg: float
    altitude_m: float
    velocity_enu: Array
    position_cov_enu: Array
    velocity_cov_enu: Array
    score: float
    rcs_dbsm: float
    local_target_id: Optional[str] = None
    local_track_key: Optional[str] = None
    source_file: Optional[str] = None
    source_excel_row: Optional[int] = None

    def to_record(self) -> Dict[str, object]:
        return {'detection_id': self.detection_id, 'frame_id': self.frame_id, 'sensor_id': self.sensor_id, 'target_id': self.target_id, 'source_track_id': self.source_track_id, 'measurement_time_s': self.measurement_time_s, 'arrival_time_s': self.arrival_time_s, 'longitude_deg': self.longitude_deg, 'latitude_deg': self.latitude_deg, 'altitude_m': self.altitude_m, 'velocity_east_mps': float(self.velocity_enu[0]), 'velocity_north_mps': float(self.velocity_enu[1]), 'velocity_up_mps': float(self.velocity_enu[2]), 'position_covariance_enu': self.position_cov_enu.tolist(), 'velocity_covariance_enu': self.velocity_cov_enu.tolist(), 'score': self.score, 'rcs_dbsm': self.rcs_dbsm, 'local_target_id': self.local_target_id or self.target_id, 'local_track_key': self.local_track_key or self.source_track_id, 'source_file': self.source_file, 'source_excel_row': self.source_excel_row}

@dataclass(frozen=True)
class NormalizedDetection:
    detection_id: str
    frame_id: str
    sensor_id: str
    target_id: str
    source_track_id: str
    corrected_time_s: float
    arrival_time_s: float
    state_enu: Array
    covariance: Array
    score: float
    rcs_dbsm: float
    local_target_id: Optional[str] = None
    local_track_key: Optional[str] = None

@dataclass
class AssociationResult:
    missed_probability: float
    detection_probabilities: Dict[str, float]
    gated_detection_ids: List[str]
    nis_by_detection: Dict[str, float]

    @property
    def hit_probability(self) -> float:
        return 1.0 - self.missed_probability

@dataclass
class TrackEstimate:
    track_id: str
    target_id: str
    event_time_s: float
    state_enu: Array
    covariance: Array
    lifecycle_state: str
    existence_probability: float
    model_probabilities: Dict[str, float]
    associated_detection_ids: List[str] = field(default_factory=list)
    association_probabilities: Dict[str, float] = field(default_factory=dict)
    associated_sources: List[Dict[str, object]] = field(default_factory=list)
    longitude_deg: float = float('nan')
    latitude_deg: float = float('nan')
    altitude_m: float = float('nan')

    def to_record(self) -> Dict[str, object]:
        return {'fusion_track_id': self.track_id, 'target_id': self.target_id, 'event_time_s': self.event_time_s, 'longitude_deg': self.longitude_deg, 'latitude_deg': self.latitude_deg, 'altitude_m': self.altitude_m, 'east_m': float(self.state_enu[0]), 'north_m': float(self.state_enu[1]), 'up_m': float(self.state_enu[2]), 'velocity_east_mps': float(self.state_enu[3]), 'velocity_north_mps': float(self.state_enu[4]), 'velocity_up_mps': float(self.state_enu[5]), 'lifecycle_state': self.lifecycle_state, 'existence_probability': self.existence_probability, 'model_probabilities': self.model_probabilities, 'associated_detection_ids': self.associated_detection_ids, 'association_probabilities': self.association_probabilities, 'associated_sources': self.associated_sources, 'state_covariance': self.covariance.tolist()}
