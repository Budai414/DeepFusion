from __future__ import annotations
import math
import numpy as np
from real_fusion.geometry import GeodeticConverter
from real_fusion.models import NormalizedDetection, RawDetection

def _validate_raw(detection: RawDetection) -> None:
    scalars = [detection.measurement_time_s, detection.arrival_time_s, detection.longitude_deg, detection.latitude_deg, detection.altitude_m, detection.score, detection.rcs_dbsm]
    if not all((math.isfinite(value) for value in scalars)):
        raise ValueError(f'Non-finite scalar in detection {detection.detection_id}')
    if not -180.0 <= detection.longitude_deg <= 180.0:
        raise ValueError(f'Invalid longitude in detection {detection.detection_id}')
    if not -90.0 <= detection.latitude_deg <= 90.0:
        raise ValueError(f'Invalid latitude in detection {detection.detection_id}')
    if not np.all(np.isfinite(detection.velocity_enu)):
        raise ValueError(f'Invalid velocity in detection {detection.detection_id}')
    if detection.position_cov_enu.shape != (3, 3) or detection.velocity_cov_enu.shape != (3, 3):
        raise ValueError(f'Invalid covariance shape in detection {detection.detection_id}')

def normalize_detection(detection: RawDetection, sensor_config: dict, converter: GeodeticConverter) -> NormalizedDetection:
    _validate_raw(detection)
    position = converter.geodetic_to_enu(detection.longitude_deg, detection.latitude_deg, detection.altitude_m)
    position -= np.asarray(sensor_config['configured_position_bias_enu_m'], dtype=float)
    velocity = detection.velocity_enu - np.asarray(sensor_config['configured_velocity_bias_enu_mps'], dtype=float)
    covariance = np.zeros((6, 6), dtype=float)
    covariance[:3, :3] = detection.position_cov_enu
    covariance[3:, 3:] = detection.velocity_cov_enu
    covariance += np.eye(6) * 1e-06
    corrected_time = detection.measurement_time_s - float(sensor_config['configured_time_correction_s'])
    return NormalizedDetection(detection_id=detection.detection_id, frame_id=detection.frame_id, sensor_id=detection.sensor_id, target_id=detection.target_id, source_track_id=detection.source_track_id, corrected_time_s=float(corrected_time), arrival_time_s=detection.arrival_time_s, state_enu=np.concatenate((position, velocity)), covariance=covariance, score=detection.score, rcs_dbsm=detection.rcs_dbsm, local_target_id=detection.local_target_id or detection.target_id, local_track_key=detection.local_track_key or detection.source_track_id)
