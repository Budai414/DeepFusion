from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterable, List
from real_fusion.models import NormalizedDetection

@dataclass(frozen=True)
class FusionWindow:
    index: int
    start_time_s: float
    end_time_s: float
    detections: List[NormalizedDetection]

class EventTimeBuffer:

    def __init__(self, config: dict):
        scenario = config['scenario']
        self.base_epoch = float(scenario['base_epoch_s'])
        self.window_s = float(scenario['window_s'])
        self.offline_after_s = float(scenario['offline_after_s'])
        self.sensor_ids = set(config['sensors'])
        self.allowed_lateness = {sensor_id: float(sensor['allowed_lateness_s']) for (sensor_id, sensor) in config['sensors'].items()}
        self._buckets: Dict[int, List[NormalizedDetection]] = {}
        self._max_event_time: Dict[str, float] = {}
        self._last_arrival_time: Dict[str, float] = {}
        self._next_window_index = 0
        self._watermark = float('-inf')
        self.late_drop_count = 0
        self.released_window_count = 0

    @property
    def watermark(self) -> float:
        return self._watermark

    def _window_index(self, event_time_s: float) -> int:
        return max(0, int((event_time_s - self.base_epoch) // self.window_s))

    def push_frame(self, detections: Iterable[NormalizedDetection]) -> List[FusionWindow]:
        frame = list(detections)
        if not frame:
            return []
        current_arrival = max((item.arrival_time_s for item in frame))
        for detection in frame:
            sensor_id = detection.sensor_id
            self._max_event_time[sensor_id] = max(detection.corrected_time_s, self._max_event_time.get(sensor_id, float('-inf')))
            self._last_arrival_time[sensor_id] = current_arrival
            window_index = self._window_index(detection.corrected_time_s)
            if window_index < self._next_window_index:
                self.late_drop_count += 1
                continue
            self._buckets.setdefault(window_index, []).append(detection)
        if not self.sensor_ids.issubset(self._max_event_time):
            return []
        online = {sensor_id for sensor_id in self.sensor_ids if current_arrival - self._last_arrival_time.get(sensor_id, float('-inf')) <= self.offline_after_s}
        if not online:
            return []
        candidate = min((self._max_event_time[sensor_id] - self.allowed_lateness[sensor_id] for sensor_id in online))
        self._watermark = max(self._watermark, candidate)
        return self._release_eligible(self._watermark)

    def _release_eligible(self, boundary_time_s: float) -> List[FusionWindow]:
        released: List[FusionWindow] = []
        while self.base_epoch + (self._next_window_index + 1) * self.window_s <= boundary_time_s:
            index = self._next_window_index
            start = self.base_epoch + index * self.window_s
            end = start + self.window_s
            detections = sorted(self._buckets.pop(index, []), key=lambda item: (item.corrected_time_s, item.sensor_id, item.frame_id, item.detection_id))
            released.append(FusionWindow(index, start, end, detections))
            self._next_window_index += 1
            self.released_window_count += 1
        return released

    def flush(self, final_time_s: float) -> List[FusionWindow]:
        self._watermark = max(self._watermark, final_time_s)
        return self._release_eligible(final_time_s)
