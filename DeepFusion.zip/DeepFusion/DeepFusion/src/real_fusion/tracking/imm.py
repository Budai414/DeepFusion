from __future__ import annotations
from typing import Callable, Dict, List, Sequence, Tuple
import numpy as np
from scipy.linalg import fractional_matrix_power
from scipy.special import logsumexp
from real_fusion.models import NormalizedDetection
from real_fusion.tracking.motion import build_motion_function
from real_fusion.tracking.ukf import UnscentedKalmanFilter, ensure_positive_definite, white_acceleration_process_noise

def scale_transition_matrix(transition: np.ndarray, duration_s: float, reference_interval_s: float) -> np.ndarray:
    duration = float(duration_s)
    reference = float(reference_interval_s)
    if duration < 0.0 or not np.isfinite(duration):
        raise ValueError('IMM转移时长必须是有限非负数。')
    if reference <= 0.0 or not np.isfinite(reference):
        raise ValueError('IMM转移矩阵参考时间必须是有限正数。')
    if duration <= 1e-12:
        return np.eye(np.asarray(transition).shape[0], dtype=float)
    exponent = duration / reference
    if abs(exponent - 1.0) <= 1e-12:
        return np.asarray(transition, dtype=float).copy()
    scaled = np.real_if_close(fractional_matrix_power(np.asarray(transition, dtype=float), exponent), tol=1000)
    if np.iscomplexobj(scaled):
        maximum_imaginary = float(np.max(np.abs(np.imag(scaled))))
        if maximum_imaginary > 1e-08:
            raise ValueError('IMM转移矩阵无法稳定换算到当前预测时长。')
        scaled = np.real(scaled)
    scaled = np.asarray(scaled, dtype=float)
    scaled = np.maximum(scaled, 0.0)
    row_sums = scaled.sum(axis=1, keepdims=True)
    if np.any(row_sums <= 0.0) or not np.all(np.isfinite(row_sums)):
        raise ValueError('IMM转移矩阵时间换算后行和无效。')
    return scaled / row_sums

class IMMFilter:

    def __init__(self, state: np.ndarray, covariance: np.ndarray, event_time_s: float, config: dict):
        self.model_names: List[str] = list(config['model_names'])
        self.transition = np.asarray(config['model_transition_matrix'], dtype=float)
        self.transition_reference_interval_s = float(config.get('transition_reference_interval_s', 0.5))
        self._transition_cache: Dict[float, np.ndarray] = {}
        self.turn_rates = list(config['turn_rates_deg_s'])
        self.acceleration_stds = list(config['process_accel_std_mps2'])
        ukf_config = config['ukf']
        self.filters = [UnscentedKalmanFilter(state, covariance, ukf_config['alpha'], ukf_config['beta'], ukf_config['kappa'], ukf_config['covariance_jitter']) for _ in self.model_names]
        self.motion_functions = [build_motion_function(name, rate) for (name, rate) in zip(self.model_names, self.turn_rates)]
        self.model_probabilities = np.asarray([0.1, 0.7, 0.1, 0.1], dtype=float)
        self.event_time_s = float(event_time_s)

    def predict_to(self, event_time_s: float) -> None:
        dt = float(event_time_s - self.event_time_s)
        if dt < -1e-07:
            raise ValueError('IMM cannot predict backward in event time.')
        if dt <= 1e-09:
            return
        cache_key = round(dt, 9)
        transition = self._transition_cache.get(cache_key)
        if transition is None:
            transition = scale_transition_matrix(self.transition, dt, self.transition_reference_interval_s)
            self._transition_cache[cache_key] = transition
        prior_probabilities = self.model_probabilities.copy()
        destination_probabilities = prior_probabilities @ transition
        mixed_states: List[np.ndarray] = []
        mixed_covariances: List[np.ndarray] = []
        for (destination_index, destination_probability) in enumerate(destination_probabilities):
            weights = prior_probabilities * transition[:, destination_index] / max(destination_probability, 1e-15)
            mixed_state = sum((weight * filt.state for (weight, filt) in zip(weights, self.filters)))
            mixed_covariance = np.zeros((6, 6), dtype=float)
            for (weight, filt) in zip(weights, self.filters):
                difference = filt.state - mixed_state
                mixed_covariance += weight * (filt.covariance + np.outer(difference, difference))
            mixed_states.append(mixed_state)
            mixed_covariances.append(ensure_positive_definite(mixed_covariance))
        for (index, filt) in enumerate(self.filters):
            filt.state = mixed_states[index]
            filt.covariance = mixed_covariances[index]
            process_noise = white_acceleration_process_noise(dt, self.acceleration_stds[index])
            filt.predict(dt, self.motion_functions[index], process_noise)
        self.model_probabilities = destination_probabilities / destination_probabilities.sum()
        self.event_time_s = float(event_time_s)

    def fused_state(self) -> Tuple[np.ndarray, np.ndarray]:
        state = sum((probability * filt.state for (probability, filt) in zip(self.model_probabilities, self.filters)))
        covariance = np.zeros((6, 6), dtype=float)
        for (probability, filt) in zip(self.model_probabilities, self.filters):
            difference = filt.state - state
            covariance += probability * (filt.covariance + np.outer(difference, difference))
        return (state, ensure_positive_definite(covariance))

    def update_pda(self, detections: Sequence[NormalizedDetection], missed_probability: float, detection_probabilities: Dict[str, float]) -> None:
        branch_probabilities = [float(missed_probability)] + [float(detection_probabilities.get(item.detection_id, 0.0)) for item in detections]
        model_log_evidence = np.zeros(len(self.filters), dtype=float)
        hit_probability = max(0.0, 1.0 - float(missed_probability))
        for (model_index, filt) in enumerate(self.filters):
            updates = [filt.conditional_update(item.state_enu, item.covariance) for item in detections]
            branch_states = [filt.state] + [item.state for item in updates]
            branch_covariances = [filt.covariance] + [item.covariance for item in updates]
            mixed_state = sum((probability * state for (probability, state) in zip(branch_probabilities, branch_states)))
            mixed_covariance = np.zeros((6, 6), dtype=float)
            for (probability, state, covariance) in zip(branch_probabilities, branch_states, branch_covariances):
                difference = state - mixed_state
                mixed_covariance += probability * (covariance + np.outer(difference, difference))
            filt.state = mixed_state
            filt.covariance = ensure_positive_definite(mixed_covariance)
            evidence_terms = [np.log(probability / max(hit_probability, 1e-15)) + update.log_likelihood for (probability, update) in zip(branch_probabilities[1:], updates) if probability > 0.0]
            if evidence_terms:
                model_log_evidence[model_index] = logsumexp(evidence_terms)
        if hit_probability >= 0.1 and detections:
            centered_evidence = model_log_evidence - logsumexp(model_log_evidence)
            posterior_logs = np.log(np.maximum(self.model_probabilities, 1e-15)) + 0.35 * centered_evidence
            posterior_logs -= logsumexp(posterior_logs)
            self.model_probabilities = np.exp(posterior_logs)

    def update_generic(self, measurement: np.ndarray, covariance: np.ndarray, association_probability: float, measurement_function: Callable[[np.ndarray], np.ndarray]=lambda state: state, measurement_mean_function=None, measurement_residual_function=None) -> list:
        beta = float(np.clip(association_probability, 0.0, 1.0))
        updates = []
        log_evidence = np.zeros(len(self.filters), dtype=float)
        for (index, filt) in enumerate(self.filters):
            update = filt.conditional_update(measurement, covariance, measurement_function, measurement_mean_function, measurement_residual_function)
            updates.append(update)
            prior_state = filt.state.copy()
            mixed_state = (1.0 - beta) * prior_state + beta * update.state
            prior_difference = prior_state - mixed_state
            update_difference = update.state - mixed_state
            filt.covariance = ensure_positive_definite((1.0 - beta) * (filt.covariance + np.outer(prior_difference, prior_difference)) + beta * (update.covariance + np.outer(update_difference, update_difference)))
            filt.state = mixed_state
            log_evidence[index] = update.log_likelihood
        if beta >= 0.1:
            centered = log_evidence - logsumexp(log_evidence)
            posterior = np.log(np.maximum(self.model_probabilities, 1e-15)) + 0.35 * beta * centered
            posterior -= logsumexp(posterior)
            self.model_probabilities = np.exp(posterior)
        return updates

    def probability_dict(self) -> Dict[str, float]:
        return {name: float(probability) for (name, probability) in zip(self.model_names, self.model_probabilities)}
