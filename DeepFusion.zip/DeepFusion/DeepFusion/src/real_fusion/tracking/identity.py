from __future__ import annotations
from dataclasses import dataclass, field, replace
import hashlib
import json
from typing import Any, Dict, List, Mapping, Optional, Sequence
import numpy as np
from scipy.stats import chi2
from scipy.spatial import cKDTree
from real_fusion.models import NormalizedDetection, RawDetection
from real_fusion.tracking.birth import TentativeBirthManager

@dataclass(frozen=True)
class LocalTrackPairDiagnostic:
    left_local_track_key: str
    right_local_track_key: str
    left_sensor_id: str
    right_sensor_id: str
    left_zbb: str
    right_zbb: str
    left_local_target_id: str
    right_local_target_id: str
    temporal_pair_count: int
    compatible_pair_count: int
    compatible_time_bin_count: int
    compatible_fraction: float
    minimum_position_distance_m: float | None
    median_position_mahalanobis_sq: float | None
    median_velocity_mahalanobis_sq: float | None
    position_gate_threshold: float
    velocity_gate_threshold: float
    compatible: bool
    reason: str

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

@dataclass(frozen=True)
class IdentityCandidateNode:
    local_track_key: str
    sensor_id: str
    report_count: int
    first_corrected_time_s: float
    last_corrected_time_s: float
    model_history_sha256: str

@dataclass(frozen=True)
class IdentityCandidateEdge:
    left_local_track_key: str
    right_local_track_key: str
    provenance: tuple[str, ...]

    @property
    def pair(self) -> tuple[str, str]:
        return (self.left_local_track_key, self.right_local_track_key)

@dataclass(frozen=True)
class IdentityCandidateSearchMode:
    left_sensor_id: str
    right_sensor_id: str
    mode: str
    cartesian_pair_count: int

@dataclass(frozen=True)
class IdentityCandidatePairSets:
    nodes: tuple[IdentityCandidateNode, ...]
    model_edges: tuple[IdentityCandidateEdge, ...]
    mby_audit_edges: tuple[IdentityCandidateEdge, ...]
    search_modes: tuple[IdentityCandidateSearchMode, ...]
    birth_window_s: float
    exhaustive_pair_limit: int
    maximum_candidates_per_other_sensor: int
    candidate_search_radius_m: float
    candidate_domain_version: str = 's0-model-v1'

    @classmethod
    def empty(cls) -> 'IdentityCandidatePairSets':
        return cls((), (), (), (), 0.0, 0, 0, 0.0)

    @property
    def node_ids(self) -> tuple[str, ...]:
        return tuple((node.local_track_key for node in self.nodes))

    @property
    def model_pairs(self) -> tuple[tuple[str, str], ...]:
        return tuple((edge.pair for edge in self.model_edges))

    @property
    def mby_audit_pairs(self) -> tuple[tuple[str, str], ...]:
        return tuple((edge.pair for edge in self.mby_audit_edges))

    @property
    def audit_only_edges(self) -> tuple[IdentityCandidateEdge, ...]:
        model_pairs = set(self.model_pairs)
        return tuple((edge for edge in self.mby_audit_edges if edge.pair not in model_pairs))

    @property
    def audit_only_pairs(self) -> tuple[tuple[str, str], ...]:
        return tuple((edge.pair for edge in self.audit_only_edges))

    @property
    def legacy_pairs(self) -> tuple[tuple[str, str], ...]:
        return tuple(sorted(set(self.model_pairs) | set(self.mby_audit_pairs)))

@dataclass(frozen=True)
class GlobalTrackMembership:
    global_target_id: str
    fusion_track_id: str
    association_mode: str
    local_track_key: str
    local_target_id: str
    sensor_id: str
    zbb: str
    source_track_id: str
    report_count: int
    first_time_s: float
    last_time_s: float
    supporting_peer_count: int
    supporting_local_track_keys: List[str]

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

@dataclass(frozen=True)
class GlobalIdentityResolution:
    detections: List[RawDetection]
    memberships: List[GlobalTrackMembership]
    pair_diagnostics: List[LocalTrackPairDiagnostic]
    global_target_track_ids: Dict[str, str]
    local_track_to_global_target: Dict[str, str]
    identity_learning_audits: List[Any] = field(default_factory=list)
    candidate_pair_sets: IdentityCandidatePairSets = field(default_factory=IdentityCandidatePairSets.empty)

def _local_track_key(detection: RawDetection) -> str:
    return str(detection.local_track_key or detection.source_track_id)

def _local_target_id(detection: RawDetection) -> str:
    return str(detection.local_target_id or detection.target_id)

def _sensor_zbb(sensor_id: str, sensors: Mapping[str, Mapping[str, object]]) -> str:
    return str(sensors.get(sensor_id, {}).get('zbb', sensor_id))

def _model_history_sha256(items: Sequence[NormalizedDetection]) -> str:
    records = [{'corrected_time_s': float(item.corrected_time_s), 'state_enu': np.asarray(item.state_enu, dtype=float).tolist(), 'covariance': np.asarray(item.covariance, dtype=float).tolist(), 'score': float(item.score), 'rcs_dbsm': float(item.rcs_dbsm)} for item in items]
    payload = json.dumps(records, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()

def _pair_diagnostic(left_key: str, right_key: str, left_items: Sequence[NormalizedDetection], right_items: Sequence[NormalizedDetection], sensors: Mapping[str, Mapping[str, object]], scenario: Mapping[str, object], tracker: Mapping[str, object], identity: Mapping[str, object]) -> LocalTrackPairDiagnostic:
    left = sorted(left_items, key=lambda item: (item.corrected_time_s, item.detection_id))
    right = sorted(right_items, key=lambda item: (item.corrected_time_s, item.detection_id))
    left_first, right_first = (left[0], right[0])
    birth_window_s = float(tracker['birth_window_s'])
    position_gate = float(chi2.ppf(float(identity.get('position_gate_probability', tracker['birth_gate_probability'])), df=3))
    velocity_gate = float(chi2.ppf(float(identity.get('velocity_gate_probability', 0.999)), df=3)) * float(identity.get('velocity_gate_multiplier', 4.0))
    minimum_pair_support = int(identity.get('minimum_pair_support', 2))
    minimum_time_bins = int(identity.get('minimum_compatible_time_bins', tracker.get('birth_min_time_bins', 2)))
    minimum_fraction = float(identity.get('minimum_compatible_fraction', 0.35))
    base_epoch = float(scenario['base_epoch_s'])
    window_s = float(scenario['window_s'])
    right_times = np.asarray([item.corrected_time_s for item in right], dtype=float)
    temporal_pair_count = 0
    compatible_pair_count = 0
    compatible_bins = set()
    position_distances: List[float] = []
    position_nis_values: List[float] = []
    velocity_nis_values: List[float] = []
    for left_item in left:
        start = int(np.searchsorted(right_times, left_item.corrected_time_s - birth_window_s, side='left'))
        stop = int(np.searchsorted(right_times, left_item.corrected_time_s + birth_window_s, side='right'))
        best = None
        best_rank = None
        for right_item in right[start:stop]:
            temporal_pair_count += 1
            event_time = max(left_item.corrected_time_s, right_item.corrected_time_s)
            left_state, left_covariance = TentativeBirthManager._aligned(left_item, event_time)
            right_state, right_covariance = TentativeBirthManager._aligned(right_item, event_time)
            position_difference = left_state[:3] - right_state[:3]
            position_covariance = left_covariance[:3, :3] + right_covariance[:3, :3]
            position_nis = float(position_difference @ np.linalg.solve(position_covariance, position_difference))
            velocity_difference = left_state[3:] - right_state[3:]
            velocity_covariance = left_covariance[3:, 3:] + right_covariance[3:, 3:]
            velocity_nis = float(velocity_difference @ np.linalg.solve(velocity_covariance, velocity_difference))
            rank = (position_nis / max(position_gate, 1e-12), velocity_nis)
            if best_rank is None or rank < best_rank:
                best_rank = rank
                best = (event_time, position_difference, position_nis, velocity_nis)
        if best is None:
            continue
        event_time, position_difference, position_nis, velocity_nis = best
        position_distances.append(float(np.linalg.norm(position_difference)))
        position_nis_values.append(position_nis)
        velocity_nis_values.append(velocity_nis)
        if position_nis <= position_gate and velocity_nis <= velocity_gate:
            compatible_pair_count += 1
            compatible_bins.add(max(0, int((event_time - base_epoch) // window_s)))
    common_support_denominator = max(1, min(len(left), len(right)))
    compatible_fraction = min(1.0, float(compatible_pair_count / common_support_denominator))
    compatible = bool(compatible_pair_count >= minimum_pair_support and len(compatible_bins) >= minimum_time_bins and (compatible_fraction >= minimum_fraction))
    if compatible:
        reason = f'跨装备局部航迹在{len(compatible_bins)}个时间片内持续通过位置/速度门控，可共同支持一个全局目标出生。'
    elif temporal_pair_count == 0:
        reason = '两条局部航迹在出生时间窗内没有时间邻近报告。'
    elif compatible_pair_count == 0:
        reason = '存在时间邻近报告，但没有报告对同时通过位置和速度门控。'
    elif len(compatible_bins) < minimum_time_bins:
        reason = '通过门控的报告没有覆盖足够的融合时间片。'
    else:
        reason = '通过门控的报告比例不足，不能证明两条局部航迹持续属于同一目标。'
    return LocalTrackPairDiagnostic(left_local_track_key=left_key, right_local_track_key=right_key, left_sensor_id=left_first.sensor_id, right_sensor_id=right_first.sensor_id, left_zbb=_sensor_zbb(left_first.sensor_id, sensors), right_zbb=_sensor_zbb(right_first.sensor_id, sensors), left_local_target_id=str(left_first.target_id), right_local_target_id=str(right_first.target_id), temporal_pair_count=temporal_pair_count, compatible_pair_count=compatible_pair_count, compatible_time_bin_count=len(compatible_bins), compatible_fraction=compatible_fraction, minimum_position_distance_m=min(position_distances) if position_distances else None, median_position_mahalanobis_sq=float(np.median(position_nis_values)) if position_nis_values else None, median_velocity_mahalanobis_sq=float(np.median(velocity_nis_values)) if velocity_nis_values else None, position_gate_threshold=position_gate, velocity_gate_threshold=velocity_gate, compatible=compatible, reason=reason)

def _candidate_pair_sets(keys: Sequence[str], raw_by_key: Mapping[str, Sequence[RawDetection]], normalized_by_key: Mapping[str, Sequence[NormalizedDetection]], tracker: Mapping[str, object], identity: Mapping[str, object]) -> IdentityCandidatePairSets:
    keys_by_sensor: Dict[str, List[str]] = {}
    for key in keys:
        keys_by_sensor.setdefault(raw_by_key[key][0].sensor_id, []).append(key)
    representatives = {key: np.median(np.asarray([item.state_enu[:3] for item in normalized_by_key[key]], dtype=float), axis=0) for key in keys}
    time_ranges = {key: (float(normalized_by_key[key][0].corrected_time_s), float(normalized_by_key[key][-1].corrected_time_s)) for key in keys}
    local_mby = {key: _local_target_id(raw_by_key[key][0]) for key in keys}
    birth_window = float(tracker['birth_window_s'])
    exhaustive_limit = int(identity.get('exhaustive_pair_limit', 10000))
    maximum_neighbors = int(identity.get('maximum_candidates_per_other_sensor', 16))
    search_radius = float(identity.get('candidate_search_radius_m', 50000.0))

    def overlaps(left_key: str, right_key: str) -> bool:
        left_start, left_end = time_ranges[left_key]
        right_start, right_end = time_ranges[right_key]
        return max(left_start, right_start) <= min(left_end, right_end) + birth_window
    model_provenance: Dict[tuple[str, str], set[str]] = {}
    mby_audit_matches: set[tuple[str, str]] = set()
    search_modes: List[IdentityCandidateSearchMode] = []

    def add_model_pair(left_key: str, right_key: str, provenance: str) -> None:
        pair = tuple(sorted((left_key, right_key)))
        model_provenance.setdefault(pair, set()).add(provenance)
    sensor_ids = sorted(keys_by_sensor)
    for sensor_index, left_sensor in enumerate(sensor_ids):
        left_keys = sorted(keys_by_sensor[left_sensor])
        for right_sensor in sensor_ids[sensor_index + 1:]:
            right_keys = sorted(keys_by_sensor[right_sensor])
            right_by_mby: Dict[str, List[str]] = {}
            for right_key in right_keys:
                right_by_mby.setdefault(local_mby[right_key], []).append(right_key)
            for left_key in left_keys:
                for right_key in right_by_mby.get(local_mby[left_key], []):
                    if overlaps(left_key, right_key):
                        mby_audit_matches.add(tuple(sorted((left_key, right_key))))
            if len(left_keys) * len(right_keys) <= exhaustive_limit:
                search_modes.append(IdentityCandidateSearchMode(left_sensor_id=left_sensor, right_sensor_id=right_sensor, mode='exhaustive_time_overlap', cartesian_pair_count=len(left_keys) * len(right_keys)))
                for left_key in left_keys:
                    for right_key in right_keys:
                        if overlaps(left_key, right_key):
                            add_model_pair(left_key, right_key, 'cross_sensor_time_overlap_exhaustive')
                continue
            search_modes.append(IdentityCandidateSearchMode(left_sensor_id=left_sensor, right_sensor_id=right_sensor, mode='bidirectional_kdtree_radius', cartesian_pair_count=len(left_keys) * len(right_keys)))

            def add_nearest(query_keys: Sequence[str], reference_keys: Sequence[str]) -> None:
                tree = cKDTree(np.asarray([representatives[key] for key in reference_keys]))
                neighbor_count = min(maximum_neighbors, len(reference_keys))
                for query_key in query_keys:
                    distances, indices = tree.query(representatives[query_key], k=neighbor_count, distance_upper_bound=search_radius)
                    for distance, reference_index in zip(np.atleast_1d(distances), np.atleast_1d(indices)):
                        if not np.isfinite(distance) or int(reference_index) >= len(reference_keys):
                            continue
                        reference_key = reference_keys[int(reference_index)]
                        if overlaps(query_key, reference_key):
                            add_model_pair(query_key, reference_key, 'cross_sensor_bidirectional_kdtree_radius')
            add_nearest(left_keys, right_keys)
            add_nearest(right_keys, left_keys)
    model_pairs = set(model_provenance)
    nodes = tuple((IdentityCandidateNode(local_track_key=key, sensor_id=str(raw_by_key[key][0].sensor_id), report_count=len(normalized_by_key[key]), first_corrected_time_s=float(normalized_by_key[key][0].corrected_time_s), last_corrected_time_s=float(normalized_by_key[key][-1].corrected_time_s), model_history_sha256=_model_history_sha256(normalized_by_key[key])) for key in sorted(keys)))
    model_edges = tuple((IdentityCandidateEdge(left_local_track_key=pair[0], right_local_track_key=pair[1], provenance=tuple(sorted(model_provenance[pair]))) for pair in sorted(model_pairs)))
    mby_audit_edges = tuple((IdentityCandidateEdge(left_local_track_key=pair[0], right_local_track_key=pair[1], provenance=('A-MBY',)) for pair in sorted(mby_audit_matches)))
    return IdentityCandidatePairSets(nodes=nodes, model_edges=model_edges, mby_audit_edges=mby_audit_edges, search_modes=tuple(search_modes), birth_window_s=birth_window, exhaustive_pair_limit=exhaustive_limit, maximum_candidates_per_other_sensor=maximum_neighbors, candidate_search_radius_m=search_radius)

def _candidate_pairs(keys: Sequence[str], raw_by_key: Mapping[str, Sequence[RawDetection]], normalized_by_key: Mapping[str, Sequence[NormalizedDetection]], tracker: Mapping[str, object], identity: Mapping[str, object]) -> List[tuple[str, str]]:
    return list(_candidate_pair_sets(keys, raw_by_key, normalized_by_key, tracker, identity).legacy_pairs)

def resolve_global_identities(raw_detections: Sequence[RawDetection], normalized_detections: Sequence[NormalizedDetection], runtime_config: dict, identity_learning: Optional[Any]=None) -> GlobalIdentityResolution:
    if not raw_detections:
        return GlobalIdentityResolution([], [], [], {}, {}, [])
    normalized_by_id = {item.detection_id: item for item in normalized_detections}
    raw_by_key: Dict[str, List[RawDetection]] = {}
    normalized_by_key: Dict[str, List[NormalizedDetection]] = {}
    for raw in raw_detections:
        key = _local_track_key(raw)
        raw_by_key.setdefault(key, []).append(raw)
        normalized_by_key.setdefault(key, []).append(normalized_by_id[raw.detection_id])
    for items in raw_by_key.values():
        items.sort(key=lambda item: (item.measurement_time_s, item.detection_id))
    for items in normalized_by_key.values():
        items.sort(key=lambda item: (item.corrected_time_s, item.detection_id))
    keys = sorted(raw_by_key)
    sensors = runtime_config['sensors']
    scenario = runtime_config['scenario']
    tracker = runtime_config['tracker']
    identity = runtime_config.get('identity', {})
    pair_diagnostics: List[LocalTrackPairDiagnostic] = []
    diagnostic_by_pair: Dict[tuple[str, str], LocalTrackPairDiagnostic] = {}
    candidate_pair_sets = _candidate_pair_sets(keys, raw_by_key, normalized_by_key, tracker, identity)
    for left_key, right_key in candidate_pair_sets.legacy_pairs:
        diagnostic = _pair_diagnostic(left_key, right_key, normalized_by_key[left_key], normalized_by_key[right_key], sensors, scenario, tracker, identity)
        pair_diagnostics.append(diagnostic)
        diagnostic_by_pair[left_key, right_key] = diagnostic
    identity_learning_audits: List[Any] = []
    if identity_learning is not None and pair_diagnostics:
        from real_fusion.learning.features.identity import build_track_pair_example
        task_id = str(getattr(identity_learning, 'task_id', scenario.get('name', 'unspecified-task')))
        examples = []
        baseline_decisions: List[bool] = []
        audit_by_pair: Dict[tuple[str, str], Any] = {}
        for diagnostic in pair_diagnostics:
            pair = (diagnostic.left_local_track_key, diagnostic.right_local_track_key)
            try:
                example = build_track_pair_example(task_id=task_id, left_local_track_key=pair[0], right_local_track_key=pair[1], left_items=normalized_by_key[pair[0]], right_items=normalized_by_key[pair[1]], tracker_config=tracker, identity_config=identity, scenario_config=scenario, metadata={'left_sensor_id': diagnostic.left_sensor_id, 'right_sensor_id': diagnostic.right_sensor_id})
            except Exception:
                audit_by_pair[pair] = identity_learning.feature_failure_audit(task_id=task_id, left_local_track_key=pair[0], right_local_track_key=pair[1], baseline_decision=diagnostic.compatible, reason='feature_invalid')
                continue
            examples.append(example)
            baseline_decisions.append(diagnostic.compatible)
        if examples:
            try:
                evaluated = identity_learning.evaluate_pairs(examples, baseline_decisions)
            except Exception:
                evaluated = [identity_learning.feature_failure_audit(task_id=example.task_id, left_local_track_key=example.left_local_track_key, right_local_track_key=example.right_local_track_key, baseline_decision=baseline, hard_physical_gate_passed=example.hard_physical_gate_passed, reason='inference_error') for example, baseline in zip(examples, baseline_decisions)]
            for audit in evaluated:
                audit_by_pair[audit.left_local_track_key, audit.right_local_track_key] = audit
        identity_learning_audits = [audit_by_pair[item.left_local_track_key, item.right_local_track_key] for item in pair_diagnostics if (item.left_local_track_key, item.right_local_track_key) in audit_by_pair]
    clusters: List[set[str]] = [{key} for key in keys]
    compatible_edges = sorted((item for item in pair_diagnostics if item.compatible), key=lambda item: (-item.compatible_time_bin_count, -item.compatible_fraction, item.median_position_mahalanobis_sq if item.median_position_mahalanobis_sq is not None else float('inf'), item.left_local_track_key, item.right_local_track_key))

    def cluster_for(key: str) -> set[str]:
        return next((cluster for cluster in clusters if key in cluster))

    def time_range(key: str) -> tuple[float, float]:
        values = normalized_by_key[key]
        return (values[0].corrected_time_s, values[-1].corrected_time_s)

    def may_merge(left_cluster: set[str], right_cluster: set[str]) -> bool:
        left_sensors = {raw_by_key[key][0].sensor_id for key in left_cluster}
        right_sensors = {raw_by_key[key][0].sensor_id for key in right_cluster}
        if left_sensors & right_sensors:
            return False
        birth_window = float(tracker['birth_window_s'])
        for left_key in left_cluster:
            for right_key in right_cluster:
                left_start, left_end = time_range(left_key)
                right_start, right_end = time_range(right_key)
                overlaps = max(left_start, right_start) <= min(left_end, right_end) + birth_window
                if not overlaps:
                    continue
                pair = tuple(sorted((left_key, right_key)))
                diagnostic = diagnostic_by_pair.get(pair)
                if diagnostic is None or not diagnostic.compatible:
                    return False
        return True
    for edge in compatible_edges:
        left_cluster = cluster_for(edge.left_local_track_key)
        right_cluster = cluster_for(edge.right_local_track_key)
        if left_cluster is right_cluster or not may_merge(left_cluster, right_cluster):
            continue
        merged = left_cluster | right_cluster
        clusters.remove(left_cluster)
        clusters.remove(right_cluster)
        clusters.append(merged)
    clusters.sort(key=lambda cluster: (min((raw_by_key[key][0].measurement_time_s for key in cluster)), min(cluster)))
    local_to_global: Dict[str, str] = {}
    global_track_ids: Dict[str, str] = {}
    memberships: List[GlobalTrackMembership] = []
    for index, cluster in enumerate(clusters, start=1):
        global_target_id = f'GT-{index:04d}'
        fusion_track_id = f'RF-{index:04d}'
        global_track_ids[global_target_id] = fusion_track_id
        association_mode = 'multi_sensor_birth' if len(cluster) > 1 else 'single_source'
        for key in sorted(cluster):
            local_to_global[key] = global_target_id
            items = raw_by_key[key]
            first = items[0]
            peers = sorted(cluster - {key})
            memberships.append(GlobalTrackMembership(global_target_id=global_target_id, fusion_track_id=fusion_track_id, association_mode=association_mode, local_track_key=key, local_target_id=_local_target_id(first), sensor_id=first.sensor_id, zbb=_sensor_zbb(first.sensor_id, sensors), source_track_id=first.source_track_id, report_count=len(items), first_time_s=float(items[0].measurement_time_s), last_time_s=float(items[-1].measurement_time_s), supporting_peer_count=len(peers), supporting_local_track_keys=peers))
    rewritten = [replace(item, target_id=local_to_global[_local_track_key(item)], local_target_id=_local_target_id(item), local_track_key=_local_track_key(item)) for item in raw_detections]
    rewritten.sort(key=lambda item: (item.arrival_time_s, item.target_id, item.sensor_id, item.frame_id))
    return GlobalIdentityResolution(detections=rewritten, memberships=memberships, pair_diagnostics=pair_diagnostics, global_target_track_ids=global_track_ids, local_track_to_global_target=local_to_global, identity_learning_audits=identity_learning_audits, candidate_pair_sets=candidate_pair_sets)
