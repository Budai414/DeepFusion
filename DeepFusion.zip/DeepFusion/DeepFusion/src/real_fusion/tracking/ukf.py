from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Tuple
import numpy as np
StateFunction = Callable[[np.ndarray, float], np.ndarray]
MeasurementFunction = Callable[[np.ndarray], np.ndarray]
MeasurementMeanFunction = Callable[[np.ndarray, np.ndarray], np.ndarray]
MeasurementResidualFunction = Callable[[np.ndarray, np.ndarray], np.ndarray]

def ensure_positive_definite(matrix: np.ndarray, jitter: float=1e-09) -> np.ndarray:
    symmetric = 0.5 * (matrix + matrix.T)
    minimum = float(np.min(np.linalg.eigvalsh(symmetric)))
    if minimum <= 0.0:
        symmetric = symmetric + np.eye(symmetric.shape[0]) * (-minimum + jitter)
    return symmetric

@dataclass(frozen=True)
class ConditionalUpdate:
    state: np.ndarray
    covariance: np.ndarray
    log_likelihood: float
    nis: float

class UnscentedKalmanFilter:

    def __init__(self, state: np.ndarray, covariance: np.ndarray, alpha: float, beta: float, kappa: float, jitter: float):
        self.state = np.asarray(state, dtype=float).copy()
        self.covariance = ensure_positive_definite(np.asarray(covariance, dtype=float), jitter)
        self.dimension = self.state.size
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.kappa = float(kappa)
        self.jitter = float(jitter)
        self.lambda_value = self.alpha ** 2 * (self.dimension + self.kappa) - self.dimension
        scale = self.dimension + self.lambda_value
        self.mean_weights = np.full(2 * self.dimension + 1, 0.5 / scale)
        self.covariance_weights = self.mean_weights.copy()
        self.mean_weights[0] = self.lambda_value / scale
        self.covariance_weights[0] = self.mean_weights[0] + 1.0 - self.alpha ** 2 + self.beta

    def copy(self) -> 'UnscentedKalmanFilter':
        return UnscentedKalmanFilter(self.state, self.covariance, self.alpha, self.beta, self.kappa, self.jitter)

    def _sigma_points(self, state: np.ndarray, covariance: np.ndarray) -> np.ndarray:
        covariance = ensure_positive_definite(covariance, self.jitter)
        scale = self.dimension + self.lambda_value
        for multiplier in (1.0, 10.0, 100.0, 1000.0):
            try:
                root = np.linalg.cholesky(scale * covariance + np.eye(self.dimension) * self.jitter * multiplier)
                break
            except np.linalg.LinAlgError:
                continue
        else:
            raise np.linalg.LinAlgError('Unable to form UKF sigma points from covariance.')
        sigma = np.empty((2 * self.dimension + 1, self.dimension), dtype=float)
        sigma[0] = state
        for index in range(self.dimension):
            sigma[index + 1] = state + root[:, index]
            sigma[self.dimension + index + 1] = state - root[:, index]
        return sigma

    def predict(self, dt: float, state_function: StateFunction, process_noise: np.ndarray) -> None:
        sigma = self._sigma_points(self.state, self.covariance)
        propagated = np.asarray([state_function(point, dt) for point in sigma], dtype=float)
        state = np.sum(self.mean_weights[:, None] * propagated, axis=0)
        covariance = np.asarray(process_noise, dtype=float).copy()
        for weight, point in zip(self.covariance_weights, propagated):
            difference = point - state
            covariance += weight * np.outer(difference, difference)
        self.state = state
        self.covariance = ensure_positive_definite(covariance, self.jitter)

    def conditional_update(self, measurement: np.ndarray, measurement_covariance: np.ndarray, measurement_function: MeasurementFunction=lambda state: state, measurement_mean_function: MeasurementMeanFunction | None=None, measurement_residual_function: MeasurementResidualFunction | None=None) -> ConditionalUpdate:
        sigma = self._sigma_points(self.state, self.covariance)
        measurement_sigma = np.asarray([measurement_function(point) for point in sigma], dtype=float)
        if measurement_mean_function is None:
            predicted_measurement = np.sum(self.mean_weights[:, None] * measurement_sigma, axis=0)
        else:
            predicted_measurement = np.asarray(measurement_mean_function(measurement_sigma, self.mean_weights), dtype=float)
        residual = measurement_residual_function or (lambda left, right: left - right)
        measurement_dimension = predicted_measurement.size
        innovation_covariance = np.asarray(measurement_covariance, dtype=float).copy()
        cross_covariance = np.zeros((self.dimension, measurement_dimension), dtype=float)
        for weight, state_point, measurement_point in zip(self.covariance_weights, sigma, measurement_sigma):
            state_difference = state_point - self.state
            measurement_difference = residual(measurement_point, predicted_measurement)
            innovation_covariance += weight * np.outer(measurement_difference, measurement_difference)
            cross_covariance += weight * np.outer(state_difference, measurement_difference)
        innovation_covariance = ensure_positive_definite(innovation_covariance, self.jitter)
        gain = np.linalg.solve(innovation_covariance, cross_covariance.T).T
        innovation = residual(np.asarray(measurement, dtype=float), predicted_measurement)
        updated_state = self.state + gain @ innovation
        updated_covariance = self.covariance - gain @ innovation_covariance @ gain.T
        updated_covariance = ensure_positive_definite(updated_covariance, self.jitter)
        nis = float(innovation @ np.linalg.solve(innovation_covariance, innovation))
        sign, log_determinant = np.linalg.slogdet(innovation_covariance)
        if sign <= 0:
            log_likelihood = float('-inf')
        else:
            log_likelihood = -0.5 * (measurement_dimension * np.log(2.0 * np.pi) + log_determinant + nis)
        return ConditionalUpdate(updated_state, updated_covariance, float(log_likelihood), nis)

def white_acceleration_process_noise(dt: float, acceleration_std: float) -> np.ndarray:
    variance = float(acceleration_std) ** 2
    noise = np.zeros((6, 6), dtype=float)
    for axis in range(3):
        noise[axis, axis] = variance * dt ** 4 / 4.0
        noise[axis, axis + 3] = variance * dt ** 3 / 2.0
        noise[axis + 3, axis] = variance * dt ** 3 / 2.0
        noise[axis + 3, axis + 3] = variance * dt ** 2
    return noise + np.eye(6) * 1e-09
