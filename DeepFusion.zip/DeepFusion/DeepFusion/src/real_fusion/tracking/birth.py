from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Tuple
import numpy as np
from scipy.stats import chi2
from real_fusion.models import NormalizedDetection
from real_fusion.tracking.ukf import ensure_positive_definite, white_acceleration_process_noise

@dataclass(frozen=True)
class BirthEstimate:
    event_time_s: float
    state: np.ndarray
    covariance: np.ndarray
    supporting_detections: List[NormalizedDetection]

class TentativeBirthManager:

    def __init__(self, scenario_config: dict, tracker_config: dict):
        self.base_epoch = float(scenario_config['base_epoch_s'])
        self.window_s = float(scenario_config['window_s'])
        self.birth_window_s = float(tracker_config['birth_window_s'])
        self.minimum_sensors = int(tracker_config['birth_min_sensors'])
        self.minimum_time_bins = int(tracker_config['birth_min_time_bins'])
        self.gate = float(chi2.ppf(tracker_config['birth_gate_probability'], df=3))
        self._candidates: List[NormalizedDetection] = []

    def add(self, detections: List[NormalizedDetection]) -> None:
        self._candidates.extend((item for item in detections if item.score >= 0.55))

    @staticmethod
    def _aligned(detection: NormalizedDetection, event_time_s: float) -> Tuple[np.ndarray, np.ndarray]:
        dt = max(0.0, event_time_s - detection.corrected_time_s)
        transition = np.eye(6)
        transition[:3, 3:] = np.eye(3) * dt
        state = transition @ detection.state_enu
        covariance = transition @ detection.covariance @ transition.T + white_acceleration_process_noise(dt, 2.5)
        return (state, ensure_positive_definite(covariance))

    def try_initialize(self, event_time_s: float) -> Optional[BirthEstimate]:
        cutoff = event_time_s - self.birth_window_s
        self._candidates = [item for item in self._candidates if item.corrected_time_s >= cutoff]
        if len({item.sensor_id for item in self._candidates}) < self.minimum_sensors:
            return None
        best_cluster = None
        best_rank = None
        aligned_cache = {item.detection_id: self._aligned(item, event_time_s) for item in self._candidates}
        for seed in self._candidates:
            seed_state, seed_covariance = aligned_cache[seed.detection_id]
            cluster = [seed]
            distance_sum = 0.0
            for sensor_id in {item.sensor_id for item in self._candidates if item.sensor_id != seed.sensor_id}:
                best_item = None
                best_distance = float('inf')
                for candidate in self._candidates:
                    if candidate.sensor_id != sensor_id:
                        continue
                    state, covariance = aligned_cache[candidate.detection_id]
                    difference = state[:3] - seed_state[:3]
                    distance = float(difference @ np.linalg.solve(seed_covariance[:3, :3] + covariance[:3, :3], difference))
                    if distance <= self.gate and distance < best_distance:
                        best_item = candidate
                        best_distance = distance
                if best_item is not None:
                    cluster.append(best_item)
                    distance_sum += best_distance
            time_bins = {max(0, int((item.corrected_time_s - self.base_epoch) // self.window_s)) for item in cluster}
            sensors = {item.sensor_id for item in cluster}
            rank = (len(sensors), len(time_bins), sum((item.score for item in cluster)), -distance_sum)
            if best_rank is None or rank > best_rank:
                best_rank = rank
                best_cluster = cluster
        if best_cluster is None:
            return None
        if len({item.sensor_id for item in best_cluster}) < self.minimum_sensors:
            return None
        if len({max(0, int((item.corrected_time_s - self.base_epoch) // self.window_s)) for item in best_cluster}) < self.minimum_time_bins:
            return None
        information_matrix = np.zeros((6, 6), dtype=float)
        information_vector = np.zeros(6, dtype=float)
        for item in best_cluster:
            state, covariance = aligned_cache[item.detection_id]
            inverse = np.linalg.inv(covariance)
            information_matrix += inverse
            information_vector += inverse @ state
        covariance = ensure_positive_definite(np.linalg.inv(information_matrix))
        state = covariance @ information_vector
        self._candidates.clear()
        return BirthEstimate(float(event_time_s), state, covariance, best_cluster)
