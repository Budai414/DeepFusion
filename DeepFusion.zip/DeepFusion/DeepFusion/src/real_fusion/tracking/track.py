from __future__ import annotations
from typing import Dict, List, Sequence, Set
import numpy as np
from real_fusion.models import AssociationResult, NormalizedDetection, TrackEstimate
from real_fusion.tracking.association import associate_single_track, select_known_source_continuation
from real_fusion.tracking.birth import BirthEstimate
from real_fusion.tracking.imm import IMMFilter

class FusionTrack:

    def __init__(self, track_id: str, target_id: str, birth: BirthEstimate, config: dict):
        self.track_id = track_id
        self.target_id = target_id
        self.config = config
        self.imm = IMMFilter(birth.state, birth.covariance, birth.event_time_s, config)
        self.lifecycle_state = 'confirmed'
        self.existence_probability = 0.9
        self.last_strong_update_s = birth.event_time_s
        self.known_sources: Set[str] = {item.source_track_id for item in birth.supporting_detections}
        self.current_associations: Dict[str, float] = {item.detection_id: 1.0 / len(birth.supporting_detections) for item in birth.supporting_detections}
        self.current_sources: Dict[str, Dict[str, object]] = {item.detection_id: {'detection_id': item.detection_id, 'sensor_id': item.sensor_id, 'target_id': item.target_id, 'local_target_id': item.local_target_id, 'local_track_key': item.local_track_key, 'source_track_id': item.source_track_id, 'probability': 1.0 / len(birth.supporting_detections)} for item in birth.supporting_detections}
        self.nis_values: List[float] = []

    def begin_window(self) -> None:
        self.current_associations = {}
        self.current_sources = {}

    def process_sensor_frame(self, event_time_s: float, detections: Sequence[NormalizedDetection], sensor_config: dict) -> AssociationResult:
        self.imm.predict_to(event_time_s)
        (predicted_state, predicted_covariance) = self.imm.fused_state()
        association = associate_single_track(predicted_state, predicted_covariance, detections, sensor_config, self.config['gating_probability'], self.known_sources)
        hit_threshold = float(self.config['hit_probability_threshold'])
        continuation_used = False
        continuation = None
        if bool(self.config.get('single_source_continuation_enabled', True)) and association.hit_probability < hit_threshold and (event_time_s - self.last_strong_update_s <= float(self.config['single_source_continuation_max_gap_s'])):
            continuation = select_known_source_continuation(predicted_state, predicted_covariance, detections, self.known_sources, float(self.config['single_source_continuation_gate_probability']), float(self.config['single_source_continuation_gate_multiplier']), float(self.config['single_source_continuation_max_residual_m']), float(self.config['single_source_continuation_covariance_inflation']))
        if continuation is not None:
            (item, position_nis) = continuation
            beta = float(self.config['single_source_continuation_probability'])
            self.imm.update_generic(item.state_enu[:3], item.covariance[:3, :3] * float(self.config['single_source_continuation_covariance_inflation']), beta, measurement_function=lambda state: state[:3])
            association = AssociationResult(missed_probability=1.0 - beta, detection_probabilities={item.detection_id: beta}, gated_detection_ids=[item.detection_id], nis_by_detection={item.detection_id: position_nis})
            gated = [item]
            continuation_used = True
        else:
            gated = [item for item in detections if item.detection_id in association.gated_detection_ids]
            self.imm.update_pda(gated, association.missed_probability, association.detection_probabilities)
        if association.hit_probability >= hit_threshold:
            self.last_strong_update_s = event_time_s
            self.existence_probability = min(0.999, self.existence_probability + 0.18 * association.hit_probability)
        else:
            self.existence_probability = max(0.01, self.existence_probability * 0.92)
        for item in gated:
            probability = association.detection_probabilities.get(item.detection_id, 0.0)
            if probability >= float(self.config['source_record_beta']):
                self.known_sources.add(item.source_track_id)
                self.current_associations[item.detection_id] = probability
                self.current_sources[item.detection_id] = {'detection_id': item.detection_id, 'sensor_id': item.sensor_id, 'target_id': item.target_id, 'local_target_id': item.local_target_id, 'local_track_key': item.local_track_key, 'source_track_id': item.source_track_id, 'probability': probability, 'association_mode': 'known_source_single_continuation' if continuation_used else 'pda'}
                self.nis_values.append(association.nis_by_detection[item.detection_id])
        return association

    def predict_to(self, event_time_s: float) -> None:
        self.imm.predict_to(event_time_s)
        age_since_update = event_time_s - self.last_strong_update_s
        if age_since_update >= float(self.config['delete_after_s']):
            self.lifecycle_state = 'deleted'
            self.existence_probability = max(0.0, self.existence_probability * 0.5)
        elif age_since_update >= float(self.config['coast_after_s']):
            self.lifecycle_state = 'coasting'
            self.existence_probability = max(0.05, self.existence_probability * 0.96)
        else:
            self.lifecycle_state = 'confirmed'

    def estimate(self, event_time_s: float) -> TrackEstimate:
        self.predict_to(event_time_s)
        (state, covariance) = self.imm.fused_state()
        lifecycle_state = self.lifecycle_state
        active_sources = {str(item['source_track_id']) for item in self.current_sources.values()}
        if lifecycle_state == 'confirmed' and len(self.known_sources) >= 2 and (len(active_sources) == 1):
            lifecycle_state = 'single_source_continuation'
        return TrackEstimate(track_id=self.track_id, target_id=self.target_id, event_time_s=event_time_s, state_enu=state, covariance=covariance, lifecycle_state=lifecycle_state, existence_probability=float(self.existence_probability), model_probabilities=self.imm.probability_dict(), associated_detection_ids=sorted(self.current_associations), association_probabilities=dict(sorted(self.current_associations.items())), associated_sources=[self.current_sources[key] for key in sorted(self.current_sources)])
