from __future__ import annotations
from typing import Iterable, Optional, Sequence, Set, Tuple
import numpy as np
from scipy.special import logsumexp
from scipy.stats import chi2
from real_fusion.models import AssociationResult, NormalizedDetection

def select_known_source_continuation(predicted_state: np.ndarray, predicted_covariance: np.ndarray, detections: Sequence[NormalizedDetection], known_sources: Iterable[str], gate_probability: float, gate_multiplier: float, maximum_position_residual_m: float, covariance_inflation: float) -> Optional[Tuple[NormalizedDetection, float]]:
    known = set(known_sources)
    if not known:
        return None
    gate = float(chi2.ppf(float(gate_probability), df=3)) * float(gate_multiplier)
    best: Optional[Tuple[NormalizedDetection, float]] = None
    best_rank: Optional[Tuple[float, float, str]] = None
    for detection in detections:
        if detection.source_track_id not in known:
            continue
        innovation = detection.state_enu[:3] - predicted_state[:3]
        residual_m = float(np.linalg.norm(innovation))
        if residual_m > float(maximum_position_residual_m):
            continue
        innovation_covariance = predicted_covariance[:3, :3] + detection.covariance[:3, :3] * float(covariance_inflation)
        position_nis = float(innovation @ np.linalg.solve(innovation_covariance, innovation))
        if position_nis > gate:
            continue
        rank = (position_nis, residual_m, detection.detection_id)
        if best_rank is None or rank < best_rank:
            best = (detection, position_nis)
            best_rank = rank
    return best

def associate_single_track(predicted_state: np.ndarray, predicted_covariance: np.ndarray, detections: Sequence[NormalizedDetection], sensor_config: dict, gating_probability: float, known_sources: Iterable[str]=()) -> AssociationResult:
    gate = float(chi2.ppf(gating_probability, df=6))
    known: Set[str] = set(known_sources)
    gated = []
    log_weights = []
    nis_by_detection = {}
    detection_probability = float(sensor_config['detection_probability'])
    for detection in detections:
        innovation = detection.state_enu - predicted_state
        innovation_covariance = predicted_covariance + detection.covariance
        nis = float(innovation @ np.linalg.solve(innovation_covariance, innovation))
        nis_by_detection[detection.detection_id] = nis
        if nis > gate:
            continue
        source_bonus = np.log(1.35) if detection.source_track_id in known else 0.0
        log_weight = np.log(max(detection_probability, 1e-09)) + np.log(max(detection.score, 1e-09)) - 0.5 * nis + source_bonus
        gated.append(detection)
        log_weights.append(log_weight)
    missed_log_weight = np.log(max(1.0 - detection_probability, 1e-06)) + np.log(0.5)
    normalization = logsumexp([missed_log_weight] + log_weights)
    missed_probability = float(np.exp(missed_log_weight - normalization))
    probabilities = {detection.detection_id: float(np.exp(log_weight - normalization)) for (detection, log_weight) in zip(gated, log_weights)}
    return AssociationResult(missed_probability=missed_probability, detection_probabilities=probabilities, gated_detection_ids=[item.detection_id for item in gated], nis_by_detection=nis_by_detection)
