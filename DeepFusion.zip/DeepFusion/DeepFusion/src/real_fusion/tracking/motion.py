from __future__ import annotations
from typing import Callable
import numpy as np

def cruise(state: np.ndarray, dt: float) -> np.ndarray:
    result = state.copy()
    result[:3] += state[3:] * dt
    return result

def hover(state: np.ndarray, dt: float, tau: float=2.0) -> np.ndarray:
    result = state.copy()
    factor = np.exp(-dt / tau)
    result[:3] += state[3:] * tau * (1.0 - factor)
    result[3:] *= factor
    return result

def coordinated_turn(state: np.ndarray, dt: float, turn_rate_rad_s: float) -> np.ndarray:
    if abs(turn_rate_rad_s) < 1e-09:
        return cruise(state, dt)
    result = state.copy()
    angle = turn_rate_rad_s * dt
    (cosine, sine) = (np.cos(angle), np.sin(angle))
    (east_velocity, north_velocity) = (state[3], state[4])
    result[0] += sine / turn_rate_rad_s * east_velocity - (1.0 - cosine) / turn_rate_rad_s * north_velocity
    result[1] += (1.0 - cosine) / turn_rate_rad_s * east_velocity + sine / turn_rate_rad_s * north_velocity
    result[2] += state[5] * dt
    result[3] = cosine * east_velocity - sine * north_velocity
    result[4] = sine * east_velocity + cosine * north_velocity
    return result

def build_motion_function(model_name: str, turn_rate_deg_s: float) -> Callable[[np.ndarray, float], np.ndarray]:
    if model_name == 'hover':
        return hover
    if model_name == 'cruise':
        return cruise
    rate = np.deg2rad(float(turn_rate_deg_s))
    return lambda state, dt: coordinated_turn(state, dt, rate)
