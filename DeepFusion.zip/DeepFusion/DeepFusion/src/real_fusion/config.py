from __future__ import annotations
import math
from pathlib import Path
from typing import Any, Dict
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import yaml
SW_SCHEMA_COLUMN_COUNT = 56
SW_CORE_COLUMN_INDEX = {'MBY': 2, 'ZBB': 3, 'MBJ': 16, 'MBW': 17, 'HB': 51, 'RCS': 22, 'JDSC': 53}
EW_SCHEMA_COLUMN_COUNT = 55
EW_CORE_COLUMN_INDEX = {'MBY': 2, 'ZBB': 3, 'XJ': 16, 'FW': 17, 'FY': 18, 'FW_RATE': 19, 'FY_RATE': 20, 'RCS': 21, 'HB': 50, 'JDSC': 52}

def _derive_sw_core_columns(expected_columns: list[str]) -> Dict[str, str]:
    if len(expected_columns) != SW_SCHEMA_COLUMN_COUNT:
        raise ValueError(f'sw.expected_columns 必须保持 {SW_SCHEMA_COLUMN_COUNT} 列，实际为 {len(expected_columns)} 列。')
    core_columns = {role: expected_columns[index] for (role, index) in SW_CORE_COLUMN_INDEX.items()}
    if len(set(core_columns.values())) != len(core_columns):
        raise ValueError('目标编号、装备编号、目标经度、目标纬度、海拔、第23项和绝对时戳的列名必须各不相同。')
    return core_columns

def _derive_ew_core_columns(expected_columns: list[str]) -> Dict[str, str]:
    if len(expected_columns) != EW_SCHEMA_COLUMN_COUNT:
        raise ValueError(f'ew.expected_columns 必须保持 {EW_SCHEMA_COLUMN_COUNT} 列，实际为 {len(expected_columns)} 列。')
    core_columns = {role: expected_columns[index] for (role, index) in EW_CORE_COLUMN_INDEX.items()}
    if len(set(core_columns.values())) != len(core_columns):
        raise ValueError('EW 的目标、装备、角度、斜距、RCS、海拔和绝对时戳列名必须各不相同。')
    return core_columns

def _load_yaml_mapping(path: Path, label: str) -> Dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f'{label}不存在: {path}')
    with path.open('r', encoding='utf-8') as handle:
        data = yaml.safe_load(handle) or {}
    if not isinstance(data, dict):
        raise ValueError(f'{label}最外层必须是 YAML 映射: {path}')
    return data

def _prepare_sw_input_config(config: Dict[str, Any], config_path: Path) -> None:
    sw = config.get('sw')
    if not isinstance(sw, dict):
        return
    expected_columns = sw.get('expected_columns')
    if not isinstance(expected_columns, list) or not expected_columns:
        raise ValueError('sw.expected_columns 必须在 real_sw.yaml 中提供非空的56列名称列表。')
    normalized_columns = [str(column).strip() for column in expected_columns]
    if any((not column for column in normalized_columns)):
        raise ValueError('sw.expected_columns 不能包含空列名。')
    duplicate_columns = sorted({column for column in normalized_columns if normalized_columns.count(column) > 1})
    if duplicate_columns:
        raise ValueError(f'sw.expected_columns 存在重复列名: {duplicate_columns}')
    sw['expected_columns'] = normalized_columns
    sw['header_aliases'] = {str(key).strip(): str(value).strip() for (key, value) in (sw.get('header_aliases') or {}).items()}
    sw['_core_columns'] = _derive_sw_core_columns(sw['expected_columns'])
    sw.setdefault('sheet_name', 0)
    sw.setdefault('header_row', 1)
    sw.setdefault('trim_header_whitespace', True)
    sw.setdefault('allow_extra_columns', False)
    sw.setdefault('require_exact_header_order', False)
    timezone_name = str(sw.setdefault('timezone', 'Asia/Shanghai')).strip()
    if not timezone_name:
        raise ValueError('sw.timezone 不能为空，必须填写 IANA 时区名称，例如 Asia/Shanghai 或 UTC。')
    try:
        ZoneInfo(timezone_name)
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise ValueError(f'sw.timezone 不是可识别的 IANA 时区名称: {timezone_name!r}。例如中国标准时间使用 Asia/Shanghai，协调世界时使用 UTC。') from error
    sw['timezone'] = timezone_name
    position_validation = sw.setdefault('position_validation', {})
    if not isinstance(position_validation, dict):
        raise ValueError('sw.position_validation 必须是 YAML 映射。')
    position_validation.setdefault('reject_zero_longitude', True)
    position_validation.setdefault('reject_zero_latitude', True)
    position_validation.setdefault('reject_zero_altitude', True)
    position_validation.setdefault('zero_epsilon', 1e-09)
    position_validation.setdefault('longitude_range_deg', [-180.0, 180.0])
    position_validation.setdefault('latitude_range_deg', [-90.0, 90.0])
    position_validation.setdefault('altitude_range_m', [-1000.0, 100000.0])
    for key in ('reject_zero_longitude', 'reject_zero_latitude', 'reject_zero_altitude'):
        if not isinstance(position_validation[key], bool):
            raise ValueError(f'sw.position_validation.{key} 必须是 true 或 false。')
    try:
        zero_epsilon = float(position_validation['zero_epsilon'])
    except (TypeError, ValueError) as error:
        raise ValueError('sw.position_validation.zero_epsilon 必须是非负数值。') from error
    if not math.isfinite(zero_epsilon) or zero_epsilon < 0.0:
        raise ValueError('sw.position_validation.zero_epsilon 必须是有限非负数值。')
    position_validation['zero_epsilon'] = zero_epsilon
    for key in ('longitude_range_deg', 'latitude_range_deg', 'altitude_range_m'):
        values = position_validation[key]
        if not isinstance(values, list) or len(values) != 2:
            raise ValueError(f'sw.position_validation.{key} 必须是 [最小值, 最大值]。')
        try:
            numeric = [float(value) for value in values]
        except (TypeError, ValueError) as error:
            raise ValueError(f'sw.position_validation.{key} 必须全部是数值。') from error
        if not all((math.isfinite(value) for value in numeric)) or numeric[0] >= numeric[1]:
            raise ValueError(f'sw.position_validation.{key} 必须是递增的两个有限数值。')
        position_validation[key] = numeric
    sw['_input_config_path'] = str(config_path)
    sw['_schema_name'] = str(sw.get('schema_name', 'sw'))

def _prepare_ew_input_config(config: Dict[str, Any], config_path: Path) -> None:
    ew = config.get('ew')
    if ew is None:
        return
    if not isinstance(ew, dict):
        raise ValueError('ew 必须是 YAML 映射。')
    expected_columns = ew.get('expected_columns')
    if not isinstance(expected_columns, list) or not expected_columns:
        raise ValueError('ew.expected_columns 必须提供非空的55列名称列表。')
    normalized_columns = [str(column).strip() for column in expected_columns]
    if any((not column for column in normalized_columns)):
        raise ValueError('ew.expected_columns 不能包含空列名。')
    duplicates = sorted({column for column in normalized_columns if normalized_columns.count(column) > 1})
    if duplicates:
        raise ValueError(f'ew.expected_columns 存在重复列名: {duplicates}')
    ew['expected_columns'] = normalized_columns
    ew['_core_columns'] = _derive_ew_core_columns(normalized_columns)
    ew['_input_config_path'] = str(config_path)
    ew['_schema_name'] = str(ew.get('schema_name', 'ew'))
    ew.setdefault('sheet_name', 0)
    ew.setdefault('header_row', 1)
    ew.setdefault('trim_header_whitespace', True)
    ew.setdefault('header_aliases', {})
    ew.setdefault('schema_validation', 'strict')
    ew.setdefault('allow_extra_columns', False)
    ew.setdefault('require_exact_header_order', False)
    ew.setdefault('invalid_row_policy', 'drop')
    ew.setdefault('max_rejected_examples', 20)
    ew.setdefault('range_zero_is_missing', True)
    ew.setdefault('range_zero_epsilon_m', 1e-09)
    ew.setdefault('timezone', str(config.get('sw', {}).get('timezone', 'Asia/Shanghai')))
    try:
        ZoneInfo(str(ew['timezone']))
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise ValueError(f"ew.timezone 不是可识别的 IANA 时区名称: {ew['timezone']!r}。") from error
    measurement = ew.setdefault('measurement', {})
    if not isinstance(measurement, dict):
        raise ValueError('ew.measurement 必须是 YAML 映射。')
    measurement.setdefault('range_scale_m_per_unit', 1.0)
    measurement.setdefault('azimuth_scale_deg_per_unit', 0.01)
    measurement.setdefault('elevation_scale_deg_per_unit', 0.01)
    measurement.setdefault('azimuth_rate_scale_deg_s_per_unit', 0.01)
    measurement.setdefault('elevation_rate_scale_deg_s_per_unit', 0.01)
    measurement.setdefault('azimuth_range_deg', [0.0, 360.0])
    measurement.setdefault('elevation_range_deg', [-90.0, 90.0])
    measurement.setdefault('azimuth_rate_range_deg_s', [-20.0, 20.0])
    measurement.setdefault('elevation_rate_range_deg_s', [-20.0, 20.0])
    measurement.setdefault('azimuth_std_deg', 1.5)
    measurement.setdefault('elevation_std_deg', 1.5)
    measurement.setdefault('range_std_m', 120.0)
    measurement.setdefault('altitude_std_m', 150.0)
    measurement.setdefault('configured_time_correction_s', 0.0)
    measurement.setdefault('azimuth_bias_deg', 0.0)
    measurement.setdefault('elevation_bias_deg', 0.0)
    measurement.setdefault('range_bias_m', 0.0)
    for key in ('range_scale_m_per_unit', 'azimuth_scale_deg_per_unit', 'elevation_scale_deg_per_unit', 'azimuth_rate_scale_deg_s_per_unit', 'elevation_rate_scale_deg_s_per_unit'):
        try:
            value = float(measurement[key])
        except (TypeError, ValueError) as error:
            raise ValueError(f'ew.measurement.{key} 必须是正数。') from error
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f'ew.measurement.{key} 必须是有限正数。')
        measurement[key] = value
    for key in ('azimuth_range_deg', 'elevation_range_deg', 'azimuth_rate_range_deg_s', 'elevation_rate_range_deg_s'):
        bounds = measurement[key]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(f'ew.measurement.{key} 必须是[最小值, 最大值]。')
        try:
            numeric = [float(value) for value in bounds]
        except (TypeError, ValueError) as error:
            raise ValueError(f'ew.measurement.{key} 必须全部是数值。') from error
        if not all((math.isfinite(value) for value in numeric)) or numeric[0] >= numeric[1]:
            raise ValueError(f'ew.measurement.{key} 必须是递增的两个有限数值。')
        measurement[key] = numeric
    sensors = ew.setdefault('sensors', {})
    if not isinstance(sensors, dict):
        raise ValueError('ew.sensors 必须是以装备编号为键的映射。')
    for (zbb, sensor) in sensors.items():
        if not isinstance(sensor, dict):
            raise ValueError(f'ew.sensors.{zbb} 必须是 YAML 映射。')
        missing = [key for key in ('longitude_deg', 'latitude_deg', 'altitude_m') if key not in sensor]
        if missing:
            raise ValueError(f'ew.sensors.{zbb} 缺少共享装备位置字段: {missing}')
        for key in ('longitude_deg', 'latitude_deg', 'altitude_m'):
            try:
                value = float(sensor[key])
            except (TypeError, ValueError) as error:
                raise ValueError(f'ew.sensors.{zbb}.{key} 必须是数值。') from error
            if not math.isfinite(value):
                raise ValueError(f'ew.sensors.{zbb}.{key} 必须是有限数值。')
            sensor[key] = value
    joint = ew.setdefault('joint_fusion', {})
    if not isinstance(joint, dict):
        raise ValueError('ew.joint_fusion 必须是 YAML 映射。')
    joint.setdefault('gating_probability', 0.995)
    joint.setdefault('maximum_sw_prediction_gap_s', 6.0)
    joint.setdefault('local_track_history_prior_multiplier', 3.0)
    joint.setdefault('clutter_weight', 0.08)
    joint.setdefault('minimum_association_probability', 0.08)
    joint.setdefault('sw_anchor_covariance_scale', 1.0)
    joint.setdefault('ray_display_length_m', 5000.0)
    joint.setdefault('maximum_visualized_ew_reports', 5000)
    joint.setdefault('maximum_standalone_view_constraints', 120)
    joint.setdefault('maximum_combined_view_constraints', 24)
    joint.setdefault('combined_view_constraints_per_source', 2)
    joint.setdefault('coarse_azimuth_gate_deg', 25.0)
    joint.setdefault('coarse_elevation_gate_deg', 20.0)
    joint.setdefault('coarse_range_gate_m', 15000.0)
    joint.setdefault('coarse_altitude_gate_m', 1500.0)
    joint.setdefault('maximum_geometry_candidates', 8)

def _prepare_visualization_config(config: Dict[str, Any]) -> None:
    visualization = config.setdefault('visualization', {})
    if not isinstance(visualization, dict):
        raise ValueError('visualization 必须是 YAML 映射。')
    adaptive = visualization.setdefault('adaptive_axes', {})
    if not isinstance(adaptive, dict):
        raise ValueError('visualization.adaptive_axes 必须是 YAML 映射。')
    adaptive.setdefault('padding_ratio_enu', [0.08, 0.08, 0.12])
    adaptive.setdefault('minimum_span_enu_m', [30.0, 30.0, 15.0])
    for (key, positive) in (('padding_ratio_enu', False), ('minimum_span_enu_m', True)):
        values = adaptive[key]
        if not isinstance(values, list) or len(values) != 3:
            raise ValueError(f'visualization.adaptive_axes.{key} 必须包含 E、N、U 三个数值。')
        try:
            numeric = [float(value) for value in values]
        except (TypeError, ValueError) as error:
            raise ValueError(f'visualization.adaptive_axes.{key} 必须全部是数值。') from error
        if positive and any((value <= 0.0 for value in numeric)):
            raise ValueError(f'visualization.adaptive_axes.{key} 必须全部大于 0。')
        if not positive and any((value < 0.0 for value in numeric)):
            raise ValueError(f'visualization.adaptive_axes.{key} 不能包含负数。')
        adaptive[key] = numeric

def _prepare_identity_config(config: Dict[str, Any]) -> None:
    identity = config.setdefault('identity', {})
    if not isinstance(identity, dict):
        raise ValueError('identity 必须是 YAML 映射。')
    identity.setdefault('mby_scope', 'per_sensor')
    identity.setdefault('minimum_pair_support', 2)
    identity.setdefault('minimum_compatible_time_bins', 2)
    identity.setdefault('minimum_compatible_fraction', 0.35)
    identity.setdefault('position_gate_probability', 0.999)
    identity.setdefault('velocity_gate_probability', 0.999)
    identity.setdefault('velocity_gate_multiplier', 4.0)
    identity.setdefault('exhaustive_pair_limit', 10000)
    identity.setdefault('maximum_candidates_per_other_sensor', 16)
    identity.setdefault('candidate_search_radius_m', 50000.0)
    if str(identity['mby_scope']).lower() != 'per_sensor':
        raise ValueError('identity.mby_scope 当前必须为 per_sensor；禁止把 MBY 当作跨装备全局目标号。')
    for key in ('minimum_pair_support', 'minimum_compatible_time_bins', 'exhaustive_pair_limit', 'maximum_candidates_per_other_sensor'):
        value = int(identity[key])
        if value < 1:
            raise ValueError(f'identity.{key} 必须至少为1。')
        identity[key] = value
    fraction = float(identity['minimum_compatible_fraction'])
    if not 0.0 < fraction <= 1.0:
        raise ValueError('identity.minimum_compatible_fraction 必须在 (0, 1] 内。')
    identity['minimum_compatible_fraction'] = fraction
    for key in ('position_gate_probability', 'velocity_gate_probability'):
        value = float(identity[key])
        if not 0.0 < value < 1.0:
            raise ValueError(f'identity.{key} 必须在 (0, 1) 内。')
        identity[key] = value
    multiplier = float(identity['velocity_gate_multiplier'])
    if not math.isfinite(multiplier) or multiplier <= 0.0:
        raise ValueError('identity.velocity_gate_multiplier 必须是有限正数。')
    identity['velocity_gate_multiplier'] = multiplier
    search_radius = float(identity['candidate_search_radius_m'])
    if not math.isfinite(search_radius) or search_radius <= 0.0:
        raise ValueError('identity.candidate_search_radius_m 必须是有限正数。')
    identity['candidate_search_radius_m'] = search_radius

def _prepare_realtime_config(config: Dict[str, Any]) -> None:
    realtime = config.setdefault('realtime', {})
    if not isinstance(realtime, dict):
        raise ValueError('realtime 必须是 YAML 映射。')
    realtime.setdefault('enabled', True)
    realtime.setdefault('host', '127.0.0.1')
    realtime.setdefault('sw_port', 19001)
    realtime.setdefault('ew_port', 19002)
    realtime.setdefault('maximum_message_bytes', 1048576)
    realtime.setdefault('queue_capacity', 100000)
    realtime.setdefault('dequeue_batch_size', 2000)
    realtime.setdefault('queue_put_timeout_s', 0.25)
    realtime.setdefault('allowed_lateness_s', 0.5)
    realtime.setdefault('idle_flush_s', 0.65)
    realtime.setdefault('fusion_interval_s', 0.5)
    realtime.setdefault('history_window_s', 120.0)
    realtime.setdefault('maximum_records_per_stream', 50000)
    realtime.setdefault('require_full_schema', True)
    realtime.setdefault('drop_late_messages', True)
    realtime.setdefault('persist_journal', True)
    realtime.setdefault('journal_directory', 'output/realtime_journal')
    if not str(realtime['host']).strip():
        raise ValueError('realtime.host 不能为空。')
    realtime['host'] = str(realtime['host']).strip()
    for key in ('sw_port', 'ew_port'):
        value = int(realtime[key])
        if value < 0 or value > 65535:
            raise ValueError(f'realtime.{key} 必须在 0 到 65535 之间；0 仅用于自动端口测试。')
        realtime[key] = value
    if realtime['sw_port'] and realtime['sw_port'] == realtime['ew_port']:
        raise ValueError('realtime.sw_port 与 realtime.ew_port 不能相同。')
    for key in ('maximum_message_bytes', 'queue_capacity', 'dequeue_batch_size', 'maximum_records_per_stream'):
        value = int(realtime[key])
        if value < 1:
            raise ValueError(f'realtime.{key} 必须至少为1。')
        realtime[key] = value
    for key in ('queue_put_timeout_s', 'allowed_lateness_s', 'idle_flush_s', 'fusion_interval_s', 'history_window_s'):
        value = float(realtime[key])
        if not math.isfinite(value) or value < 0.0:
            raise ValueError(f'realtime.{key} 必须是有限非负数。')
        realtime[key] = value
    if realtime['fusion_interval_s'] <= 0.0 or realtime['history_window_s'] <= 0.0:
        raise ValueError('realtime.fusion_interval_s 和 history_window_s 必须大于0。')
    for key in ('enabled', 'require_full_schema', 'drop_late_messages', 'persist_journal'):
        realtime[key] = bool(realtime[key])

def _prepare_tracker_continuation_config(config: Dict[str, Any]) -> None:
    tracker = config['tracker']
    if not isinstance(tracker, dict):
        raise ValueError('tracker 必须是 YAML 映射。')
    delete_after_s = float(tracker['delete_after_s'])
    tracker.setdefault('single_source_continuation_enabled', True)
    tracker.setdefault('single_source_continuation_max_gap_s', delete_after_s)
    tracker.setdefault('single_source_continuation_gate_probability', 0.9999)
    tracker.setdefault('single_source_continuation_gate_multiplier', 4.0)
    tracker.setdefault('single_source_continuation_max_residual_m', 3000.0)
    tracker.setdefault('single_source_continuation_probability', 0.85)
    tracker.setdefault('single_source_continuation_covariance_inflation', 4.0)
    tracker.setdefault('transition_reference_interval_s', 0.5)
    enabled = tracker['single_source_continuation_enabled']
    if isinstance(enabled, str):
        normalized = enabled.strip().lower()
        if normalized not in {'true', 'false'}:
            raise ValueError('tracker.single_source_continuation_enabled 必须为 true 或 false。')
        enabled = normalized == 'true'
    tracker['single_source_continuation_enabled'] = bool(enabled)
    coast_after_s = float(tracker['coast_after_s'])
    if not 0.0 < coast_after_s < delete_after_s:
        raise ValueError('tracker 必须满足 0 < coast_after_s < delete_after_s。')
    maximum_gap = float(tracker['single_source_continuation_max_gap_s'])
    if not 0.0 < maximum_gap <= delete_after_s:
        raise ValueError('tracker.single_source_continuation_max_gap_s 必须大于0且不超过 delete_after_s。')
    tracker['coast_after_s'] = coast_after_s
    tracker['delete_after_s'] = delete_after_s
    tracker['single_source_continuation_max_gap_s'] = maximum_gap
    gate_probability = float(tracker['single_source_continuation_gate_probability'])
    if not 0.0 < gate_probability < 1.0:
        raise ValueError('tracker.single_source_continuation_gate_probability 必须在 (0, 1) 内。')
    tracker['single_source_continuation_gate_probability'] = gate_probability
    continuation_probability = float(tracker['single_source_continuation_probability'])
    if not 0.0 < continuation_probability <= 1.0:
        raise ValueError('tracker.single_source_continuation_probability 必须在 (0, 1] 内。')
    tracker['single_source_continuation_probability'] = continuation_probability
    transition_reference_interval_s = float(tracker['transition_reference_interval_s'])
    if not math.isfinite(transition_reference_interval_s) or transition_reference_interval_s <= 0.0:
        raise ValueError('tracker.transition_reference_interval_s 必须是有限正数。')
    tracker['transition_reference_interval_s'] = transition_reference_interval_s
    for key in ('single_source_continuation_gate_multiplier', 'single_source_continuation_max_residual_m', 'single_source_continuation_covariance_inflation'):
        value = float(tracker[key])
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f'tracker.{key} 必须是有限正数。')
        tracker[key] = value

def load_config(path: str | Path) -> Dict[str, Any]:
    config_path = Path(path).expanduser().resolve()
    config = _load_yaml_mapping(config_path, 'RealFusion 配置文件')
    _prepare_sw_input_config(config, config_path)
    _prepare_ew_input_config(config, config_path)
    _prepare_identity_config(config)
    _prepare_realtime_config(config)
    _prepare_visualization_config(config)
    required = {'scenario', 'sw', 'tracker'}
    missing = required.difference(config or {})
    if missing:
        raise ValueError(f'配置缺少区段: {sorted(missing)}')
    _prepare_tracker_continuation_config(config)
    sensors = config.get('sensors', {})
    if not isinstance(sensors, dict):
        raise ValueError('sensors 必须是映射；真实文件中的未知 ZBB 会使用 default_device。')
    for (zbb, sensor) in sensors.items():
        if not isinstance(sensor, dict):
            raise ValueError(f'sensors.{zbb} 必须是 YAML 映射，不能留空或写成 null。使用 SW 默认参数请写成 {{}} 或删除该装备条目；EW 装备位置应填写在 ew.sensors，位置未确定时先不列入。')
    if not isinstance(config['sw'].get('default_device'), dict):
        raise ValueError('sw.default_device 必须提供未知 ZBB 的默认设备参数。')
    schema_validation = str(config['sw'].get('schema_validation', 'required_columns')).lower()
    if schema_validation not in {'strict', 'warn', 'required_columns'}:
        raise ValueError('sw.schema_validation 只能是 strict、warn 或 required_columns。')
    expected_columns = config['sw'].get('expected_columns') or []
    if expected_columns:
        core_columns = config['sw'].get('_core_columns') or {}
        missing_core_columns = sorted(set(core_columns.values()).difference(expected_columns))
        if missing_core_columns:
            raise ValueError(f'SW 56列表头缺少自动识别的核心列: {missing_core_columns}')
    transition = config['tracker']['model_transition_matrix']
    if len(transition) != 4 or any((len(row) != 4 for row in transition)):
        raise ValueError('IMM 转移矩阵必须是 4x4。')
    for row in transition:
        if abs(sum(row) - 1.0) > 1e-09:
            raise ValueError('IMM 转移矩阵的每一行概率之和必须为 1。')
    if float(config['scenario']['window_s']) <= 0.0:
        raise ValueError('scenario.window_s 必须大于 0。')
    if int(config['sw'].get('minimum_points_per_device', 3)) < 2:
        raise ValueError('sw.minimum_points_per_device 必须至少为2；单点只能作为点迹，不能估计速度。')
    return config

def load_kafka_config(path: str | Path) -> Dict[str, Any]:
    config_path = Path(path).expanduser().resolve()
    config = _load_yaml_mapping(config_path, 'Kafka 配置文件')
    config['_config_path'] = str(config_path)
    config.setdefault('enabled', False)
    config['enabled'] = bool(config['enabled'])
    brokers = config.get('brokers')
    if not isinstance(brokers, list) or not brokers:
        raise ValueError('kafka.brokers 必须是至少包含一个服务器地址的列表。')
    config['brokers'] = [str(value).strip() for value in brokers]
    if any((not value for value in config['brokers'])):
        raise ValueError('kafka.brokers 不能包含空地址。')
    for key in ('group_id', 'client_id', 'input_topic', 'input_topic_1', 'output_topic'):
        value = str(config.get(key, '')).strip()
        if not value:
            raise ValueError(f'kafka.{key} 不能为空。')
        config[key] = value
    if config['input_topic'] == config['input_topic_1']:
        raise ValueError('Kafka三维与二维输入Topic不能相同。')
    consumer = config.setdefault('consumer', {})
    producer = config.setdefault('producer', {})
    replay_producer = config.setdefault('input_replay_producer', {})
    security = config.setdefault('security', {})
    json_config = config.setdefault('json', {})
    event_time = config.setdefault('event_time', {})
    output = config.setdefault('output', {})
    delivery = config.setdefault('delivery', {})
    for (name, section) in (('consumer', consumer), ('producer', producer), ('input_replay_producer', replay_producer), ('security', security), ('json', json_config), ('event_time', event_time), ('output', output), ('delivery', delivery)):
        if not isinstance(section, dict):
            raise ValueError(f'kafka.{name} 必须是YAML映射。')
    consumer.setdefault('auto_offset_reset', 'latest')
    if str(consumer['auto_offset_reset']) not in {'latest', 'earliest'}:
        raise ValueError('kafka.consumer.auto_offset_reset 只能是latest或earliest。')
    for key in ('poll_timeout_ms', 'max_poll_records', 'session_timeout_ms', 'heartbeat_interval_ms', 'request_timeout_ms', 'retry_backoff_ms', 'reconnect_backoff_ms', 'reconnect_backoff_max_ms', 'max_partition_fetch_bytes', 'fetch_max_bytes'):
        value = int(consumer.get(key, 1))
        if value < 1:
            raise ValueError(f'kafka.consumer.{key} 必须至少为1。')
        consumer[key] = value
    for key in ('enable_auto_commit', 'commit_accepted_batches', 'commit_rejected_messages'):
        consumer[key] = bool(consumer.get(key, False))
    if consumer['enable_auto_commit']:
        raise ValueError('kafka.consumer.enable_auto_commit必须为false，输入持久化后才能提交位点。')
    delivery.setdefault('directory', 'output/kafka_delivery')
    generation = delivery.setdefault('generation', '')
    if not isinstance(generation, str) or len(generation) > 128:
        raise ValueError('kafka.delivery.generation必须是不超过128字符的字符串。')
    for (key, default) in (('max_pending_messages', 200000), ('max_pending_outputs', 10000)):
        value = delivery.setdefault(key, default)
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f'kafka.delivery.{key}必须为正整数。')
    retry = float(delivery.setdefault('retry_backoff_s', 0.5))
    if not math.isfinite(retry) or retry <= 0:
        raise ValueError('kafka.delivery.retry_backoff_s必须为有限正数。')
    delivery['retry_backoff_s'] = retry
    producer.setdefault('enabled', True)
    producer['enabled'] = bool(producer['enabled'])
    request_size = producer.setdefault('max_request_size', 10485760)
    if isinstance(request_size, bool) or not isinstance(request_size, int) or request_size < 1:
        raise ValueError('kafka.producer.max_request_size必须为正整数。')
    block_ms = producer.setdefault('max_block_ms', 1000)
    if isinstance(block_ms, bool) or not isinstance(block_ms, int) or block_ms < 1:
        raise ValueError('kafka.producer.max_block_ms必须为正整数。')
    replay_producer.setdefault('enabled', True)
    replay_producer.setdefault('acknowledgements', 'all')
    replay_producer.setdefault('retries', 5)
    replay_producer.setdefault('linger_ms', 20)
    replay_producer.setdefault('batch_size', 32768)
    replay_producer.setdefault('request_timeout_ms', 30000)
    replay_producer.setdefault('max_request_size', 10485760)
    replay_producer.setdefault('compression_type', None)
    replay_producer.setdefault('ack_batch_size', 200)
    replay_producer.setdefault('delivery_timeout_s', 30.0)
    replay_producer.setdefault('speed', 1.0)
    replay_producer.setdefault('startup_delay_s', 1.0)
    replay_producer.setdefault('preserve_broker_timestamp', False)
    replay_producer.setdefault('continue_on_error', False)
    replay_producer['enabled'] = bool(replay_producer['enabled'])
    for key in ('retries', 'linger_ms', 'batch_size', 'request_timeout_ms', 'max_request_size', 'ack_batch_size'):
        value = int(replay_producer[key])
        minimum = 0 if key in {'retries', 'linger_ms'} else 1
        if value < minimum:
            raise ValueError(f'kafka.input_replay_producer.{key}必须至少为{minimum}。')
        replay_producer[key] = value
    for key in ('delivery_timeout_s', 'speed', 'startup_delay_s'):
        value = float(replay_producer[key])
        minimum_inclusive = key != 'delivery_timeout_s'
        invalid = not math.isfinite(value) or value < 0.0 or (not minimum_inclusive and value == 0.0)
        if invalid:
            suffix = '非负数' if minimum_inclusive else '正数'
            raise ValueError(f'kafka.input_replay_producer.{key}必须是有限{suffix}。')
        replay_producer[key] = value
    for key in ('preserve_broker_timestamp', 'continue_on_error'):
        replay_producer[key] = bool(replay_producer[key])
    security.setdefault('protocol', 'PLAINTEXT')
    protocol = str(security['protocol']).upper()
    if protocol not in {'PLAINTEXT', 'SSL', 'SASL_PLAINTEXT', 'SASL_SSL'}:
        raise ValueError('kafka.security.protocol 不是支持的Kafka安全协议。')
    security['protocol'] = protocol
    json_config.setdefault('encoding', 'utf-8')
    json_config.setdefault('envelope_keys', ['payload', 'data', 'record'])
    json_config.setdefault('ignore_unknown_fields', True)
    json_config.setdefault('case_sensitive_fields', False)
    json_config.setdefault('invalid_string_values', ['', 'null', 'none', 'nan'])
    event_time.setdefault('timezone', 'Asia/Shanghai')
    future_skew = float(event_time.setdefault('maximum_future_skew_s', 300.0))
    if not math.isfinite(future_skew) or future_skew < 0:
        raise ValueError('kafka.event_time.maximum_future_skew_s必须为有限非负数。')
    event_time['maximum_future_skew_s'] = future_skew
    watermarked_skew = event_time.setdefault('watermarked_future_tolerance_s', None)
    if watermarked_skew is not None:
        if isinstance(watermarked_skew, bool):
            raise ValueError('kafka.event_time.watermarked_future_tolerance_s必须为空或有限非负数。')
        watermarked_skew = float(watermarked_skew)
        if not math.isfinite(watermarked_skew) or watermarked_skew < 0:
            raise ValueError('kafka.event_time.watermarked_future_tolerance_s必须为空或有限非负数。')
        event_time['watermarked_future_tolerance_s'] = watermarked_skew
    try:
        ZoneInfo(str(event_time['timezone']))
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise ValueError(f"kafka.event_time.timezone无法识别: {event_time['timezone']!r}") from error
    output.setdefault('format', 'fusion_model_object_array')
    flush_timeout = float(output.setdefault('flush_timeout_s', 10.0))
    if not math.isfinite(flush_timeout) or flush_timeout <= 0:
        raise ValueError('kafka.output.flush_timeout_s必须为有限正数。')
    output['flush_timeout_s'] = flush_timeout
    if output['format'] != 'fusion_model_object_array':
        raise ValueError('kafka.output.format必须为fusion_model_object_array。')
    output.setdefault('timezone', 'Asia/Shanghai')
    try:
        ZoneInfo(str(output['timezone']))
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise ValueError(f"kafka.output.timezone无法识别: {output['timezone']!r}") from error
    for key in ('coordinate_unit_deg', 'velocity_unit_mps'):
        raw_value = output.setdefault(key, 1.0)
        if isinstance(raw_value, bool):
            raise ValueError(f'kafka.output.{key}必须为有限正数。')
        value = float(raw_value)
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f'kafka.output.{key}必须为有限正数。')
        output[key] = value
    axes = output.setdefault('velocity_axes', ['east', 'north', 'up'])
    if not isinstance(axes, list) or len(axes) != 3 or set(axes) != {'east', 'north', 'up'}:
        raise ValueError('kafka.output.velocity_axes必须为east、north、up的完整排列。')
    for (kind, topic_key) in (('sw', 'input_topic'), ('ew', 'input_topic_1')):
        section = config.get(kind)
        if not isinstance(section, dict):
            raise ValueError(f'kafka.{kind} 必须是YAML映射。')
        fields = section.get('fields')
        core_fields = section.get('core_fields')
        required_roles = section.get('required_valid_roles')
        if not isinstance(fields, list) or not fields:
            raise ValueError(f'kafka.{kind}.fields 必须是非空列表。')
        normalized_fields = [str(value).strip() for value in fields]
        duplicate_keys = normalized_fields if bool(json_config['case_sensitive_fields']) else [value.casefold() for value in normalized_fields]
        if len(set(duplicate_keys)) != len(duplicate_keys):
            raise ValueError(f'kafka.{kind}.fields 存在重复字段。')
        if not isinstance(core_fields, dict) or not isinstance(required_roles, list):
            raise ValueError(f'kafka.{kind}必须提供core_fields和required_valid_roles。')
        missing_roles = [role for role in required_roles if role not in core_fields]
        if missing_roles:
            raise ValueError(f'kafka.{kind}.core_fields缺少必需角色: {missing_roles}')
        missing_names = [name for name in core_fields.values() if str(name) not in normalized_fields]
        if missing_names:
            raise ValueError(f'kafka.{kind}.core_fields引用了未声明字段: {missing_names}')
        section['fields'] = normalized_fields
        section['topic'] = config[topic_key]
    return config
