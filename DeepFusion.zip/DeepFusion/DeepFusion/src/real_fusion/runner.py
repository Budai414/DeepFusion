from __future__ import annotations
from pathlib import Path
from typing import Dict, Sequence
from real_fusion.evaluation.metrics import compute_metrics
from real_fusion.evaluation.plots import create_plots
from real_fusion.evaluation.summary import create_fusion_summary, gate_conflict_report_records, target_status_report_records
from real_fusion.io.artifacts import write_csv, write_json, write_jsonl
from real_fusion.ew import read_and_combine_ew_files
from real_fusion.ew.fusion import run_ew_joint_fusion
from real_fusion.pipeline import ExperimentResult, build_converter, run_sw_experiment
from real_fusion.visualization import create_cesium_player, create_fusion_player
FALSE_ALARM_REPORT_FIELDS = ['classification', 'reason', 'target_id', 'local_target_id', 'local_track_key', 'sensor_id', 'zbb', 'group_input_rows', 'group_unique_timestamp_count', 'minimum_required_points', 'measurement_time', 'longitude_deg', 'latitude_deg', 'altitude_m', 'rcs_dbsm', 'source_file', 'source_excel_row']
TARGET_STATUS_REPORT_FIELDS = ['target_id', 'classification', 'display_status', 'fusion_track_id', 'input_point_count', 'valid_track_point_count', 'sparse_point_count', 'valid_sensor_ids', 'valid_zbb_values', 'sparse_sensor_ids', 'sparse_zbb_values', 'fused_estimate_count', 'source_files', 'member_local_track_keys', 'member_local_target_ids', 'minimum_cross_sensor_distance_m', 'minimum_cross_sensor_mahalanobis_sq', 'birth_gate_mahalanobis_sq_threshold', 'closest_zbb_pair', 'reason']
GLOBAL_TRACK_MEMBERSHIP_FIELDS = ['global_target_id', 'fusion_track_id', 'association_mode', 'local_track_key', 'local_target_id', 'sensor_id', 'zbb', 'source_track_id', 'report_count', 'first_time_s', 'last_time_s', 'supporting_peer_count', 'supporting_local_track_keys']
IDENTITY_PAIR_DIAGNOSTIC_FIELDS = ['left_local_track_key', 'right_local_track_key', 'left_sensor_id', 'right_sensor_id', 'left_zbb', 'right_zbb', 'left_local_target_id', 'right_local_target_id', 'temporal_pair_count', 'compatible_pair_count', 'compatible_time_bin_count', 'compatible_fraction', 'minimum_position_distance_m', 'median_position_mahalanobis_sq', 'median_velocity_mahalanobis_sq', 'position_gate_threshold', 'velocity_gate_threshold', 'compatible', 'reason']

def save_experiment(result: ExperimentResult, metrics: Dict[str, object], output_directory: str | Path) -> None:
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    write_jsonl((item.to_record() for item in result.raw_detections), output / 'source_track_reports.jsonl')
    write_csv((item.to_record() for item in result.raw_detections), output / 'source_tracks.csv')
    write_csv((item.to_record() for item in result.source_tracks.summaries), output / 'device_frequency_summary.csv')
    write_csv((item.to_record() for item in result.global_track_memberships), output / 'global_track_membership.csv', fieldnames=GLOBAL_TRACK_MEMBERSHIP_FIELDS)
    write_csv((item.to_record() for item in result.identity_pair_diagnostics), output / 'identity_pair_diagnostics.csv', fieldnames=IDENTITY_PAIR_DIAGNOSTIC_FIELDS)
    if result.identity_learning_audits:
        write_jsonl((item.to_record() for item in result.identity_learning_audits), output / 'identity_learning_audit.jsonl')
    write_csv((item.to_record() for item in result.estimates), output / 'fused_tracks.csv')
    if result.ew_read is not None:
        write_csv((item.to_record() for item in result.ew_measurements), output / 'ew_measurements.csv')
        write_csv((item.to_record() for item in result.ew_associations), output / 'ew_association_report.csv')
        write_csv((item.to_record() for item in result.joint_estimates), output / 'joint_fused_tracks.csv')
    write_csv((item.to_record() for item in result.source_tracks.false_alarm_records), output / 'false_alarm_report.csv', fieldnames=FALSE_ALARM_REPORT_FIELDS)
    target_records = target_status_report_records(result)
    write_csv(target_records, output / 'target_status_report.csv', fieldnames=TARGET_STATUS_REPORT_FIELDS)
    write_csv(gate_conflict_report_records(result), output / 'gate_conflict_report.csv', fieldnames=TARGET_STATUS_REPORT_FIELDS)
    write_json(metrics, output / 'metrics.json')
    create_plots(result, output / 'figures')
    create_fusion_player(result, output / 'fusion_player.html')
    create_cesium_player(result, output / 'cesium_map_player.html')
    create_fusion_summary(result, metrics, output)
    report = {'status': 'disabled'}
    if result.config.get('reporting', {}).get('observable_comparison', True):
        try:
            from real_fusion.evaluation.observable_comparison import create_observable_comparison
            create_observable_comparison(result, metrics, output / 'comparison_dashboard')
        except Exception as error:
            report = {'status': 'failed', 'error_type': type(error).__name__, 'error': str(error)}
        else:
            report = {'status': 'complete', 'directory': 'comparison_dashboard'}
    metrics['reports'] = {'observable_comparison': report}
    write_json(metrics['reports'], output / 'report_status.json')
    write_json(metrics, output / 'metrics.json')

def execute_sw(config: dict, sw_paths: str | Path | Sequence[str | Path], output_directory: str | Path, start_time: object=None, end_time: object=None, identity_learning: object=None) -> tuple[ExperimentResult, Dict[str, object]]:
    result = run_sw_experiment(config, sw_paths, start_time=start_time, end_time=end_time, identity_learning=identity_learning)
    metrics = compute_metrics(result)
    save_experiment(result, metrics, output_directory)
    return (result, metrics)

def execute_sw_ew(config: dict, sw_paths: str | Path | Sequence[str | Path], ew_paths: str | Path | Sequence[str | Path], output_directory: str | Path, start_time: object=None, end_time: object=None, identity_learning: object=None) -> tuple[ExperimentResult, Dict[str, object]]:
    result = run_sw_experiment(config, sw_paths, start_time=start_time, end_time=end_time, identity_learning=identity_learning)
    if 'ew' not in config:
        raise ValueError('当前 YAML 没有 ew 区段，不能读取 EW 文件。')
    paths = [ew_paths] if isinstance(ew_paths, (str, Path)) else list(ew_paths)
    ew_read = read_and_combine_ew_files(paths, config['ew'], start_time=start_time, end_time=end_time)
    converter = build_converter(config, result.sw_read)
    run_ew_joint_fusion(result, ew_read, converter)
    metrics = compute_metrics(result)
    save_experiment(result, metrics, output_directory)
    return (result, metrics)
