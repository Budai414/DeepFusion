from __future__ import annotations
from dataclasses import dataclass, field
from itertools import groupby
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence
import numpy as np
from scipy.stats import chi2
from real_fusion.geometry import GeodeticConverter
from real_fusion.models import NormalizedDetection, RawDetection, TrackEstimate
from real_fusion.preprocessing.event_time import EventTimeBuffer, FusionWindow
from real_fusion.preprocessing.normalize import normalize_detection
from real_fusion.sw import SourceTrackBuildResult, SwReadResult, build_source_tracks, read_and_combine_sw_files
from real_fusion.tracking.birth import TentativeBirthManager
from real_fusion.tracking.identity import GlobalTrackMembership, IdentityCandidatePairSets, LocalTrackPairDiagnostic, resolve_global_identities
from real_fusion.tracking.track import FusionTrack

@dataclass
class ExperimentResult:
    config: dict
    raw_detections: List[RawDetection]
    normalized_detections: List[NormalizedDetection]
    estimates: List[TrackEstimate]
    late_drop_count: int
    released_window_count: int
    nis_values: List[float]
    sw_read: SwReadResult
    source_tracks: SourceTrackBuildResult
    target_fusion_modes: Dict[str, str] = field(default_factory=dict)
    target_statuses: Dict[str, 'TargetFusionStatus'] = field(default_factory=dict)
    global_track_memberships: List[GlobalTrackMembership] = field(default_factory=list)
    identity_pair_diagnostics: List[LocalTrackPairDiagnostic] = field(default_factory=list)
    identity_learning_audits: List[Any] = field(default_factory=list)
    local_track_to_global_target: Dict[str, str] = field(default_factory=dict)
    identity_candidate_pair_sets: IdentityCandidatePairSets = field(default_factory=IdentityCandidatePairSets.empty)
    ew_read: Optional[Any] = None
    ew_measurements: List[Any] = field(default_factory=list)
    ew_associations: List[Any] = field(default_factory=list)
    joint_estimates: List[TrackEstimate] = field(default_factory=list)
    ew_sensor_positions: Dict[str, np.ndarray] = field(default_factory=dict)

@dataclass(frozen=True)
class TargetFusionStatus:
    target_id: str
    classification: str
    display_status: str
    reason: str
    track_id: Optional[str]
    valid_sensor_ids: List[str]
    valid_zbb_values: List[str]
    sparse_sensor_ids: List[str]
    sparse_zbb_values: List[str]
    input_point_count: int
    valid_track_point_count: int
    sparse_point_count: int
    fused_estimate_count: int
    source_files: List[str]
    member_local_track_keys: List[str] = field(default_factory=list)
    member_local_target_ids: List[str] = field(default_factory=list)
    diagnostic: Dict[str, object] = field(default_factory=dict)

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

def build_converter(config: dict, sw_read: Optional[SwReadResult]=None) -> GeodeticConverter:
    reference = config['scenario']['reference']
    if str(reference.get('mode', 'fixed')).lower() == 'auto':
        if sw_read is None:
            raise ValueError('自动 ENU 参考点需要先读取 SW 文件。')
        return GeodeticConverter(float(sw_read.frame['_mbj'].median()), float(sw_read.frame['_mbw'].median()), float(sw_read.frame['_mbg'].median()))
    return GeodeticConverter(reference['longitude_deg'], reference['latitude_deg'], reference['altitude_m'])

def _process_window(window: FusionWindow, config: dict, converter: GeodeticConverter, birth_manager: TentativeBirthManager, track: Optional[FusionTrack], track_id: str, target_id: str) -> tuple[Optional[FusionTrack], Optional[TrackEstimate]]:
    if track is not None:
        track.begin_window()
    frame_key = lambda item: (item.corrected_time_s, item.sensor_id, item.frame_id)
    for ((_, sensor_id, _), frame_iterator) in groupby(window.detections, key=frame_key):
        frame = list(frame_iterator)
        frame_time = max((item.corrected_time_s for item in frame))
        if track is None:
            birth_manager.add(frame)
            birth = birth_manager.try_initialize(frame_time)
            if birth is not None:
                track = FusionTrack(track_id, target_id, birth, config['tracker'])
            continue
        track.process_sensor_frame(frame_time, frame, config['sensors'][sensor_id])
    if track is None:
        return (None, None)
    estimate = track.estimate(window.end_time_s)
    (estimate.longitude_deg, estimate.latitude_deg, estimate.altitude_m) = converter.enu_to_geodetic(estimate.state_enu[:3])
    if estimate.lifecycle_state == 'deleted':
        return (None, estimate)
    return (track, estimate)

def _run_one_target(target_id: str, track_id: str, raw_detections: List[RawDetection], runtime_config: dict, converter: GeodeticConverter) -> tuple[List[NormalizedDetection], List[TrackEstimate], int, int, List[float]]:
    target_sensor_ids = sorted({item.sensor_id for item in raw_detections})
    target_config = dict(runtime_config)
    target_config['scenario'] = dict(runtime_config['scenario'])
    target_config['sensors'] = {sensor_id: runtime_config['sensors'][sensor_id] for sensor_id in target_sensor_ids}
    event_times = [item.measurement_time_s for item in raw_detections]
    base_epoch = float(min(event_times))
    end_epoch = float(max(event_times))
    window_s = float(target_config['scenario']['window_s'])
    target_config['scenario']['base_epoch_s'] = base_epoch
    target_config['scenario']['duration_s'] = max(window_s, end_epoch - base_epoch + window_s)
    normalized_detections: List[NormalizedDetection] = []
    event_buffer = EventTimeBuffer(target_config)
    birth_manager = TentativeBirthManager(target_config['scenario'], target_config['tracker'])
    track: Optional[FusionTrack] = None
    last_track: Optional[FusionTrack] = None
    estimates: List[TrackEstimate] = []
    arrival_key = lambda item: (item.arrival_time_s, item.sensor_id, item.frame_id)
    for (_, raw_frame_iterator) in groupby(raw_detections, key=arrival_key):
        raw_frame = list(raw_frame_iterator)
        normalized_frame = [normalize_detection(item, target_config['sensors'][item.sensor_id], converter) for item in raw_frame]
        normalized_detections.extend(normalized_frame)
        for window in event_buffer.push_frame(normalized_frame):
            (track, estimate) = _process_window(window, target_config, converter, birth_manager, track, track_id, target_id)
            if track is not None:
                last_track = track
            if estimate is not None:
                estimates.append(estimate)
    final_time = base_epoch + float(target_config['scenario']['duration_s'])
    for window in event_buffer.flush(final_time):
        (track, estimate) = _process_window(window, target_config, converter, birth_manager, track, track_id, target_id)
        if track is not None:
            last_track = track
        if estimate is not None:
            estimates.append(estimate)
    return (normalized_detections, estimates, event_buffer.late_drop_count, event_buffer.released_window_count, [] if last_track is None else list(last_track.nis_values))

def _cross_sensor_birth_diagnostic(detections: Sequence[NormalizedDetection], runtime_config: dict) -> Dict[str, object]:
    by_sensor: Dict[str, List[NormalizedDetection]] = {}
    for detection in detections:
        by_sensor.setdefault(detection.sensor_id, []).append(detection)
    for values in by_sensor.values():
        values.sort(key=lambda item: (item.corrected_time_s, item.detection_id))
    birth_window_s = float(runtime_config['tracker']['birth_window_s'])
    gate_threshold = float(chi2.ppf(float(runtime_config['tracker']['birth_gate_probability']), df=3))
    temporal_pair_count = 0
    compatible_pair_count = 0
    minimum_distance_m = float('inf')
    minimum_mahalanobis_sq = float('inf')
    closest_pair: Optional[tuple[str, str]] = None
    closest_time_difference_s: Optional[float] = None
    sensor_ids = sorted(by_sensor)
    for (left_index, left_sensor) in enumerate(sensor_ids):
        left_items = by_sensor[left_sensor]
        for right_sensor in sensor_ids[left_index + 1:]:
            right_items = by_sensor[right_sensor]
            right_times = np.asarray([item.corrected_time_s for item in right_items], dtype=float)
            for left in left_items:
                start = int(np.searchsorted(right_times, left.corrected_time_s - birth_window_s, side='left'))
                stop = int(np.searchsorted(right_times, left.corrected_time_s + birth_window_s, side='right'))
                for right in right_items[start:stop]:
                    temporal_pair_count += 1
                    event_time = max(left.corrected_time_s, right.corrected_time_s)
                    (left_state, left_covariance) = TentativeBirthManager._aligned(left, event_time)
                    (right_state, right_covariance) = TentativeBirthManager._aligned(right, event_time)
                    difference = left_state[:3] - right_state[:3]
                    distance_m = float(np.linalg.norm(difference))
                    mahalanobis_sq = float(difference @ np.linalg.solve(left_covariance[:3, :3] + right_covariance[:3, :3], difference))
                    if mahalanobis_sq <= gate_threshold:
                        compatible_pair_count += 1
                    if mahalanobis_sq < minimum_mahalanobis_sq:
                        minimum_mahalanobis_sq = mahalanobis_sq
                        minimum_distance_m = distance_m
                        closest_pair = (left_sensor, right_sensor)
                        closest_time_difference_s = abs(float(left.corrected_time_s - right.corrected_time_s))
    sensor_zbb = {sensor_id: str(runtime_config['sensors'][sensor_id].get('zbb', sensor_id)) for sensor_id in sensor_ids}
    return {'birth_window_s': birth_window_s, 'birth_gate_probability': float(runtime_config['tracker']['birth_gate_probability']), 'birth_gate_mahalanobis_sq_threshold': gate_threshold, 'temporal_cross_sensor_pair_count': temporal_pair_count, 'gate_compatible_pair_count': compatible_pair_count, 'minimum_cross_sensor_distance_m': None if not np.isfinite(minimum_distance_m) else minimum_distance_m, 'minimum_cross_sensor_mahalanobis_sq': None if not np.isfinite(minimum_mahalanobis_sq) else minimum_mahalanobis_sq, 'closest_sensor_pair': list(closest_pair) if closest_pair else [], 'closest_zbb_pair': [sensor_zbb[value] for value in closest_pair] if closest_pair else [], 'closest_pair_time_difference_s': closest_time_difference_s}

def _target_status(target_id: str, track_id: Optional[str], target_raw: Sequence[RawDetection], target_normalized: Sequence[NormalizedDetection], target_estimates: Sequence[TrackEstimate], source_tracks: SourceTrackBuildResult, runtime_config: dict, valid_summaries: Optional[Sequence[object]]=None, sparse_groups: Optional[Sequence[object]]=None, sparse_records: Optional[Sequence[object]]=None, memberships: Optional[Sequence[GlobalTrackMembership]]=None) -> TargetFusionStatus:
    valid_summaries = list(valid_summaries) if valid_summaries is not None else [item for item in source_tracks.summaries if item.target_id == target_id]
    sparse_groups = list(sparse_groups) if sparse_groups is not None else [item for item in source_tracks.sparse_groups if item.target_id == target_id]
    sparse_records = list(sparse_records) if sparse_records is not None else [item for item in source_tracks.false_alarm_records if item.target_id == target_id]
    memberships = list(memberships or [])
    valid_sensor_ids = sorted({item.sensor_id for item in valid_summaries})
    valid_zbb_values = sorted({item.zbb for item in valid_summaries})
    sparse_sensor_ids = sorted({item.sensor_id for item in sparse_groups})
    sparse_zbb_values = sorted({item.zbb for item in sparse_groups})
    source_files = sorted({str(item.source_file) for item in target_raw if item.source_file} | {str(item.source_file) for item in sparse_records if item.source_file})
    input_point_count = sum((item.input_rows for item in valid_summaries)) + sum((item.input_rows for item in sparse_groups))
    valid_track_point_count = len(target_raw)
    sparse_point_count = sum((item.input_rows for item in sparse_groups))
    diagnostic: Dict[str, object] = {}
    if memberships:
        diagnostic['local_track_memberships'] = [item.to_record() for item in memberships]
    if not valid_sensor_ids:
        classification = 'unformed_false_alarm'
        display_status = '未成轨'
        reason = f"该装备内局部批号少于{runtime_config['sw'].get('minimum_points_per_device', 3)}个唯一时戳，不能形成局部源航迹，按虚警候选报告。"
    elif len(valid_sensor_ids) == 1:
        classification = 'single_source_passthrough'
        display_status = '单装备成轨'
        reason = f'仅装备={valid_zbb_values[0]}形成有效源航迹，按单源直通规则输出。'
    elif target_estimates:
        classification = 'multi_source_fused'
        display_status = '已融合'
        reason = f'{len(valid_sensor_ids)}种装备共同提供有效源航迹，并形成融合航迹。'
    else:
        diagnostic.update(_cross_sensor_birth_diagnostic(target_normalized, runtime_config))
        temporal_pairs = int(diagnostic['temporal_cross_sensor_pair_count'])
        compatible_pairs = int(diagnostic['gate_compatible_pair_count'])
        if temporal_pairs > 0 and compatible_pairs == 0:
            classification = 'cross_sensor_over_gate'
            display_status = '过远'
            distance = diagnostic.get('minimum_cross_sensor_distance_m')
            distance_label = '未知' if distance is None else f'{float(distance):.1f}米'
            reason = f'{len(valid_sensor_ids)}种装备均已成源航迹，但时间邻近的跨装备点对全部超过出生融合门控；最接近点对仍相距{distance_label}，不强行融合。'
        elif temporal_pairs == 0:
            classification = 'source_time_not_overlapping'
            display_status = '时段不重叠'
            reason = f'{len(valid_sensor_ids)}种装备均已成源航迹，但在出生时间窗内没有跨装备邻近点对，不能共同支持融合航迹。'
        else:
            classification = 'fusion_not_formed'
            display_status = '未融合'
            reason = '存在少量门内跨装备证据，但未同时满足出生所需的装备数、时间片数或连续性条件；保留各装备源航迹并写入总结。'
    return TargetFusionStatus(target_id=target_id, classification=classification, display_status=display_status, reason=reason, track_id=track_id if target_estimates else None, valid_sensor_ids=valid_sensor_ids, valid_zbb_values=valid_zbb_values, sparse_sensor_ids=sparse_sensor_ids, sparse_zbb_values=sparse_zbb_values, input_point_count=input_point_count, valid_track_point_count=valid_track_point_count, sparse_point_count=sparse_point_count, fused_estimate_count=len(target_estimates), source_files=source_files, member_local_track_keys=sorted({item.local_track_key for item in memberships}), member_local_target_ids=sorted({item.local_target_id for item in memberships}), diagnostic=diagnostic)

def _run_single_source_target(target_id: str, track_id: str, raw_detections: List[RawDetection], runtime_config: dict, converter: GeodeticConverter) -> tuple[List[NormalizedDetection], List[TrackEstimate]]:
    normalized = [normalize_detection(item, runtime_config['sensors'][item.sensor_id], converter) for item in sorted(raw_detections, key=lambda value: (value.measurement_time_s, value.sensor_id, value.frame_id))]
    raw_by_id = {item.detection_id: item for item in raw_detections}
    estimates: List[TrackEstimate] = []
    for item in normalized:
        raw = raw_by_id[item.detection_id]
        estimate = TrackEstimate(track_id=track_id, target_id=target_id, event_time_s=float(item.corrected_time_s), state_enu=item.state_enu.copy(), covariance=item.covariance.copy(), lifecycle_state='confirmed', existence_probability=1.0, model_probabilities={'single_source_passthrough': 1.0}, associated_detection_ids=[item.detection_id], association_probabilities={item.detection_id: 1.0}, associated_sources=[{'detection_id': item.detection_id, 'sensor_id': item.sensor_id, 'target_id': item.target_id, 'local_target_id': item.local_target_id, 'local_track_key': item.local_track_key, 'source_track_id': item.source_track_id, 'probability': 1.0, 'source_file': raw.source_file, 'source_excel_row': raw.source_excel_row}])
        (estimate.longitude_deg, estimate.latitude_deg, estimate.altitude_m) = converter.enu_to_geodetic(estimate.state_enu[:3])
        estimates.append(estimate)
    return (normalized, estimates)

def run_sw_experiment(config: dict, sw_paths: str | Path | Sequence[str | Path], start_time: object=None, end_time: object=None, prepared_read: Optional[SwReadResult]=None, identity_learning: Optional[Any]=None) -> ExperimentResult:
    if prepared_read is None:
        paths = [sw_paths] if isinstance(sw_paths, (str, Path)) else list(sw_paths)
        sw_read = read_and_combine_sw_files(paths, config['sw'], start_time=start_time, end_time=end_time)
    else:
        sw_read = prepared_read
    converter = build_converter(config, sw_read)
    source_tracks = build_source_tracks(sw_read, config, converter)
    runtime_config = dict(config)
    runtime_config['scenario'] = dict(config['scenario'])
    runtime_config['scenario']['reference'] = {'mode': 'resolved', 'longitude_deg': converter.longitude_deg, 'latitude_deg': converter.latitude_deg, 'altitude_m': converter.altitude_m}
    runtime_config['sensors'] = source_tracks.sensors
    runtime_config['scenario']['source_track_ids'] = source_tracks.source_track_ids
    base_epoch = float(sw_read.frame['_epoch_s'].min())
    end_epoch = float(sw_read.frame['_epoch_s'].max())
    window_s = float(runtime_config['scenario']['window_s'])
    runtime_config['scenario']['base_epoch_s'] = base_epoch
    runtime_config['scenario']['duration_s'] = max(window_s, end_epoch - base_epoch + window_s)
    runtime_config['scenario']['name'] = str(config['scenario'].get('name', 'real_sw_track_fusion'))
    local_normalized = [normalize_detection(item, runtime_config['sensors'][item.sensor_id], converter) for item in source_tracks.detections]
    identity_resolution = resolve_global_identities(source_tracks.detections, local_normalized, runtime_config, identity_learning=identity_learning)
    raw_detections = identity_resolution.detections
    target_track_ids = identity_resolution.global_target_track_ids
    active_target_values = sorted(target_track_ids)
    sparse_target_values = sorted({item.target_id for item in source_tracks.sparse_groups})
    input_target_values = active_target_values + [value for value in sparse_target_values if value not in target_track_ids]
    runtime_config['scenario']['target_track_ids'] = target_track_ids
    runtime_config['scenario']['target_values'] = active_target_values
    runtime_config['scenario']['input_target_values'] = input_target_values
    runtime_config['scenario']['raw_mby_values'] = sorted(sw_read.target_values)
    runtime_config['scenario']['local_track_to_global_target'] = dict(identity_resolution.local_track_to_global_target)
    normalized_detections: List[NormalizedDetection] = []
    estimates: List[TrackEstimate] = []
    late_drop_count = 0
    released_window_count = 0
    nis_values: List[float] = []
    target_fusion_modes: Dict[str, str] = {}
    target_statuses: Dict[str, TargetFusionStatus] = {}
    raw_by_target: Dict[str, List[RawDetection]] = {}
    for detection in raw_detections:
        raw_by_target.setdefault(detection.target_id, []).append(detection)
    membership_by_source_track = {item.source_track_id: item for item in identity_resolution.memberships}
    memberships_by_target: Dict[str, List[GlobalTrackMembership]] = {}
    for membership in identity_resolution.memberships:
        memberships_by_target.setdefault(membership.global_target_id, []).append(membership)
    summaries_by_target: Dict[str, list] = {}
    for summary in source_tracks.summaries:
        membership = membership_by_source_track.get(summary.source_track_id)
        if membership is not None:
            summaries_by_target.setdefault(membership.global_target_id, []).append(summary)
    sparse_groups_by_target: Dict[str, list] = {}
    for sparse_group in source_tracks.sparse_groups:
        sparse_groups_by_target.setdefault(sparse_group.target_id, []).append(sparse_group)
    sparse_records_by_target: Dict[str, list] = {}
    for sparse_record in source_tracks.false_alarm_records:
        sparse_records_by_target.setdefault(sparse_record.target_id, []).append(sparse_record)
    for (target_id, track_id) in target_track_ids.items():
        target_raw = raw_by_target.get(target_id, [])
        target_sensor_ids = {item.sensor_id for item in target_raw}
        if len(target_sensor_ids) == 1:
            target_fusion_modes[target_id] = 'single_source_passthrough'
            (target_normalized, target_estimates) = _run_single_source_target(target_id, track_id, target_raw, runtime_config, converter)
            (target_late, target_released, target_nis) = (0, 0, [])
        else:
            (target_normalized, target_estimates, target_late, target_released, target_nis) = _run_one_target(target_id, track_id, target_raw, runtime_config, converter)
            target_fusion_modes[target_id] = 'multi_source_pda_imm' if target_estimates else 'not_fused'
        normalized_detections.extend(target_normalized)
        estimates.extend(target_estimates)
        late_drop_count += target_late
        released_window_count += target_released
        nis_values.extend(target_nis)
        target_statuses[target_id] = _target_status(target_id, track_id, target_raw, target_normalized, target_estimates, source_tracks, runtime_config, valid_summaries=summaries_by_target.get(target_id, []), sparse_groups=sparse_groups_by_target.get(target_id, []), sparse_records=sparse_records_by_target.get(target_id, []), memberships=memberships_by_target.get(target_id, []))
    for target_id in sparse_target_values:
        if target_id in target_statuses:
            continue
        target_statuses[target_id] = _target_status(target_id, None, [], [], [], source_tracks, runtime_config, valid_summaries=summaries_by_target.get(target_id, []), sparse_groups=sparse_groups_by_target.get(target_id, []), sparse_records=sparse_records_by_target.get(target_id, []), memberships=[])
    for (target_id, status) in target_statuses.items():
        if status.classification == 'cross_sensor_over_gate':
            target_fusion_modes[target_id] = 'cross_sensor_over_gate'
        elif status.classification == 'source_time_not_overlapping':
            target_fusion_modes[target_id] = 'source_time_not_overlapping'
        elif status.classification == 'fusion_not_formed':
            target_fusion_modes[target_id] = 'fusion_not_formed'
    normalized_detections.sort(key=lambda item: (item.arrival_time_s, item.target_id, item.sensor_id, item.frame_id))
    estimates.sort(key=lambda item: (item.event_time_s, item.track_id))
    return ExperimentResult(config=runtime_config, raw_detections=raw_detections, normalized_detections=normalized_detections, estimates=estimates, late_drop_count=late_drop_count, released_window_count=released_window_count, nis_values=nis_values, sw_read=sw_read, source_tracks=source_tracks, target_fusion_modes=target_fusion_modes, target_statuses=target_statuses, global_track_memberships=identity_resolution.memberships, identity_pair_diagnostics=identity_resolution.pair_diagnostics, identity_learning_audits=identity_resolution.identity_learning_audits, local_track_to_global_target=identity_resolution.local_track_to_global_target, identity_candidate_pair_sets=identity_resolution.candidate_pair_sets)
