from __future__ import annotations
import os
from pathlib import Path

class DeepFusionRootError(RuntimeError):
    pass

def _is_project_root(path: Path) -> bool:
    return path.name == 'DeepFusion' and (path / 'pyproject.toml').is_file() and (path / 'src' / 'real_fusion').is_dir() and (path / 'research' / 'df_paag').is_dir()

def deepfusion_project_root(anchor: str | Path | None=None) -> Path:
    for name in ('DEEPFUSION_ROOT', 'DF_ROOT'):
        raw = os.environ.get(name)
        if raw:
            candidate = Path(raw).expanduser().resolve()
            if _is_project_root(candidate):
                return candidate
            raise DeepFusionRootError(f'{name}未指向有效DeepFusion根目录: {candidate}')
    start = Path(__file__ if anchor is None else anchor).expanduser().resolve()
    candidates = (start.parent, *start.parents)
    for candidate in candidates:
        if _is_project_root(candidate):
            return candidate
    raise DeepFusionRootError(f'无法从运行路径定位DeepFusion根目录: {start}；请设置DEEPFUSION_ROOT')
__all__ = ['DeepFusionRootError', 'deepfusion_project_root']
