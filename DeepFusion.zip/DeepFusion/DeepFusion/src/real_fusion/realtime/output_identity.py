from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass, replace
import math
from typing import Dict, FrozenSet, Optional, Tuple
import uuid
JAVA_INT_MAX = 2147483647
_EPS = 1e-06
_TERMINAL_STATES = frozenset({'deleted', 'terminated', 'ended', 'finished', 'dead', 'closed', 'completed'})
OutputIdentity = Tuple[str, int]

def _finite(value) -> Optional[float]:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None

@dataclass(frozen=True)
class _Observation:
    members: FrozenSet[str]
    start: Optional[float]
    end: Optional[float]
    closed_at: Optional[float]
    epoch_start: Optional[float]

@dataclass(frozen=True)
class _Record:
    identity: OutputIdentity
    observation: _Observation
    revision: int

def _observe(estimates, memberships) -> _Observation:
    keys = [str(getattr(member, 'local_track_key', '') or '').strip() for member in memberships]
    members = frozenset(keys) if keys and all(keys) else frozenset()
    times = []
    terminals = []
    for estimate in estimates:
        timestamp = _finite(getattr(estimate, 'event_time_s', None))
        if timestamp is None:
            continue
        times.append(timestamp)
        if str(getattr(estimate, 'lifecycle_state', '')).lower() in _TERMINAL_STATES:
            terminals.append(timestamp)
    if not times:
        return _Observation(members, None, None, None, None)
    latest = max(times)
    interior = [timestamp for timestamp in terminals if timestamp < latest - _EPS]
    epoch_start = max(interior) if interior else None
    if epoch_start is not None:
        times = [timestamp for timestamp in times if timestamp > epoch_start + _EPS]
    (start, end) = (min(times), max(times))
    closed_at = latest if any((abs(timestamp - latest) <= _EPS for timestamp in terminals)) else None
    ranges = []
    for membership in memberships:
        first = _finite(getattr(membership, 'first_time_s', None))
        last = _finite(getattr(membership, 'last_time_s', None))
        if first is not None and last is not None and (first <= last):
            ranges.append((first, last))
    if ranges:
        start = max(start, min((first for (first, _) in ranges)))
        end = min(end, max((last for (_, last) in ranges)))
        if start > end + _EPS:
            start = end = None
    return _Observation(members, start, end, closed_at, epoch_start)

def _continues(before: _Observation, after: _Observation) -> bool:
    if not before.members or before.members != after.members:
        return False
    if any((value is None for value in (before.start, before.end, after.start, after.end))):
        return False
    if after.start > before.end + _EPS or before.start > after.end + _EPS:
        return False
    if before.closed_at is not None:
        if after.closed_at is None or abs(after.closed_at - before.closed_at) > _EPS:
            return False
    if after.epoch_start is not None and (before.epoch_start is None or abs(after.epoch_start - before.epoch_start) > _EPS):
        return False
    if before.epoch_start is not None and after.end <= before.epoch_start + _EPS:
        return False
    return True

class RealtimeOutputIdentity:

    def __init__(self, *, retention_s: float=120.0, maximum_cached_records: int=4096, session_id: Optional[str]=None) -> None:
        retention = _finite(retention_s)
        if retention is None or retention < 0:
            raise ValueError('retention_s must be finite and nonnegative')
        if int(maximum_cached_records) < 0:
            raise ValueError('maximum_cached_records must be nonnegative')
        self.session_id = str(uuid.UUID(str(session_id))) if session_id is not None else str(uuid.uuid4())
        self.retention_s = retention
        self.maximum_cached_records = int(maximum_cached_records)
        self._sequence = 0
        self._revision = 0
        self._records: Dict[int, _Record] = {}

    def resolve(self, result) -> Dict[str, OutputIdentity]:
        grouped = defaultdict(list)
        memberships = defaultdict(list)
        for estimate in result.estimates:
            grouped[str(estimate.target_id)].append(estimate)
        for membership in result.global_track_memberships:
            memberships[str(membership.global_target_id)].append(membership)
        observations = {target: _observe(estimates, memberships.get(target, [])) for (target, estimates) in grouped.items()}
        current_by_members = defaultdict(list)
        previous_by_members = defaultdict(list)
        current_owners = defaultdict(set)
        previous_owners = defaultdict(set)
        for (target, observation) in observations.items():
            if observation.members:
                current_by_members[observation.members].append(target)
                for member in observation.members:
                    current_owners[member].add(target)
        for record in self._records.values():
            previous_by_members[record.observation.members].append(record)
            for member in record.observation.members:
                previous_owners[member].add(record.identity[1])
        revision = self._revision + 1
        sequence = self._sequence
        identities: Dict[str, OutputIdentity] = {}
        current: Dict[int, _Record] = {}
        for target in sorted(observations):
            observation = observations[target]
            candidates = previous_by_members.get(observation.members, [])
            previous = candidates[0] if len(candidates) == 1 else None
            if observation.members and len(current_by_members[observation.members]) == 1 and all((len(current_owners[member]) == 1 and len(previous_owners[member]) == 1 for member in observation.members)) and (previous is not None) and _continues(previous.observation, observation):
                identity = previous.identity
                observation = replace(observation, closed_at=observation.closed_at if observation.closed_at is not None else previous.observation.closed_at, epoch_start=observation.epoch_start if observation.epoch_start is not None else previous.observation.epoch_start)
            else:
                if sequence >= JAVA_INT_MAX:
                    raise OverflowError('Kafka mbzhph session sequence exceeds Java int32 range')
                sequence += 1
                identity = (f'{self.session_id}:{sequence}', sequence)
            identities[target] = identity
            if observation.members:
                current[identity[1]] = _Record(identity, observation, revision)
        dormant = [record for record in self._records.values() if record.observation.members.isdisjoint(current_owners)]
        latest = max((item.end for item in observations.values() if item.end is not None), default=None)
        if latest is not None:
            dormant = [record for record in dormant if record.observation.end is not None and latest - record.observation.end <= self.retention_s + _EPS]
        dormant.sort(key=lambda record: (record.revision, record.identity[1]), reverse=True)
        retained = {record.identity[1]: record for record in dormant[:self.maximum_cached_records]}
        retained.update(current)
        self._records = retained
        self._sequence = sequence
        self._revision = revision
        return identities
