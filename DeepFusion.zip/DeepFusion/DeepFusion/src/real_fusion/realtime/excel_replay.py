from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime
import math
from pathlib import Path
import random
from typing import Dict, Iterable, List, Mapping, Sequence
import pandas as pd
from real_fusion.ew import read_and_combine_ew_files
from real_fusion.realtime.demo import RealtimeDemoMessage
from real_fusion.realtime.kafka import split_kafka_json_records, transform_kafka_json_message
from real_fusion.sw import read_and_combine_sw_files
from real_fusion.sw import parse_time_range
REPLAY_EVENT_TIME_FIELD = '__DeepFusionReplayEventTime'

@dataclass(frozen=True)
class ExcelReplayConversion:
    messages: List[RealtimeDemoMessage]
    sw_rows: int
    ew_rows: int
    sw_rejected_rows: int
    ew_rejected_rows: int
    source_field_count_sw: int
    source_field_count_ew: int
    recognized_field_count_sw: int
    recognized_field_count_ew: int
    seed: int
    maximum_gap_s: float | None
    selected_start_time: str | None = None
    selected_end_time: str | None = None

def _json_value(value: object) -> object:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, (pd.Timestamp, datetime, date)):
        return pd.Timestamp(value).isoformat()
    if hasattr(value, 'item'):
        value = value.item()
    if isinstance(value, float) and (not math.isfinite(value)):
        return None
    return value

def _time_fields(timestamp: pd.Timestamp) -> Dict[str, int]:
    return {'D': int(timestamp.day), 'H': int(timestamp.hour), 'Min': int(timestamp.minute), 'Sec': int(timestamp.second), 'Ms': int(timestamp.microsecond // 1000)}

def _wide_source_object(row: pd.Series, source_columns: Iterable[str]) -> Dict[str, object]:
    return {str(name): _json_value(row[str(name)]) for name in source_columns}

def _recognized_base(fields: Sequence[str], kind: str, sequence: int) -> Dict[str, object]:
    result: Dict[str, object] = {str(field): None for field in fields}
    result.update({'Mbzhph': f'EXCEL-{kind}-{sequence:07d}', 'Sjl': int(sequence), 'Bf': 'DeepFusion Excel实时回放'})
    return result

def _timestamp_with_timezone(value: object, timezone_name: str) -> pd.Timestamp:
    timestamp = pd.Timestamp(value)
    if pd.isna(timestamp):
        raise ValueError('Excel 有效行仍包含空绝对时戳。')
    if timestamp.tzinfo is None:
        return timestamp.tz_localize(timezone_name)
    return timestamp.tz_convert(timezone_name)

def _sw_record(row: pd.Series, source_columns: Sequence[str], fields: Sequence[str], sequence: int, timestamp: pd.Timestamp, target_height_column: str | None) -> Dict[str, object]:
    wide = _wide_source_object(row, source_columns)
    if REPLAY_EVENT_TIME_FIELD in wide:
        raise ValueError(f'Excel列名不得使用保留回放字段{REPLAY_EVENT_TIME_FIELD!r}。')
    wide[REPLAY_EVENT_TIME_FIELD] = timestamp.isoformat()
    recognized = _recognized_base(fields, 'SW', sequence)
    recognized.update({'Mbysph': str(row['_mby']), 'Kqly': str(row['_zbb']), 'Kqlysbbh': str(row['_zbb']), 'Mbjd': _json_value(row['_mbj']), 'Mbwd': _json_value(row['_mbw']), 'Mbgd': _json_value(row[target_height_column]) if target_height_column and target_height_column in row.index else None, 'Hb': _json_value(row['_mbg']), 'RCS': _json_value(row.get('_rcs')), 'Xfxsd': None, 'Yfxsd': None, 'Zfxsd': None, **_time_fields(timestamp)})
    wide.update(recognized)
    return wide

def _ew_record(row: pd.Series, source_columns: Sequence[str], fields: Sequence[str], sequence: int, timestamp: pd.Timestamp) -> Dict[str, object]:
    wide = _wide_source_object(row, source_columns)
    if REPLAY_EVENT_TIME_FIELD in wide:
        raise ValueError(f'Excel列名不得使用保留回放字段{REPLAY_EVENT_TIME_FIELD!r}。')
    wide[REPLAY_EVENT_TIME_FIELD] = timestamp.isoformat()
    recognized = _recognized_base(fields, 'EW', sequence)
    recognized.update({'Mbysph': str(row['_mby']), 'Kqly': str(row['_zbb']), 'Kqlysbbh': str(row['_zbb']), 'Hb': _json_value(row.get('_hb')), 'RCS': _json_value(row.get('_rcs')), 'Xj': _json_value(row.get('_range_raw')), 'Fw': _json_value(row.get('_azimuth_raw')), 'Fy': _json_value(row.get('_elevation_raw')), 'Fwjsd': _json_value(row.get('_azimuth_rate_raw')), 'Fyjsd': _json_value(row.get('_elevation_rate_raw')), **_time_fields(timestamp)})
    wide.update(recognized)
    return wide

def build_excel_realtime_messages(fusion_config: dict, kafka_config: dict, sw_paths: Sequence[str | Path], ew_paths: Sequence[str | Path]=(), *, seed: int=20260913, maximum_gap_s: float | None=2.0, start_time: object=None, end_time: object=None) -> ExcelReplayConversion:
    if not sw_paths:
        raise ValueError('Excel 实时回放至少需要一个 SW 文件。')
    maximum_gap = None if maximum_gap_s is None else float(maximum_gap_s)
    if maximum_gap is not None and (not math.isfinite(maximum_gap) or maximum_gap < 0.0):
        raise ValueError('maximum_gap_s 必须是有限非负数或 None。')
    selection_timezone = str(fusion_config['sw'].get('timezone', 'Asia/Shanghai'))
    (range_start, range_end) = parse_time_range(start_time, end_time, selection_timezone)
    sw_read = read_and_combine_sw_files(sw_paths, fusion_config['sw'], start_time=range_start, end_time=range_end)
    ew_read = read_and_combine_ew_files(ew_paths, fusion_config['ew'], start_time=range_start, end_time=range_end) if ew_paths else None
    timezone_name = str(kafka_config.get('event_time', {}).get('timezone', fusion_config['sw'].get('timezone', 'Asia/Shanghai')))
    sw_fields = [str(value) for value in kafka_config['sw']['fields']]
    ew_fields = [str(value) for value in kafka_config['ew']['fields']]
    sw_columns = [str(value) for value in sw_read.input_columns]
    ew_columns = [str(value) for value in ew_read.input_columns] if ew_read else []
    target_height_column = str(fusion_config['sw']['expected_columns'][18]) if len(fusion_config['sw']['expected_columns']) > 18 else None
    pending: List[tuple[pd.Timestamp, int, str, Dict[str, object]]] = []
    sequence = 0
    for (_, row) in sw_read.frame.iterrows():
        sequence += 1
        timestamp = _timestamp_with_timezone(row['_jdsc'], timezone_name)
        pending.append((timestamp, sequence, 'SW', _sw_record(row, sw_columns, sw_fields, sequence, timestamp, target_height_column)))
    if ew_read is not None:
        for (_, row) in ew_read.frame.iterrows():
            sequence += 1
            timestamp = _timestamp_with_timezone(row['_jdsc'], timezone_name)
            pending.append((timestamp, sequence, 'EW', _ew_record(row, ew_columns, ew_fields, sequence, timestamp)))
    pending.sort(key=lambda item: (item[0], item[1], item[2]))
    rng = random.Random(int(seed))
    messages: List[RealtimeDemoMessage] = []
    playback_clock = 0.0
    previous_arrival_offset = -1.0
    previous_time: pd.Timestamp | None = None
    for (timestamp, item_sequence, kind, wide) in pending:
        if previous_time is not None:
            event_gap = max(0.0, float((timestamp - previous_time).total_seconds()))
            playback_clock += event_gap if maximum_gap is None else min(event_gap, maximum_gap)
        previous_time = timestamp
        arrival_offset = max(playback_clock + rng.uniform(0.0002, 0.001), previous_arrival_offset + 1e-06)
        previous_arrival_offset = arrival_offset
        topic = kafka_config['input_topic'] if kind == 'SW' else kafka_config['input_topic_1']
        payload: object = [wide]
        message = RealtimeDemoMessage(kind=kind, topic=str(topic), event_time=timestamp, broker_timestamp_s=float(timestamp.timestamp()), arrival_offset_s=float(arrival_offset), payload=payload)
        records = split_kafka_json_records(kind, payload, kafka_config)
        if len(records) != 1:
            raise AssertionError('单行 Excel 应转换为恰好一条实时对象记录。')
        transform_kafka_json_message(kind, records[0], fusion_config, kafka_config, broker_timestamp_s=message.broker_timestamp_s, arrival_time_s=message.broker_timestamp_s)
        messages.append(message)
    return ExcelReplayConversion(messages=messages, sw_rows=int(sw_read.valid_rows), ew_rows=int(ew_read.valid_rows if ew_read is not None else 0), sw_rejected_rows=int(sw_read.rejected_rows), ew_rejected_rows=int(ew_read.rejected_rows if ew_read is not None else 0), source_field_count_sw=len(sw_columns), source_field_count_ew=len(ew_columns), recognized_field_count_sw=len(sw_fields), recognized_field_count_ew=len(ew_fields), seed=int(seed), maximum_gap_s=maximum_gap, selected_start_time=range_start.isoformat() if range_start is not None else None, selected_end_time=range_end.isoformat() if range_end is not None else None)

def replay_manifest(conversion: ExcelReplayConversion) -> Mapping[str, object]:
    return {'schema_version': 'deepfusion.excel-replay.v2', 'message_shape': 'one JSON object-batch array per Excel row: [{...}]', 'wide_object_policy': 'preserve Excel fields; recognize configured Kafka fields; ignore others', 'legacy_positional_array_policy': 'SW=38, EW=37 only', 'event_time_policy': f'full source event time in extra field {REPLAY_EVENT_TIME_FIELD}; not counted in SW38/EW37', 'sw_rows': conversion.sw_rows, 'ew_rows': conversion.ew_rows, 'sw_rejected_rows': conversion.sw_rejected_rows, 'ew_rejected_rows': conversion.ew_rejected_rows, 'source_field_count_sw': conversion.source_field_count_sw, 'source_field_count_ew': conversion.source_field_count_ew, 'recognized_field_count_sw': conversion.recognized_field_count_sw, 'recognized_field_count_ew': conversion.recognized_field_count_ew, 'seed': conversion.seed, 'maximum_gap_s': conversion.maximum_gap_s, 'selected_start_time': conversion.selected_start_time, 'selected_end_time': conversion.selected_end_time, 'first_event_time': conversion.messages[0].event_time.isoformat() if conversion.messages else None, 'last_event_time': conversion.messages[-1].event_time.isoformat() if conversion.messages else None, 'message_count': len(conversion.messages)}
