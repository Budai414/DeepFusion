from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
import math
from typing import Mapping, Optional
from zoneinfo import ZoneInfo
from real_fusion.realtime.output_schema import new_output_record
TERMINAL_STATES = frozenset({'deleted', 'terminated', 'ended', 'finished', 'dead', 'closed', 'completed'})

def _finite(value: object) -> Optional[float]:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None

@dataclass(frozen=True)
class OutputEncoding:
    coordinate_unit_deg: float
    velocity_unit_mps: float
    velocity_axes: tuple[str, str, str]
    timezone: str

    def __post_init__(self) -> None:
        for name in ('coordinate_unit_deg', 'velocity_unit_mps'):
            value = getattr(self, name)
            number = _finite(value)
            if number is None or number <= 0:
                raise ValueError('Kafka输出经纬度/速度单位必须为有限正数。')
            object.__setattr__(self, name, number)
        if len(self.velocity_axes) != 3 or set(self.velocity_axes) != {'east', 'north', 'up'}:
            raise ValueError('Kafka输出速度轴必须是east、north、up的一个完整排列。')
        object.__setattr__(self, 'velocity_axes', tuple(self.velocity_axes))
        ZoneInfo(self.timezone)

def _local_time(epoch_s: object, timezone: str) -> Optional[datetime]:
    seconds = _finite(epoch_s)
    if seconds is None:
        return None
    try:
        value = datetime.fromtimestamp(seconds, ZoneInfo(timezone))
        return value.replace(microsecond=value.microsecond // 1000 * 1000)
    except (ValueError, OverflowError, OSError):
        return None

def latest_output_estimates(result: object) -> list:
    latest = {}
    latest_sw = {}
    for estimate in result.estimates:
        key = str(estimate.target_id)
        previous = latest_sw.get(key)
        current_time = _finite(estimate.event_time_s)
        previous_time = None if previous is None else _finite(previous.event_time_s)
        if previous is None or (current_time is not None and (previous_time is None or current_time >= previous_time)):
            latest_sw[key] = estimate
    ended = {key for (key, estimate) in latest_sw.items() if str(getattr(estimate, 'lifecycle_state', '')).lower() in TERMINAL_STATES}
    for (is_joint, estimates) in ((False, result.estimates), (True, result.joint_estimates)):
        for estimate in estimates:
            key = str(estimate.target_id)
            if key in ended or str(getattr(estimate, 'lifecycle_state', '')).lower() in TERMINAL_STATES:
                continue
            anchor = latest_sw.get(key)
            if is_joint and anchor is not None and (str(estimate.track_id) != f'J{anchor.track_id}'):
                continue
            previous = latest.get(key)
            current_time = _finite(estimate.event_time_s)
            previous_time = None if previous is None else _finite(previous.event_time_s)
            if previous is None or (current_time is not None and (previous_time is None or current_time >= previous_time)):
                latest[key] = estimate
    return [latest[key] for key in sorted(latest)]

def build_fusion_output_array(snapshot: object, encoding: OutputEncoding, identities: Optional[Mapping[str, tuple[str, int]]]=None) -> list[dict]:
    identities = identities or {}
    generated = _local_time(snapshot.generated_time_s, encoding.timezone)
    records = []
    for estimate in latest_output_estimates(snapshot.result):
        record = new_output_record()
        identity = identities.get(str(estimate.target_id))
        if identity is not None:
            (identifier, ordinal) = identity
            if not isinstance(identifier, str) or not identifier:
                raise ValueError('融合输出mbbh必须为非空字符串。')
            if isinstance(ordinal, bool) or not isinstance(ordinal, int) or (not 1 <= ordinal <= 2147483647):
                raise ValueError('融合输出mbzhph必须为Java int范围内的正整数。')
            record.update(mbbh=identifier, mbzhph=ordinal)
        longitude = _finite(estimate.longitude_deg)
        latitude = _finite(estimate.latitude_deg)
        record['mbjd'] = _finite(longitude / encoding.coordinate_unit_deg) if longitude is not None and -180 <= longitude <= 180 else None
        record['mbwd'] = _finite(latitude / encoding.coordinate_unit_deg) if latitude is not None and -90 <= latitude <= 90 else None
        record['hb'] = _finite(estimate.altitude_m)
        state = estimate.state_enu
        velocity = {axis: _finite(state[index]) if len(state) > index else None for (index, axis) in enumerate(('east', 'north', 'up'), start=3)}
        for (field, axis) in zip(('xfxsd', 'yfxsd', 'zfxsd'), encoding.velocity_axes):
            value = velocity[axis]
            record[field] = None if value is None else _finite(value / encoding.velocity_unit_mps)
        if all((value is not None for value in velocity.values())):
            record['zhsd'] = _finite(math.hypot(*velocity.values()))
        (east, north) = (velocity['east'], velocity['north'])
        if east is not None and north is not None and (east != 0 or north != 0):
            record['zhydfx'] = math.degrees(math.atan2(east, north)) % 360.0
        event_time = _local_time(estimate.event_time_s, encoding.timezone)
        if event_time is not None:
            record.update(ms=event_time.microsecond // 1000, sec=event_time.second, min=event_time.minute, h=event_time.hour, d=event_time.day)
        if generated is not None:
            record['rhsj'] = generated.strftime('%Y-%m-%d %H:%M:%S')
        records.append(record)
    return records
