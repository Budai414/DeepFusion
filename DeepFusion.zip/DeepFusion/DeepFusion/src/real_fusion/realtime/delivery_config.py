from __future__ import annotations
import hashlib
import json
from pathlib import Path

def delivery_consumer_group(config: dict) -> str:
    generation = str(config.get('delivery', {}).get('generation', '')).strip()
    if not generation:
        return config['group_id']
    suffix = hashlib.sha256(generation.encode('utf-8')).hexdigest()[:16]
    return config['group_id'] + '-delivery-' + suffix

def delivery_database_path(config: dict) -> str:
    settings = config.get('delivery', {})
    generation = str(settings.get('generation', '')).strip()
    explicit = settings.get('database')
    if explicit:
        if str(explicit) == ':memory:' or not generation:
            return str(explicit)
        location = Path(explicit)
        token = hashlib.sha256(generation.encode('utf-8')).hexdigest()[:16]
        return str(location.with_name(location.stem + '.' + token + location.suffix))
    base = Path(config.get('_config_path', 'configs/kafka.yaml')).resolve().parent.parent
    directory = Path(settings.get('directory', 'output/kafka_delivery'))
    if not directory.is_absolute():
        directory = base / directory
    namespace = {name: config.get(name) for name in ('brokers', 'group_id', 'input_topic', 'input_topic_1', 'output_topic', 'sw', 'ew', 'json', 'event_time', 'output')}
    namespace['event_time'] = dict(namespace.get('event_time') or {})
    namespace['event_time'].pop('watermarked_future_tolerance_s', None)
    if generation:
        namespace['delivery_generation'] = generation
    token = hashlib.sha256(json.dumps(namespace, sort_keys=True, default=str).encode()).hexdigest()[:24]
    return str(directory / (token + '.sqlite3'))
