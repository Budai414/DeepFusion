from __future__ import annotations
import copy
from dataclasses import dataclass
import json
import math
from pathlib import Path
import random
import threading
import time
from typing import Callable, Dict, List, Optional
import numpy as np
import pandas as pd
from real_fusion.geometry import GeodeticConverter
from real_fusion.realtime.kafka import KafkaBridgeStatus, split_kafka_json_records, transform_kafka_json_message
from real_fusion.realtime.service import RealtimeFusionService, RealtimeSnapshot

@dataclass(frozen=True)
class RealtimeDemoMessage:
    kind: str
    topic: str
    event_time: pd.Timestamp
    broker_timestamp_s: float
    arrival_offset_s: float
    payload: object

def configure_realtime_demo(config: dict) -> dict:
    configured = copy.deepcopy(config)
    reference = configured['scenario'].setdefault('reference', {})
    if not all((key in reference for key in ('longitude_deg', 'latitude_deg', 'altitude_m'))):
        reference.clear()
        reference.update({'mode': 'fixed', 'longitude_deg': 114.5, 'latitude_deg': 38.0, 'altitude_m': 100.0})
    converter = GeodeticConverter(float(reference['longitude_deg']), float(reference['latitude_deg']), float(reference['altitude_m']))
    sensor_enu = {'101': np.asarray([-2100.0, -900.0, -18.0]), '205': np.asarray([2100.0, 1050.0, -9.0])}
    configured.setdefault('ew', {})['sensors'] = {}
    for (zbb, enu) in sensor_enu.items():
        (longitude, latitude, altitude) = converter.enu_to_geodetic(enu)
        configured['ew']['sensors'][zbb] = {'longitude_deg': float(longitude), 'latitude_deg': float(latitude), 'altitude_m': float(altitude), 'azimuth_std_deg': 0.8, 'elevation_std_deg': 0.8, 'range_std_m': 100.0, 'altitude_std_m': 80.0}
    configured.setdefault('realtime', {}).update({'persist_journal': False, 'allowed_lateness_s': 0.45, 'idle_flush_s': 0.35, 'fusion_interval_s': 0.45, 'history_window_s': 120.0, 'maximum_records_per_stream': 10000})
    return configured

def _time_fields(timestamp: pd.Timestamp) -> dict:
    return {'D': int(timestamp.day), 'H': int(timestamp.hour), 'Min': int(timestamp.minute), 'Sec': int(timestamp.second), 'Ms': int(timestamp.microsecond // 1000)}

def _base_payload(fields: List[str], kind: str, sequence: int) -> dict:
    payload = {name: 0 for name in fields}
    payload.update({'Mbzhph': f'LIVE-{kind}-{sequence:05d}', 'Kqlysblx': 'SW/EW共享异构装备', 'Kqlysbbh': f'DEMO-{kind}-{sequence:05d}', 'Sjl': sequence, 'Bjmblx': '低空目标', 'Bf': 'RealFusion本地实时演示', 'Hjzl': 1, 'Xdys': 1, 'Dwsx': '空中', 'Hlsx': '模拟', 'Flmb': 1, 'Hsqk': 0, 'Jzzdfp': 0, 'Jfgrxg': 0, 'Grzt': 1, 'Gxbz': 1, 'Sbbz': 1, 'Mbpd': 1, 'Zxd': 0.95, 'Mbsn': '未知', 'Qspl': 0, 'Jspl': 0, 'Mbpl': kind})
    return payload

def _target_state(target: str, seconds: float) -> tuple[np.ndarray, np.ndarray]:
    if target == 'A':
        initial = np.asarray([-1650.0, -700.0, 260.0])
        velocity = np.asarray([82.0, 34.0, 2.0])
    else:
        initial = np.asarray([1450.0, 1050.0, 410.0])
        velocity = np.asarray([-58.0, -40.0, -1.4])
    return (initial + velocity * float(seconds), velocity)

def _shuffled(payload: dict, rng: random.Random) -> dict:
    fields = list(payload)
    rng.shuffle(fields)
    return {field: payload[field] for field in fields}

def build_realtime_demo_messages(config: dict, kafka_config: dict, seed: int=20260901, start_time: object=None) -> List[RealtimeDemoMessage]:
    rng = random.Random(int(seed))
    reference = config['scenario']['reference']
    converter = GeodeticConverter(float(reference['longitude_deg']), float(reference['latitude_deg']), float(reference['altitude_m']))
    timezone_name = str(kafka_config.get('event_time', {}).get('timezone', config.get('sw', {}).get('timezone', 'Asia/Shanghai')))
    if start_time is None:
        start = pd.Timestamp.now(tz=timezone_name).floor('s')
    else:
        start = pd.Timestamp(start_time)
        if start.tzinfo is None:
            start = start.tz_localize(timezone_name)
        else:
            start = start.tz_convert(timezone_name)
        start = start.floor('s')
    sw_devices = ['101', '205', '309']
    ew_devices = ['101', '205']
    sw_mby = {('A', '101'): 'A-101', ('A', '205'): 'X-205-A', ('A', '309'): '77-A', ('B', '101'): 'B-101', ('B', '205'): 'Y-205-B', ('B', '309'): '88-B'}
    ew_mby = {('A', '101'): 'EW-ALPHA', ('A', '205'): 'EW-X9', ('B', '101'): 'EW-BETA', ('B', '205'): 'EW-Y7'}
    device_bias = {'101': np.asarray([12.0, -8.0, 4.0]), '205': np.asarray([-10.0, 11.0, -3.0]), '309': np.asarray([5.0, 14.0, 2.0])}
    sensor_config = config.get('ew', {}).get('sensors', {})
    sensor_enu = {zbb: converter.geodetic_to_enu(float(sensor_config[zbb]['longitude_deg']), float(sensor_config[zbb]['latitude_deg']), float(sensor_config[zbb]['altitude_m'])) for zbb in ew_devices}
    sw_fields = list(kafka_config['sw']['fields'])
    ew_fields = list(kafka_config['ew']['fields'])
    messages: List[RealtimeDemoMessage] = []
    sequence = 0

    def append(kind: str, event_time: pd.Timestamp, payload: dict, arrival_offset: float) -> None:
        topic = kafka_config['input_topic'] if kind == 'SW' else kafka_config['input_topic_1']
        messages.append(RealtimeDemoMessage(kind=kind, topic=topic, event_time=event_time, broker_timestamp_s=float((event_time + pd.Timedelta(seconds=0.05)).timestamp()), arrival_offset_s=float(arrival_offset), payload=_shuffled(payload, rng)))
    for second in range(18):
        event_time = start + pd.Timedelta(seconds=second)
        for (target_index, target) in enumerate(('A', 'B')):
            (true_position, velocity) = _target_state(target, second)
            for (device_index, zbb) in enumerate(sw_devices):
                if (second + target_index * 2 + device_index) % 17 == 9:
                    continue
                sequence += 1
                payload = _base_payload(sw_fields, 'SW', sequence)
                noise = np.asarray([2.5 * math.sin(0.43 * second + device_index + target_index), 2.2 * math.cos(0.31 * second + device_index), 0.9 * math.sin(0.27 * second + target_index)])
                measured = true_position + device_bias[zbb] + noise
                (longitude, latitude, altitude) = converter.enu_to_geodetic(measured)
                payload.update({'Mbysph': sw_mby[target, zbb], 'Kqly': zbb, 'Kqlysbbh': f'SHARED-{zbb}', 'Mbjd': round(float(longitude), 9), 'Mbwd': round(float(latitude), 9), 'Mbgd': round(float(altitude) + 15.0, 3), 'Hb': round(float(altitude), 3), 'Xfxsd': round(float(velocity[0]), 3), 'Yfxsd': round(float(velocity[1]), 3), 'Zfxsd': round(float(velocity[2]), 3), 'RCS': -7.0 if target == 'A' else -4.5, **_time_fields(event_time)})
                delay = 0.05 + device_index * 0.025 + target_index * 0.012
                if sequence % 19 == 0:
                    delay += 0.32
                append('SW', event_time, payload, second + delay)
    for step in range(14):
        seconds = 0.45 + step * 1.25
        event_time = start + pd.Timedelta(seconds=seconds)
        for (target_index, target) in enumerate(('A', 'B')):
            (true_position, _) = _target_state(target, seconds)
            (_, _, true_altitude) = converter.enu_to_geodetic(true_position)
            for (device_index, zbb) in enumerate(ew_devices):
                if (step + target_index + device_index) % 23 == 11:
                    continue
                sequence += 1
                payload = _base_payload(ew_fields, 'EW', sequence)
                relative = true_position - sensor_enu[zbb]
                horizontal = float(np.hypot(relative[0], relative[1]))
                azimuth = math.degrees(math.atan2(relative[0], relative[1])) % 360.0
                elevation = math.degrees(math.atan2(relative[2], max(horizontal, 1e-09)))
                distance = float(np.linalg.norm(relative))
                azimuth += 0.14 * math.sin(step + device_index + target_index)
                elevation += 0.09 * math.cos(step + device_index)
                has_range = (step + device_index + target_index) % 5 in {1, 4}
                payload.update({'Mbysph': ew_mby[target, zbb], 'Kqly': zbb, 'Kqlysbbh': f'SHARED-{zbb}', 'Hb': round(float(true_altitude) + 4.0 * math.sin(step), 3), 'RCS': -7.0 if target == 'A' else -4.5, 'Xj': int(round(distance)) if has_range else 0, 'Fw': int(round(azimuth % 360.0 * 100.0)), 'Fy': int(round(elevation * 100.0)), 'Fwjsd': 0, 'Fyjsd': 0, **_time_fields(event_time)})
                delay = 0.08 + device_index * 0.035 + target_index * 0.016
                if sequence % 13 == 0:
                    delay += 0.28
                append('EW', event_time, payload, seconds + delay)
    messages.sort(key=lambda item: (item.arrival_offset_s, item.topic))
    return messages

def write_realtime_demo_jsonl(messages: List[RealtimeDemoMessage], path: str | Path) -> Path:
    destination = Path(path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('w', encoding='utf-8') as handle:
        for (index, item) in enumerate(messages, start=1):
            handle.write(json.dumps({'arrival_index': index, 'kind': item.kind, 'topic': item.topic, 'event_time': item.event_time.isoformat(), 'broker_timestamp_s': item.broker_timestamp_s, 'arrival_offset_s': round(item.arrival_offset_s, 6), 'payload': item.payload}, ensure_ascii=False, separators=(',', ':')) + '\n')
    return destination

class DemoRealtimeBridge:

    def __init__(self, service: RealtimeFusionService, kafka_config: dict, messages: List[RealtimeDemoMessage], playback_scale: float=0.38, startup_delay_s: float=1.2, on_log: Optional[Callable[[str], None]]=None, on_complete: Optional[Callable[[], None]]=None) -> None:
        self.service = service
        self.config = copy.deepcopy(kafka_config)
        self.messages = list(messages)
        self.playback_scale = max(0.0, float(playback_scale))
        self.startup_delay_s = max(0.0, float(startup_delay_s))
        self.on_log = on_log
        self.on_complete = on_complete
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._running = False
        self._consumed = 0
        self._rejected = 0
        self._published = 0
        self._last_error: Optional[str] = None
        self._downstream_snapshot_callback = service.on_snapshot

    def _log(self, message: str) -> None:
        if self.on_log is not None:
            self.on_log(str(message))

    def start(self) -> None:
        if self._running:
            return
        self._stop_event.clear()
        self.service.on_snapshot = self._handle_snapshot
        self._running = True
        self._thread = threading.Thread(target=self._play, name='RealFusionLocalRealtimeDemo', daemon=True)
        self._thread.start()
        self._log(f'本地实时演示已启动：共{len(self.messages)}条SW/EW交错报文，无需Kafka服务器。')

    def _play(self) -> None:
        started = time.monotonic()
        try:
            for item in self.messages:
                deadline = started + self.startup_delay_s + item.arrival_offset_s * self.playback_scale
                wait_s = deadline - time.monotonic()
                if wait_s > 0 and self._stop_event.wait(wait_s):
                    break
                if self._stop_event.is_set():
                    break
                try:
                    records = split_kafka_json_records(item.kind, item.payload, self.config)
                    for (record_index, record) in enumerate(records):
                        normalized = transform_kafka_json_message(item.kind, record, self.service.config, self.config, broker_timestamp_s=item.broker_timestamp_s, arrival_time_s=time.time())
                        peer = 'local-demo' if len(records) == 1 else f'local-demo#item={record_index}'
                        self.service.submit(item.kind, normalized, peer=peer)
                except Exception as error:
                    with self._lock:
                        self._rejected += 1
                        self._last_error = str(error)
                    self._log(f'本地演示报文拒绝：{error}')
                else:
                    with self._lock:
                        self._consumed += len(records)
                        self._last_error = None
            if not self._stop_event.is_set():
                drain_timeout_s = max(5.0, float(self.service.realtime.get('completion_drain_timeout_s', 30.0)))
                drain_deadline = time.monotonic() + drain_timeout_s
                drained = False
                while not self._stop_event.is_set():
                    if self.service.wait_until_idle(timeout_s=0.1):
                        drained = True
                        break
                    if time.monotonic() >= drain_deadline:
                        self._log('本地实时演示数据已发送完毕，融合仍在处理；继续等待最后一份快照后清除航迹。')
                        drain_deadline = time.monotonic() + drain_timeout_s
                if drained:
                    status = self.service.status()
                    if status.buffered_sw == 0 and status.buffered_ew > 0:
                        self._log('本地实时回放输入已处理完毕，当前窗口缺少SW主航迹；EW量测已保留，未生成本批融合快照。')
                    else:
                        self._log('本地实时演示数据已全部处理，已结束航迹将从地图清除。')
                    if self.on_complete is not None:
                        self.on_complete()
        finally:
            with self._lock:
                self._running = False

    def _handle_snapshot(self, snapshot: RealtimeSnapshot) -> None:
        with self._lock:
            self._published += 1
        if self._downstream_snapshot_callback is not None:
            self._downstream_snapshot_callback(snapshot)

    def status(self) -> KafkaBridgeStatus:
        with self._lock:
            return KafkaBridgeStatus(running=self._running, consumed_messages=self._consumed, rejected_messages=self._rejected, published_snapshots=self._published, last_error=self._last_error)

    def stop_receiving(self, timeout_s: float=30.0) -> None:
        self._stop_event.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=max(0.0, float(timeout_s)))
            if thread.is_alive():
                raise TimeoutError('实时回放输入仍在停止，请等待后重试。')
        self._thread = None
        with self._lock:
            self._running = False

    def stop(self) -> None:
        self.stop_receiving()
        self.service.on_snapshot = self._downstream_snapshot_callback
        with self._lock:
            self._running = False
        self._log('本地实时演示已停止。')
