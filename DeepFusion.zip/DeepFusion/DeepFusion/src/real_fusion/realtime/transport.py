from __future__ import annotations
import json
import socketserver
import threading
from typing import Callable, Optional

class _ThreadingServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

class JsonLineTcpReceiver:

    def __init__(self, host: str, port: int, data_kind: str, callback: Callable[[str, object, str], int], maximum_message_bytes: int=1048576) -> None:
        self.host = str(host)
        self.requested_port = int(port)
        self.data_kind = str(data_kind).upper()
        self.callback = callback
        self.maximum_message_bytes = int(maximum_message_bytes)
        self._server: Optional[_ThreadingServer] = None
        self._thread: Optional[threading.Thread] = None

    @property
    def port(self) -> int:
        if self._server is None:
            return self.requested_port
        return int(self._server.server_address[1])

    def start(self) -> None:
        if self._server is not None:
            return
        owner = self

        class Handler(socketserver.StreamRequestHandler):

            def handle(self) -> None:
                peer = f'{self.client_address[0]}:{self.client_address[1]}'
                while True:
                    line = self.rfile.readline(owner.maximum_message_bytes + 1)
                    if not line:
                        return
                    if len(line) > owner.maximum_message_bytes:
                        response = {'ok': False, 'error': '报文超过最大字节数'}
                    else:
                        try:
                            message = json.loads(line.decode('utf-8-sig'))
                            sequence = owner.callback(owner.data_kind, message, peer)
                            response = {'ok': True, 'sequence': sequence, 'data_kind': owner.data_kind}
                        except Exception as error:
                            response = {'ok': False, 'error': str(error), 'data_kind': owner.data_kind}
                    self.wfile.write((json.dumps(response, ensure_ascii=False) + '\n').encode('utf-8'))
                    self.wfile.flush()
        self._server = _ThreadingServer((self.host, self.requested_port), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, kwargs={'poll_interval': 0.2}, name=f'RealFusion{self.data_kind}Receiver', daemon=True)
        self._thread.start()

    def stop(self) -> None:
        (server, thread) = (self._server, self._thread)
        self._server = None
        self._thread = None
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)
