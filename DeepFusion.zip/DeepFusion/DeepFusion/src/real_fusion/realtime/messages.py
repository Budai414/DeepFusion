from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Mapping
import pandas as pd
from real_fusion.realtime.validation import validate_stream_core_fields

@dataclass(frozen=True)
class StreamRecord:
    data_kind: str
    payload: Dict[str, object]
    event_time_s: float
    arrival_time_s: float
    sequence: int
    peer: str = 'local'

def _payload_body(message: object) -> object:
    if not isinstance(message, Mapping):
        return message
    for key in ('payload', 'data', 'record'):
        if key in message:
            return message[key]
    return {key: value for (key, value) in message.items() if key not in {'data_kind', 'kind', 'type', 'topic'}}

def _event_epoch(value: object, timezone_name: str) -> float:
    try:
        timestamp = pd.Timestamp(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f'绝对时戳无法解析: {value!r}') from error
    if pd.isna(timestamp):
        raise ValueError('绝对时戳不能为空。')
    if timestamp.tzinfo is None:
        timestamp = timestamp.tz_localize(timezone_name)
    else:
        timestamp = timestamp.tz_convert(timezone_name)
    return float(timestamp.timestamp())

def normalize_stream_message(data_kind: str, message: object, config: dict, arrival_time_s: float, sequence: int, peer: str='local') -> StreamRecord:
    kind = str(data_kind).strip().upper()
    if kind not in {'SW', 'EW'}:
        raise ValueError(f'实时数据类型只能是 SW 或 EW，实际为: {data_kind!r}')
    section = config[kind.lower()]
    expected = [str(value) for value in section['expected_columns']]
    body = _payload_body(message)
    if isinstance(body, (list, tuple)):
        if len(body) != len(expected):
            raise ValueError(f'{kind} 数组报文必须包含 {len(expected)} 项，实际为 {len(body)} 项。')
        payload = dict(zip(expected, body))
    elif isinstance(body, Mapping):
        trim = bool(section.get('trim_header_whitespace', True))
        aliases = {str(key).strip() if trim else str(key): str(value).strip() if trim else str(value) for (key, value) in section.get('header_aliases', {}).items()}
        payload = {}
        for (key, value) in body.items():
            name = str(key).strip() if trim else str(key)
            name = aliases.get(name, name)
            if name in payload:
                raise ValueError(f'{kind} 实时报文表头规范化后出现重复字段: {name}')
            payload[name] = value
    else:
        raise ValueError(f'{kind} 实时报文必须是 JSON 对象或按表头顺序排列的数组。')
    realtime = config.get('realtime', {})
    require_full = bool(realtime.get('require_full_schema', True))
    core = {str(key): str(value) for (key, value) in section['_core_columns'].items()}
    required_roles = ('MBY', 'ZBB', 'MBJ', 'MBW', 'HB', 'JDSC') if kind == 'SW' else ('MBY', 'ZBB', 'FW', 'JDSC')
    required = expected if require_full else [core[role] for role in required_roles]
    missing = [name for name in required if name not in payload]
    if missing:
        raise ValueError(f'{kind} 实时报文缺少字段: {missing}')
    if require_full:
        extra = [name for name in payload if name not in expected and (not str(name).startswith('__realtime_'))]
        if extra and (not bool(section.get('allow_extra_columns', False))):
            raise ValueError(f'{kind} 实时报文包含配置之外的字段: {extra}')
    normalized = {name: payload.get(name) for name in expected}
    normalized.update({str(name): value for (name, value) in payload.items() if str(name).startswith('__realtime_')})
    validate_stream_core_fields(kind, normalized, section)
    event_time_s = _event_epoch(normalized[core['JDSC']], str(section['timezone']))
    return StreamRecord(data_kind=kind, payload=normalized, event_time_s=event_time_s, arrival_time_s=float(arrival_time_s), sequence=int(sequence), peer=str(peer))
