from __future__ import annotations
from dataclasses import dataclass
from itertools import chain
import json
import math
import threading
import time
from typing import Iterable, Optional

@dataclass(frozen=True)
class KafkaReplayProducerStatus:
    running: bool
    attempted_messages: int
    sent_messages: int
    failed_messages: int
    stopped: bool
    last_error: Optional[str]

class KafkaInputReplayProducer:

    def __init__(self, kafka_config: dict, *, producer_factory=None, on_log=None, stop_event: Optional[threading.Event]=None, monotonic_fn=time.monotonic, wait_fn=None) -> None:
        self.config = kafka_config
        self.producer_factory = producer_factory
        self.on_log = on_log
        self.stop_event = stop_event or threading.Event()
        self.monotonic_fn = monotonic_fn
        self.wait_fn = wait_fn
        self._producer = None
        self._lock = threading.Lock()
        self._running = False
        self._attempted = 0
        self._sent = 0
        self._failed = 0
        self._stopped = False
        self._last_error: Optional[str] = None

    def _log(self, message: str) -> None:
        if self.on_log is not None:
            self.on_log(str(message))

    def _security_kwargs(self) -> dict:
        security = self.config.get('security', {})
        kwargs = {'security_protocol': str(security.get('protocol', 'PLAINTEXT'))}
        if kwargs['security_protocol'].startswith('SASL'):
            kwargs.update({'sasl_mechanism': str(security.get('sasl_mechanism', 'PLAIN')), 'sasl_plain_username': str(security.get('username', '')), 'sasl_plain_password': str(security.get('password', ''))})
        for key in ('ssl_cafile', 'ssl_certfile', 'ssl_keyfile'):
            if str(security.get(key, '')).strip():
                kwargs[key] = str(security[key]).strip()
        if kwargs['security_protocol'] in {'SSL', 'SASL_SSL'}:
            kwargs['ssl_check_hostname'] = bool(security.get('ssl_check_hostname', True))
        return kwargs

    def _create_producer(self) -> None:
        if any((value == '服务器地址' for value in self.config['brokers'])):
            raise ValueError('请先把configs/kafka.yaml中的“服务器地址”改为实际host:port。')
        factory = self.producer_factory
        if factory is None:
            try:
                from kafka import KafkaProducer
            except ImportError as error:
                raise RuntimeError('缺少Kafka客户端，请在DeepFusion环境安装requirements.txt中的kafka-python-ng。') from error
            factory = KafkaProducer
        producer = self.config.get('input_replay_producer', {})
        kwargs = {'bootstrap_servers': self.config['brokers'], 'client_id': self.config['client_id'] + '-input-replay-producer', 'acks': producer.get('acknowledgements', 'all'), 'retries': int(producer.get('retries', 5)), 'linger_ms': int(producer.get('linger_ms', 20)), 'batch_size': int(producer.get('batch_size', 32768)), 'request_timeout_ms': int(producer.get('request_timeout_ms', 30000)), 'max_request_size': int(producer.get('max_request_size', 10485760)), 'value_serializer': lambda value: json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode(str(self.config.get('json', {}).get('encoding', 'utf-8'))), **self._security_kwargs()}
        if producer.get('compression_type'):
            kwargs['compression_type'] = str(producer['compression_type'])
        self._producer = factory(**kwargs)

    def _wait(self, seconds: float) -> bool:
        if seconds <= 0.0:
            return self.stop_event.is_set()
        if self.wait_fn is not None:
            self.wait_fn(seconds)
            return self.stop_event.is_set()
        return self.stop_event.wait(seconds)

    def _await_futures(self, pending: list[object], timeout_s: float) -> None:
        first_error: Optional[Exception] = None
        for future in pending:
            try:
                getter = getattr(future, 'get', None)
                if callable(getter):
                    getter(timeout=timeout_s)
                with self._lock:
                    self._sent += 1
            except Exception as error:
                with self._lock:
                    self._failed += 1
                    self._last_error = str(error)
                if first_error is None:
                    first_error = error
        pending.clear()
        if first_error is not None:
            raise RuntimeError(f'Kafka broker未确认输入回放报文: {first_error}') from first_error

    def publish(self, messages: Iterable[object], *, speed: Optional[float]=None, startup_delay_s: Optional[float]=None) -> KafkaReplayProducerStatus:
        producer_config = self.config.get('input_replay_producer', {})
        selected_speed = float(producer_config.get('speed', 1.0) if speed is None else speed)
        selected_delay = float(producer_config.get('startup_delay_s', 1.0) if startup_delay_s is None else startup_delay_s)
        if not math.isfinite(selected_speed) or selected_speed < 0.0:
            raise ValueError('Kafka回放speed必须是有限非负数；0表示不等待。')
        if not math.isfinite(selected_delay) or selected_delay < 0.0:
            raise ValueError('Kafka回放startup_delay_s必须是有限非负数。')
        allowed_topics = {str(self.config['input_topic']): 'SW', str(self.config['input_topic_1']): 'EW'}
        ack_batch_size = int(producer_config.get('ack_batch_size', 200))
        timeout_s = float(producer_config.get('delivery_timeout_s', 30.0))
        preserve_timestamp = bool(producer_config.get('preserve_broker_timestamp', True))
        continue_on_error = bool(producer_config.get('continue_on_error', False))
        if ack_batch_size < 1 or timeout_s <= 0.0:
            raise ValueError('ack_batch_size必须至少为1，delivery_timeout_s必须大于0。')
        iterator = iter(messages)
        try:
            first = next(iterator)
        except StopIteration as error:
            raise ValueError('没有可发送的Kafka回放报文。') from error
        if self._producer is None:
            self._create_producer()
        self.stop_event.clear()
        with self._lock:
            self._running = True
            self._attempted = 0
            self._sent = 0
            self._failed = 0
            self._stopped = False
            self._last_error = None
        start = self.monotonic_fn()
        first_offset = float(first.arrival_offset_s)
        pending: list[object] = []
        try:
            for message in chain((first,), iterator):
                if self.stop_event.is_set():
                    with self._lock:
                        self._stopped = True
                    break
                offset = float(message.arrival_offset_s)
                if not math.isfinite(offset) or offset < 0.0 or offset < first_offset:
                    raise ValueError('回放记录arrival_offset_s必须为有限非负数并按非递减顺序排列。')
                if selected_speed > 0.0:
                    deadline = start + selected_delay + (offset - first_offset) / selected_speed
                    if self._wait(deadline - self.monotonic_fn()):
                        with self._lock:
                            self._stopped = True
                        break
                topic = str(message.topic)
                kind = str(message.kind).strip().upper()
                expected_kind = allowed_topics.get(topic)
                if expected_kind is None or expected_kind != kind:
                    raise ValueError(f'拒绝向非配置输入Topic发送：kind={kind!r}, topic={topic!r}。')
                send_kwargs = {'value': message.payload}
                if preserve_timestamp:
                    timestamp_s = float(message.broker_timestamp_s)
                    if not math.isfinite(timestamp_s):
                        raise ValueError('broker_timestamp_s必须是有限数值。')
                    send_kwargs['timestamp_ms'] = int(round(timestamp_s * 1000.0))
                with self._lock:
                    self._attempted += 1
                try:
                    pending.append(self._producer.send(topic, **send_kwargs))
                    if len(pending) >= ack_batch_size:
                        self._await_futures(pending, timeout_s)
                except Exception as error:
                    with self._lock:
                        if not isinstance(error, RuntimeError) or not str(error).startswith('Kafka broker未确认'):
                            self._failed += 1
                        self._last_error = str(error)
                    if not continue_on_error:
                        raise
                    self._log(f'Kafka输入回放报文发送失败，已按配置继续：{error}')
            if pending:
                try:
                    self._await_futures(pending, timeout_s)
                except Exception as error:
                    if not continue_on_error:
                        raise
                    self._log(f'Kafka输入回放末批确认失败，已按配置结束：{error}')
            self._producer.flush(timeout=timeout_s)
        except Exception as error:
            with self._lock:
                self._last_error = str(error)
            raise
        finally:
            with self._lock:
                self._running = False
        status = self.status()
        self._log(f'Kafka输入回放结束：尝试={status.attempted_messages}，broker确认={status.sent_messages}，失败={status.failed_messages}。')
        return status

    def status(self) -> KafkaReplayProducerStatus:
        with self._lock:
            return KafkaReplayProducerStatus(running=self._running, attempted_messages=self._attempted, sent_messages=self._sent, failed_messages=self._failed, stopped=self._stopped, last_error=self._last_error)

    def stop(self) -> None:
        self.stop_event.set()

    def close(self) -> None:
        self.stop_event.set()
        if self._producer is not None:
            timeout = float(self.config.get('input_replay_producer', {}).get('delivery_timeout_s', 30.0))
            self._producer.flush(timeout=timeout)
            self._producer.close(timeout=timeout)
            self._producer = None
