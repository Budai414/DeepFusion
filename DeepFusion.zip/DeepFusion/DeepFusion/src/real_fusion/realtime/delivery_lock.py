from __future__ import annotations
import os
from pathlib import Path

class DeliveryStoreInUseError(RuntimeError):
    pass

class FileDeliveryLock:

    def __init__(self, path):
        self.path = Path(path)
        self._handle = None

    def acquire(self):
        if self._handle is not None:
            return self
        handle = self.path.open('a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                handle.seek(0, os.SEEK_END)
                if handle.tell() == 0:
                    handle.write(b'\x00')
                    handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            handle.close()
            raise DeliveryStoreInUseError(f'Kafka delivery database is already in use by another instance: {self.path}; stop that instance before reopening the same database') from error
        except BaseException:
            handle.close()
            raise
        self._handle = handle
        return self

    def close(self):
        (handle, self._handle) = (self._handle, None)
        if handle is None:
            return
        try:
            if os.name == 'nt':
                import msvcrt
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()
