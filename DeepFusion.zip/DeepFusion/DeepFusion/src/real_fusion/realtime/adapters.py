from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Sequence
import numpy as np
import pandas as pd
from real_fusion.ew.reader import EwReadResult
from real_fusion.realtime.messages import StreamRecord
from real_fusion.sw.reader import SwReadResult, normalize_zbb
STREAM_SW_PATH = Path('realtime_sw_stream')
STREAM_EW_PATH = Path('realtime_ew_stream')

def _base_frame(records: Sequence[StreamRecord], columns: Sequence[str], timezone_name: str) -> pd.DataFrame:
    frame = pd.DataFrame.from_records([item.payload for item in records])
    for column in columns:
        if column not in frame:
            frame[column] = None
    internal_columns = sorted((column for column in frame.columns if str(column).startswith('__realtime_')))
    frame = frame[[*list(columns), *internal_columns]]
    frame['_stream_sequence'] = [item.sequence for item in records]
    frame['_arrival_epoch_s'] = [item.arrival_time_s for item in records]
    frame['_epoch_s'] = [item.event_time_s for item in records]
    frame['_jdsc'] = pd.to_datetime(frame['_epoch_s'], unit='s', utc=True, errors='coerce').dt.round('us').dt.tz_convert(timezone_name).dt.tz_localize(None)
    return frame

def build_sw_read_result(records: Sequence[StreamRecord], sw_config: dict) -> SwReadResult:
    if not records:
        raise ValueError('实时 SW 缓冲区中没有可融合报文。')
    expected = [str(value) for value in sw_config['expected_columns']]
    core = {str(key): str(value) for (key, value) in sw_config['_core_columns'].items()}
    working = _base_frame(records, expected, str(sw_config.get('timezone', 'Asia/Shanghai')))
    total = len(working)
    working['_source_file'] = 'realtime://sw'
    working['_excel_row'] = working['_stream_sequence'].astype(int)
    working['_mby'] = working[core['MBY']].map(normalize_zbb)
    working['_zbb'] = working[core['ZBB']].map(normalize_zbb)
    working['_mbj'] = pd.to_numeric(working[core['MBJ']], errors='coerce')
    working['_mbw'] = pd.to_numeric(working[core['MBW']], errors='coerce')
    working['_mbg'] = pd.to_numeric(working[core['HB']], errors='coerce')
    rcs_column = core.get('RCS')
    if rcs_column in working:
        working['_rcs'] = working[rcs_column]
    for (axis, internal_name) in (('east', '__realtime_velocity_east_mps'), ('north', '__realtime_velocity_north_mps'), ('up', '__realtime_velocity_up_mps')):
        working[f'_reported_velocity_{axis}_mps'] = pd.to_numeric(working[internal_name], errors='coerce') if internal_name in working else np.nan
    validation = sw_config.get('position_validation', {})
    epsilon = float(validation.get('zero_epsilon', 1e-09))
    lon_range = validation.get('longitude_range_deg', [-180.0, 180.0])
    lat_range = validation.get('latitude_range_deg', [-90.0, 90.0])
    alt_range = validation.get('altitude_range_m', [-1000.0, 100000.0])
    lon = working['_mbj'].to_numpy(dtype=float)
    lat = working['_mbw'].to_numpy(dtype=float)
    alt = working['_mbg'].to_numpy(dtype=float)
    invalid_mby = working['_mby'].eq('').to_numpy(dtype=bool)
    invalid_zbb = working['_zbb'].eq('').to_numpy(dtype=bool)
    invalid_time = working['_jdsc'].isna().to_numpy(dtype=bool)
    invalid_lon = ~np.isfinite(lon) | (lon < float(lon_range[0])) | (lon > float(lon_range[1]))
    invalid_lat = ~np.isfinite(lat) | (lat < float(lat_range[0])) | (lat > float(lat_range[1]))
    invalid_alt = ~np.isfinite(alt) | (alt < float(alt_range[0])) | (alt > float(alt_range[1]))
    if bool(validation.get('reject_zero_longitude', True)):
        invalid_lon |= np.abs(lon) <= epsilon
    if bool(validation.get('reject_zero_latitude', True)):
        invalid_lat |= np.abs(lat) <= epsilon
    if bool(validation.get('reject_zero_altitude', True)):
        invalid_alt |= np.abs(alt) <= epsilon
    invalid = invalid_mby | invalid_zbb | invalid_time | invalid_lon | invalid_lat | invalid_alt
    rejected_examples: List[Dict[str, object]] = []
    for position in np.flatnonzero(invalid)[:int(sw_config.get('max_rejected_examples', 20))]:
        row = working.iloc[int(position)]
        reasons = []
        if invalid_mby[position]:
            reasons.append('目标编号为空')
        if invalid_zbb[position]:
            reasons.append('装备编号为空')
        if invalid_time[position]:
            reasons.append('绝对时戳不能解析')
        if invalid_lon[position]:
            reasons.append('目标经度无效')
        if invalid_lat[position]:
            reasons.append('目标纬度无效')
        if invalid_alt[position]:
            reasons.append('海拔无效')
        rejected_examples.append({'source_file': 'realtime://sw', 'excel_row': int(row['_stream_sequence']), 'mby': row['_mby'] or None, 'zbb': row['_zbb'] or None, 'reason': '；'.join(reasons)})
    valid = working.loc[~invalid].copy()
    if valid.empty:
        raise ValueError('实时 SW 窗口没有同时具备目标、装备、经纬度、海拔和绝对时戳的有效报文。')
    valid = valid.sort_values(['_jdsc', '_mby', '_zbb', '_stream_sequence'], kind='stable').reset_index(drop=True)
    targets = list(dict.fromkeys(valid['_mby'].tolist()))
    devices = list(dict.fromkeys(valid['_zbb'].tolist()))
    rejected = int(invalid.sum())
    summary = {'source_file': '实时SW流', 'source_path': 'realtime://sw', 'read_rows': total, 'valid_rows': len(valid), 'quality_valid_rows': len(valid), 'time_filtered_rows': 0, 'rejected_rows': rejected, 'target_count': len(targets), 'target_values': '、'.join(sorted(targets)), 'zbb_count': len(devices), 'zbb_values': '、'.join(sorted(devices))}
    return SwReadResult(path=STREAM_SW_PATH, frame=valid, total_rows=total, valid_rows=len(valid), rejected_rows=rejected, rejected_examples=rejected_examples, device_values=devices, target_values=targets, input_columns=expected, expected_columns=expected, schema_validation_mode='realtime', input_config_path=Path(str(sw_config['_input_config_path'])) if sw_config.get('_input_config_path') else None, schema_name=str(sw_config.get('_schema_name', 'sw')), source_paths=[STREAM_SW_PATH], file_summaries=[summary], quality_valid_rows=len(valid))

def build_ew_read_result(records: Sequence[StreamRecord], ew_config: dict) -> EwReadResult:
    expected = [str(value) for value in ew_config['expected_columns']]
    if not records:
        empty = pd.DataFrame(columns=expected)
        return EwReadResult(path=STREAM_EW_PATH, frame=empty, total_rows=0, valid_rows=0, rejected_rows=0, rejected_examples=[], input_columns=expected, expected_columns=expected, source_paths=[STREAM_EW_PATH])
    core = {str(key): str(value) for (key, value) in ew_config['_core_columns'].items()}
    working = _base_frame(records, expected, str(ew_config.get('timezone', 'Asia/Shanghai')))
    total = len(working)
    working['_source_file'] = 'realtime://ew'
    working['_excel_row'] = working['_stream_sequence'].astype(int)
    working['_mby'] = working[core['MBY']].map(normalize_zbb)
    working['_zbb'] = working[core['ZBB']].map(normalize_zbb)
    measurement = ew_config.get('measurement', {})
    for (target, role) in (('_azimuth_raw', 'FW'), ('_elevation_raw', 'FY'), ('_azimuth_rate_raw', 'FW_RATE'), ('_elevation_rate_raw', 'FY_RATE'), ('_range_raw', 'XJ')):
        column = core.get(role)
        working[target] = pd.to_numeric(working[column], errors='coerce') if column in working else np.nan
    working['_azimuth_deg'] = working['_azimuth_raw'] * float(measurement.get('azimuth_scale_deg_per_unit', 0.01))
    working['_elevation_deg'] = working['_elevation_raw'] * float(measurement.get('elevation_scale_deg_per_unit', 0.01))
    working['_azimuth_rate_deg_s'] = working['_azimuth_rate_raw'] * float(measurement.get('azimuth_rate_scale_deg_s_per_unit', 0.01))
    working['_elevation_rate_deg_s'] = working['_elevation_rate_raw'] * float(measurement.get('elevation_rate_scale_deg_s_per_unit', 0.01))
    working['_range_m'] = working['_range_raw'] * float(measurement.get('range_scale_m_per_unit', 1.0))
    if bool(ew_config.get('range_zero_is_missing', True)):
        working.loc[working['_range_m'].abs() <= float(ew_config.get('range_zero_epsilon_m', 1e-09)), '_range_m'] = np.nan
    working.loc[working['_range_m'] < 0.0, '_range_m'] = np.nan
    working['_hb'] = pd.to_numeric(working[core['HB']], errors='coerce')
    working.loc[~np.isfinite(working['_hb'].to_numpy(dtype=float)), '_hb'] = np.nan
    rcs_column = core.get('RCS')
    working['_rcs'] = pd.to_numeric(working[rcs_column], errors='coerce') if rcs_column in working else np.nan
    azimuth = working['_azimuth_deg'].to_numpy(dtype=float)
    elevation = working['_elevation_deg'].to_numpy(dtype=float)
    azimuth_rate = working['_azimuth_rate_deg_s'].to_numpy(dtype=float)
    elevation_rate = working['_elevation_rate_deg_s'].to_numpy(dtype=float)
    azimuth_range = measurement.get('azimuth_range_deg', [0.0, 360.0])
    elevation_range = measurement.get('elevation_range_deg', [-90.0, 90.0])
    azimuth_rate_range = measurement.get('azimuth_rate_range_deg_s', [-20.0, 20.0])
    elevation_rate_range = measurement.get('elevation_rate_range_deg_s', [-20.0, 20.0])
    invalid = working['_mby'].eq('').to_numpy(dtype=bool) | working['_zbb'].eq('').to_numpy(dtype=bool) | working['_jdsc'].isna().to_numpy(dtype=bool) | ~np.isfinite(azimuth) | (azimuth < float(azimuth_range[0])) | (azimuth > float(azimuth_range[1])) | np.isfinite(elevation) & ((elevation < float(elevation_range[0])) | (elevation > float(elevation_range[1]))) | np.isfinite(azimuth_rate) & ((azimuth_rate < float(azimuth_rate_range[0])) | (azimuth_rate > float(azimuth_rate_range[1]))) | np.isfinite(elevation_rate) & ((elevation_rate < float(elevation_rate_range[0])) | (elevation_rate > float(elevation_rate_range[1])))
    working['_azimuth_deg'] = np.mod(working['_azimuth_deg'], 360.0)
    working['_measurement_kind'] = np.where(working['_range_m'].notna() & working['_elevation_deg'].notna(), 'bearing_elevation_range', np.where(working['_elevation_deg'].notna(), 'bearing_elevation', 'bearing_only'))
    valid = working.loc[~invalid].copy()
    if not valid.empty:
        valid = valid.sort_values(['_jdsc', '_mby', '_zbb', '_stream_sequence'], kind='stable').reset_index(drop=True)
    else:
        valid['_epoch_s'] = pd.Series(dtype=float)
    targets = list(dict.fromkeys(valid['_mby'].tolist()))
    devices = list(dict.fromkeys(valid['_zbb'].tolist()))
    rejected = int(invalid.sum())
    summary = {'source_file': '实时EW流', 'source_path': 'realtime://ew', 'read_rows': total, 'valid_rows': len(valid), 'quality_valid_rows': len(valid), 'time_filtered_rows': 0, 'rejected_rows': rejected, 'target_count': len(targets), 'target_values': '、'.join(sorted(targets)), 'zbb_count': len(devices), 'zbb_values': '、'.join(sorted(devices)), 'bearing_only_rows': int((valid['_measurement_kind'] == 'bearing_only').sum()), 'bearing_elevation_rows': int((valid['_measurement_kind'] == 'bearing_elevation').sum()), 'ranged_rows': int((valid['_measurement_kind'] == 'bearing_elevation_range').sum())}
    return EwReadResult(path=STREAM_EW_PATH, frame=valid, total_rows=total, valid_rows=len(valid), rejected_rows=rejected, rejected_examples=[], device_values=devices, target_values=targets, input_columns=expected, expected_columns=expected, source_paths=[STREAM_EW_PATH], file_summaries=[summary], quality_valid_rows=len(valid))
