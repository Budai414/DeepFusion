from __future__ import annotations
import hashlib
import json
import queue
from pathlib import Path
import sys
import tempfile
import threading
import time
import uuid
from real_fusion.realtime.delivery_store import DurableDeliveryStore
from real_fusion.realtime.delivery_config import delivery_database_path
from real_fusion.realtime.messages import normalize_stream_message

def _source_fingerprint(record):
    digest = hashlib.sha256()
    for value in (record.topic, record.partition, record.offset, getattr(record, 'key', None), record.value, getattr(record, 'timestamp', None)):
        if isinstance(value, (bytes, bytearray, memoryview)):
            (tag, encoded) = (b'bytes', bytes(value))
        elif isinstance(value, str):
            (tag, encoded) = (b'text', value.encode('utf-8'))
        else:
            tag = b'json'
            encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        digest.update(tag)
        digest.update(len(encoded).to_bytes(8, 'big'))
        digest.update(encoded)
    return digest.hexdigest()

def _future_timestamp_error(event_time_s, arrival_time_s, kafka_config, service_config):
    settings = kafka_config.get('event_time', {})
    hard_limit = float(settings.get('maximum_future_skew_s', 300.0))
    if hard_limit <= 0:
        return None
    precision_s = 1e-06
    if event_time_s > arrival_time_s + hard_limit + precision_s:
        return ValueError(f'事件时间超出接收时间允许的未来偏差({hard_limit:g}s)。')
    realtime = service_config.get('realtime', {})
    lateness = float(realtime.get('allowed_lateness_s', 0.5))
    idle_flush = float(realtime.get('idle_flush_s', max(1.0, lateness)))
    configured = settings.get('watermarked_future_tolerance_s')
    tolerance = min(lateness, idle_flush)
    if configured is not None:
        tolerance = min(tolerance, float(configured))
    if event_time_s > arrival_time_s + tolerance + precision_s:
        return ValueError(f'事件时间超出水位允许的未来偏差({tolerance:g}s)，拒收以保护当前窗口。')
    return None

class KafkaDeliveryMixin:

    def _init_delivery(self):
        self._store = None
        self._delivery_lock = threading.RLock()
        self._submitted_ids = set()
        self._publisher = None
        self._publisher_stop = threading.Event()
        self._publisher_wake = threading.Event()
        self._recovering = False
        self._recovery_snapshot = None
        self._recovery_ids = set()
        self._recovery_interrupted = False
        self._previous_checkpoint = getattr(self.service, 'on_input_checkpoint', None)
        self._result_recorder = None

    def _ensure_result_recorder(self):
        settings = self.config.get('client_recording', {})
        if self._result_recorder is not None or not bool(settings.get('enabled', True)):
            return
        from real_fusion.realtime.client_result_recording import ResultRecorder
        base = Path(self.config.get('_config_path', 'configs/kafka.yaml')).resolve().parent.parent
        configured = settings.get('state_directory')
        if configured is not None:
            state = Path(configured).expanduser()
            if not state.is_absolute():
                state = base / state
        elif self.config.get('delivery', {}).get('database'):
            database_path = delivery_database_path(self.config)
            if database_path == ':memory:':
                state = Path(tempfile.mkdtemp(prefix='deepfusion-client-results-'))
            else:
                database = Path(database_path).resolve()
                state = database.parent / (database.stem + '-results')
        else:
            state = base / 'output'
        self._result_recorder = ResultRecorder(state, uuid.uuid4().hex)
        message = 'Kafka已确认融合报文实时记录：' + str(self._result_recorder.directory / 'results.txt')
        self._log(message)
        try:
            print(message, file=sys.stderr, flush=True)
        except (OSError, ValueError):
            pass

    def _finish_result_recorder(self, complete, reason=None, close=True):
        recorder = self._result_recorder
        if recorder is None:
            return
        recorder.finish(complete=complete, reason=reason, close=close)
        if close:
            self._result_recorder = None
            self._log('Kafka融合报文文件已保存：' + str(recorder.directory / 'results.txt'))

    def _open_store(self):
        with self._delivery_lock:
            if self._store is not None:
                return self._store
            settings = self.config.get('delivery', {})
            path = delivery_database_path(self.config)
            self._store = DurableDeliveryStore(path, max_pending_messages=int(settings.get('max_pending_messages', 200000)), max_pending_outputs=int(settings.get('max_pending_outputs', 10000)), history_limit_per_kind=int(getattr(self.service, 'config', {}).get('realtime', {}).get('maximum_records_per_stream', 50000)))
            return self._store

    def _ensure_publisher(self):
        with self._delivery_lock:
            if self._producer is None or (self._publisher is not None and self._publisher.is_alive()):
                return
            self._open_store()
            self._ensure_result_recorder()
            self._publisher_stop.clear()
            self._publisher = threading.Thread(target=self._publish_loop, name='DeepFusionKafkaPublisher', daemon=True)
            self._publisher.start()

    def _publish_loop(self):
        retry = float(self.config.get('delivery', {}).get('retry_backoff_s', 0.5))
        while not self._publisher_stop.is_set():
            item = None
            try:
                item = self._store.next_output()
                if item is None:
                    self._publisher_wake.wait(0.1)
                    self._publisher_wake.clear()
                    continue
                (done, outcome) = (threading.Event(), {})

                def acknowledged(metadata):
                    outcome['metadata'] = metadata
                    done.set()

                def failed(error):
                    outcome['error'] = error
                    done.set()
                from kafka.errors import MessageSizeTooLargeError
                encoded = json.dumps(item['payload'], ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                size_limit = int(self.config.get('producer', {}).get('max_request_size', 10485760))
                if len(encoded) + len(item['key']) > size_limit:
                    raise MessageSizeTooLargeError(f'JSON及key超过max_request_size={size_limit}字节')
                future = self._producer.send(item['topic'], key=item['key'], value=item['payload'])
                future.add_callback(acknowledged)
                future.add_errback(failed)
                while not done.wait(0.1):
                    if self._publisher_stop.is_set():
                        return
                if 'error' in outcome:
                    raise outcome['error']
                if self._result_recorder is not None:
                    self._result_recorder.record(item)
                self._store.ack_output(item['id'])
                self._snapshot_acknowledged(outcome['metadata'])
            except Exception as error:
                self._snapshot_failed(error)
                if item is not None and self._is_permanent_record_error(error):
                    try:
                        self._store.quarantine_output(item['id'], str(error))
                    except Exception as storage_error:
                        self._snapshot_failed(storage_error)
                    else:
                        self._log(f"Kafka输出批次{item['id']}已隔离保留，后续正常结果继续发送；请查看失败输出。")
                        continue
                self._publisher_stop.wait(retry)

    @staticmethod
    def _is_permanent_record_error(error):
        from kafka.errors import MessageSizeTooLargeError, RecordListTooLargeError
        return isinstance(error, (MessageSizeTooLargeError, RecordListTooLargeError))

    def _validate_source_offsets(self):
        from kafka import TopicPartition
        store = self._open_store()
        blocked = store.blocked_sources()
        if blocked:
            from real_fusion.realtime.delivery_store import DeliveryGenerationError
            first = blocked[0]
            raise DeliveryGenerationError(first['topic'], first['partition'], first['reason'])
        receipts = store.receipts()
        if not receipts or not callable(getattr(self._consumer, 'end_offsets', None)):
            return
        partitions = [TopicPartition(row['topic'], row['partition']) for row in receipts]
        ends = self._consumer.end_offsets(partitions)
        for partition in partitions:
            if partition not in ends:
                raise RuntimeError(f'无法核验Kafka输入分区末端：{partition}')
            store.check_partition_end(partition.topic, partition.partition, int(ends[partition]))

    def _checkpoint_inputs(self, ids, cutoff_s, discard=False):
        store = self._open_store()
        if discard:
            store.discard_input(ids)
        else:
            store.checkpoint(ids, cutoff_s)
        with self._delivery_lock:
            self._submitted_ids.difference_update(ids)
        if self._previous_checkpoint is not None:
            self._previous_checkpoint(ids, cutoff_s, discard=discard)

    def _submit_durable_items(self, items, *, recovering=False):
        for item in items:
            if not recovering and item.get('processed', False):
                continue
            identity = item['id']
            future_error = _future_timestamp_error(item['event_time_s'], time.time(), self.config, self.service.config)
            if future_error is not None:
                self._reject_record(item['peer'], ValueError(f'已落盘输入ID={identity}未进入实时窗口：{future_error}'))
                while not self._stop_event.is_set():
                    try:
                        self._checkpoint_inputs((identity,), float('-inf'), discard=True)
                    except Exception as error:
                        with self._lock:
                            self._last_error = str(error)
                        self._log(f'Kafka未来输入隔离尚未完成，将保留并重试：{error}')
                        self._stop_event.wait(0.05)
                    else:
                        break
                else:
                    return
                continue
            while not self._stop_event.is_set() or not recovering:
                with self._delivery_lock:
                    if identity in self._submitted_ids:
                        break
                    self._submitted_ids.add(identity)
                payload = dict(item['payload'], __realtime_delivery_id=identity)
                try:
                    self.service.submit(item['kind'], payload, peer=item['peer'])
                except Exception as error:
                    with self._delivery_lock:
                        self._submitted_ids.discard(identity)
                    if not isinstance(error, queue.Full):
                        with self._lock:
                            self._last_error = str(error)
                        self._log(f'Kafka已落盘数据暂未入队，将重试：{error}')
                    if getattr(self.service, '_accepting_submissions', True) is False:
                        return
                    time.sleep(0.05)
                    continue
                with self._lock:
                    self._consumed += 1
                    self._last_error = None
                break
            if recovering and self._stop_event.is_set():
                return

    def _recover_inputs(self):
        from dataclasses import replace
        items = sorted(self._open_store().load_replay(), key=lambda item: (item['event_time_s'], item['id']))
        if not items:
            return
        with self._delivery_lock:
            self._recovering = True
            self._recovery_interrupted = False
            self._recovery_snapshot = None
            self._recovery_ids.clear()
        completed = False
        try:
            self._log(f'Kafka恢复：先恢复本地{len(items)}条输入，再接收新消息。')
            self._submit_durable_items(items, recovering=True)
            if getattr(self.service.status(), 'running', False):
                while not self._stop_event.is_set() and (not self.service.wait_until_idle(0.1)):
                    pass
            if self._stop_event.is_set():
                return
            with self._delivery_lock:
                snapshot = self._recovery_snapshot
                identifiers = tuple(sorted(self._recovery_ids))
                self._recovering = False
            if snapshot is not None:
                final_snapshot = replace(snapshot, processed_input_ids=identifiers)
                retry = max(0.1, float(self.config.get('delivery', {}).get('retry_backoff_s', 0.5)))
                while not self._stop_event.is_set():
                    try:
                        self._handle_snapshot(final_snapshot)
                    except Exception as error:
                        self._log(f'Kafka恢复结果尚未安全交接，将重试：{error}')
                        self._stop_event.wait(retry)
                    else:
                        completed = True
                        break
            else:
                completed = True
        finally:
            with self._delivery_lock:
                self._recovering = False
                self._recovery_interrupted = not completed
                if completed:
                    self._recovery_snapshot = None
                    self._recovery_ids.clear()

    def _decode_record(self, record, kind):
        from real_fusion.realtime.kafka import split_kafka_json_records, transform_kafka_json_message
        arrival = time.time()
        stamp = getattr(record, 'timestamp', None)
        broker_time = None if stamp is None or stamp < 0 else float(stamp) / 1000.0
        peer = f'kafka://{record.topic}/{record.partition}/{record.offset}'
        (rejected, items) = (0, [])
        try:
            raw = record.value
            if isinstance(raw, (bytes, bytearray, memoryview)):
                raw = bytes(raw).decode(str(self.config.get('json', {}).get('encoding', 'utf-8')))
            if isinstance(raw, str):
                raw = json.loads(raw)
            objects = split_kafka_json_records(kind, raw, self.config)
        except Exception as error:
            self._reject_record(peer, error)
            return ([], 1)
        for (index, obj) in enumerate(objects):
            item_peer = peer if len(objects) == 1 else f'{peer}#item={index}'
            try:
                payload = transform_kafka_json_message(kind, obj, self.service.config, self.config, broker_timestamp_s=broker_time, arrival_time_s=arrival)
                normalized = normalize_stream_message(kind, payload, self.service.config, arrival, 0, item_peer)
                future_error = _future_timestamp_error(normalized.event_time_s, arrival, self.config, self.service.config)
                if future_error is not None:
                    raise future_error
                items.append(dict(kind=kind, payload=normalized.payload, event_time_s=normalized.event_time_s, peer=item_peer))
            except Exception as error:
                rejected += 1
                self._reject_record(item_peer, error)
        return (items, rejected)

    def _reject_record(self, peer, error):
        with self._lock:
            self._rejected += 1
            self._last_error = str(error)
            self._last_rejection_error = str(error)
        self._log(f'Kafka报文拒绝：{peer}：{error}')

    def _consume_durable_loop(self):
        from kafka import TopicPartition, OffsetAndMetadata
        config = self.config['consumer']
        kinds = {self.config['input_topic']: 'SW', self.config['input_topic_1']: 'EW'}
        blocked_commits = set()
        retry = float(config.get('retry_backoff_ms', 500)) / 1000.0
        try:
            while not self._stop_event.is_set():
                try:
                    self._validate_source_offsets()
                    self._recover_inputs()
                except Exception as error:
                    with self._lock:
                        self._last_error = str(error)
                    self._log(f'Kafka本地恢复暂时失败，保留输入并重试：{error}')
                    self._stop_event.wait(retry)
                else:
                    with self._lock:
                        self._last_error = None
                    break
            while not self._stop_event.is_set():
                try:
                    batches = self._consumer.poll(timeout_ms=int(config['poll_timeout_ms']), max_records=int(config['max_poll_records']))
                    while not self._stop_event.is_set():
                        try:
                            self._validate_source_offsets()
                            break
                        except Exception as error:
                            with self._lock:
                                self._last_error = str(error)
                            self._log(f'Kafka输入源状态尚未通过检查，保留本批并重试：{error}')
                            self._stop_event.wait(retry)
                    else:
                        return
                    decoded = []
                    for records in batches.values():
                        for record in records:
                            if self._stop_event.is_set():
                                return
                            kind = kinds.get(str(record.topic))
                            if kind is None:
                                continue
                            (items, rejected) = self._decode_record(record, kind)
                            decoded.append(dict(topic=record.topic, partition=record.partition, offset=record.offset, items=items, rejected=rejected, source_fingerprint=_source_fingerprint(record)))
                    if not decoded:
                        continue
                    while not self._stop_event.is_set():
                        try:
                            self._validate_source_offsets()
                            saved_batches = self._open_store().accept_poll(decoded)
                            break
                        except Exception as error:
                            with self._lock:
                                self._last_error = str(error)
                            self._log(f'Kafka本批输入未安全落盘，消费位点保留并重试：{error}')
                            self._stop_event.wait(retry)
                    else:
                        return
                    for record in decoded:
                        partition = TopicPartition(record['topic'], record['partition'])
                        committable = (not record['items'] or bool(config.get('commit_accepted_batches', True))) and (not record['rejected'] or bool(config.get('commit_rejected_messages', True)))
                        if not committable:
                            blocked_commits.add(partition)
                        if partition not in blocked_commits:
                            try:
                                self._consumer.commit({partition: OffsetAndMetadata(record['offset'] + 1, '')})
                            except Exception as error:
                                with self._lock:
                                    self._last_error = str(error)
                                self._log(f'Kafka位点提交失败；输入已持久化，可安全重读：{error}')
                    saved = sorted((item for group in saved_batches for item in group), key=lambda item: (item['event_time_s'], item['id']))
                    self._submit_durable_items(saved)
                except Exception as error:
                    with self._lock:
                        self._last_error = str(error)
                    self._log(f'Kafka消费循环异常，将继续重试：{error}')
                    self._stop_event.wait(retry)
        finally:
            self._running = False

    def _drain_publisher(self, timeout_s):
        deadline = time.monotonic() + max(0.0, timeout_s)
        while self._store is not None and self._store.counts()['outbox']:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                count = self._store.counts()['outbox']
                raise TimeoutError(f'Kafka仍有{count}批输出待确认，已持久化保留；请恢复连接后重试停止。')
            self._publisher_wake.set()
            try:
                self._producer.flush(timeout=min(0.2, remaining))
            except Exception:
                pass
            self._publisher_stop.wait(min(0.02, remaining))
        self._publisher_stop.set()
        if self._publisher is not None:
            self._publisher.join(timeout=max(0.0, deadline - time.monotonic()))
            if self._publisher.is_alive():
                raise TimeoutError('Kafka输出线程仍在结束，持久化待发记录保持不变，请重试停止。')
            self._publisher = None
