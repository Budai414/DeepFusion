from __future__ import annotations
import copy
import heapq
import json
import queue
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional
from real_fusion.evaluation.metrics import compute_metrics
from real_fusion.ew.fusion import run_ew_joint_fusion
from real_fusion.pipeline import ExperimentResult, build_converter, run_sw_experiment
from real_fusion.realtime.adapters import build_ew_read_result, build_sw_read_result
from real_fusion.realtime.messages import StreamRecord, normalize_stream_message
from real_fusion.realtime.transport import JsonLineTcpReceiver

@dataclass(frozen=True)
class RealtimeStatus:
    running: bool
    sw_port: int
    ew_port: int
    received_sw: int
    received_ew: int
    rejected_messages: int
    late_dropped_messages: int
    queue_size: int
    pending_event_count: int
    buffered_sw: int
    buffered_ew: int
    fusion_run_count: int
    fusion_error_count: int
    last_error: Optional[str]
    last_fusion_duration_s: float = 0.0
    mean_fusion_duration_s: float = 0.0
    last_snapshot_interval_s: float = 0.0
    journal_error: Optional[str] = None

@dataclass(frozen=True)
class RealtimeSnapshot:
    result: ExperimentResult
    metrics: Dict[str, object]
    status: RealtimeStatus
    latest_event_time_s: float
    generated_time_s: float
    processed_input_ids: tuple[int, ...] = ()

class RealtimeFusionService:

    def __init__(self, config: dict, on_snapshot: Optional[Callable[[RealtimeSnapshot], None]]=None, on_log: Optional[Callable[[str], None]]=None, on_input_checkpoint: Optional[Callable[[tuple[int, ...], float, bool], None]]=None) -> None:
        self.config = copy.deepcopy(config)
        self.realtime = self.config.get('realtime', {})
        self.on_snapshot = on_snapshot
        self.on_log = on_log
        self.on_input_checkpoint = on_input_checkpoint
        self._queue: queue.Queue[StreamRecord] = queue.Queue(maxsize=int(self.realtime.get('queue_capacity', 100000)))
        self._stop_event = threading.Event()
        self._worker: Optional[threading.Thread] = None
        self._sw_receiver: Optional[JsonLineTcpReceiver] = None
        self._ew_receiver: Optional[JsonLineTcpReceiver] = None
        self._lock = threading.Lock()
        self._submission_lock = threading.Lock()
        self._accepting_submissions = True
        self._sequence = 0
        self._running = False
        self._received_sw = 0
        self._received_ew = 0
        self._rejected = 0
        self._late_dropped = 0
        self._pending_count = 0
        self._buffered_sw = 0
        self._buffered_ew = 0
        self._fusion_runs = 0
        self._fusion_errors = 0
        self._last_error: Optional[str] = None
        self._last_fusion_duration_s = 0.0
        self._mean_fusion_duration_s = 0.0
        self._last_snapshot_interval_s = 0.0
        self._last_snapshot_wall: Optional[float] = None
        self._journal_lock = threading.Lock()
        self._journal_error: Optional[str] = None
        self._journal_path = self._resolve_journal_path()
        self._journal_handle = None
        self._idle_event = threading.Event()
        self._idle_event.set()

    def _resolve_journal_path(self) -> Optional[Path]:
        if not bool(self.realtime.get('persist_journal', True)):
            return None
        config_path = self.config.get('sw', {}).get('_input_config_path')
        project_root = Path(config_path).resolve().parent.parent if config_path else Path.cwd()
        directory = Path(str(self.realtime.get('journal_directory', 'output/realtime_journal')))
        if not directory.is_absolute():
            directory = project_root / directory
        directory.mkdir(parents=True, exist_ok=True)
        return directory / f"realtime_{time.strftime('%Y%m%d')}.jsonl"

    @property
    def sw_port(self) -> int:
        return self._sw_receiver.port if self._sw_receiver is not None else int(self.realtime.get('sw_port', 19001))

    @property
    def ew_port(self) -> int:
        return self._ew_receiver.port if self._ew_receiver is not None else int(self.realtime.get('ew_port', 19002))

    def _log(self, message: str) -> None:
        if self.on_log is not None:
            try:
                self.on_log(str(message))
            except Exception as error:
                with self._lock:
                    self._last_error = f'日志回调失败：{error}'

    def start(self, host: Optional[str]=None, sw_port: Optional[int]=None, ew_port: Optional[int]=None, start_tcp: bool=True) -> None:
        if self._running:
            return
        bind_host = str(host if host is not None else self.realtime.get('host', '127.0.0.1'))
        sw_value = int(sw_port if sw_port is not None else self.realtime.get('sw_port', 19001))
        ew_value = int(ew_port if ew_port is not None else self.realtime.get('ew_port', 19002))
        maximum_bytes = int(self.realtime.get('maximum_message_bytes', 1048576))
        if start_tcp:
            self._sw_receiver = JsonLineTcpReceiver(bind_host, sw_value, 'SW', self.submit, maximum_bytes)
            self._ew_receiver = JsonLineTcpReceiver(bind_host, ew_value, 'EW', self.submit, maximum_bytes)
            try:
                self._sw_receiver.start()
                self._ew_receiver.start()
            except Exception:
                self._sw_receiver.stop()
                self._ew_receiver.stop()
                self._sw_receiver = None
                self._ew_receiver = None
                raise
        self._stop_event.clear()
        if self._journal_path is not None:
            self._journal_handle = self._journal_path.open('a', encoding='utf-8', buffering=1)
        with self._submission_lock:
            self._accepting_submissions = True
        self._running = True
        self._worker = threading.Thread(target=self._consume_loop, name='RealFusionRealtimeConsumer', daemon=True)
        self._worker.start()
        self._log(f'实时融合内核已启动：SW={bind_host}:{self.sw_port}，EW={bind_host}:{self.ew_port}。' if start_tcp else '实时融合内核已启动：输入传输层=Kafka。')

    def stop(self, timeout_s: float=30.0) -> None:
        deadline = time.monotonic() + max(0.0, float(timeout_s))
        if not self._submission_lock.acquire(timeout=max(0.0, deadline - time.monotonic())):
            raise TimeoutError('实时融合仍在处理已进入的接收请求，请等待后重试停止。')
        try:
            self._accepting_submissions = False
            self._stop_event.set()
        finally:
            self._submission_lock.release()
        for receiver in (self._sw_receiver, self._ew_receiver):
            if receiver is not None:
                receiver.stop()
        self._sw_receiver = None
        self._ew_receiver = None
        worker = self._worker
        if worker is not None and worker.is_alive():
            worker.join(timeout=max(0.0, deadline - time.monotonic()))
            if worker.is_alive():
                raise TimeoutError('实时融合仍在排空已接收数据，请等待后重试停止。')
        self._worker = None
        with self._journal_lock:
            if self._journal_handle is not None:
                handle = self._journal_handle
                self._journal_handle = None
                try:
                    handle.close()
                except Exception as error:
                    self._record_journal_error(error)
        self._running = False
        self._log('实时服务已停止。')

    def submit(self, data_kind: str, message: object, peer: str='local') -> int:
        arrival = time.time()
        with self._submission_lock:
            if not self._accepting_submissions:
                with self._lock:
                    self._rejected += 1
                raise RuntimeError('实时服务正在停止或已停止，不能接收新报文。')
            with self._lock:
                self._sequence += 1
                next_sequence = self._sequence
            self._idle_event.clear()
            try:
                record = normalize_stream_message(data_kind, message, self.config, arrival, next_sequence, peer)
                self._queue.put(record, timeout=float(self.realtime.get('queue_put_timeout_s', 0.25)))
            except queue.Full:
                raise
            except Exception:
                with self._lock:
                    self._rejected += 1
                raise
            with self._lock:
                if record.data_kind == 'SW':
                    self._received_sw += 1
                else:
                    self._received_ew += 1
            try:
                self._append_journal(record)
            except Exception as error:
                self._record_journal_error(error)
            else:
                with self._lock:
                    previous_journal_error = self._journal_error
                    self._journal_error = None
                if previous_journal_error is not None:
                    self._log('实时审计写入已恢复。')
            return record.sequence

    def _record_journal_error(self, error: Exception) -> None:
        message = str(error)
        with self._lock:
            changed = self._journal_error != message
            self._journal_error = message
        if changed:
            self._log(f'实时审计写入失败；已入队报文不重复接收：{message}')

    def wait_until_idle(self, timeout_s: Optional[float]=None) -> bool:
        timeout = None if timeout_s is None else max(0.0, float(timeout_s))
        return self._idle_event.wait(timeout=timeout)

    def _append_journal(self, record: StreamRecord) -> None:
        if self._journal_path is None:
            return
        row = {'sequence': record.sequence, 'data_kind': record.data_kind, 'event_time_s': record.event_time_s, 'arrival_time_s': record.arrival_time_s, 'peer': record.peer, 'payload': record.payload}
        with self._journal_lock:
            handle = self._journal_handle
            if handle is None:
                with self._journal_path.open('a', encoding='utf-8') as fallback:
                    fallback.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')
            else:
                handle.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')

    def status(self) -> RealtimeStatus:
        with self._lock:
            return RealtimeStatus(running=self._running, sw_port=self.sw_port, ew_port=self.ew_port, received_sw=self._received_sw, received_ew=self._received_ew, rejected_messages=self._rejected, late_dropped_messages=self._late_dropped, queue_size=self._queue.qsize(), pending_event_count=self._pending_count, buffered_sw=self._buffered_sw, buffered_ew=self._buffered_ew, fusion_run_count=self._fusion_runs, fusion_error_count=self._fusion_errors, last_error=self._last_error, last_fusion_duration_s=self._last_fusion_duration_s, mean_fusion_duration_s=self._mean_fusion_duration_s, last_snapshot_interval_s=self._last_snapshot_interval_s, journal_error=self._journal_error)

    def _consume_loop(self) -> None:
        pending: List[tuple[float, int, StreamRecord]] = []
        sw_history: List[StreamRecord] = []
        ew_history: List[StreamRecord] = []
        maximum_event_time = float('-inf')
        last_released_time = float('-inf')
        last_arrival_wall = time.monotonic()
        last_fusion_wall = 0.0
        dirty = False
        unfused_ew_logged = False
        processed_input_ids: set[int] = set()
        discarded_input_ids: set[int] = set()
        snapshot_retry_at: Optional[float] = None
        checkpoint_retry_at = 0.0
        discard_retry_at = 0.0
        delivery_errors: Dict[str, str] = {}
        allowed_lateness = float(self.realtime.get('allowed_lateness_s', 0.5))
        idle_flush = float(self.realtime.get('idle_flush_s', max(1.0, allowed_lateness)))
        interval = float(self.realtime.get('fusion_interval_s', 0.5))
        history_window = float(self.realtime.get('history_window_s', 120.0))
        drop_late = bool(self.realtime.get('drop_late_messages', True))
        maximum_records = int(self.realtime.get('maximum_records_per_stream', 50000))
        dequeue_batch_size = int(self.realtime.get('dequeue_batch_size', 2000))
        retry_delay = max(0.1, min(1.0, interval))

        def delivery_id(record: StreamRecord) -> Optional[int]:
            value = record.payload.get('__realtime_delivery_id')
            return value if isinstance(value, int) and (not isinstance(value, bool)) else None

        def report_failure(stage: str, error: Exception) -> None:
            delivery_errors[stage] = str(error)
            with self._lock:
                self._fusion_errors += 1
                self._last_error = f'{stage}：{error}'
            self._log(f'{stage}：{error}')

        def refresh_error() -> None:
            with self._lock:
                self._last_error = next((f'{stage}：{error}' for (stage, error) in delivery_errors.items()), None)
        while not self._stop_event.is_set() or not self._queue.empty() or pending or dirty or discarded_input_ids:
            try:
                record = self._queue.get(timeout=0.1)
            except queue.Empty:
                record = None
            received_batch: List[StreamRecord] = []
            if record is not None:
                received_batch.append(record)
                for _ in range(dequeue_batch_size - 1):
                    try:
                        received_batch.append(self._queue.get_nowait())
                    except queue.Empty:
                        break
            if received_batch:
                for received in received_batch:
                    maximum_event_time = max(maximum_event_time, received.event_time_s)
                    heapq.heappush(pending, (received.event_time_s, received.sequence, received))
                last_arrival_wall = time.monotonic()
            watermark = maximum_event_time - allowed_lateness
            flush_all = bool(pending and (self._stop_event.is_set() or time.monotonic() - last_arrival_wall >= idle_flush))
            while pending and (flush_all or pending[0][0] <= watermark):
                (_, _, released) = heapq.heappop(pending)
                if drop_late and released.event_time_s < last_released_time - 1e-09:
                    with self._lock:
                        self._late_dropped += 1
                    input_id = delivery_id(released)
                    if input_id is not None:
                        discarded_input_ids.add(input_id)
                    continue
                last_released_time = max(last_released_time, released.event_time_s)
                (sw_history if released.data_kind == 'SW' else ew_history).append(released)
                input_id = delivery_id(released)
                if input_id is not None:
                    processed_input_ids.add(input_id)
                dirty = True
            cutoff = maximum_event_time - history_window
            if maximum_event_time != float('-inf'):
                sw_history = [item for item in sw_history if item.event_time_s >= cutoff][-maximum_records:]
                ew_history = [item for item in ew_history if item.event_time_s >= cutoff][-maximum_records:]
            with self._lock:
                self._pending_count = len(pending)
                self._buffered_sw = len(sw_history)
                self._buffered_ew = len(ew_history)
            now = time.monotonic()
            snapshot_due = now >= snapshot_retry_at if snapshot_retry_at is not None else self._stop_event.is_set() or now - last_fusion_wall >= interval
            if dirty and sw_history and snapshot_due:
                fusion_started_wall = now
                failure_stage = '实时融合失败'
                try:
                    snapshot = self._fuse(sw_history, ew_history, maximum_event_time)
                    fusion_completed_wall = time.monotonic()
                    fusion_duration_s = fusion_completed_wall - fusion_started_wall
                    with self._lock:
                        previous_runs = self._fusion_runs
                        self._fusion_runs += 1
                        self._last_fusion_duration_s = fusion_duration_s
                        self._mean_fusion_duration_s = (self._mean_fusion_duration_s * previous_runs + fusion_duration_s) / self._fusion_runs
                        if self._last_snapshot_wall is not None:
                            self._last_snapshot_interval_s = fusion_completed_wall - self._last_snapshot_wall
                        self._last_snapshot_wall = fusion_completed_wall
                    current_status = self.status()
                    current_metrics = dict(snapshot.metrics)
                    current_metrics['realtime'] = dict(current_status.__dict__)
                    snapshot = RealtimeSnapshot(result=snapshot.result, metrics=current_metrics, status=current_status, latest_event_time_s=snapshot.latest_event_time_s, generated_time_s=snapshot.generated_time_s, processed_input_ids=tuple(sorted(processed_input_ids)))
                    failure_stage = '实时快照交接失败'
                    if self.on_snapshot is not None:
                        self.on_snapshot(snapshot)
                except Exception as error:
                    with self._lock:
                        self._last_fusion_duration_s = time.monotonic() - fusion_started_wall
                    delivery_errors.pop('实时融合失败', None)
                    delivery_errors.pop('实时快照交接失败', None)
                    report_failure(failure_stage, error)
                    snapshot_retry_at = time.monotonic() + retry_delay
                else:
                    processed_input_ids.clear()
                    dirty = False
                    snapshot_retry_at = None
                    delivery_errors.pop('实时融合失败', None)
                    delivery_errors.pop('实时快照交接失败', None)
                    delivery_errors.pop('实时输入交接失败', None)
                    refresh_error()
                last_fusion_wall = fusion_started_wall
                unfused_ew_logged = False
            if dirty and (not sw_history) and (now >= checkpoint_retry_at):
                if ew_history and (not unfused_ew_logged):
                    self._log('当前窗口缺少SW主航迹，EW量测已保留，尚未产生融合快照。')
                    unfused_ew_logged = True
                try:
                    if processed_input_ids and self.on_input_checkpoint is not None:
                        self.on_input_checkpoint(tuple(sorted(processed_input_ids)), cutoff, discard=False)
                except Exception as error:
                    report_failure('实时输入交接失败', error)
                    checkpoint_retry_at = time.monotonic() + retry_delay
                else:
                    processed_input_ids.clear()
                    dirty = False
                    snapshot_retry_at = None
                    delivery_errors.pop('实时输入交接失败', None)
                    delivery_errors.pop('实时融合失败', None)
                    delivery_errors.pop('实时快照交接失败', None)
                    refresh_error()
            if discarded_input_ids and now >= discard_retry_at:
                try:
                    if self.on_input_checkpoint is not None:
                        self.on_input_checkpoint(tuple(sorted(discarded_input_ids)), cutoff, discard=True)
                except Exception as error:
                    report_failure('实时迟到输入交接失败', error)
                    discard_retry_at = time.monotonic() + retry_delay
                else:
                    discarded_input_ids.clear()
                    delivery_errors.pop('实时迟到输入交接失败', None)
                    refresh_error()
            if not dirty and (not pending) and (not discarded_input_ids):
                with self._submission_lock:
                    if self._queue.empty():
                        self._idle_event.set()
        self._running = False
        self._idle_event.set()

    def _fuse(self, sw_history: List[StreamRecord], ew_history: List[StreamRecord], latest_event_time_s: float) -> RealtimeSnapshot:
        batch_config = copy.deepcopy(self.config)
        sw_read = build_sw_read_result(sw_history, batch_config['sw'])
        sensors = batch_config.setdefault('sensors', {})
        for zbb in sw_read.device_values:
            device = sensors.setdefault(str(zbb), {})
            safe = ''.join((character if character.isalnum() else '_' for character in str(zbb)))
            device.setdefault('sensor_id', f"RT_SW_{safe or 'UNKNOWN'}")
        result = run_sw_experiment(batch_config, [], prepared_read=sw_read)
        if ew_history:
            ew_read = build_ew_read_result(ew_history, batch_config['ew'])
            converter = build_converter(result.config, result.sw_read)
            result = run_ew_joint_fusion(result, ew_read, converter)
        metrics = compute_metrics(result)
        metrics['realtime'] = dict(self.status().__dict__)
        return RealtimeSnapshot(result=result, metrics=metrics, status=self.status(), latest_event_time_s=float(latest_event_time_s), generated_time_s=time.time())
