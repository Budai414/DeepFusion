from __future__ import annotations
import json
import hashlib
import math
from pathlib import Path
import sqlite3
import threading
import time
from typing import Sequence
from real_fusion.realtime.delivery_lock import FileDeliveryLock, DeliveryStoreInUseError

class DeliveryCapacityError(RuntimeError):
    pass

class DeliveryGenerationError(RuntimeError):

    def __init__(self, topic, partition, reason):
        (self.topic, self.partition, self.reason) = (topic, partition, str(reason))
        super().__init__(f'Kafka source generation requires explicit review: {topic}/{partition}: {reason}; preserve the old database and select a new delivery generation if the source was reset')

class DurableDeliveryStore:

    def __init__(self, path, max_pending_messages=100000, max_pending_outputs=10000, history_limit_per_kind=50000, fingerprint_limit_per_partition=None):
        self.max_pending_messages = self._positive_integer(max_pending_messages, 'max_pending_messages')
        self.max_pending_outputs = self._positive_integer(max_pending_outputs, 'max_pending_outputs')
        self.history_limit_per_kind = self._positive_integer(history_limit_per_kind, 'history_limit_per_kind')
        self.fingerprint_limit_per_partition = self._positive_integer(max(100000, self.max_pending_messages) if fingerprint_limit_per_partition is None else fingerprint_limit_per_partition, 'fingerprint_limit_per_partition')
        self._lock = threading.RLock()
        self._file_lock = None
        self._connection = None
        if str(path) == ':memory:':
            database = ':memory:'
        else:
            location = Path(path).expanduser().resolve()
            location.parent.mkdir(parents=True, exist_ok=True)
            database = str(location)
            self._file_lock = FileDeliveryLock(database + '.lock').acquire()
        try:
            self._connection = sqlite3.connect(database, timeout=1.0, check_same_thread=False)
            self._connection.row_factory = sqlite3.Row
            self._connection.execute('PRAGMA busy_timeout=1000')
            self._connection.execute('PRAGMA journal_mode=WAL')
            self._connection.execute('PRAGMA synchronous=FULL')
            self._connection.executescript('\n                CREATE TABLE IF NOT EXISTS delivery_receipts (\n                    topic TEXT NOT NULL,\n                    partition_id INTEGER NOT NULL,\n                    maximum_offset INTEGER NOT NULL,\n                    PRIMARY KEY (topic, partition_id)\n                );\n                CREATE TABLE IF NOT EXISTS delivery_inbox (\n                    id INTEGER PRIMARY KEY AUTOINCREMENT,\n                    topic TEXT NOT NULL,\n                    partition_id INTEGER NOT NULL,\n                    record_offset INTEGER NOT NULL,\n                    kind TEXT NOT NULL,\n                    payload_json TEXT NOT NULL,\n                    event_time_s REAL NOT NULL,\n                    peer TEXT NOT NULL,\n                    processed INTEGER NOT NULL DEFAULT 0\n                );\n                CREATE INDEX IF NOT EXISTS delivery_inbox_record\n                    ON delivery_inbox(topic, partition_id, record_offset);\n                CREATE INDEX IF NOT EXISTS delivery_inbox_trim\n                    ON delivery_inbox(processed, event_time_s);\n                CREATE INDEX IF NOT EXISTS delivery_inbox_kind_history\n                    ON delivery_inbox(processed, kind, event_time_s, id);\n                CREATE TABLE IF NOT EXISTS delivery_outbox (\n                    id INTEGER PRIMARY KEY AUTOINCREMENT,\n                    topic TEXT NOT NULL,\n                    message_key BLOB NOT NULL,\n                    payload_json TEXT NOT NULL\n                );\n                CREATE TABLE IF NOT EXISTS delivery_source_blocks (\n                    topic TEXT NOT NULL,\n                    partition_id INTEGER NOT NULL,\n                    reason TEXT NOT NULL,\n                    blocked_time_s REAL NOT NULL,\n                    PRIMARY KEY (topic, partition_id)\n                );\n                CREATE TABLE IF NOT EXISTS delivery_proof_counters (\n                    topic TEXT NOT NULL,\n                    partition_id INTEGER NOT NULL,\n                    proof_sequence INTEGER NOT NULL,\n                    PRIMARY KEY (topic, partition_id)\n                );\n                CREATE TABLE IF NOT EXISTS delivery_record_fingerprints (\n                    topic TEXT NOT NULL,\n                    partition_id INTEGER NOT NULL,\n                    record_offset INTEGER NOT NULL,\n                    fingerprint TEXT NOT NULL,\n                    proof_sequence INTEGER NOT NULL,\n                    PRIMARY KEY (topic, partition_id, record_offset)\n                );\n                CREATE INDEX IF NOT EXISTS delivery_fingerprint_expiry\n                    ON delivery_record_fingerprints(topic, partition_id, proof_sequence);\n                CREATE TABLE IF NOT EXISTS delivery_failed_outbox (\n                    id INTEGER PRIMARY KEY,\n                    topic TEXT NOT NULL,\n                    message_key BLOB NOT NULL,\n                    payload_json TEXT NOT NULL,\n                    error TEXT NOT NULL,\n                    failed_time_s REAL NOT NULL\n                );\n            ')
        except BaseException:
            self.close()
            raise

    @staticmethod
    def _positive_integer(value, name):
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f'{name} must be a positive integer')
        return value

    def _database(self):
        if self._connection is None:
            raise RuntimeError('Kafka delivery store is closed')
        return self._connection

    @staticmethod
    def _json(value, *, allow_nan=False):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=allow_nan)

    @staticmethod
    def _input(row):
        return {'id': row['id'], 'kind': row['kind'], 'payload': json.loads(row['payload_json']), 'event_time_s': row['event_time_s'], 'peer': row['peer'], 'processed': bool(row['processed'])}

    @staticmethod
    def _topic(topic):
        if not isinstance(topic, str) or not topic.strip():
            raise ValueError('Kafka delivery topic must be a nonempty string')
        return topic

    def _prepare_record(self, topic, partition, offset, items, source_fingerprint=None):
        topic = self._topic(topic)
        for (value, name) in ((partition, 'partition'), (offset, 'offset')):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f'Kafka {name} must be a nonnegative integer')
        prepared = []
        for item in items:
            event_time = float(item['event_time_s'])
            if isinstance(item['event_time_s'], bool) or not math.isfinite(event_time):
                raise ValueError('Kafka inbox event_time_s must be finite')
            (kind, peer) = (item['kind'], item['peer'])
            if not isinstance(kind, str) or not isinstance(peer, str):
                raise ValueError('Kafka inbox kind and peer must be strings')
            encoded = self._json(item['payload'], allow_nan=True)
            prepared.append(dict(kind=kind, payload=json.loads(encoded), event_time_s=event_time, peer=peer))
        if source_fingerprint is None:
            canonical = json.dumps(prepared, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=True)
            source_fingerprint = 'items-v1:' + hashlib.sha256(canonical.encode('utf-8')).hexdigest()
        elif not isinstance(source_fingerprint, str) or not source_fingerprint:
            raise ValueError('Kafka source_fingerprint must be a nonempty string')
        return dict(topic=topic, partition=partition, offset=offset, items=prepared, source_fingerprint=source_fingerprint)

    def _check_block(self, connection, topic, partition):
        blocked = connection.execute('SELECT reason FROM delivery_source_blocks WHERE topic=? AND partition_id=?', (topic, partition)).fetchone()
        if blocked is not None:
            raise DeliveryGenerationError(topic, partition, blocked['reason'])

    @staticmethod
    def _remember_block(connection, error):
        with connection:
            connection.execute('INSERT INTO delivery_source_blocks(topic,partition_id,reason,blocked_time_s) VALUES (?,?,?,?) ON CONFLICT(topic,partition_id) DO NOTHING', (error.topic, error.partition, error.reason, time.time()))

    def _accept_record(self, connection, record, allow_exceed=False):
        (topic, partition, offset) = (record['topic'], record['partition'], record['offset'])
        (items, fingerprint) = (record['items'], record['source_fingerprint'])
        self._check_block(connection, topic, partition)
        receipt = connection.execute('SELECT maximum_offset FROM delivery_receipts WHERE topic=? AND partition_id=?', (topic, partition)).fetchone()
        if receipt is not None and offset <= receipt['maximum_offset']:
            proof = connection.execute('SELECT fingerprint FROM delivery_record_fingerprints WHERE topic=? AND partition_id=? AND record_offset=?', (topic, partition, offset)).fetchone()
            if proof is None:
                raise DeliveryGenerationError(topic, partition, f"offset {offset} is below stored maximum {receipt['maximum_offset']} but its original fingerprint is unavailable; replay cannot be verified")
            if proof['fingerprint'] != fingerprint:
                raise DeliveryGenerationError(topic, partition, f'offset {offset} has a different source fingerprint')
            return [self._input(row) for row in connection.execute('SELECT * FROM delivery_inbox WHERE topic=? AND partition_id=? AND record_offset=? ORDER BY id', (topic, partition, offset))]
        if not allow_exceed:
            count = connection.execute('SELECT COUNT(*) FROM delivery_inbox WHERE processed=0').fetchone()[0]
            if count + len(items) > self.max_pending_messages:
                raise DeliveryCapacityError(f'Kafka durable inbox capacity exceeded: {count}+{len(items)}>{self.max_pending_messages}; record not accepted')
        accepted = []
        for item in items:
            cursor = connection.execute('INSERT INTO delivery_inbox (topic,partition_id,record_offset,kind,payload_json,event_time_s,peer) VALUES (?,?,?,?,?,?,?)', (topic, partition, offset, item['kind'], self._json(item['payload'], allow_nan=True), item['event_time_s'], item['peer']))
            accepted.append(dict(item, id=cursor.lastrowid, processed=False))
        connection.execute('INSERT INTO delivery_receipts(topic,partition_id,maximum_offset) VALUES (?,?,?) ON CONFLICT(topic,partition_id) DO UPDATE SET maximum_offset=excluded.maximum_offset', (topic, partition, offset))
        counter = connection.execute('SELECT proof_sequence FROM delivery_proof_counters WHERE topic=? AND partition_id=?', (topic, partition)).fetchone()
        sequence = (counter[0] if counter else 0) + 1
        connection.execute('INSERT INTO delivery_proof_counters(topic,partition_id,proof_sequence) VALUES (?,?,?) ON CONFLICT(topic,partition_id) DO UPDATE SET proof_sequence=excluded.proof_sequence', (topic, partition, sequence))
        connection.execute('INSERT INTO delivery_record_fingerprints (topic,partition_id,record_offset,fingerprint,proof_sequence) VALUES (?,?,?,?,?)', (topic, partition, offset, fingerprint, sequence))
        connection.execute('DELETE FROM delivery_record_fingerprints WHERE topic=? AND partition_id=? AND proof_sequence<=?', (topic, partition, sequence - self.fingerprint_limit_per_partition))
        return accepted

    def accept(self, topic, partition, offset, items: list[dict], source_fingerprint=None) -> list[dict]:
        record = self._prepare_record(topic, partition, offset, items, source_fingerprint)
        with self._lock:
            connection = self._database()
            try:
                with connection:
                    connection.execute('BEGIN IMMEDIATE')
                    return self._accept_record(connection, record)
            except DeliveryGenerationError as error:
                self._remember_block(connection, error)
                raise

    def accept_poll(self, records) -> list[list[dict]]:
        prepared = [self._prepare_record(row['topic'], row['partition'], row['offset'], row['items'], row.get('source_fingerprint')) for row in records]
        with self._lock:
            connection = self._database()
            try:
                with connection:
                    connection.execute('BEGIN IMMEDIATE')
                    empty = connection.execute('SELECT NOT EXISTS(SELECT 1 FROM delivery_inbox WHERE processed=0)').fetchone()[0]
                    return [self._accept_record(connection, row, allow_exceed=bool(empty)) for row in prepared]
            except DeliveryGenerationError as error:
                self._remember_block(connection, error)
                raise

    def receipts(self):
        with self._lock:
            return [dict(topic=row['topic'], partition=row['partition_id'], maximum_offset=row['maximum_offset']) for row in self._database().execute('SELECT * FROM delivery_receipts ORDER BY topic,partition_id')]

    def blocked_sources(self):
        with self._lock:
            return [dict(topic=row['topic'], partition=row['partition_id'], reason=row['reason'], blocked_time_s=row['blocked_time_s']) for row in self._database().execute('SELECT * FROM delivery_source_blocks ORDER BY topic,partition_id')]

    def check_partition_end(self, topic, partition, end_offset):
        topic = self._topic(topic)
        if isinstance(partition, bool) or not isinstance(partition, int) or partition < 0 or isinstance(end_offset, bool) or (not isinstance(end_offset, int)) or (end_offset < 0):
            raise ValueError('Kafka partition and end_offset must be nonnegative integers')
        with self._lock:
            connection = self._database()
            try:
                self._check_block(connection, topic, partition)
                row = connection.execute('SELECT maximum_offset FROM delivery_receipts WHERE topic=? AND partition_id=?', (topic, partition)).fetchone()
                if row is not None and end_offset <= row[0]:
                    raise DeliveryGenerationError(topic, partition, f'broker end offset {end_offset} regressed below stored next offset {row[0] + 1}')
            except DeliveryGenerationError as error:
                self._remember_block(connection, error)
                raise

    def load_replay(self) -> list[dict]:
        with self._lock:
            return [self._input(row) for row in self._database().execute('SELECT * FROM delivery_inbox ORDER BY id')]

    def _checkpoint(self, connection, input_ids: Sequence[int], cutoff_s: float):
        cutoff = float(cutoff_s)
        if math.isnan(cutoff):
            raise ValueError('Kafka replay cutoff cannot be NaN')
        identifiers = list(input_ids)
        if any((isinstance(value, bool) or not isinstance(value, int) or value < 1 for value in identifiers)):
            raise ValueError('Kafka inbox checkpoint IDs must be positive integers')
        for start in range(0, len(identifiers), 900):
            chunk = identifiers[start:start + 900]
            connection.execute('UPDATE delivery_inbox SET processed=1 WHERE id IN (' + ','.join(('?' for _ in chunk)) + ')', chunk)
        connection.execute('DELETE FROM delivery_inbox WHERE processed=1 AND event_time_s<?', (cutoff,))
        kinds = [row[0] for row in connection.execute('SELECT DISTINCT kind FROM delivery_inbox WHERE processed=1')]
        for kind in kinds:
            connection.execute('DELETE FROM delivery_inbox WHERE processed=1 AND kind=? AND id NOT IN (SELECT id FROM delivery_inbox WHERE processed=1 AND kind=? ORDER BY event_time_s DESC,id DESC LIMIT ?)', (kind, kind, self.history_limit_per_kind))

    def stage_output(self, topic, key: bytes, payload: object, input_ids: Sequence[int], cutoff_s: float) -> int:
        topic = self._topic(topic)
        if not isinstance(key, bytes):
            raise ValueError('Kafka outbox key must be bytes')
        encoded = self._json(payload)
        with self._lock:
            connection = self._database()
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                count = connection.execute('SELECT COUNT(*) FROM delivery_outbox').fetchone()[0]
                if count >= self.max_pending_outputs:
                    raise DeliveryCapacityError(f'Kafka durable outbox capacity exceeded: {count}>={self.max_pending_outputs}; output and checkpoint not accepted')
                cursor = connection.execute('INSERT INTO delivery_outbox(topic,message_key,payload_json) VALUES (?,?,?)', (topic, key, encoded))
                self._checkpoint(connection, input_ids, cutoff_s)
                return cursor.lastrowid

    def checkpoint(self, input_ids: Sequence[int], cutoff_s: float):
        with self._lock:
            connection = self._database()
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                self._checkpoint(connection, input_ids, cutoff_s)

    def discard_input(self, input_ids: Sequence[int]):
        identifiers = list(input_ids)
        if any((isinstance(value, bool) or not isinstance(value, int) or value < 1 for value in identifiers)):
            raise ValueError('Kafka discarded inbox IDs must be positive integers')
        with self._lock:
            connection = self._database()
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                for start in range(0, len(identifiers), 900):
                    chunk = identifiers[start:start + 900]
                    connection.execute('DELETE FROM delivery_inbox WHERE id IN (' + ','.join(('?' for _ in chunk)) + ')', chunk)

    def next_output(self):
        with self._lock:
            row = self._database().execute('SELECT * FROM delivery_outbox ORDER BY id LIMIT 1').fetchone()
            if row is None:
                return None
            return {'id': row['id'], 'topic': row['topic'], 'key': bytes(row['message_key']), 'payload': json.loads(row['payload_json'])}

    def ack_output(self, identifier):
        with self._lock:
            connection = self._database()
            with connection:
                connection.execute('DELETE FROM delivery_outbox WHERE id=?', (identifier,))

    def quarantine_output(self, identifier, error):
        with self._lock:
            connection = self._database()
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                row = connection.execute('SELECT * FROM delivery_outbox WHERE id=?', (identifier,)).fetchone()
                if row is None:
                    return False
                connection.execute('INSERT INTO delivery_failed_outbox (id,topic,message_key,payload_json,error,failed_time_s) VALUES (?,?,?,?,?,?)', (row['id'], row['topic'], row['message_key'], row['payload_json'], str(error), time.time()))
                connection.execute('DELETE FROM delivery_outbox WHERE id=?', (identifier,))
                return True

    def list_failed_outputs(self, limit=100):
        limit = self._positive_integer(limit, 'limit')
        with self._lock:
            rows = self._database().execute('SELECT * FROM delivery_failed_outbox ORDER BY id LIMIT ?', (limit,))
            return [dict(id=row['id'], topic=row['topic'], key=bytes(row['message_key']), payload=json.loads(row['payload_json']), error=row['error'], failed_time_s=row['failed_time_s']) for row in rows]

    def requeue_failed(self, identifier):
        with self._lock:
            connection = self._database()
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                row = connection.execute('SELECT * FROM delivery_failed_outbox WHERE id=?', (identifier,)).fetchone()
                if row is None:
                    raise KeyError(f'Kafka failed output {identifier} does not exist')
                count = connection.execute('SELECT COUNT(*) FROM delivery_outbox').fetchone()[0]
                if count >= self.max_pending_outputs:
                    raise DeliveryCapacityError('Kafka durable outbox capacity exceeded; failed output retained')
                cursor = connection.execute('INSERT INTO delivery_outbox(topic,message_key,payload_json) VALUES (?,?,?)', (row['topic'], row['message_key'], row['payload_json']))
                connection.execute('DELETE FROM delivery_failed_outbox WHERE id=?', (identifier,))
                return cursor.lastrowid

    def counts(self) -> dict:
        with self._lock:
            connection = self._database()
            return {'inbox': connection.execute('SELECT COUNT(*) FROM delivery_inbox').fetchone()[0], 'outbox': connection.execute('SELECT COUNT(*) FROM delivery_outbox').fetchone()[0], 'pending_inputs': connection.execute('SELECT COUNT(*) FROM delivery_inbox WHERE processed=0').fetchone()[0], 'failed_outputs': connection.execute('SELECT COUNT(*) FROM delivery_failed_outbox').fetchone()[0]}

    def close(self):
        with self._lock:
            try:
                if self._connection is not None:
                    self._connection.close()
                    self._connection = None
            finally:
                if self._file_lock is not None:
                    self._file_lock.close()
                    self._file_lock = None
