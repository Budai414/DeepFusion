from __future__ import annotations
from typing import Dict
FUSION_OUTPUT_FIELD_TYPES: Dict[str, str] = {'mbzhph': 'int', 'mbysph': 'int', 'kqly': 'String', 'kqlysblx': 'String', 'kqlysbbh': 'String', 'sjl': 'int', 'bjmblx': 'String', 'zhlx': 'String', 'ccxh': 'String', 'ckms': 'String', 'centerLon': 'Double', 'centerLat': 'Double', 'bf': 'int', 'hjzl': 'String', 'mbjd': 'double', 'mbwd': 'double', 'mbgd': 'double', 'hb': 'double', 'xfxsd': 'double', 'yfxsd': 'double', 'zfxsd': 'double', 'RCS': 'int', 'xdys': 'int', 'ms': 'int', 'sec': 'int', 'min': 'int', 'h': 'int', 'd': 'int', 'dwsx': 'String', 'hlsx': 'String', 'flmb': 'String', 'hsqk': 'String', 'jzzdfp': 'String', 'jfgrxg': 'String', 'grzt': 'String', 'gxbz': 'String', 'sbbz': 'String', 'ysmbbh': 'String', 'snm': 'String', 'mbpd': 'String', 'mbbh': 'String', 'rhsj': 'String', 'ysswmbtsList': 'List<A0A7_VO>', 'ysswmbridList': 'JSONArray', 'ysewmbtsList': 'JSONArray', 'wxdj': 'int', 'zhsd': 'double', 'zhydfx': 'double', 'rwfpzl': 'String', 'xwid': 'String', 'ysmbcs': 'JSONArray'}

def new_output_record() -> Dict[str, object]:
    return {name: None for name in FUSION_OUTPUT_FIELD_TYPES}
