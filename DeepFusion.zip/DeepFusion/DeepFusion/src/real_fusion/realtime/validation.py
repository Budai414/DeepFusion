from __future__ import annotations
import math
from typing import Mapping
import pandas as pd
from real_fusion.sw.reader import normalize_zbb

def _numeric(value: object) -> float:
    try:
        return float(pd.to_numeric(value, errors='coerce'))
    except (TypeError, ValueError, OverflowError):
        return float('nan')

def validate_stream_core_fields(kind: str, payload: Mapping[str, object], section: Mapping[str, object]) -> None:
    core = {str(role): str(name) for (role, name) in section['_core_columns'].items()}
    for (role, name) in core.items():
        value = payload.get(name)
        if not pd.api.types.is_scalar(value) or isinstance(value, bool):
            raise ValueError(f'{kind} 核心字段 {name} ({role}) 必须是标量，不能是容器或布尔值。')
    for role in ('MBY', 'ZBB'):
        name = core[role]
        if not normalize_zbb(payload.get(name)):
            raise ValueError(f'{kind} 核心字段 {name} ({role}) 不能为空或非有限编号。')
    if kind == 'SW':
        validation = section.get('position_validation', {})
        epsilon = float(validation.get('zero_epsilon', 1e-09))
        for (role, range_key, default_range, zero_key) in (('MBJ', 'longitude_range_deg', (-180.0, 180.0), 'reject_zero_longitude'), ('MBW', 'latitude_range_deg', (-90.0, 90.0), 'reject_zero_latitude'), ('HB', 'altitude_range_m', (-1000.0, 100000.0), 'reject_zero_altitude')):
            name = core[role]
            number = _numeric(payload.get(name))
            (lower, upper) = map(float, validation.get(range_key, default_range))
            if not math.isfinite(number) or not lower <= number <= upper:
                raise ValueError(f'SW 核心字段 {name} ({role}) 必须是 [{lower}, {upper}] 内的有限数值。')
            if bool(validation.get(zero_key, True)) and abs(number) <= epsilon:
                raise ValueError(f'SW 核心字段 {name} ({role}) 按当前配置不能为零。')
        return
    measurement = section.get('measurement', {})
    for (role, scale_key, range_key, default_range, required) in (('FW', 'azimuth_scale_deg_per_unit', 'azimuth_range_deg', (0.0, 360.0), True), ('FY', 'elevation_scale_deg_per_unit', 'elevation_range_deg', (-90.0, 90.0), False), ('FW_RATE', 'azimuth_rate_scale_deg_s_per_unit', 'azimuth_rate_range_deg_s', (-20.0, 20.0), False), ('FY_RATE', 'elevation_rate_scale_deg_s_per_unit', 'elevation_rate_range_deg_s', (-20.0, 20.0), False)):
        name = core.get(role)
        number = _numeric(payload.get(name)) * float(measurement.get(scale_key, 0.01))
        if not math.isfinite(number):
            if required:
                raise ValueError(f'EW 核心字段 {name} ({role}) 必须是有限数值。')
            continue
        (lower, upper) = map(float, measurement.get(range_key, default_range))
        if not lower <= number <= upper:
            raise ValueError(f'EW 核心字段 {name} ({role}) 换算后必须在 [{lower}, {upper}] 内。')
