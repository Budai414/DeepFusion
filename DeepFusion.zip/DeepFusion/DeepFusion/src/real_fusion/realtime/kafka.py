from __future__ import annotations
import calendar
from dataclasses import dataclass
from datetime import datetime
import json
import math
import threading
import time
from typing import Dict, List, Mapping, Optional, Sequence
from zoneinfo import ZoneInfo
import pandas as pd
from real_fusion.realtime.service import RealtimeFusionService, RealtimeSnapshot
from real_fusion.realtime.output import OutputEncoding, build_fusion_output_array
from real_fusion.realtime.output_identity import RealtimeOutputIdentity
from real_fusion.realtime.kafka_delivery import KafkaDeliveryMixin
from real_fusion.realtime.delivery_config import delivery_consumer_group
INTERNAL_VELOCITY_FIELDS = {'east': '__realtime_velocity_east_mps', 'north': '__realtime_velocity_north_mps', 'up': '__realtime_velocity_up_mps'}
REPLAY_AUDIT_FIELDS = {'__DeepFusionReplayEventTime': '__realtime_replay_event_time', '__DeepFusionReplayRunId': '__realtime_replay_run_id', '__DeepFusionReplaySequence': '__realtime_replay_sequence'}

def _message_body(message: object, envelope_keys: Sequence[str]) -> object:
    if not isinstance(message, Mapping):
        return message
    for key in envelope_keys:
        if key in message:
            return message[key]
    return message

def _invalid_value(value: object, invalid_strings: set[str]) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip().casefold() in invalid_strings
    if isinstance(value, float):
        return not math.isfinite(value)
    return False

def _mapping_by_configured_names(body: Mapping[object, object], case_sensitive: bool) -> Dict[str, object]:
    normalized: Dict[str, object] = {}
    original_names: Dict[str, str] = {}
    for (raw_key, value) in body.items():
        original = str(raw_key).strip()
        key = original if case_sensitive else original.casefold()
        if key in normalized:
            raise ValueError(f'Kafka JSON对象包含规范化后重复的字段：{original_names[key]!r} 与 {original!r}。')
        normalized[key] = value
        original_names[key] = original
    return normalized

def split_kafka_json_records(data_kind: str, message: object, kafka_config: dict) -> List[Mapping[object, object]]:
    kind = str(data_kind).strip().upper()
    if kind not in {'SW', 'EW'}:
        raise ValueError(f'Kafka数据类型只能是SW或EW，实际为{data_kind!r}。')
    stream_config = kafka_config[kind.lower()]
    json_config = kafka_config.get('json', {})
    envelope_keys = [str(value) for value in json_config.get('envelope_keys', ['payload', 'data', 'record'])]
    body = _message_body(message, envelope_keys)
    if isinstance(body, Mapping):
        return [body]
    if not isinstance(body, (list, tuple)):
        raise ValueError(f'{kind} Kafka报文必须是JSON对象、对象批次数组或按配置顺序排列的值数组。')
    if not body:
        raise ValueError(f'{kind} Kafka对象批次数组不能为空。')
    mapping_flags = [isinstance(item, Mapping) for item in body]
    if all(mapping_flags):
        return list(body)
    if any(mapping_flags):
        raise ValueError(f'{kind} Kafka数组不能混合JSON对象与位置值。')
    declared_fields = [str(value) for value in stream_config['fields']]
    if len(body) != len(declared_fields):
        raise ValueError(f'{kind}固定位置值数组应有{len(declared_fields)}项，实际为{len(body)}项；若使用对象报文，格式应为 [{{"字段名":值,...}}]。')
    return [dict(zip(declared_fields, body))]

def _lookup_field(body: Mapping[str, object], field_name: str, case_sensitive: bool) -> object:
    key = str(field_name).strip()
    return body.get(key if case_sensitive else key.casefold())

def _timestamp_from_value(value: object, timezone_name: str, numeric_unit: str) -> pd.Timestamp:
    if isinstance(value, (int, float)) and (not isinstance(value, bool)):
        numeric = float(value)
        if not math.isfinite(numeric):
            raise ValueError('时间戳不是有限数值。')
        unit = str(numeric_unit).lower()
        if unit == 'auto':
            unit = 'ms' if abs(numeric) >= 100000000000.0 else 's'
        timestamp = pd.Timestamp(numeric, unit=unit, tz='UTC').tz_convert(timezone_name)
    else:
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize(timezone_name)
        else:
            timestamp = timestamp.tz_convert(timezone_name)
    if pd.isna(timestamp):
        raise ValueError('时间戳为空。')
    return timestamp

def _component_timestamp(body: Mapping[str, object], event_config: dict, case_sensitive: bool, invalid_strings: set[str], base_epoch_s: float) -> Optional[pd.Timestamp]:
    fields = event_config.get('component_fields', {})
    if not isinstance(fields, dict):
        return None
    names = [fields.get(key) for key in ('day', 'hour', 'minute', 'second', 'millisecond')]
    if any((not name for name in names)):
        return None
    values = [_lookup_field(body, str(name), case_sensitive) for name in names]
    if any((_invalid_value(value, invalid_strings) for value in values)):
        return None
    try:
        (day, hour, minute, second, millisecond) = (int(float(value)) for value in values)
    except (TypeError, ValueError, OverflowError):
        return None
    if not (0 <= hour <= 23 and 0 <= minute <= 59 and (0 <= second <= 59) and (0 <= millisecond <= 999)):
        return None
    timezone = ZoneInfo(str(event_config.get('timezone', 'Asia/Shanghai')))
    base = datetime.fromtimestamp(float(base_epoch_s), tz=timezone)
    candidates = []
    for month_delta in (-1, 0, 1):
        month_index = base.year * 12 + base.month - 1 + month_delta
        (year, month_zero) = divmod(month_index, 12)
        month = month_zero + 1
        if day < 1 or day > calendar.monthrange(year, month)[1]:
            continue
        candidates.append(datetime(year, month, day, hour, minute, second, millisecond * 1000, tzinfo=timezone))
    if not candidates:
        return None
    selected = min(candidates, key=lambda value: abs(value.timestamp() - base_epoch_s))
    return pd.Timestamp(selected)

def resolve_kafka_event_time(body: Mapping[str, object], kafka_config: dict, broker_timestamp_s: Optional[float], arrival_time_s: float) -> pd.Timestamp:
    event_config = kafka_config.get('event_time', {})
    json_config = kafka_config.get('json', {})
    timezone_name = str(event_config.get('timezone', 'Asia/Shanghai'))
    case_sensitive = bool(json_config.get('case_sensitive_fields', False))
    invalid_strings = {str(value).strip().casefold() for value in json_config.get('invalid_string_values', [])}
    for field_name in event_config.get('direct_timestamp_fields', []):
        value = _lookup_field(body, str(field_name), case_sensitive)
        if _invalid_value(value, invalid_strings):
            continue
        try:
            return _timestamp_from_value(value, timezone_name, str(event_config.get('direct_numeric_unit', 'auto')))
        except (TypeError, ValueError, OverflowError):
            continue
    base_epoch_s = float(broker_timestamp_s) if broker_timestamp_s is not None and math.isfinite(float(broker_timestamp_s)) else float(arrival_time_s)
    component = _component_timestamp(body, event_config, case_sensitive, invalid_strings, base_epoch_s)
    if component is not None:
        return component
    if broker_timestamp_s is not None and bool(event_config.get('fallback_to_kafka_timestamp', True)):
        return pd.Timestamp(float(broker_timestamp_s), unit='s', tz='UTC').tz_convert(timezone_name)
    if bool(event_config.get('fallback_to_arrival_time', True)):
        return pd.Timestamp(float(arrival_time_s), unit='s', tz='UTC').tz_convert(timezone_name)
    raise ValueError('报文没有可用事件时间，且未启用Kafka时间或到达时间后备。')

def transform_kafka_json_message(data_kind: str, message: object, fusion_config: dict, kafka_config: dict, broker_timestamp_s: Optional[float]=None, arrival_time_s: Optional[float]=None) -> Dict[str, object]:
    kind = str(data_kind).strip().upper()
    if kind not in {'SW', 'EW'}:
        raise ValueError(f'Kafka数据类型只能是SW或EW，实际为{data_kind!r}。')
    stream_config = kafka_config[kind.lower()]
    json_config = kafka_config.get('json', {})
    records = split_kafka_json_records(kind, message, kafka_config)
    if len(records) != 1:
        raise ValueError(f'{kind} Kafka消息包含{len(records)}条对象记录，需先展开后逐条转换。')
    body = records[0]
    declared_fields = [str(value) for value in stream_config['fields']]
    case_sensitive = bool(json_config.get('case_sensitive_fields', False))
    values = _mapping_by_configured_names(body, case_sensitive)
    allowed = {name if case_sensitive else name.casefold() for name in declared_fields}
    unknown = [name for name in values if name not in allowed]
    if unknown and (not bool(json_config.get('ignore_unknown_fields', True))):
        raise ValueError(f'{kind} Kafka报文包含未声明字段: {unknown}')
    invalid_strings = {str(value).strip().casefold() for value in json_config.get('invalid_string_values', [])}
    core_fields = {str(role): str(name) for (role, name) in stream_config['core_fields'].items()}
    role_values = {role: _lookup_field(values, field_name, case_sensitive) for (role, field_name) in core_fields.items()}
    missing_roles = [str(role) for role in stream_config.get('required_valid_roles', []) if _invalid_value(role_values.get(str(role)), invalid_strings)]
    if missing_roles:
        raise ValueError(f'{kind} Kafka报文核心字段无效或缺失: {missing_roles}')
    section = fusion_config[kind.lower()]
    expected = [str(value) for value in section['expected_columns']]
    destination_roles = {str(role): str(name) for (role, name) in section['_core_columns'].items()}
    normalized: Dict[str, object] = {name: None for name in expected}
    for (role, value) in role_values.items():
        if role in destination_roles:
            normalized[destination_roles[role]] = None if _invalid_value(value, invalid_strings) else value
    arrival = time.time() if arrival_time_s is None else float(arrival_time_s)
    event_timestamp = resolve_kafka_event_time(values, kafka_config, broker_timestamp_s, arrival)
    normalized[destination_roles['JDSC']] = event_timestamp.isoformat()
    normalized['__realtime_source_fields'] = {field_name: _lookup_field(values, field_name, case_sensitive) for field_name in declared_fields}
    normalized['__realtime_input_field_count'] = len(values)
    normalized['__realtime_recognized_field_count'] = len(values.keys() & allowed)
    normalized['__realtime_ignored_field_count'] = len(unknown)
    for (source_name, internal_name) in REPLAY_AUDIT_FIELDS.items():
        value = _lookup_field(values, source_name, case_sensitive)
        if not _invalid_value(value, invalid_strings):
            normalized[internal_name] = value
    if kind == 'SW' and bool(stream_config.get('velocity', {}).get('enabled', False)):
        velocity_config = stream_config['velocity']
        scale = float(velocity_config.get('unit_scale_to_mps', 1.0))
        axis_mapping = velocity_config.get('axis_mapping', {'east': 'VE', 'north': 'VN', 'up': 'VU'})
        for (axis, internal_name) in INTERNAL_VELOCITY_FIELDS.items():
            role = str(axis_mapping.get(axis, ''))
            value = role_values.get(role)
            if _invalid_value(value, invalid_strings):
                normalized[internal_name] = None
                continue
            try:
                numeric = float(value) * scale
            except (TypeError, ValueError, OverflowError):
                numeric = float('nan')
            normalized[internal_name] = numeric if math.isfinite(numeric) else None
    return normalized

def build_realtime_output_message(snapshot: RealtimeSnapshot, kafka_config: dict, identity_resolver: Optional[RealtimeOutputIdentity]=None) -> list[dict]:
    settings = kafka_config.get('output', {})
    encoding = OutputEncoding(coordinate_unit_deg=settings.get('coordinate_unit_deg', 1.0), velocity_unit_mps=settings.get('velocity_unit_mps', 1.0), velocity_axes=tuple(settings.get('velocity_axes', ('east', 'north', 'up'))), timezone=str(settings.get('timezone', 'Asia/Shanghai')))
    resolver = identity_resolver if identity_resolver is not None else RealtimeOutputIdentity()
    return build_fusion_output_array(snapshot, encoding, resolver.resolve(snapshot.result))

@dataclass(frozen=True)
class KafkaBridgeStatus:
    running: bool
    consumed_messages: int
    rejected_messages: int
    published_snapshots: int
    last_error: Optional[str]
    pending_inputs: int = 0
    pending_outputs: int = 0
    recovering: bool = False
    failed_outputs: int = 0
    last_input_error: Optional[str] = None

class KafkaRealtimeBridge(KafkaDeliveryMixin):

    def __init__(self, service: RealtimeFusionService, kafka_config: dict, on_log=None, consumer_factory=None, producer_factory=None) -> None:
        self.service = service
        self.config = kafka_config
        self.on_log = on_log
        self.consumer_factory = consumer_factory
        self.producer_factory = producer_factory
        self._consumer = None
        self._producer = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._running = False
        self._consumed = 0
        self._rejected = 0
        self._published = 0
        self._last_error: Optional[str] = None
        self._last_publish_error: Optional[str] = None
        self._last_rejection_error: Optional[str] = None
        self._last_delivery_counts = {}
        self._output_identity = RealtimeOutputIdentity()
        self._downstream_snapshot_callback = service.on_snapshot
        self._init_delivery()

    def _log(self, message: str) -> None:
        if self.on_log is not None:
            try:
                self.on_log(str(message))
            except Exception as error:
                with self._lock:
                    self._last_error = f'Kafka日志通知失败：{error}'

    def _client_security_kwargs(self) -> dict:
        security = self.config.get('security', {})
        kwargs = {'security_protocol': str(security.get('protocol', 'PLAINTEXT'))}
        if kwargs['security_protocol'].startswith('SASL'):
            kwargs.update({'sasl_mechanism': str(security.get('sasl_mechanism', 'PLAIN')), 'sasl_plain_username': str(security.get('username', '')), 'sasl_plain_password': str(security.get('password', ''))})
        for (config_key, client_key) in (('ssl_cafile', 'ssl_cafile'), ('ssl_certfile', 'ssl_certfile'), ('ssl_keyfile', 'ssl_keyfile')):
            if str(security.get(config_key, '')).strip():
                kwargs[client_key] = str(security[config_key]).strip()
        if kwargs['security_protocol'] in {'SSL', 'SASL_SSL'}:
            kwargs['ssl_check_hostname'] = bool(security.get('ssl_check_hostname', True))
        return kwargs

    def _create_clients(self) -> None:
        if any((value == '服务器地址' for value in self.config['brokers'])):
            raise ValueError('请先在configs/kafka.yaml中把brokers的“服务器地址”改为实际host:port。')
        if self.consumer_factory is None or self.producer_factory is None:
            try:
                from kafka import KafkaConsumer, KafkaProducer
            except ImportError as error:
                raise RuntimeError('缺少Kafka客户端。请安装requirements.txt中的kafka-python-ng后重试。') from error
            consumer_factory = self.consumer_factory or KafkaConsumer
            producer_factory = self.producer_factory or KafkaProducer
        else:
            consumer_factory = self.consumer_factory
            producer_factory = self.producer_factory
        consumer = self.config['consumer']
        if bool(consumer.get('enable_auto_commit', False)):
            raise ValueError('可靠接收要求关闭enable_auto_commit；位点只在本地持久化后提交。')
        common = self._client_security_kwargs()
        self._consumer = consumer_factory(self.config['input_topic'], self.config['input_topic_1'], bootstrap_servers=self.config['brokers'], group_id=delivery_consumer_group(self.config), client_id=self.config['client_id'] + '-consumer', auto_offset_reset='earliest' if str(self.config.get('delivery', {}).get('generation', '')).strip() else str(consumer['auto_offset_reset']), enable_auto_commit=bool(consumer['enable_auto_commit']), session_timeout_ms=int(consumer['session_timeout_ms']), heartbeat_interval_ms=int(consumer['heartbeat_interval_ms']), request_timeout_ms=int(consumer['request_timeout_ms']), retry_backoff_ms=int(consumer['retry_backoff_ms']), reconnect_backoff_ms=int(consumer['reconnect_backoff_ms']), reconnect_backoff_max_ms=int(consumer['reconnect_backoff_max_ms']), max_partition_fetch_bytes=int(consumer['max_partition_fetch_bytes']), fetch_max_bytes=int(consumer['fetch_max_bytes']), **common)
        producer = self.config.get('producer', {})
        if bool(producer.get('enabled', True)):
            producer_kwargs = {'bootstrap_servers': self.config['brokers'], 'client_id': self.config['client_id'] + '-producer', 'acks': producer.get('acknowledgements', 'all'), 'retries': int(producer.get('retries', 5)), 'linger_ms': int(producer.get('linger_ms', 20)), 'batch_size': int(producer.get('batch_size', 32768)), 'request_timeout_ms': int(producer.get('request_timeout_ms', 30000)), 'max_request_size': int(producer.get('max_request_size', 10485760)), 'max_block_ms': int(producer.get('max_block_ms', 1000)), 'max_in_flight_requests_per_connection': 1, 'value_serializer': lambda value: json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8'), **common}
            if producer.get('compression_type'):
                producer_kwargs['compression_type'] = str(producer['compression_type'])
            self._producer = producer_factory(**producer_kwargs)

    def start(self) -> None:
        if self._running:
            return
        self._open_store()
        if bool(self.config.get('producer', {}).get('enabled', True)):
            self._ensure_result_recorder()
        self._create_clients()
        self._ensure_publisher()
        self._stop_event.clear()
        self.service.on_snapshot = self._handle_snapshot
        self.service.on_input_checkpoint = self._checkpoint_inputs
        self._running = True
        self._thread = threading.Thread(target=self._consume_loop, name='RealFusionKafkaConsumer', daemon=True)
        self._thread.start()
        self._log(f"Kafka已连接：SW={self.config['input_topic']}，EW={self.config['input_topic_1']}，输出={self.config['output_topic']}。")

    def stop_receiving(self, timeout_s: float=30.0) -> None:
        self._stop_event.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=max(0.0, float(timeout_s)))
            if thread.is_alive():
                raise TimeoutError('Kafka输入仍在停止，请等待后重试；输出连接保持开启。')
        self._thread = None
        if self._consumer is not None:
            self._consumer.close()
            self._consumer = None
        with self._lock:
            self._running = False

    def stop(self) -> None:
        try:
            self._stop_bridge()
        except Exception as error:
            self._finish_result_recorder(False, str(error), close=False)
            raise

    def _stop_bridge(self) -> None:
        self.stop_receiving()
        if self._producer is not None:
            timeout = float(self.config.get('output', {}).get('flush_timeout_s', 10.0))
            if self._publisher is not None:
                self._drain_publisher(timeout)
            self._producer.flush(timeout=timeout)
            self._producer.close(timeout=timeout)
            self._producer = None
        self.service.on_snapshot = self._downstream_snapshot_callback
        self.service.on_input_checkpoint = self._previous_checkpoint
        with self._delivery_lock:
            if self._store is not None:
                self._last_delivery_counts = self._store.counts()
                pending = self._last_delivery_counts.get('pending_inputs', 0)
                if pending:
                    self._log(f'Kafka停止时保留{pending}条已落盘未完成输入，下次启动将优先恢复。')
                failed = self._last_delivery_counts.get('failed_outputs', 0)
                if failed:
                    self._log(f'Kafka停止时仍有{failed}批隔离输出未交付，原报文已保留，请导出检查。')
                self._store.close()
                self._store = None
            self._submitted_ids.clear()
        self._running = False
        counts = self._last_delivery_counts
        unfinished = any((counts.get(name, 0) for name in ('pending_inputs', 'outbox', 'failed_outputs')))
        self._finish_result_recorder(not unfinished, '存在未完成输入或未交付输出，TXT仅包含已确认发送的报文' if unfinished else None)
        self._log('Kafka接收与输出已停止。')

    def status(self) -> KafkaBridgeStatus:
        with self._delivery_lock:
            counts = self._store.counts() if self._store is not None else self._last_delivery_counts
        failed = counts.get('failed_outputs', 0)
        failed_error = f'{failed}批输出因永久错误被隔离，尚未交付；请导出检查。' if failed else None
        with self._lock:
            return KafkaBridgeStatus(self._running, self._consumed, self._rejected, self._published, self._last_publish_error or self._last_error or failed_error, counts.get('pending_inputs', 0), counts.get('outbox', 0), self._recovering, failed, self._last_rejection_error)

    def _consume_loop(self) -> None:
        self._consume_durable_loop()

    def _handle_snapshot(self, snapshot: RealtimeSnapshot) -> None:
        ids = tuple(getattr(snapshot, 'processed_input_ids', ()))
        history = float(getattr(self.service, 'config', {}).get('realtime', {}).get('history_window_s', 120.0))
        cutoff = snapshot.latest_event_time_s - history
        try:
            with self._delivery_lock:
                if self._recovering or self._recovery_interrupted:
                    self._recovery_snapshot = snapshot
                    self._recovery_ids.update(ids)
                    return
            if self._producer is not None:
                message = build_realtime_output_message(snapshot, self.config, self._output_identity)
                self._open_store().stage_output(self.config['output_topic'], str(int(snapshot.latest_event_time_s * 1000)).encode('ascii'), message, ids, cutoff)
                with self._delivery_lock:
                    self._submitted_ids.difference_update(ids)
                self._ensure_publisher()
                self._publisher_wake.set()
            elif ids:
                self._checkpoint_inputs(ids, cutoff)
        except Exception as error:
            self._snapshot_failed(error)
            raise
        finally:
            if self._downstream_snapshot_callback is not None:
                try:
                    self._downstream_snapshot_callback(snapshot)
                except Exception as error:
                    self._log(f'融合快照界面通知失败：{error}')

    def _snapshot_acknowledged(self, _metadata) -> None:
        with self._lock:
            self._published += 1
            self._last_publish_error = None

    def _snapshot_failed(self, error: Exception) -> None:
        with self._lock:
            self._last_publish_error = str(error)
        self._log(f'Kafka融合结果发布失败：{error}')
