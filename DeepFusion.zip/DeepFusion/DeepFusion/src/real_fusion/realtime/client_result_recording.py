from __future__ import annotations
from datetime import datetime
import json
import os
from pathlib import Path
import re
import sqlite3
import threading
import time
VERSION = 'client-20261111.1'
SESSION = re.compile('^[0-9]{8}_[0-9]{6}_[0-9a-f]{32}$')

def atomic_text(path, text):
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)

def atomic_json(path, value):
    atomic_text(path, json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n')

def rebuild(directory, connection):
    temporary = directory / 'results.txt.rebuild'
    count = 0
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        for (line,) in connection.execute('SELECT line FROM messages ORDER BY sequence'):
            stream.write(line + '\n')
            count += 1
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, directory / 'results.txt')
    return count

class ResultRecorder:

    def __init__(self, state_dir, run_id):
        if not re.fullmatch('[0-9a-f]{32}', run_id):
            raise ValueError('invalid recording run_id')
        self._lock = threading.RLock()
        self._lease = self._db = self._stream = None
        self._closed = False
        self._dirty = False
        self._count = 0
        self._phase = 'recording'
        self._error = None
        self._terminal_reason = None
        self._updated_at = time.time()
        self._run_id = run_id
        self.root = Path(state_dir) / 'fusion_results'
        self.root.mkdir(parents=True, exist_ok=True)
        try:
            self._lease = (self.root / 'recording.lock').open('a+b')
            if os.name == 'nt':
                import msvcrt
                self._lease.seek(0)
                if not self._lease.read(1):
                    self._lease.write(b'0')
                    self._lease.flush()
                self._lease.seek(0)
                msvcrt.locking(self._lease.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self._recover_previous()
            self.session = datetime.now().strftime('%Y%m%d_%H%M%S_') + run_id
            self.directory = self.root / self.session
            self.directory.mkdir(exist_ok=False)
            self._db = sqlite3.connect(str(self.directory / 'records.sqlite3'), check_same_thread=False)
            self._db.execute('PRAGMA journal_mode=WAL')
            self._db.execute('PRAGMA synchronous=FULL')
            self._db.execute('CREATE TABLE messages (\n                sequence INTEGER PRIMARY KEY AUTOINCREMENT,\n                output_id INTEGER UNIQUE NOT NULL,\n                topic TEXT NOT NULL, message_key BLOB NOT NULL, line TEXT NOT NULL)')
            self._db.commit()
            rebuild(self.directory, self._db)
            self._stream = (self.directory / 'results.txt').open('a', encoding='utf-8', newline='\n')
            self._save_status()
            atomic_json(self.root / 'current.json', self.status())
            atomic_text(self.root / 'latest.txt', self.session + '\n')
        except BaseException:
            self.close()
            raise

    def _recover_previous(self):
        latest = self.root / 'latest.txt'
        if not latest.exists():
            return
        name = latest.read_text(encoding='utf-8').strip()
        if not SESSION.fullmatch(name):
            raise ValueError('invalid fusion_results/latest.txt; preserve records and review this state directory')
        directory = self.root / name
        if directory.is_symlink() or not directory.is_dir():
            raise ValueError('previous recording directory is missing or is a symbolic link')
        database = directory / 'records.sqlite3'
        if not database.is_file() or database.is_symlink():
            raise ValueError('previous recording journal is missing or is a symbolic link')
        status_path = directory / 'recording-status.json'
        try:
            previous = json.loads(status_path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            previous = {}
        target = directory / 'results.txt'
        if previous.get('phase') == 'completed' and target.is_file() and (target.stat().st_size == previous.get('txt_bytes')):
            return
        connection = sqlite3.connect(str(database))
        try:
            count = rebuild(directory, connection)
        finally:
            connection.close()
        previous.update(version=VERSION, session=name, phase='interrupted', message_count=count, updated_at=time.time(), error='Previous service did not complete recording normally; saved journal recovered', txt_bytes=target.stat().st_size, results_file=str(target))
        atomic_json(status_path, previous)

    def status(self):
        return dict(version=VERSION, session=getattr(self, 'session', None), run_id=self._run_id, phase=self._phase, message_count=self._count, updated_at=self._updated_at, error=self._error or self._terminal_reason, results_file=str(self.directory / 'results.txt') if hasattr(self, 'directory') else None)

    def _save_status(self):
        state = self.status()
        state['txt_bytes'] = (self.directory / 'results.txt').stat().st_size
        atomic_json(self.directory / 'recording-status.json', state)

    def _repair_txt(self):
        if self._stream is not None:
            try:
                self._stream.close()
            finally:
                self._stream = None
        self._count = rebuild(self.directory, self._db)
        self._stream = (self.directory / 'results.txt').open('a', encoding='utf-8', newline='\n')
        self._dirty = False

    def record(self, item):
        payload = item['payload']
        if not isinstance(payload, list) or any((not isinstance(row, dict) for row in payload)):
            raise ValueError('fusion output must be a JSON object array')
        identifier = item['id']
        if isinstance(identifier, bool) or not isinstance(identifier, int) or identifier < 1:
            raise ValueError('invalid durable outbox identifier')
        line = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
        key = bytes(item['key'])
        topic = str(item['topic'])
        with self._lock:
            if self._closed:
                raise RuntimeError('result recorder is closed')
            try:
                if self._dirty:
                    self._repair_txt()
                prior = self._db.execute('SELECT topic,message_key,line FROM messages WHERE output_id=?', (identifier,)).fetchone()
                fresh = prior is None
                if prior is not None and (prior[0], bytes(prior[1]), prior[2]) != (topic, key, line):
                    raise ValueError('durable outbox identifier reused with different content')
                if fresh:
                    with self._db:
                        self._db.execute('INSERT INTO messages(output_id,topic,message_key,line) VALUES (?,?,?,?)', (identifier, topic, key, line))
                    self._dirty = True
                    self._stream.write(line + '\n')
                    self._stream.flush()
                    os.fsync(self._stream.fileno())
                    self._count += 1
                    self._dirty = False
                self._error = None
                self._updated_at = time.time()
                self._save_status()
            except Exception as error:
                self._error = str(error)
                self._updated_at = time.time()
                raise
        if fresh:
            try:
                print(line, flush=True)
            except (OSError, ValueError):
                pass

    def finish(self, complete=True, reason=None, close=True):
        if not close:
            self._phase = 'incomplete'
            self._terminal_reason = reason or self._terminal_reason or 'publisher did not stop cleanly'
            self._updated_at = time.time()
            return
        with self._lock:
            try:
                if self._dirty:
                    self._repair_txt()
                if self._stream is not None:
                    self._stream.flush()
                    os.fsync(self._stream.fileno())
                self._phase = 'completed' if complete and (not self._error) else 'incomplete'
                self._terminal_reason = reason if complete else reason or self._terminal_reason
                self._updated_at = time.time()
                self._save_status()
            except Exception as error:
                self._phase = 'incomplete'
                self._terminal_reason = str(error)
                self._updated_at = time.time()
                raise
            if close:
                self.close()

    def close(self):
        with self._lock:
            self._closed = True
            error = None
            for name in ('_stream', '_db', '_lease'):
                resource = getattr(self, name, None)
                if resource is not None:
                    try:
                        resource.close()
                    except Exception as caught:
                        error = error or caught
                    finally:
                        setattr(self, name, None)
            if error is not None:
                raise error

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
