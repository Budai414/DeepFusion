from __future__ import annotations
import argparse
from pathlib import Path
from real_fusion.config import load_config, load_kafka_config
from real_fusion.runner import execute_sw, execute_sw_ew
from real_fusion.visualization import serve_cesium_player, serve_fusion_player

def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='DS-SW 多设备航迹构建与航迹融合')
    subparsers = parser.add_subparsers(dest='command', required=True)
    run = subparsers.add_parser('run-sw', help='读取一个或多个同表头 SW 分卷并进行航迹融合')
    run.add_argument('--input', required=True, nargs='+', help='一个或多个同表头 DS-SW Excel 分卷；全部作为同一数据集融合')
    run.add_argument('--config', default='configs/real_sw.yaml')
    run.add_argument('--output', default='output/real_sw')
    run.add_argument('--start-time', default=None, help='可选闭区间开始绝对时戳；格式与Excel绝对时戳列相同')
    run.add_argument('--end-time', default=None, help='可选闭区间结束绝对时戳；格式与Excel绝对时戳列相同')
    joint = subparsers.add_parser('run-sw-ew', help='以 SW 为主航迹，融合异步 EW 方位/俯仰/可选斜距量测')
    joint.add_argument('--sw-input', required=True, nargs='+', help='一个或多个同表头 SW 分卷')
    joint.add_argument('--ew-input', required=True, nargs='+', help='一个或多个同表头 EW 分卷')
    joint.add_argument('--config', default='configs/real_sw.yaml')
    joint.add_argument('--output', default='output/real_sw_ew')
    joint.add_argument('--start-time', default=None)
    joint.add_argument('--end-time', default=None)
    player = subparsers.add_parser('open-player', help='本地打开已生成的动态播放器')
    player.add_argument('--file', default='output/real_sw/fusion_player.html')
    player.add_argument('--port', type=int, default=8765)
    player.add_argument('--no-browser', action='store_true')
    cesium_player = subparsers.add_parser('open-cesium-player', help='完全离线打开Cesium真实地图动态三维回放')
    cesium_player.add_argument('--file', default='output/real_sw/cesium_map_player.html')
    cesium_player.add_argument('--port', type=int, default=8766)
    cesium_player.add_argument('--no-browser', action='store_true')
    excel_to_kafka = subparsers.add_parser('excel-to-kafka', help='把SW56列/可选EW55列Excel直接转换为对象数组报文并实时发送到Kafka')
    excel_to_kafka.add_argument('--sw-input', required=True, nargs='+')
    excel_to_kafka.add_argument('--ew-input', nargs='*', default=[])
    excel_to_kafka.add_argument('--config', default='configs/real_sw.yaml')
    excel_to_kafka.add_argument('--kafka-config', default='configs/kafka.yaml')
    excel_to_kafka.add_argument('--seed', type=int, default=20260913)
    excel_to_kafka.add_argument('--maximum-gap-s', type=float, default=2.0)
    excel_to_kafka.add_argument('--start-time', default=None)
    excel_to_kafka.add_argument('--end-time', default=None)
    excel_to_kafka.add_argument('--speed', type=float, default=None, help='1为原节拍，10为十倍速，0为无等待；默认读取kafka.yaml')
    excel_to_kafka.add_argument('--startup-delay-s', type=float, default=None)
    return parser

def _print_summary(metrics: dict, output: Path) -> None:
    fusion = metrics['fusion']
    print(f"file_count={metrics['input']['file_count']}")
    print(f"global_target_count={metrics['input']['target_count']}")
    print(f"global_target_values={metrics['input']['target_values']}")
    print(f"raw_mby_values={metrics['input']['raw_mby_values']}")
    print(f"device_count={metrics['input']['device_count']}")
    print(f"device_values={metrics['input']['device_values']}")
    print(f"time_range={metrics['input']['time_range']}")
    print(f"time_filtered_rows={metrics['input']['time_filtered_rows']}")
    for source in metrics['source_tracks']:
        print('local_mby={target_id} zbb={zbb} sensor={sensor_id} reports={output_reports} median_interval_s={median_interval_s:.4f} frequency_hz={estimated_frequency_hz:.3f}'.format(**source))
    print(f"track_ids={fusion['track_ids']}")
    print(f"estimate_count={fusion['estimate_count']}")
    print(f"late_drop_count={fusion['late_drop_count']}")
    print(f"target_fusion_modes={fusion['target_fusion_modes']}")
    print(f"target_status_counts={fusion['target_status_counts']}")
    print(f"over_gate_target_ids={fusion['over_gate_target_ids']}")
    print(f"false_alarm_target_ids={fusion['sparse_handling']['false_alarm_target_ids']}")
    print(f"fusion_summary={output.resolve() / 'fusion_summary.html'}")
    print(f"cesium_map_player={output.resolve() / 'cesium_map_player.html'}")
    if 'ew' in metrics:
        print(f"ew_file_count={metrics['ew']['file_count']}")
        print(f"ew_valid_rows={metrics['ew']['valid_rows']}")
        print(f"ew_associated_count={metrics['joint_fusion']['associated_count']}")
        print(f"joint_track_ids={metrics['joint_fusion']['track_ids']}")
    comparison = metrics.get('reports', {}).get('observable_comparison', {})
    if comparison.get('status') == 'complete':
        print(f"paper_figures={output.resolve() / 'comparison_dashboard'}")
        print('paper_claim_scope=observable_without_independent_ground_truth')
    elif comparison.get('status') == 'failed':
        print(f"comparison_report_warning={comparison.get('error', '')}")
    print(f'output={output.resolve()}')

def main() -> None:
    args = _parser().parse_args()
    if args.command == 'open-player':
        serve_fusion_player(args.file, port=args.port, open_browser=not args.no_browser)
        return
    if args.command == 'open-cesium-player':
        serve_cesium_player(args.file, port=args.port, open_browser=not args.no_browser)
        return
    if args.command == 'excel-to-kafka':
        from real_fusion.realtime import KafkaInputReplayProducer, build_excel_realtime_messages
        fusion_config = load_config(args.config)
        kafka_config = load_kafka_config(args.kafka_config)
        if not kafka_config['input_replay_producer']['enabled']:
            raise ValueError('kafka.input_replay_producer.enabled=false，Excel输入回放已关闭。')
        conversion = build_excel_realtime_messages(fusion_config, kafka_config, args.sw_input, args.ew_input, seed=args.seed, maximum_gap_s=args.maximum_gap_s, start_time=args.start_time, end_time=args.end_time)
        print(f'message_shape=[{{宽对象}}]')
        print(f'message_count={len(conversion.messages)}')
        print(f'sw_message_count={conversion.sw_rows}')
        print(f'ew_message_count={conversion.ew_rows}')
        print(f'sw_rejected_rows={conversion.sw_rejected_rows}')
        print(f'ew_rejected_rows={conversion.ew_rejected_rows}')
        print(f'recognized_fields=SW:{conversion.recognized_field_count_sw},EW:{conversion.recognized_field_count_ew}')
        print(f"selected_start_time={conversion.selected_start_time or 'unbounded'}")
        print(f"selected_end_time={conversion.selected_end_time or 'unbounded'}")
        if conversion.messages:
            print(f'first_event_time={conversion.messages[0].event_time.isoformat()}')
            print(f'last_event_time={conversion.messages[-1].event_time.isoformat()}')
        producer = KafkaInputReplayProducer(kafka_config, on_log=print)
        try:
            status = producer.publish(conversion.messages, speed=args.speed, startup_delay_s=args.startup_delay_s)
        finally:
            producer.close()
        print(f'attempted_messages={status.attempted_messages}')
        print(f'broker_confirmed_messages={status.sent_messages}')
        print(f'failed_messages={status.failed_messages}')
        print(f'stopped={status.stopped}')
        return
    config = load_config(args.config)
    output = Path(args.output)
    if args.command == 'run-sw-ew':
        (_, metrics) = execute_sw_ew(config, args.sw_input, args.ew_input, output, start_time=args.start_time, end_time=args.end_time)
    else:
        (_, metrics) = execute_sw(config, args.input, output, start_time=args.start_time, end_time=args.end_time)
    _print_summary(metrics, output)
