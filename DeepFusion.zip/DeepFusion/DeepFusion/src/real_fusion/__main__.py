from real_fusion.cli import main
main()
