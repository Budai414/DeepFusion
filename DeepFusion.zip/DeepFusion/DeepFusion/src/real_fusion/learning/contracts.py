from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Dict, Optional

@dataclass(frozen=True)
class ModelProposal:
    task: str
    scores: Dict[str, float]
    confidence: float
    aleatoric_uncertainty: Optional[float]
    epistemic_uncertainty: Optional[float]
    ood_score: Optional[float]
    abstain: bool
    latency_ms: float
    model_id: str
    model_version: str
    model_sha256: str
    feature_schema_version: str
    explanation: Dict[str, object]

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

@dataclass(frozen=True)
class DecisionEnvelope:
    baseline_decision: bool
    learned_proposal: Optional[ModelProposal]
    authoritative_decision: bool
    authoritative_path: str
    guard_checks: Dict[str, bool]
    fallback_reason: Optional[str]

    def to_record(self) -> Dict[str, object]:
        return {'baseline_decision': self.baseline_decision, 'learned_proposal': self.learned_proposal.to_record() if self.learned_proposal is not None else None, 'authoritative_decision': self.authoritative_decision, 'authoritative_path': self.authoritative_path, 'guard_checks': dict(self.guard_checks), 'fallback_reason': self.fallback_reason}

@dataclass(frozen=True)
class IdentityLearningAudit:
    task_id: str
    left_local_track_key: str
    right_local_track_key: str
    hard_physical_gate_passed: bool
    feature_schema_version: str
    feature_sha256: str
    features: Dict[str, float]
    decision_threshold: float
    decision: DecisionEnvelope

    def to_record(self) -> Dict[str, object]:
        proposal = self.decision.learned_proposal
        return {'task_id': self.task_id, 'left_local_track_key': self.left_local_track_key, 'right_local_track_key': self.right_local_track_key, 'hard_physical_gate_passed': self.hard_physical_gate_passed, 'feature_schema_version': self.feature_schema_version, 'feature_sha256': self.feature_sha256, 'features': dict(self.features), 'decision_threshold': self.decision_threshold, 'baseline_decision': self.decision.baseline_decision, 'learned_same_target_probability': proposal.scores.get('same_target_probability') if proposal is not None else None, 'learned_decision': bool(proposal.scores.get('same_target_probability', 0.0) >= self.decision_threshold) if proposal is not None and proposal.scores.get('same_target_probability') is not None and isinstance(proposal.scores.get('same_target_probability'), (int, float)) and math.isfinite(float(proposal.scores['same_target_probability'])) else None, 'confidence': proposal.confidence if proposal is not None else None, 'aleatoric_uncertainty': proposal.aleatoric_uncertainty if proposal is not None else None, 'epistemic_uncertainty': proposal.epistemic_uncertainty if proposal is not None else None, 'ood_score': proposal.ood_score if proposal is not None else None, 'abstain': proposal.abstain if proposal is not None else True, 'latency_ms': proposal.latency_ms if proposal is not None else None, 'model_id': proposal.model_id if proposal is not None else None, 'model_version': proposal.model_version if proposal is not None else None, 'model_sha256': proposal.model_sha256 if proposal is not None else None, 'explanation': dict(proposal.explanation) if proposal is not None else {}, 'guard_checks': dict(self.decision.guard_checks), 'authoritative_decision': self.decision.authoritative_decision, 'authoritative_path': self.decision.authoritative_path, 'fallback_reason': self.decision.fallback_reason}
