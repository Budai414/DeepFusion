from __future__ import annotations
from dataclasses import dataclass, field
import hashlib
import json
import math
from typing import Dict, List, Mapping, Optional, Sequence, Tuple
import numpy as np
from real_fusion.models import NormalizedDetection
from real_fusion.tracking.birth import TentativeBirthManager
IDENTITY_FEATURE_SCHEMA_VERSION = 'df-paag.identity-pair.v1'
TRACK_FEATURE_NAMES: Tuple[str, ...] = ('log1p_report_count', 'log1p_duration_s', 'log1p_median_interval_s', 'log1p_median_speed_mps', 'log1p_speed_mad_mps', 'log1p_median_acceleration_mps2', 'median_rcs_scaled', 'log1p_rcs_mad', 'mean_detection_score', 'detection_score_std', 'rcs_missing_fraction')
PAIR_FEATURE_NAMES: Tuple[str, ...] = ('log1p_overlap_duration_s', 'log1p_symmetric_match_count', 'median_abs_time_offset_over_window', 'p90_abs_time_offset_over_window', 'median_position_nis_over_gate', 'p90_position_nis_over_gate', 'median_velocity_nis_over_gate', 'p90_velocity_nis_over_gate', 'minimum_position_distance_over_search_radius', 'hard_gate_pass_fraction', 'log1p_hard_gate_time_bin_count', 'position_stat_missing', 'velocity_stat_missing')
FLAT_FEATURE_NAMES: Tuple[str, ...] = PAIR_FEATURE_NAMES + tuple((f'track_sum__{name}' for name in TRACK_FEATURE_NAMES)) + tuple((f'track_absdiff__{name}' for name in TRACK_FEATURE_NAMES))

def _finite(value: object, default: float=0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return float(default)
    return number if math.isfinite(number) else float(default)

def _safe_log1p(value: object) -> float:
    return float(math.log1p(max(0.0, _finite(value))))

def _median_interval(times: np.ndarray) -> float:
    unique = np.unique(times)
    if len(unique) < 2:
        return 0.0
    return float(np.median(np.diff(unique)))

def _track_features(items: Sequence[NormalizedDetection]) -> np.ndarray:
    ordered = sorted(items, key=lambda item: (item.corrected_time_s, item.detection_id))
    times = np.asarray([item.corrected_time_s for item in ordered], dtype=float)
    velocities = np.asarray([item.state_enu[3:] for item in ordered], dtype=float)
    speeds = np.linalg.norm(velocities, axis=1)
    median_speed = float(np.median(speeds)) if len(speeds) else 0.0
    speed_mad = float(np.median(np.abs(speeds - median_speed))) if len(speeds) else 0.0
    accelerations: List[float] = []
    for index in range(1, len(ordered)):
        delta_t = float(times[index] - times[index - 1])
        if delta_t > 1e-09:
            accelerations.append(float(np.linalg.norm(velocities[index] - velocities[index - 1]) / delta_t))
    rcs_values = np.asarray([float(item.rcs_dbsm) for item in ordered if math.isfinite(float(item.rcs_dbsm))], dtype=float)
    rcs_missing_fraction = 1.0 - float(len(rcs_values) / max(1, len(ordered)))
    if len(rcs_values):
        median_rcs = float(np.median(rcs_values))
        rcs_mad = float(np.median(np.abs(rcs_values - median_rcs)))
    else:
        median_rcs, rcs_mad = (0.0, 0.0)
    scores = np.asarray([_finite(item.score) for item in ordered], dtype=float)
    duration = float(max(0.0, times[-1] - times[0])) if len(times) else 0.0
    values = np.asarray([_safe_log1p(len(ordered)), _safe_log1p(duration), _safe_log1p(_median_interval(times)), _safe_log1p(median_speed), _safe_log1p(speed_mad), _safe_log1p(float(np.median(accelerations)) if accelerations else 0.0), float(np.clip(median_rcs / 50.0, -2.0, 2.0)), _safe_log1p(rcs_mad), float(np.mean(scores)) if len(scores) else 0.0, float(np.std(scores)) if len(scores) else 0.0, rcs_missing_fraction], dtype=float)
    if not np.all(np.isfinite(values)):
        raise ValueError('identity_track_features_non_finite')
    return values

def _aligned_pair_statistics(left: NormalizedDetection, right: NormalizedDetection) -> Tuple[float, float, float]:
    event_time = max(float(left.corrected_time_s), float(right.corrected_time_s))
    left_state, left_covariance = TentativeBirthManager._aligned(left, event_time)
    right_state, right_covariance = TentativeBirthManager._aligned(right, event_time)
    position_difference = left_state[:3] - right_state[:3]
    velocity_difference = left_state[3:] - right_state[3:]
    position_covariance = left_covariance[:3, :3] + right_covariance[:3, :3]
    velocity_covariance = left_covariance[3:, 3:] + right_covariance[3:, 3:]
    try:
        position_nis = float(position_difference @ np.linalg.solve(position_covariance, position_difference))
    except np.linalg.LinAlgError:
        position_nis = float(position_difference @ np.linalg.pinv(position_covariance) @ position_difference)
    try:
        velocity_nis = float(velocity_difference @ np.linalg.solve(velocity_covariance, velocity_difference))
    except np.linalg.LinAlgError:
        velocity_nis = float(velocity_difference @ np.linalg.pinv(velocity_covariance) @ velocity_difference)
    return (float(np.linalg.norm(position_difference)), position_nis, velocity_nis)

def _symmetric_matches(left_items: Sequence[NormalizedDetection], right_items: Sequence[NormalizedDetection], birth_window_s: float) -> List[Tuple[NormalizedDetection, NormalizedDetection]]:
    left = sorted(left_items, key=lambda item: (item.corrected_time_s, item.detection_id))
    right = sorted(right_items, key=lambda item: (item.corrected_time_s, item.detection_id))
    selected: Dict[Tuple[str, str], Tuple[NormalizedDetection, NormalizedDetection]] = {}

    def add_nearest(queries: Sequence[NormalizedDetection], references: Sequence[NormalizedDetection], query_is_left: bool) -> None:
        reference_times = np.asarray([item.corrected_time_s for item in references], dtype=float)
        for query in queries:
            start = int(np.searchsorted(reference_times, query.corrected_time_s - birth_window_s, side='left'))
            stop = int(np.searchsorted(reference_times, query.corrected_time_s + birth_window_s, side='right'))
            candidates = references[start:stop]
            if not candidates:
                continue
            reference = min(candidates, key=lambda item: (abs(float(item.corrected_time_s - query.corrected_time_s)), item.detection_id))
            pair = (query, reference) if query_is_left else (reference, query)
            key = tuple(sorted((pair[0].detection_id, pair[1].detection_id)))
            selected[key] = pair
    add_nearest(left, right, True)
    add_nearest(right, left, False)
    return [selected[key] for key in sorted(selected)]

@dataclass(frozen=True)
class TrackPairExample:
    task_id: str
    left_local_track_key: str
    right_local_track_key: str
    pair_features: Tuple[float, ...]
    left_track_features: Tuple[float, ...]
    right_track_features: Tuple[float, ...]
    hard_physical_gate_passed: bool
    label: Optional[int] = None
    split: Optional[str] = None
    difficulty_tags: Tuple[str, ...] = ()
    metadata: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if len(self.pair_features) != len(PAIR_FEATURE_NAMES):
            raise ValueError('identity_pair_feature_dimension_mismatch')
        if len(self.left_track_features) != len(TRACK_FEATURE_NAMES):
            raise ValueError('identity_left_track_feature_dimension_mismatch')
        if len(self.right_track_features) != len(TRACK_FEATURE_NAMES):
            raise ValueError('identity_right_track_feature_dimension_mismatch')
        values = np.asarray(self.pair_features + self.left_track_features + self.right_track_features, dtype=float)
        if not np.all(np.isfinite(values)):
            raise ValueError('identity_features_non_finite')
        if self.label not in {None, 0, 1}:
            raise ValueError('identity_label_must_be_zero_or_one')
        if self.split not in {None, 'train', 'validation', 'test', 'ood'}:
            raise ValueError('identity_split_invalid')

    @property
    def flat_feature_vector(self) -> Tuple[float, ...]:
        left = np.asarray(self.left_track_features, dtype=float)
        right = np.asarray(self.right_track_features, dtype=float)
        vector = np.concatenate([np.asarray(self.pair_features, dtype=float), left + right, np.abs(left - right)])
        return tuple((float(value) for value in vector))

    @property
    def flat_feature_mapping(self) -> Dict[str, float]:
        return dict(zip(FLAT_FEATURE_NAMES, self.flat_feature_vector))

    @property
    def feature_sha256(self) -> str:
        track_vectors = sorted([list(self.left_track_features), list(self.right_track_features)])
        payload = {'schema': IDENTITY_FEATURE_SCHEMA_VERSION, 'pair': list(self.pair_features), 'tracks': track_vectors}
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        return hashlib.sha256(encoded).hexdigest()

    def swapped(self) -> 'TrackPairExample':
        return TrackPairExample(task_id=self.task_id, left_local_track_key=self.right_local_track_key, right_local_track_key=self.left_local_track_key, pair_features=self.pair_features, left_track_features=self.right_track_features, right_track_features=self.left_track_features, hard_physical_gate_passed=self.hard_physical_gate_passed, label=self.label, split=self.split, difficulty_tags=self.difficulty_tags, metadata=self.metadata)

    def to_record(self) -> Dict[str, object]:
        return {'schema_version': IDENTITY_FEATURE_SCHEMA_VERSION, 'task_id': self.task_id, 'left_local_track_key': self.left_local_track_key, 'right_local_track_key': self.right_local_track_key, 'pair_features': dict(zip(PAIR_FEATURE_NAMES, self.pair_features)), 'left_track_features': dict(zip(TRACK_FEATURE_NAMES, self.left_track_features)), 'right_track_features': dict(zip(TRACK_FEATURE_NAMES, self.right_track_features)), 'flat_features': self.flat_feature_mapping, 'feature_sha256': self.feature_sha256, 'hard_physical_gate_passed': self.hard_physical_gate_passed, 'label': self.label, 'split': self.split, 'difficulty_tags': list(self.difficulty_tags), 'metadata': dict(self.metadata)}

    @classmethod
    def from_record(cls, record: Mapping[str, object]) -> 'TrackPairExample':
        if str(record.get('schema_version')) != IDENTITY_FEATURE_SCHEMA_VERSION:
            raise ValueError('identity_feature_schema_mismatch')

        def ordered(mapping_name: str, names: Tuple[str, ...]) -> Tuple[float, ...]:
            values = record.get(mapping_name)
            if not isinstance(values, Mapping) or set(values) != set(names):
                raise ValueError(f'identity_{mapping_name}_names_mismatch')
            return tuple((float(values[name]) for name in names))
        example = cls(task_id=str(record['task_id']), left_local_track_key=str(record['left_local_track_key']), right_local_track_key=str(record['right_local_track_key']), pair_features=ordered('pair_features', PAIR_FEATURE_NAMES), left_track_features=ordered('left_track_features', TRACK_FEATURE_NAMES), right_track_features=ordered('right_track_features', TRACK_FEATURE_NAMES), hard_physical_gate_passed=bool(record['hard_physical_gate_passed']), label=None if record.get('label') is None else int(record['label']), split=None if record.get('split') is None else str(record['split']), difficulty_tags=tuple((str(value) for value in record.get('difficulty_tags', []))), metadata=dict(record.get('metadata', {})) if isinstance(record.get('metadata', {}), Mapping) else {})
        expected_hash = record.get('feature_sha256')
        if expected_hash is not None and str(expected_hash) != example.feature_sha256:
            raise ValueError('identity_feature_hash_mismatch')
        return example

@dataclass(frozen=True)
class AssociationGraphExample:
    task_id: str
    local_track_keys: Tuple[str, ...]
    edges: Tuple[TrackPairExample, ...]

    def __post_init__(self) -> None:
        known = set(self.local_track_keys)
        if any((edge.left_local_track_key not in known or edge.right_local_track_key not in known for edge in self.edges)):
            raise ValueError('identity_graph_edge_has_unknown_node')

def build_track_pair_example(*, task_id: str, left_local_track_key: str, right_local_track_key: str, left_items: Sequence[NormalizedDetection], right_items: Sequence[NormalizedDetection], tracker_config: Mapping[str, object], identity_config: Mapping[str, object], scenario_config: Mapping[str, object], label: Optional[int]=None, split: Optional[str]=None, difficulty_tags: Sequence[str]=(), metadata: Optional[Mapping[str, object]]=None) -> TrackPairExample:
    if not left_items or not right_items:
        raise ValueError('identity_pair_requires_two_non_empty_tracks')
    birth_window_s = max(1e-09, float(tracker_config['birth_window_s']))
    position_gate_probability = float(identity_config.get('position_gate_probability', tracker_config['birth_gate_probability']))
    velocity_gate_probability = float(identity_config.get('velocity_gate_probability', 0.999))
    velocity_gate_multiplier = float(identity_config.get('velocity_gate_multiplier', 4.0))
    from scipy.stats import chi2
    position_gate = float(chi2.ppf(position_gate_probability, df=3))
    velocity_gate = float(chi2.ppf(velocity_gate_probability, df=3)) * velocity_gate_multiplier
    search_radius = max(1e-09, float(identity_config.get('candidate_search_radius_m', 50000.0)))
    matches = _symmetric_matches(left_items, right_items, birth_window_s)
    time_offsets: List[float] = []
    distances: List[float] = []
    position_nis_values: List[float] = []
    velocity_nis_values: List[float] = []
    hard_passes = 0
    hard_bins = set()
    base_epoch = float(scenario_config['base_epoch_s'])
    window_s = max(1e-09, float(scenario_config['window_s']))
    for left, right in matches:
        time_offsets.append(abs(float(left.corrected_time_s - right.corrected_time_s)))
        distance, position_nis, velocity_nis = _aligned_pair_statistics(left, right)
        distances.append(distance)
        position_nis_values.append(position_nis)
        velocity_nis_values.append(velocity_nis)
        if position_nis <= position_gate and velocity_nis <= velocity_gate:
            hard_passes += 1
            event_time = max(float(left.corrected_time_s), float(right.corrected_time_s))
            hard_bins.add(max(0, int((event_time - base_epoch) // window_s)))
    left_times = np.asarray([item.corrected_time_s for item in left_items], dtype=float)
    right_times = np.asarray([item.corrected_time_s for item in right_items], dtype=float)
    overlap = max(0.0, min(float(np.max(left_times)), float(np.max(right_times))) - max(float(np.min(left_times)), float(np.min(right_times))))

    def percentile(values: Sequence[float], quantile: float, default: float=0.0) -> float:
        return float(np.percentile(values, quantile)) if values else float(default)
    position_missing = float(not position_nis_values)
    velocity_missing = float(not velocity_nis_values)
    pair_values = np.asarray([_safe_log1p(overlap), _safe_log1p(len(matches)), float(np.clip(percentile(time_offsets, 50.0) / birth_window_s, 0.0, 10.0)), float(np.clip(percentile(time_offsets, 90.0) / birth_window_s, 0.0, 10.0)), float(np.clip(percentile(position_nis_values, 50.0) / position_gate, 0.0, 20.0)), float(np.clip(percentile(position_nis_values, 90.0) / position_gate, 0.0, 20.0)), float(np.clip(percentile(velocity_nis_values, 50.0) / velocity_gate, 0.0, 20.0)), float(np.clip(percentile(velocity_nis_values, 90.0) / velocity_gate, 0.0, 20.0)), float(np.clip((min(distances) if distances else search_radius) / search_radius, 0.0, 20.0)), float(hard_passes / max(1, len(matches))), _safe_log1p(len(hard_bins)), position_missing, velocity_missing], dtype=float)
    if not np.all(np.isfinite(pair_values)):
        raise ValueError('identity_pair_features_non_finite')
    return TrackPairExample(task_id=str(task_id), left_local_track_key=str(left_local_track_key), right_local_track_key=str(right_local_track_key), pair_features=tuple((float(value) for value in pair_values)), left_track_features=tuple((float(value) for value in _track_features(left_items))), right_track_features=tuple((float(value) for value in _track_features(right_items))), hard_physical_gate_passed=bool(hard_passes), label=label, split=split, difficulty_tags=tuple(sorted({str(value) for value in difficulty_tags})), metadata=dict(metadata or {}))
