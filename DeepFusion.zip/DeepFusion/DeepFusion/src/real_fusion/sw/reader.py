from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence
import numpy as np
import pandas as pd
REQUIRED_COLUMNS = ('MBY', 'ZBB', 'MBJ', 'MBW', 'HB', 'JDSC')
NUMERIC_CORE_TO_INTERNAL = {'MBJ': '_mbj', 'MBW': '_mbw', 'HB': '_mbg'}
SUPPORTED_EXTENSIONS = {'.xls', '.xlsx', '.xlsm'}

@dataclass(frozen=True)
class SwReadResult:
    path: Path
    frame: pd.DataFrame
    total_rows: int
    valid_rows: int
    rejected_rows: int
    rejected_examples: List[Dict[str, object]]
    device_values: List[str]
    target_values: List[str] = field(default_factory=list)
    input_columns: List[str] = field(default_factory=list)
    expected_columns: List[str] = field(default_factory=list)
    schema_missing_columns: List[str] = field(default_factory=list)
    schema_extra_columns: List[str] = field(default_factory=list)
    header_order_matches: bool = True
    schema_validation_mode: str = 'required_columns'
    input_config_path: Optional[Path] = None
    schema_name: Optional[str] = None
    source_paths: List[Path] = field(default_factory=list)
    file_summaries: List[Dict[str, object]] = field(default_factory=list)
    quality_valid_rows: int = 0
    time_filtered_rows: int = 0
    time_range_start: Optional[str] = None
    time_range_end: Optional[str] = None

def parse_time_range(start_time: object=None, end_time: object=None, timezone_name: str='Asia/Shanghai') -> tuple[Optional[pd.Timestamp], Optional[pd.Timestamp]]:

    def parse_one(value: object, label: str) -> Optional[pd.Timestamp]:
        if value is None or (isinstance(value, str) and (not value.strip())):
            return None
        try:
            timestamp = pd.Timestamp(value)
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError(f'{label}无法解析：{value!r}。请使用与绝对时戳列相同的格式，例如 2026-08-13 12:00:00.000000。') from error
        if pd.isna(timestamp):
            raise ValueError(f'{label}不能为空时间。')
        if timestamp.tzinfo is not None:
            timestamp = timestamp.tz_convert(timezone_name).tz_localize(None)
        return timestamp
    start = parse_one(start_time, '开始绝对时戳')
    end = parse_one(end_time, '结束绝对时戳')
    if start is not None and end is not None and (start > end):
        raise ValueError('开始绝对时戳不能晚于结束绝对时戳。')
    return (start, end)

def normalize_zbb(value: Any) -> str:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return ''
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return ''
        try:
            number = float(text)
        except ValueError:
            return text
    else:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return str(value).strip()
    if np.isfinite(number) and number.is_integer():
        return str(int(number))
    return format(number, '.15g') if np.isfinite(number) else ''

def _read_excel(path: Path, sw_config: dict) -> pd.DataFrame:
    extension = path.suffix.lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise ValueError(f'SW 输入只支持 .xls/.xlsx/.xlsm，实际为: {path.suffix}')
    engine = 'xlrd' if extension == '.xls' else 'openpyxl'
    return pd.read_excel(path, sheet_name=sw_config.get('sheet_name', 0), header=int(sw_config.get('header_row', 1)) - 1, engine=engine, dtype=object)

def _normalize_headers(frame: pd.DataFrame, sw_config: dict) -> pd.DataFrame:
    trim = bool(sw_config.get('trim_header_whitespace', True))

    def clean(value: object) -> str:
        text = str(value)
        return text.strip() if trim else text
    normalized = frame.copy()
    normalized.columns = [clean(column) for column in normalized.columns]
    aliases = {clean(key): clean(value) for (key, value) in sw_config.get('header_aliases', {}).items()}
    if aliases:
        normalized = normalized.rename(columns=aliases)
    duplicate_columns = normalized.columns[normalized.columns.duplicated()].tolist()
    if duplicate_columns:
        raise ValueError(f'SW 表头清理/别名映射后出现重复列: {duplicate_columns}')
    return normalized

def _schema_diagnostics(frame: pd.DataFrame, source: Path, sw_config: dict) -> Dict[str, object]:
    actual = [str(column) for column in frame.columns]
    expected = [str(column) for column in sw_config.get('expected_columns', [])]
    validation_mode = str(sw_config.get('schema_validation', 'required_columns')).lower()
    missing = [column for column in expected if column not in actual]
    extra = [column for column in actual if column not in expected] if expected else []
    order_matches = not expected or actual == expected
    allow_extra = bool(sw_config.get('allow_extra_columns', False))
    require_order = bool(sw_config.get('require_exact_header_order', False))
    schema_violation = bool(expected and (missing or (extra and (not allow_extra)) or (require_order and (not order_matches))))
    if validation_mode == 'strict' and schema_violation:
        details = [f'期望 {len(expected)} 列，实际 {len(actual)} 列', f'缺少列: {missing}' if missing else '缺少列: 无', f'多余列: {extra}' if extra else '多余列: 无']
        if require_order and (not order_matches):
            details.append('列顺序与统一56列表头不一致')
        raise ValueError(f"SW 文件不符合 {sw_config.get('_schema_name', 'sw')} 完整56列表头定义: " + '；'.join(details) + f'。文件: {source}')
    return {'input_columns': actual, 'expected_columns': expected, 'missing_columns': missing, 'extra_columns': extra, 'order_matches': order_matches, 'validation_mode': validation_mode}

def _resolve_core_columns(frame: pd.DataFrame, sw_config: dict) -> Dict[str, str]:
    core_columns = {role: str(column) for (role, column) in (sw_config.get('_core_columns') or {}).items()}
    if not core_columns:
        core_columns = {column: column for column in (*REQUIRED_COLUMNS, 'RCS')}
    missing = [f'{role}（实际列 {column}）' for (role, column) in core_columns.items() if role in REQUIRED_COLUMNS and column not in frame.columns]
    if missing:
        raise ValueError(f'SW 文件缺少核心字段对应列: {missing}；现有列为 {frame.columns.tolist()}')
    return core_columns

def read_sw_file(path: str | Path, sw_config: dict, start_time: object=None, end_time: object=None) -> SwReadResult:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f'SW 文件不存在: {source}')
    frame = _normalize_headers(_read_excel(source, sw_config), sw_config)
    schema = _schema_diagnostics(frame, source, sw_config)
    core_columns = _resolve_core_columns(frame, sw_config)
    total_rows = len(frame)
    working = frame.copy()
    working['_source_file'] = str(source)
    working['_excel_row'] = np.arange(total_rows, dtype=int) + int(sw_config.get('header_row', 1)) + 1
    working['_mby'] = working[core_columns['MBY']].map(normalize_zbb)
    working['_zbb'] = working[core_columns['ZBB']].map(normalize_zbb)
    for (role, internal_column) in NUMERIC_CORE_TO_INTERNAL.items():
        working[internal_column] = pd.to_numeric(working[core_columns[role]], errors='coerce')
    working['_jdsc'] = pd.to_datetime(working[core_columns['JDSC']], errors='coerce')
    rcs_column = core_columns.get('RCS')
    if rcs_column in working.columns:
        working['_rcs'] = working[rcs_column]
    if getattr(working['_jdsc'].dt, 'tz', None) is not None:
        working['_jdsc'] = working['_jdsc'].dt.tz_localize(None)
    longitude_values = working['_mbj'].to_numpy(dtype=float)
    latitude_values = working['_mbw'].to_numpy(dtype=float)
    altitude_values = working['_mbg'].to_numpy(dtype=float)
    position_validation = sw_config.get('position_validation', {})
    zero_epsilon = float(position_validation.get('zero_epsilon', 1e-09))
    longitude_range = position_validation.get('longitude_range_deg', [-180.0, 180.0])
    latitude_range = position_validation.get('latitude_range_deg', [-90.0, 90.0])
    altitude_range = position_validation.get('altitude_range_m', [-1000.0, 100000.0])
    invalid_mby = working['_mby'].eq('').to_numpy(dtype=bool)
    invalid_zbb = working['_zbb'].eq('').to_numpy(dtype=bool)
    zero_longitude = bool(position_validation.get('reject_zero_longitude', True)) & (np.abs(longitude_values) <= zero_epsilon)
    zero_latitude = bool(position_validation.get('reject_zero_latitude', True)) & (np.abs(latitude_values) <= zero_epsilon)
    zero_altitude = bool(position_validation.get('reject_zero_altitude', True)) & (np.abs(altitude_values) <= zero_epsilon)
    nonfinite_longitude = ~np.isfinite(longitude_values)
    nonfinite_latitude = ~np.isfinite(latitude_values)
    nonfinite_altitude = ~np.isfinite(altitude_values)
    out_of_range_longitude = (longitude_values < float(longitude_range[0])) | (longitude_values > float(longitude_range[1]))
    out_of_range_latitude = (latitude_values < float(latitude_range[0])) | (latitude_values > float(latitude_range[1]))
    out_of_range_altitude = (altitude_values < float(altitude_range[0])) | (altitude_values > float(altitude_range[1]))
    invalid_longitude = nonfinite_longitude | zero_longitude | out_of_range_longitude
    invalid_latitude = nonfinite_latitude | zero_latitude | out_of_range_latitude
    invalid_altitude = nonfinite_altitude | zero_altitude | out_of_range_altitude
    invalid_jdsc = working['_jdsc'].isna().to_numpy(dtype=bool)
    invalid_mask = invalid_mby | invalid_zbb | invalid_longitude | invalid_latitude | invalid_altitude | invalid_jdsc
    valid_mask = ~invalid_mask
    rejected_examples: List[Dict[str, object]] = []
    maximum_examples = int(sw_config.get('max_rejected_examples', 20))
    for position in np.flatnonzero(invalid_mask)[:maximum_examples]:
        row = working.iloc[int(position)]
        row_reasons = []
        if invalid_mby[position]:
            row_reasons.append('目标编号为空或非有限值')
        if invalid_zbb[position]:
            row_reasons.append('装备编号为空或非有限值')
        if invalid_longitude[position]:
            if nonfinite_longitude[position]:
                row_reasons.append('目标经度为空、非数值或无穷')
            elif zero_longitude[position]:
                row_reasons.append('目标经度为0（配置规定无效）')
            else:
                row_reasons.append(f'目标经度超出范围{list(longitude_range)}')
        if invalid_latitude[position]:
            if nonfinite_latitude[position]:
                row_reasons.append('目标纬度为空、非数值或无穷')
            elif zero_latitude[position]:
                row_reasons.append('目标纬度为0（配置规定无效）')
            else:
                row_reasons.append(f'目标纬度超出范围{list(latitude_range)}')
        if invalid_altitude[position]:
            if nonfinite_altitude[position]:
                row_reasons.append('海拔为空、非数值或无穷')
            elif zero_altitude[position]:
                row_reasons.append('海拔为0（配置规定无效）')
            else:
                row_reasons.append(f'海拔超出范围{list(altitude_range)}')
        if invalid_jdsc[position]:
            row_reasons.append('绝对时戳不能解析')
        rejected_examples.append({'source_file': str(source), 'excel_row': int(row['_excel_row']), 'mby': row['_mby'] or None, 'zbb': row['_zbb'] or None, 'reason': '；'.join(row_reasons)})
    valid = working.loc[valid_mask].copy()
    if valid.empty:
        raise ValueError('SW 文件没有任何同时具备目标编号、装备编号、目标经纬度、海拔和绝对时戳的有效行。')
    rejected = total_rows - len(valid)
    if rejected and str(sw_config.get('invalid_row_policy', 'drop')).lower() == 'error':
        raise ValueError(f'SW 文件存在 {rejected} 条非法关键行，示例: {rejected_examples}')
    timezone_name = str(sw_config.get('timezone', 'Asia/Shanghai'))
    (range_start, range_end) = parse_time_range(start_time, end_time, timezone_name)
    quality_valid_rows = len(valid)
    time_mask = np.ones(quality_valid_rows, dtype=bool)
    if range_start is not None:
        time_mask &= valid['_jdsc'].ge(range_start).to_numpy(dtype=bool)
    if range_end is not None:
        time_mask &= valid['_jdsc'].le(range_end).to_numpy(dtype=bool)
    valid = valid.loc[time_mask].copy()
    time_filtered_rows = quality_valid_rows - len(valid)
    valid['_epoch_s'] = valid['_jdsc'].dt.tz_localize(timezone_name).astype('int64') / 1000000000.0
    valid = valid.sort_values(['_jdsc', '_mby', '_zbb', '_excel_row'], kind='stable').reset_index(drop=True)
    target_values = list(dict.fromkeys(valid['_mby'].tolist()))
    device_values = list(dict.fromkeys(valid['_zbb'].tolist()))
    return SwReadResult(path=source, frame=valid, total_rows=total_rows, valid_rows=len(valid), rejected_rows=rejected, rejected_examples=rejected_examples, device_values=device_values, target_values=target_values, input_columns=list(schema['input_columns']), expected_columns=list(schema['expected_columns']), schema_missing_columns=list(schema['missing_columns']), schema_extra_columns=list(schema['extra_columns']), header_order_matches=bool(schema['order_matches']), schema_validation_mode=str(schema['validation_mode']), input_config_path=Path(str(sw_config['_input_config_path'])) if sw_config.get('_input_config_path') else None, schema_name=str(sw_config['_schema_name']) if sw_config.get('_schema_name') else None, source_paths=[source], file_summaries=[{'source_file': source.name, 'source_path': str(source), 'read_rows': total_rows, 'valid_rows': len(valid), 'rejected_rows': rejected, 'quality_valid_rows': quality_valid_rows, 'time_filtered_rows': time_filtered_rows, 'target_count': len(target_values), 'target_values': '、'.join(sorted(target_values)), 'zbb_count': len(device_values), 'zbb_values': '、'.join(sorted(device_values))}], quality_valid_rows=quality_valid_rows, time_filtered_rows=time_filtered_rows, time_range_start=range_start.isoformat(sep=' ') if range_start is not None else None, time_range_end=range_end.isoformat(sep=' ') if range_end is not None else None)

def read_sw_files(paths: Sequence[str | Path], sw_config: dict, start_time: object=None, end_time: object=None) -> List[SwReadResult]:
    unique_paths: List[Path] = []
    seen = set()
    for value in paths:
        resolved = Path(value).expanduser().resolve()
        key = str(resolved).casefold()
        if key not in seen:
            seen.add(key)
            unique_paths.append(resolved)
    if not unique_paths:
        raise ValueError('至少需要选择一个 SW 文件。')
    return [read_sw_file(path, sw_config, start_time=start_time, end_time=end_time) for path in unique_paths]

def combine_sw_read_results(results: Sequence[SwReadResult], max_rejected_examples: int=20) -> SwReadResult:
    items = list(results)
    if not items:
        raise ValueError('至少需要一个已读取的 SW 分卷结果。')
    first = items[0]
    for item in items[1:]:
        if item.input_columns != first.input_columns:
            raise ValueError(f'多个 SW 分卷的实际表头或列顺序不一致，不能作为同一批数据融合：{first.path.name} 与 {item.path.name}。')
        if item.expected_columns != first.expected_columns:
            raise ValueError(f'多个 SW 分卷使用的期望表头定义不一致，不能合并：{first.path.name} 与 {item.path.name}。')
        if item.time_range_start != first.time_range_start or item.time_range_end != first.time_range_end:
            raise ValueError('多个 SW 分卷的绝对时戳过滤区间不一致，不能合并。')
    combined_frame = pd.concat([item.frame for item in items], ignore_index=True, copy=False)
    combined_frame = combined_frame.sort_values(['_jdsc', '_mby', '_zbb', '_source_file', '_excel_row'], kind='stable').reset_index(drop=True)
    if combined_frame.empty:
        start_label = first.time_range_start or '不限制'
        end_label = first.time_range_end or '不限制'
        raise ValueError(f'指定绝对时戳区间内没有可分析的数据：开始={start_label}，结束={end_label}。')
    target_values = list(dict.fromkeys(combined_frame['_mby'].tolist()))
    device_values = list(dict.fromkeys(combined_frame['_zbb'].tolist()))
    rejected_examples = [example for item in items for example in item.rejected_examples][:max(0, int(max_rejected_examples))]
    source_paths = [source_path for item in items for source_path in item.source_paths or [item.path]]
    file_summaries = [summary for item in items for summary in item.file_summaries or [{'source_file': item.path.name, 'source_path': str(item.path), 'read_rows': item.total_rows, 'valid_rows': item.valid_rows, 'rejected_rows': item.rejected_rows, 'quality_valid_rows': item.quality_valid_rows, 'time_filtered_rows': item.time_filtered_rows, 'target_count': len(item.target_values), 'target_values': '、'.join(sorted(item.target_values)), 'zbb_count': len(item.device_values), 'zbb_values': '、'.join(sorted(item.device_values))}]]
    return SwReadResult(path=first.path, frame=combined_frame, total_rows=sum((item.total_rows for item in items)), valid_rows=sum((item.valid_rows for item in items)), rejected_rows=sum((item.rejected_rows for item in items)), rejected_examples=rejected_examples, device_values=device_values, target_values=target_values, input_columns=list(first.input_columns), expected_columns=list(first.expected_columns), schema_missing_columns=list(first.schema_missing_columns), schema_extra_columns=list(first.schema_extra_columns), header_order_matches=all((item.header_order_matches for item in items)), schema_validation_mode=first.schema_validation_mode, input_config_path=first.input_config_path, schema_name=first.schema_name, source_paths=source_paths, file_summaries=file_summaries, quality_valid_rows=sum((item.quality_valid_rows for item in items)), time_filtered_rows=sum((item.time_filtered_rows for item in items)), time_range_start=first.time_range_start, time_range_end=first.time_range_end)

def read_and_combine_sw_files(paths: Sequence[str | Path], sw_config: dict, start_time: object=None, end_time: object=None) -> SwReadResult:
    results = read_sw_files(paths, sw_config, start_time=start_time, end_time=end_time)
    return combine_sw_read_results(results, max_rejected_examples=int(sw_config.get('max_rejected_examples', 20)))
