from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Mapping
import numpy as np
from real_fusion.geometry import GeodeticConverter
from real_fusion.models import RawDetection
from real_fusion.sw.reader import SwReadResult
from real_fusion.tracking.ukf import ensure_positive_definite

@dataclass(frozen=True)
class SourceTrackSummary:
    sensor_id: str
    target_id: str
    zbb: str
    source_track_id: str
    input_rows: int
    output_reports: int
    duplicate_timestamp_rows: int
    median_interval_s: float
    mean_interval_s: float
    min_interval_s: float
    max_interval_s: float
    estimated_frequency_hz: float
    local_target_id: str = ''
    local_track_key: str = ''

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

@dataclass(frozen=True)
class SparseGroupSummary:
    classification: str
    target_id: str
    local_target_id: str
    local_track_key: str
    sensor_id: str
    zbb: str
    input_rows: int
    unique_timestamp_count: int
    duplicate_timestamp_rows: int
    minimum_required_points: int
    reason: str

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

@dataclass(frozen=True)
class FalseAlarmRecord:
    classification: str
    reason: str
    target_id: str
    local_target_id: str
    local_track_key: str
    sensor_id: str
    zbb: str
    group_input_rows: int
    group_unique_timestamp_count: int
    minimum_required_points: int
    measurement_time: str
    longitude_deg: float
    latitude_deg: float
    altitude_m: float
    rcs_dbsm: object
    source_file: str
    source_excel_row: int

    def to_record(self) -> Dict[str, object]:
        return dict(self.__dict__)

@dataclass(frozen=True)
class SourceTrackBuildResult:
    detections: List[RawDetection]
    summaries: List[SourceTrackSummary]
    sensors: Dict[str, dict]
    source_track_ids: Dict[str, str]
    sparse_groups: List[SparseGroupSummary] = field(default_factory=list)
    false_alarm_records: List[FalseAlarmRecord] = field(default_factory=list)

def _device_config(zbb: str, config: dict) -> dict:
    default = dict(config['sw']['default_device'])
    override = dict(config.get('sensors', {}).get(zbb, {}))
    default.update(override)
    return default

def _sensor_id(index: int, zbb: str, config: dict) -> str:
    configured = config.get('sensors', {}).get(zbb, {}).get('sensor_id')
    return str(configured or f'ZBB_{index + 1:02d}')

def _fit_position_velocity(positions: np.ndarray, times: np.ndarray, window: int) -> tuple[np.ndarray, np.ndarray]:
    count = len(positions)
    if count < 2:
        return (positions.copy(), np.zeros_like(positions))
    width = max(2, min(int(window), count))
    fitted = np.empty_like(positions)
    velocities = np.empty_like(positions)
    for index in range(count):
        candidate_start = max(0, index - width)
        candidate_end = min(count, index + width + 1)
        candidates = np.arange(candidate_start, candidate_end)
        nearest = candidates[np.argsort(np.abs(times[candidates] - times[index]), kind='stable')[:width]]
        nearest = np.sort(nearest)
        tau = times[nearest] - times[index]
        degree = min(2, len(nearest) - 1)
        design = np.column_stack([tau ** power for power in range(degree + 1)])
        scale = max(float(np.max(np.abs(tau))), 1e-06)
        weights = np.exp(-np.square(tau / scale))
        weighted_design = design * np.sqrt(weights)[:, None]
        weighted_positions = positions[nearest] * np.sqrt(weights)[:, None]
        (coefficients, _, _, _) = np.linalg.lstsq(weighted_design, weighted_positions, rcond=None)
        fitted[index] = coefficients[0]
        velocities[index] = coefficients[1] if degree >= 1 else 0.0
    return (fitted, velocities)

def _velocity_covariance(position_covariance: np.ndarray, intervals: np.ndarray, device: Mapping[str, object]) -> np.ndarray:
    floor = np.asarray(device['velocity_std_floor_enu_mps'], dtype=float)
    scale = np.asarray(device.get('velocity_covariance_scale', [1.0, 1.0, 1.0]), dtype=float)
    position_variance = np.diag(position_covariance)
    dt = np.maximum(np.asarray(intervals, dtype=float), 0.001)
    variance = 2.0 * position_variance[None, :] / np.square(dt[:, None])
    variance = np.maximum(variance * np.square(scale)[None, :], np.square(floor)[None, :])
    result = np.zeros((len(intervals), 3, 3), dtype=float)
    result[:, np.arange(3), np.arange(3)] = variance
    return result

def build_source_tracks(read_result: SwReadResult, config: dict, converter: GeodeticConverter) -> SourceTrackBuildResult:
    detections: List[RawDetection] = []
    summaries: List[SourceTrackSummary] = []
    sensors: Dict[str, dict] = {}
    source_track_ids: Dict[str, str] = {}
    global_index = 0
    zbb_order = sorted(read_result.device_values)
    target_order = sorted(read_result.target_values)
    sensor_ids_by_zbb: Dict[str, str] = {}
    devices_by_zbb: Dict[str, dict] = {}
    intervals_by_sensor: Dict[str, List[float]] = {}
    pending_sparse_groups = []
    minimum_points = int(config['sw'].get('minimum_points_per_device', 3))
    for (device_index, zbb) in enumerate(zbb_order):
        sensor_id = _sensor_id(device_index, zbb, config)
        if sensor_id in sensors:
            raise ValueError(f'多个 ZBB 映射为相同 sensor_id: {sensor_id}')
        device = _device_config(zbb, config)
        device['zbb'] = zbb
        sensor_ids_by_zbb[zbb] = sensor_id
        devices_by_zbb[zbb] = device
        intervals_by_sensor[sensor_id] = []
        sensors[sensor_id] = {'kind': 'sw_source_track', 'zbb': zbb, 'label': str(device.get('label') or f'装备编号={zbb}'), 'sample_period_s': 0.0, 'allowed_lateness_s': float(device['allowed_lateness_s']), 'detection_probability': float(device['detection_probability']), 'configured_position_bias_enu_m': list(device.get('configured_position_bias_enu_m', [0.0, 0.0, 0.0])), 'configured_velocity_bias_enu_mps': list(device.get('configured_velocity_bias_enu_mps', [0.0, 0.0, 0.0])), 'configured_time_correction_s': float(device.get('configured_time_correction_s', 0.0))}
    target_group_indices = read_result.frame.groupby('_mby', sort=False).groups
    for (target_index, target_id) in enumerate(target_order):
        target_frame = read_result.frame.loc[target_group_indices[target_id]]
        target_zbb_values = sorted(set(target_frame['_zbb'].tolist()))
        target_zbb_group_indices = target_frame.groupby('_zbb', sort=False).groups
        for zbb in target_zbb_values:
            sensor_id = sensor_ids_by_zbb[zbb]
            device = devices_by_zbb[zbb]
            original_group = target_frame.loc[target_zbb_group_indices[zbb]].copy()
            original_group = original_group.sort_values(['_jdsc', '_source_file', '_excel_row'], kind='stable')
            input_rows = len(original_group)
            duplicate_timestamp_rows = int(original_group.duplicated('_jdsc', keep='last').sum())
            group = original_group.drop_duplicates('_jdsc', keep='last')
            if len(group) < minimum_points:
                source_prefix = str(device.get('source_track_id') or f'SW-{zbb}')
                pending_sparse_groups.append({'target_id': target_id, 'zbb': zbb, 'sensor_id': sensor_id, 'input_rows': input_rows, 'unique_timestamp_count': len(group), 'duplicate_timestamp_rows': duplicate_timestamp_rows, 'local_track_key': f'{source_prefix}-MBY-{target_id}', 'rows': original_group})
                continue
            epoch_times = group['_epoch_s'].to_numpy(dtype=float)
            relative_times = epoch_times - epoch_times[0]
            intervals = np.diff(epoch_times)
            if np.any(intervals <= 0.0):
                raise ValueError(f'目标编号={target_id}、装备编号={zbb} 去重后绝对时戳仍不是严格递增。')
            intervals_by_sensor[sensor_id].extend(intervals.tolist())
            positions = converter.geodetic_many_to_enu(group['_mbj'].to_numpy(dtype=float), group['_mbw'].to_numpy(dtype=float), group['_mbg'].to_numpy(dtype=float))
            fit_window = int(device.get('source_fit_window_points', 5))
            (fitted_positions, velocities) = _fit_position_velocity(positions, relative_times, fit_window)
            reported_velocity_columns = ['_reported_velocity_east_mps', '_reported_velocity_north_mps', '_reported_velocity_up_mps']
            if all((column in group for column in reported_velocity_columns)):
                reported_velocities = group[reported_velocity_columns].to_numpy(dtype=float)
                valid_reported = np.isfinite(reported_velocities).all(axis=1)
                velocities[valid_reported] = reported_velocities[valid_reported]
            position_std = np.asarray(device['position_std_enu_m'], dtype=float)
            position_covariance = ensure_positive_definite(np.diag(np.square(position_std)))
            local_intervals = np.empty(len(epoch_times), dtype=float)
            local_intervals[0] = intervals[0]
            local_intervals[-1] = intervals[-1]
            if len(epoch_times) > 2:
                local_intervals[1:-1] = 0.5 * (intervals[:-1] + intervals[1:])
            velocity_covariances = _velocity_covariance(position_covariance, local_intervals, device)
            fitted_geodetic = converter.enu_many_to_geodetic(fitted_positions)
            source_prefix = str(device.get('source_track_id') or f'SW-{zbb}')
            source_track_id = f'{source_prefix}-MBY-{target_id}'
            source_track_ids[f'{target_id}|{sensor_id}'] = source_track_id
            rcs_column = group['_rcs'] if '_rcs' in group else None
            for (row_index, ((_, row), epoch_time, velocity, velocity_covariance)) in enumerate(zip(group.iterrows(), epoch_times, velocities, velocity_covariances)):
                rcs = float(device.get('default_rcs_dbsm', -8.0))
                if rcs_column is not None:
                    try:
                        candidate_rcs = float(row['_rcs'])
                        if np.isfinite(candidate_rcs):
                            rcs = candidate_rcs
                    except (TypeError, ValueError):
                        pass
                global_index += 1
                detection_id = f'SWD{global_index:08d}'
                frame_id = f'T{target_index + 1:03d}-{sensor_id}-F{row_index:06d}'
                arrival_delay = max(0.0, float(device.get('replay_arrival_delay_s', 0.0)))
                stream_arrival = row.get('_arrival_epoch_s', np.nan)
                arrival_time = float(epoch_time + arrival_delay)
                try:
                    if np.isfinite(float(stream_arrival)):
                        arrival_time = float(stream_arrival)
                except (TypeError, ValueError):
                    pass
                (longitude, latitude, altitude) = fitted_geodetic[row_index]
                detections.append(RawDetection(detection_id=detection_id, frame_id=frame_id, sensor_id=sensor_id, target_id=target_id, source_track_id=source_track_id, measurement_time_s=float(epoch_time), arrival_time_s=arrival_time, longitude_deg=longitude, latitude_deg=latitude, altitude_m=altitude, velocity_enu=np.asarray(velocity, dtype=float), position_cov_enu=position_covariance.copy(), velocity_cov_enu=ensure_positive_definite(velocity_covariance), score=float(device.get('score', 0.9)), rcs_dbsm=rcs, local_target_id=target_id, local_track_key=source_track_id, source_file=str(row.get('_source_file', read_result.path)), source_excel_row=int(row['_excel_row'])))
            summaries.append(SourceTrackSummary(sensor_id=sensor_id, target_id=target_id, zbb=zbb, source_track_id=source_track_id, input_rows=input_rows, output_reports=len(group), duplicate_timestamp_rows=duplicate_timestamp_rows, median_interval_s=float(np.median(intervals)), mean_interval_s=float(np.mean(intervals)), min_interval_s=float(np.min(intervals)), max_interval_s=float(np.max(intervals)), estimated_frequency_hz=float(1.0 / np.median(intervals)), local_target_id=target_id, local_track_key=source_track_id))
    for (sensor_id, intervals) in intervals_by_sensor.items():
        if intervals:
            sensors[sensor_id]['sample_period_s'] = float(np.median(intervals))
    sparse_groups: List[SparseGroupSummary] = []
    false_alarm_records: List[FalseAlarmRecord] = []
    for pending in pending_sparse_groups:
        target_id = str(pending['target_id'])
        zbb = str(pending['zbb'])
        sensor_id = str(pending['sensor_id'])
        unique_count = int(pending['unique_timestamp_count'])
        classification = 'unformed_local_track'
        local_track_key = str(pending['local_track_key'])
        display_target_id = f'LOCAL-{zbb}-MBY-{target_id}'
        reason = f'装备={zbb}内部批号={target_id}仅有{unique_count}个唯一时戳，少于成轨阈值{minimum_points}，不能形成装备局部航迹，列为虚警候选。'
        sparse_groups.append(SparseGroupSummary(classification=classification, target_id=display_target_id, local_target_id=target_id, local_track_key=local_track_key, sensor_id=sensor_id, zbb=zbb, input_rows=int(pending['input_rows']), unique_timestamp_count=unique_count, duplicate_timestamp_rows=int(pending['duplicate_timestamp_rows']), minimum_required_points=minimum_points, reason=reason))
        for (_, row) in pending['rows'].iterrows():
            false_alarm_records.append(FalseAlarmRecord(classification=classification, reason=reason, target_id=display_target_id, local_target_id=target_id, local_track_key=local_track_key, sensor_id=sensor_id, zbb=zbb, group_input_rows=int(pending['input_rows']), group_unique_timestamp_count=unique_count, minimum_required_points=minimum_points, measurement_time=row['_jdsc'].isoformat(sep=' '), longitude_deg=float(row['_mbj']), latitude_deg=float(row['_mbw']), altitude_m=float(row['_mbg']), rcs_dbsm=row.get('_rcs'), source_file=str(row.get('_source_file', read_result.path)), source_excel_row=int(row['_excel_row'])))
    return SourceTrackBuildResult(detections=sorted(detections, key=lambda item: (item.arrival_time_s, item.target_id, item.sensor_id, item.frame_id)), summaries=summaries, sensors=sensors, source_track_ids=source_track_ids, sparse_groups=sparse_groups, false_alarm_records=false_alarm_records)
