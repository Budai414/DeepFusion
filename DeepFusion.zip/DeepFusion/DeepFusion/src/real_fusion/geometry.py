from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Tuple
import numpy as np
from pyproj import Transformer

@dataclass
class GeodeticConverter:
    longitude_deg: float
    latitude_deg: float
    altitude_m: float

    def __post_init__(self) -> None:
        self._to_ecef = Transformer.from_crs('EPSG:4979', 'EPSG:4978', always_xy=True)
        self._to_geodetic = Transformer.from_crs('EPSG:4978', 'EPSG:4979', always_xy=True)
        self._origin_ecef = np.asarray(self._to_ecef.transform(self.longitude_deg, self.latitude_deg, self.altitude_m), dtype=float)
        lon = np.deg2rad(self.longitude_deg)
        lat = np.deg2rad(self.latitude_deg)
        self._ecef_to_enu = np.asarray([[-np.sin(lon), np.cos(lon), 0.0], [-np.sin(lat) * np.cos(lon), -np.sin(lat) * np.sin(lon), np.cos(lat)], [np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)]], dtype=float)

    def geodetic_to_enu(self, longitude_deg: float, latitude_deg: float, altitude_m: float) -> np.ndarray:
        ecef = np.asarray(self._to_ecef.transform(longitude_deg, latitude_deg, altitude_m), dtype=float)
        return self._ecef_to_enu @ (ecef - self._origin_ecef)

    def geodetic_many_to_enu(self, longitude_deg: Iterable[float], latitude_deg: Iterable[float], altitude_m: Iterable[float]) -> np.ndarray:
        (x, y, z) = self._to_ecef.transform(longitude_deg, latitude_deg, altitude_m)
        ecef = np.column_stack((x, y, z)).astype(float, copy=False)
        return (ecef - self._origin_ecef) @ self._ecef_to_enu.T

    def enu_to_geodetic(self, enu: Iterable[float]) -> Tuple[float, float, float]:
        enu_array = np.asarray(enu, dtype=float)
        ecef = self._origin_ecef + self._ecef_to_enu.T @ enu_array
        (longitude, latitude, altitude) = self._to_geodetic.transform(*ecef)
        return (float(longitude), float(latitude), float(altitude))

    def enu_many_to_geodetic(self, enu: Iterable[Iterable[float]]) -> np.ndarray:
        enu_array = np.asarray(enu, dtype=float)
        if enu_array.ndim != 2 or enu_array.shape[1] != 3:
            raise ValueError('批量 ENU 输入必须是 N×3 数组。')
        ecef = self._origin_ecef + enu_array @ self._ecef_to_enu
        (longitude, latitude, altitude) = self._to_geodetic.transform(ecef[:, 0], ecef[:, 1], ecef[:, 2])
        return np.column_stack((longitude, latitude, altitude)).astype(float, copy=False)
