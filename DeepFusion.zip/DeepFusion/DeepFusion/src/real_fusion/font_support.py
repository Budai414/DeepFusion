from __future__ import annotations
from pathlib import Path
from typing import Iterable
from real_fusion.runtime_paths import deepfusion_project_root
PROJECT_ROOT = deepfusion_project_root(__file__)
BUNDLED_FONT_ROOT = PROJECT_ROOT / 'offline_web_assets' / 'fonts'
REGULAR_FONT_PATH = BUNDLED_FONT_ROOT / 'NotoSansCJKsc-Regular.otf'
BOLD_FONT_PATH = BUNDLED_FONT_ROOT / 'NotoSansCJKsc-Bold.otf'
FONT_FAMILY_CANDIDATES = ('Noto Sans CJK SC', 'Noto Sans SC', 'Microsoft YaHei UI', 'Microsoft YaHei', 'SimHei', 'WenQuanYi Micro Hei', 'Arial Unicode MS', 'DejaVu Sans')

def bundled_font_files() -> tuple[Path, ...]:
    return tuple((path for path in (REGULAR_FONT_PATH, BOLD_FONT_PATH) if path.is_file()))

def configure_matplotlib_fonts() -> str:
    import matplotlib
    from matplotlib import font_manager
    registered_names: list[str] = []
    for path in bundled_font_files():
        try:
            font_manager.fontManager.addfont(str(path))
            name = font_manager.FontProperties(fname=str(path)).get_name()
            if name and name not in registered_names:
                registered_names.append(name)
        except (OSError, RuntimeError, ValueError):
            continue
    family = registered_names[0] if registered_names else FONT_FAMILY_CANDIDATES[0]
    fallbacks = [family, *FONT_FAMILY_CANDIDATES]
    matplotlib.rcParams['font.family'] = 'sans-serif'
    matplotlib.rcParams['font.sans-serif'] = list(dict.fromkeys(fallbacks))
    matplotlib.rcParams['font.weight'] = 'normal'
    matplotlib.rcParams['axes.unicode_minus'] = False
    return family

def _first_available(candidates: Iterable[str], available: set[str], fallback: str) -> str:
    by_casefold = {name.casefold(): name for name in available}
    for candidate in candidates:
        actual = by_casefold.get(candidate.casefold())
        if actual:
            return actual
    return fallback

def configure_tk_fonts(root: object) -> tuple[str, str]:
    import tkinter.font as tkfont
    available = set(tkfont.families(root))
    try:
        default_sans = str(tkfont.nametofont('TkDefaultFont', root=root).actual('family'))
    except Exception:
        default_sans = 'DejaVu Sans'
    try:
        default_mono = str(tkfont.nametofont('TkFixedFont', root=root).actual('family'))
    except Exception:
        default_mono = default_sans
    sans = _first_available(FONT_FAMILY_CANDIDATES, available, default_sans)
    mono = _first_available(('Noto Sans Mono CJK SC', 'Sarasa Mono SC', 'WenQuanYi Zen Hei Mono', 'Microsoft YaHei UI', 'Noto Sans CJK SC', 'DejaVu Sans Mono'), available, default_mono)
    for name in ('TkDefaultFont', 'TkTextFont', 'TkMenuFont', 'TkCaptionFont', 'TkSmallCaptionFont', 'TkIconFont', 'TkTooltipFont'):
        try:
            tkfont.nametofont(name, root=root).configure(family=sans, weight='normal')
        except Exception:
            continue
    try:
        tkfont.nametofont('TkHeadingFont', root=root).configure(family=sans, weight='bold')
    except Exception:
        pass
    try:
        tkfont.nametofont('TkFixedFont', root=root).configure(family=mono, weight='normal')
    except Exception:
        pass
    return (sans, mono)
