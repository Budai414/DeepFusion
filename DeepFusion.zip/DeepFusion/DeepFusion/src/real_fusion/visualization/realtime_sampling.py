from __future__ import annotations
import copy
from bisect import bisect_right

def segment_numbers(item: dict, count: int) -> list[int]:
    starts = sorted({0} | {int(value) for value in item.get('visualSegmentStarts', []) if 0 <= int(value) < count})
    return [bisect_right(starts, index) - 1 for index in range(count)]

def set_segments(item: dict, values: list, tokens: list, time_getter) -> None:
    starts = [index for index in range(len(values)) if index == 0 or tokens[index] != tokens[index - 1]]
    item['visualSegmentStarts'] = starts
    item['visualSegmentCount'] = len(starts)
    item['visualSegmentSpans'] = [[float(time_getter(values[start])), float(time_getter(values[stop - 1]))] for (start, stop) in zip(starts, starts[1:] + [len(values)])]

def sample_visual_item(item: dict, values_key: str, maximum: int, time_getter) -> None:
    values = item.get(values_key, [])
    maximum = max(0, int(maximum))
    item.setdefault('visualInputPointCount', len(values))
    if len(values) <= maximum:
        return
    numbers = segment_numbers(item, len(values))
    groups = []
    for (index, number) in enumerate(numbers):
        if not groups or groups[-1][0] != number:
            groups.append((number, []))
        groups[-1][1].append(index)
    retained = groups[-maximum:] if maximum else []
    allocations = [1] * len(retained)
    available = maximum - len(retained)
    for index in range(len(retained) - 1, -1, -1):
        if available and len(retained[index][1]) > 1:
            allocations[index] += 1
            available -= 1
    while available:
        capacities = [len(group[1]) - allocation for (group, allocation) in zip(retained, allocations)]
        total = sum(capacities)
        if not total:
            break
        before = available
        for (index, capacity) in enumerate(capacities):
            if not capacity:
                continue
            extra = min(capacity, available, max(1, before * capacity // total))
            allocations[index] += extra
            available -= extra
            if not available:
                break
    indices = []
    for ((_, group), count) in zip(retained, allocations):
        if count == 1:
            indices.append(group[-1])
        else:
            indices.extend((group[round(i * (len(group) - 1) / (count - 1))] for i in range(count)))
    old_spans = copy.deepcopy(item.get('visualSegmentSpans', []))
    item[values_key] = [values[index] for index in indices]
    set_segments(item, item[values_key], [numbers[index] for index in indices], time_getter)
    if old_spans:
        item['visualSegmentSpans'] = [old_spans[number] for (number, _) in retained]
    item['visualOmittedPointCount'] = len(values) - len(indices)
    item['visualOmittedSegmentCount'] = len(groups) - len(retained)

def merge_visual_values(old: dict, new: dict, values_key: str, time_getter, boundary_is_break) -> dict:
    result = copy.deepcopy(new)
    incoming = new.get(values_key, [])
    if not incoming:
        return copy.deepcopy(old)
    first = float(time_getter(incoming[0]))
    history = old.get(values_key, [])
    old_numbers = segment_numbers(old, len(history))
    prefix_indices = [i for (i, value) in enumerate(history) if float(time_getter(value)) < first]
    prefix = [history[i] for i in prefix_indices]
    tokens = [('old', old_numbers[i]) for i in prefix_indices]
    new_numbers = segment_numbers(new, len(incoming))
    incoming_tokens = [('new', number) for number in new_numbers]
    if prefix:
        spans = old.get('visualSegmentSpans', [])
        number = old_numbers[prefix_indices[-1]]
        covered = number < len(spans) and spans[number][0] <= first <= spans[number][1]
        last_prefix_time = float(time_getter(prefix[-1]))
        known_boundary = any((0 < int(index) < len(history) and last_prefix_time < float(time_getter(history[int(index)])) <= first for index in old.get('visualSegmentStarts', [])))
        if not known_boundary and (not new.get('continuityBreakBefore')) and (not boundary_is_break(prefix[-1], incoming[0], covered)):
            incoming_tokens = [tokens[-1] if number == 0 else ('new', number) for number in new_numbers]
    combined = copy.deepcopy(prefix + list(incoming))
    result[values_key] = combined
    set_segments(result, combined, tokens + incoming_tokens, time_getter)
    return result

def sample_realtime_data(data: dict, source_limit: int, track_limit: int, total_source: int, total_tracks: int, ray_limit: int) -> dict:
    result = copy.deepcopy(data)
    for (keys, field, per_item, total) in ((('sourceSeries',), 'positions', source_limit, total_source), (('swTracks', 'jointTracks'), 'states', track_limit, total_tracks)):
        items = [item for key in keys for item in result.get(key, [])]
        count = len(items)
        for (index, item) in enumerate(items):
            limit = min(per_item, total // max(1, count) + int(index < total % max(1, count)))
            getter = (lambda value: value[0]) if field == 'positions' else lambda value: value['position'][0]
            sample_visual_item(item, field, limit, getter)
            item['displayedPointCount' if field == 'positions' else 'displayedStateCount'] = len(item.get(field, []))
        for key in keys:
            result[key] = [item for item in result.get(key, []) if item.get(field)]
    result['ewRays'] = result.get('ewRays', [])[-max(1, ray_limit):]
    sampling = result.setdefault('displaySampling', {})
    for (key, field, prefix) in (('sourceSeries', 'positions', 'source'), ('swTracks', 'states', 'sw'), ('jointTracks', 'states', 'joint')):
        count_name = 'Points' if field == 'positions' else 'States'
        sampling[prefix + 'Displayed' + count_name] = sum((len(x[field]) for x in result[key]))
    sampling['ewDisplayedRays'] = len(result['ewRays'])
    result.setdefault('visualContinuity', {})['breakCount'] = sum((max(0, len(item.get('visualSegmentStarts', [])) - 1) for key in ('sourceSeries', 'swTracks', 'jointTracks') for item in result[key]))
    return result
