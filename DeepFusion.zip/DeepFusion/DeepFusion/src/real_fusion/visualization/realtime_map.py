from __future__ import annotations
import copy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import mimetypes
from pathlib import Path
import threading
import time
from typing import Callable, Dict, Optional
from urllib.parse import parse_qs, urlsplit
from uuid import uuid4
import webbrowser
from real_fusion.realtime.service import RealtimeSnapshot
from real_fusion.visualization.cesium_player import CESIUM_VERSION, _cesium_root, _font_root, _safe_static_path, build_cesium_player_payload
from real_fusion.visualization.realtime_identity import RealtimeDisplayIdentity, TERMINAL_STATES
from real_fusion.visualization.realtime_sampling import merge_visual_values, sample_realtime_data, set_segments

def _latest_source_time(series: dict) -> float:
    return max((float(point[0]) for point in series.get('positions', [])), default=float('-inf'))

def _latest_track_time(track: dict) -> float:
    return max((float(state['position'][0]) for state in track.get('states', [])), default=float('-inf'))

def _filter_inactive_realtime_data(data: dict, latest_event_time_s: float, inactive_after_s: float) -> dict:
    filtered = copy.deepcopy(data)
    cutoff = float(latest_event_time_s) - max(0.05, float(inactive_after_s))
    filtered['sourceSeries'] = [item for item in filtered.get('sourceSeries', []) if _latest_source_time(item) >= cutoff]
    filtered['swTracks'] = [item for item in filtered.get('swTracks', []) if _latest_track_time(item) >= cutoff]
    filtered['jointTracks'] = [item for item in filtered.get('jointTracks', []) if _latest_track_time(item) >= cutoff]
    filtered['ewRays'] = [item for item in filtered.get('ewRays', []) if float(item.get('eventTime', float('-inf'))) >= cutoff]
    active_target_ids = {str(item['targetId']) for key in ('sourceSeries', 'swTracks', 'jointTracks') for item in filtered.get(key, []) if item.get('targetId') is not None}
    active_target_ids.update((str(item['displayTargetId']) for item in filtered.get('ewRays', []) if item.get('displayTargetId') is not None))
    filtered['targetIds'] = sorted(active_target_ids)
    filtered['targetStatuses'] = {str(target_id): status for (target_id, status) in filtered.get('targetStatuses', {}).items() if str(target_id) in active_target_ids}
    sampling = filtered.setdefault('displaySampling', {})
    sampling.update({'sourceInputPoints': sum((int(item.get('totalPointCount', 0)) for item in filtered['sourceSeries'])), 'sourceDisplayedPoints': sum((int(item.get('displayedPointCount', 0)) for item in filtered['sourceSeries'])), 'swInputStates': sum((int(item.get('totalStateCount', 0)) for item in filtered['swTracks'])), 'swDisplayedStates': sum((int(item.get('displayedStateCount', 0)) for item in filtered['swTracks'])), 'jointInputStates': sum((int(item.get('totalStateCount', 0)) for item in filtered['jointTracks'])), 'jointDisplayedStates': sum((int(item.get('displayedStateCount', 0)) for item in filtered['jointTracks'])), 'ewDisplayedRays': len(filtered['ewRays'])})
    filtered['realtimeActiveCutoffEpochS'] = cutoff
    filtered['realtimeTrackInactiveS'] = max(0.05, float(inactive_after_s))
    return filtered

def _without_dynamic_tracks(data: dict) -> dict:
    cleared = copy.deepcopy(data)
    for key in ('sourceSeries', 'swTracks', 'jointTracks', 'ewRays'):
        cleared[key] = []
    cleared['targetIds'] = []
    cleared['targetStatuses'] = {}
    sampling = cleared.setdefault('displaySampling', {})
    for key in ('sourceInputPoints', 'sourceDisplayedPoints', 'swInputStates', 'swDisplayedStates', 'jointInputStates', 'jointDisplayedStates', 'ewDisplayedRays'):
        sampling[key] = 0
    return cleared

def _merge_finite_replay_data(previous: Optional[dict], current: dict, maximum_source_points_per_series: Optional[int]=None, maximum_fused_points_per_track: Optional[int]=None, maximum_total_source_points: Optional[int]=None, maximum_total_fused_points: Optional[int]=None, maximum_ew_rays: Optional[int]=None) -> dict:
    previous = previous or {}
    merged = copy.deepcopy(current)

    def merge_series(old_items: list, new_items: list, identity_key: str, values_key: str, time_getter) -> list:

        def stable_identity(item: dict) -> str:
            return str(item.get('realtimeKey') or item.get(identity_key))
        by_id = {stable_identity(item): copy.deepcopy(item) for item in old_items if item.get('realtimeKey') is not None or item.get(identity_key) is not None}
        for retired in current.get('retiredRealtimeKeys', []):
            by_id.pop(str(retired), None)
        for item in new_items:
            identifier = stable_identity(item)
            if identifier not in by_id:
                by_id[identifier] = copy.deepcopy(item)
                continue

            def boundary_is_break(left, right, covered):
                left_point = left if values_key == 'positions' else left['position']
                right_point = right if values_key == 'positions' else right['position']
                limits = current.get('visualContinuity', {})
                (starts, _) = _visual_segment_starts([left_point, right_point], float(limits.get('maximumSpeedMps', 1200.0)), 0.0 if covered else float(limits.get('maximumJumpM', 20000.0)), 0.0 if covered else float(limits.get('maximumGapS', 30.0)))
                return len(starts) > 1
            combined = merge_visual_values(by_id[identifier], item, values_key, time_getter, boundary_is_break)
            by_id[identifier] = combined
            count_key = 'totalPointCount' if values_key == 'positions' else 'totalStateCount'
            displayed_key = 'displayedPointCount' if values_key == 'positions' else 'displayedStateCount'
            combined[count_key] = len(combined[values_key])
            combined[displayed_key] = len(combined[values_key])
        return [by_id[key] for key in sorted(by_id)]
    merged['sourceSeries'] = merge_series(previous.get('sourceSeries', []), current.get('sourceSeries', []), 'seriesId', 'positions', lambda point: point[0])
    merged['swTracks'] = merge_series(previous.get('swTracks', []), current.get('swTracks', []), 'trackId', 'states', lambda state: state['position'][0])
    merged['jointTracks'] = merge_series(previous.get('jointTracks', []), current.get('jointTracks', []), 'trackId', 'states', lambda state: state['position'][0])
    rays = {str(item.get('measurementId')): copy.deepcopy(item) for item in previous.get('ewRays', []) if item.get('measurementId') is not None}
    rays.update({str(item.get('measurementId')): copy.deepcopy(item) for item in current.get('ewRays', []) if item.get('measurementId') is not None})
    merged['ewRays'] = sorted(rays.values(), key=lambda item: (float(item.get('eventTime', 0.0)), str(item.get('measurementId', ''))))
    sensors = {str(item.get('zbb', item.get('sensorId', ''))): copy.deepcopy(item) for item in previous.get('ewSensors', [])}
    sensors.update({str(item.get('zbb', item.get('sensorId', ''))): copy.deepcopy(item) for item in current.get('ewSensors', [])})
    merged['ewSensors'] = [sensors[key] for key in sorted(sensors)]
    merged['targetIds'] = sorted({str(value) for data in (previous, current) for value in data.get('targetIds', [])})
    merged['targetColors'] = {**previous.get('targetColors', {}), **current.get('targetColors', {})}
    merged['targetStatuses'] = {**previous.get('targetStatuses', {}), **current.get('targetStatuses', {})}
    merged['timeStartEpochS'] = min(float(previous.get('timeStartEpochS', current.get('timeStartEpochS', 0.0))), float(current.get('timeStartEpochS', previous.get('timeStartEpochS', 0.0))))
    merged['timeStopEpochS'] = max(float(previous.get('timeStopEpochS', current.get('timeStopEpochS', 0.0))), float(current.get('timeStopEpochS', previous.get('timeStopEpochS', 0.0))))
    sampling = merged.setdefault('displaySampling', {})
    sampling.update({'sourceInputPoints': sum((len(item.get('positions', [])) for item in merged['sourceSeries'])), 'sourceDisplayedPoints': sum((len(item.get('positions', [])) for item in merged['sourceSeries'])), 'swInputStates': sum((len(item.get('states', [])) for item in merged['swTracks'])), 'swDisplayedStates': sum((len(item.get('states', [])) for item in merged['swTracks'])), 'jointInputStates': sum((len(item.get('states', [])) for item in merged['jointTracks'])), 'jointDisplayedStates': sum((len(item.get('states', [])) for item in merged['jointTracks'])), 'ewDisplayedRays': len(merged['ewRays'])})
    return sample_realtime_data(merged, maximum_source_points_per_series or 2 ** 31, maximum_fused_points_per_track or 2 ** 31, maximum_total_source_points or 2 ** 31, maximum_total_fused_points or 2 ** 31, maximum_ew_rays or 2 ** 31)

def _geodetic_distance_m(left: list, right: list) -> float:
    try:
        (longitude_1, latitude_1, altitude_1) = map(float, left[1:4])
        (longitude_2, latitude_2, altitude_2) = map(float, right[1:4])
    except (TypeError, ValueError):
        return float('inf')
    if not all(map(math.isfinite, (longitude_1, latitude_1, altitude_1, longitude_2, latitude_2, altitude_2))):
        return float('inf')
    latitude_1_rad = math.radians(latitude_1)
    latitude_2_rad = math.radians(latitude_2)
    delta_latitude = latitude_2_rad - latitude_1_rad
    delta_longitude = math.radians((longitude_2 - longitude_1 + 180.0) % 360.0 - 180.0)
    haversine = math.sin(delta_latitude / 2.0) ** 2 + math.cos(latitude_1_rad) * math.cos(latitude_2_rad) * math.sin(delta_longitude / 2.0) ** 2
    horizontal = 2.0 * 6371008.8 * math.asin(min(1.0, math.sqrt(max(0.0, haversine))))
    return math.hypot(horizontal, altitude_2 - altitude_1)

def _visual_segment_starts(points: list, maximum_speed_mps: float, maximum_jump_m: float, maximum_gap_s: float) -> tuple[list[int], Dict[str, int]]:
    if not points:
        return ([], {'non_monotonic': 0, 'time_gap': 0, 'distance_jump': 0, 'speed': 0})
    starts = [0]
    reasons = {'non_monotonic': 0, 'time_gap': 0, 'distance_jump': 0, 'speed': 0}
    for index in range(1, len(points)):
        (previous, current) = (points[index - 1], points[index])
        delta_time = float(current[0]) - float(previous[0])
        reason = None
        if not math.isfinite(delta_time) or delta_time <= 0.0:
            reason = 'non_monotonic'
        else:
            distance = _geodetic_distance_m(previous, current)
            if maximum_gap_s > 0.0 and delta_time > maximum_gap_s:
                reason = 'time_gap'
            elif maximum_jump_m > 0.0 and distance > maximum_jump_m:
                reason = 'distance_jump'
            elif maximum_speed_mps > 0.0 and distance / delta_time > maximum_speed_mps:
                reason = 'speed'
        if reason is not None:
            starts.append(index)
            reasons[reason] += 1
    return (starts, reasons)

def _add_realtime_visual_continuity(data: dict, maximum_speed_mps: float, maximum_jump_m: float, maximum_gap_s: float) -> dict:
    decorated = copy.deepcopy(data)
    total_breaks = 0
    totals = {'non_monotonic': 0, 'time_gap': 0, 'distance_jump': 0, 'speed': 0, 'lifecycle_end': 0}

    def decorate(items: list, points_getter) -> None:
        nonlocal total_breaks
        for item in items:
            points = list(points_getter(item))
            (starts, reasons) = _visual_segment_starts(points, maximum_speed_mps, maximum_jump_m, maximum_gap_s)
            reasons['lifecycle_end'] = 0
            for (index, state) in enumerate(item.get('states', [])[:-1]):
                if str(state.get('lifecycle', '')).lower() in TERMINAL_STATES:
                    if index + 1 not in starts:
                        reasons['lifecycle_end'] += 1
                    starts.append(index + 1)
            starts = sorted(set(starts))
            numbers = []
            segment = -1
            start_set = set(starts)
            for index in range(len(points)):
                if index in start_set:
                    segment += 1
                numbers.append(segment)
            set_segments(item, points, numbers, lambda point: point[0])
            item['visualContinuityBreaks'] = reasons
            count = max(0, len(starts) - 1)
            total_breaks += count
            for (name, value) in reasons.items():
                totals[name] += int(value)
    decorate(decorated.get('sourceSeries', []), lambda item: item.get('positions', []))
    decorate(decorated.get('swTracks', []), lambda item: [state['position'] for state in item.get('states', [])])
    decorate(decorated.get('jointTracks', []), lambda item: [state['position'] for state in item.get('states', [])])
    decorated['visualContinuity'] = {'breakCount': total_breaks, 'breakReasons': totals, 'maximumSpeedMps': maximum_speed_mps, 'maximumJumpM': maximum_jump_m, 'maximumGapS': maximum_gap_s, 'fusionDataModified': False}
    return decorated

class RealtimeCesiumMapServer:

    def __init__(self, config: dict, port: int=8770, status_provider: Optional[Callable[[], Dict[str, object]]]=None, finite_replay: bool=False) -> None:
        cesium = config.get('visualization', {}).get('cesium', {})
        self.version = str(cesium.get('asset_version', CESIUM_VERSION))
        self.finite_replay = bool(finite_replay)
        self.track_inactive_s = max(0.05, float(cesium.get('realtime_track_inactive_s', 30.0)))
        configured_expiry = float(cesium.get('realtime_snapshot_expiry_s', 30.0))
        self.snapshot_expiry_s = 0.0 if self.finite_replay else max(0.0, configured_expiry)
        self.poll_interval_ms = min(2000, max(100, int(cesium.get('realtime_poll_interval_ms', 200))))
        self.display_transition_s = min(3.0, max(0.0, float(cesium.get('realtime_display_transition_s', 0.75))))
        self.visual_maximum_speed_mps = max(0.0, float(cesium.get('realtime_visual_maximum_speed_mps', 1200.0)))
        self.visual_maximum_jump_m = max(0.0, float(cesium.get('realtime_visual_maximum_jump_m', 20000.0)))
        self.visual_maximum_gap_s = max(0.0, float(cesium.get('realtime_visual_maximum_gap_s', 30.0)))
        self.maximum_source_points_per_series = max(2, int(cesium.get('maximum_source_points_per_series', 3000)))
        self.maximum_fused_points_per_track = max(2, int(cesium.get('maximum_fused_points_per_track', 6000)))
        self.maximum_total_source_points = max(2, int(cesium.get('maximum_total_source_points', 60000)))
        self.maximum_total_fused_points = max(2, int(cesium.get('maximum_total_fused_points', 60000)))
        self.maximum_ew_rays = max(1, int(cesium.get('maximum_ew_rays', 3000)))
        self.requested_port = int(port)
        if not 0 <= self.requested_port <= 65535:
            raise ValueError('实时地图端口必须在0到65535之间。')
        self.cesium_root = _cesium_root(self.version)
        self.font_root = _font_root()
        self.template = Path(__file__).with_name('realtime_cesium_template.html').read_bytes()
        self._lock = threading.Lock()
        self._revision = 0
        self.session_id = uuid4().hex
        reference = config.get('scenario', {}).get('reference', {})
        self._initial_response = {'ready': False, 'revision': 0, 'session_id': self.session_id, 'generatedTimeS': time.time(), 'message': '实时服务已启动，正在等待有效SW报文和第一份融合快照。', 'initialView': {'longitude': float(reference.get('longitude_deg', 114.5)), 'latitude': float(reference.get('latitude_deg', 38.0)), 'altitude': float(reference.get('altitude_m', 0.0))}, 'displayTimeZone': str(config.get('sw', {}).get('timezone', 'Asia/Shanghai')), 'status': {}, 'streamState': 'waiting', 'snapshotExpiryS': self.snapshot_expiry_s, 'pollIntervalMs': self.poll_interval_ms, 'displayTransitionS': self.display_transition_s}
        self._latest_response = copy.deepcopy(self._initial_response)
        self._latest_payload = json.dumps(self._initial_response, ensure_ascii=False).encode('utf-8')
        self._status_provider = status_provider
        self._finite_replay_data: Optional[dict] = None
        self._display_identity = RealtimeDisplayIdentity(maximum_gap_s=self.visual_maximum_gap_s, maximum_speed_mps=self.visual_maximum_speed_mps, maximum_jump_m=self.visual_maximum_jump_m, retain_missing=self.finite_replay)
        self._server: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self.url: Optional[str] = None

    @property
    def revision(self) -> int:
        with self._lock:
            return self._revision

    def update_snapshot(self, snapshot: RealtimeSnapshot) -> int:
        data = build_cesium_player_payload(snapshot.result, realtime=True)
        data = _add_realtime_visual_continuity(data, self.visual_maximum_speed_mps, self.visual_maximum_jump_m, self.visual_maximum_gap_s)
        data = self._display_identity.resolve(data)
        if self.finite_replay:
            data = _merge_finite_replay_data(self._finite_replay_data, data, maximum_source_points_per_series=self.maximum_source_points_per_series, maximum_fused_points_per_track=self.maximum_fused_points_per_track, maximum_total_source_points=self.maximum_total_source_points, maximum_total_fused_points=self.maximum_total_fused_points, maximum_ew_rays=self.maximum_ew_rays)
            self._finite_replay_data = copy.deepcopy(data)
        else:
            data = _filter_inactive_realtime_data(data, snapshot.latest_event_time_s, self.track_inactive_s)
        data = sample_realtime_data(data, self.maximum_source_points_per_series, self.maximum_fused_points_per_track, self.maximum_total_source_points, self.maximum_total_fused_points, self.maximum_ew_rays)
        data['title'] = 'DeepFusion 实时融合地图'
        status = snapshot.status
        joint = snapshot.metrics.get('joint_fusion', {})
        response = {'ready': True, 'revision': 0, 'session_id': self.session_id, 'generatedTimeS': float(snapshot.generated_time_s), 'latestEventTimeS': float(snapshot.latest_event_time_s), 'streamState': 'running', 'snapshotExpiryS': self.snapshot_expiry_s, 'pollIntervalMs': self.poll_interval_ms, 'displayTransitionS': self.display_transition_s, 'status': {'receivedSw': int(status.received_sw), 'receivedEw': int(status.received_ew), 'bufferedSw': int(status.buffered_sw), 'bufferedEw': int(status.buffered_ew), 'fusionRuns': int(status.fusion_run_count), 'rejected': int(status.rejected_messages), 'lateDropped': int(status.late_dropped_messages), 'fusionErrors': int(status.fusion_error_count), 'lastError': status.last_error or '', 'journalError': getattr(status, 'journal_error', None) or '', 'lastFusionDurationS': float(status.last_fusion_duration_s), 'meanFusionDurationS': float(status.mean_fusion_duration_s), 'lastSnapshotIntervalS': float(status.last_snapshot_interval_s), 'globalTargets': len(snapshot.result.config['scenario'].get('target_track_ids', {})), 'swTracks': len(data['swTracks']), 'jointTracks': len(data['jointTracks']), 'ewAssociated': int(joint.get('associated_count', 0)), 'ewAssociationReports': int(joint.get('association_report_count', 0)), 'ewAssociationRate': float(joint.get('association_rate', 0.0)), 'visualContinuityBreaks': int(data.get('visualContinuity', {}).get('breakCount', 0))}, 'data': data}
        with self._lock:
            self._revision += 1
            response['revision'] = self._revision
            self._latest_response = copy.deepcopy(response)
            self._latest_payload = json.dumps(response, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
            return self._revision

    def clear_tracks(self, message: str='实时输入已完成，动态航迹已退出地图。') -> int:
        with self._lock:
            response = copy.deepcopy(self._latest_response)
            self._revision += 1
            response.update({'revision': self._revision, 'generatedTimeS': time.time(), 'streamState': 'completed', 'snapshotExpiryS': 0.0, 'message': str(message)})
            if response.get('ready') and isinstance(response.get('data'), dict):
                response['data'] = _without_dynamic_tracks(response['data'])
                status = response.setdefault('status', {})
                status['swTracks'] = 0
                status['jointTracks'] = 0
            self._latest_response = response
            self._finite_replay_data = None
            self._display_identity.clear()
            self._latest_payload = json.dumps(response, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
            return self._revision

    def start(self, open_browser: bool=True) -> str:
        if self._server is not None:
            return str(self.url)
        owner = self

        class RealtimeMapHandler(BaseHTTPRequestHandler):

            def _send_bytes(self, payload: bytes, content_type: str, cache_control: str='no-store', include_body: bool=True) -> None:
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(payload)))
                self.send_header('Cache-Control', cache_control)
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.end_headers()
                if include_body:
                    self.wfile.write(payload)

            def _serve(self, include_body: bool) -> None:
                request = urlsplit(self.path)
                path = request.path
                if path == '/favicon.ico':
                    self.send_response(204)
                    self.end_headers()
                    return
                if path in {'/', '/realtime-map'}:
                    self._send_bytes(owner.template, 'text/html; charset=utf-8', include_body=include_body)
                    return
                if path == '/api/live-snapshot':
                    with owner._lock:
                        response = dict(owner._latest_response)
                    revision = response['revision']
                    status = dict(response.get('status', {}))
                    if owner._status_provider is not None:
                        try:
                            status.update(owner._status_provider())
                        except Exception as error:
                            status['statusProviderError'] = str(error)
                    response['status'] = status
                    query = parse_qs(request.query)
                    after_values = query.get('after', [])
                    try:
                        after_revision = int(after_values[0]) if after_values else -1
                    except (TypeError, ValueError):
                        after_revision = -1
                    if revision > 0 and after_revision == revision and (query.get('session_id', [None])[0] == owner.session_id):
                        response = {'ready': response['ready'], 'revision': revision, 'session_id': owner.session_id, 'unchanged': True, 'streamState': response['streamState'], 'snapshotExpiryS': response['snapshotExpiryS'], 'pollIntervalMs': owner.poll_interval_ms, 'status': status}
                    elif revision == 0:
                        response['generatedTimeS'] = time.time()
                    payload = json.dumps(response, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                    self._send_bytes(payload, 'application/json; charset=utf-8', include_body=include_body)
                    return
                if path == '/api/health':
                    with owner._lock:
                        revision = owner._revision
                    payload = json.dumps({'ok': True, 'offline': True, 'revision': revision, 'session_id': owner.session_id, 'cesiumVersion': owner.version}, ensure_ascii=False).encode('utf-8')
                    self._send_bytes(payload, 'application/json; charset=utf-8', include_body=include_body)
                    return
                if path.startswith('/cesium/'):
                    resource = _safe_static_path(owner.cesium_root, path[len('/cesium/'):])
                    if resource is None:
                        self.send_error(404, 'Offline Cesium resource not found.')
                        return
                    payload = resource.read_bytes()
                    content_type = mimetypes.guess_type(resource.name)[0] or 'application/octet-stream'
                    if resource.suffix.lower() == '.wasm':
                        content_type = 'application/wasm'
                    self._send_bytes(payload, content_type, 'public, max-age=31536000, immutable', include_body=include_body)
                    return
                if path.startswith('/fonts/'):
                    resource = _safe_static_path(owner.font_root, path[len('/fonts/'):])
                    if resource is None:
                        self.send_error(404, 'Bundled RealFusion font not found.')
                        return
                    content_type = mimetypes.guess_type(resource.name)[0] or 'font/otf'
                    self._send_bytes(resource.read_bytes(), content_type, 'public, max-age=31536000, immutable', include_body=include_body)
                    return
                self.send_error(404, 'Realtime map resource not found.')

            def do_GET(self) -> None:
                self._serve(True)

            def do_HEAD(self) -> None:
                self._serve(False)

            def log_message(self, format_string: str, *args: object) -> None:
                pass
        try:
            server = ThreadingHTTPServer(('127.0.0.1', self.requested_port), RealtimeMapHandler)
        except OSError:
            if self.requested_port == 0:
                raise
            server = ThreadingHTTPServer(('127.0.0.1', 0), RealtimeMapHandler)
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.2}, name='RealFusionRealtimeMap', daemon=True)
        thread.start()
        self._server = server
        self._thread = thread
        self.url = f'http://127.0.0.1:{server.server_port}/realtime-map'
        if open_browser:
            webbrowser.open(self.url, new=2)
        return self.url

    def stop(self) -> None:
        (server, self._server) = (self._server, None)
        (thread, self._thread) = (self._thread, None)
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None and thread.is_alive():
            thread.join(timeout=5.0)
        self.url = None
