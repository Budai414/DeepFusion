from __future__ import annotations
import json
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, Iterable, List, Sequence
from urllib.parse import quote, urlsplit
import numpy as np
from real_fusion.geometry import GeodeticConverter
from real_fusion.models import NormalizedDetection
from real_fusion.pipeline import ExperimentResult
from real_fusion.visualization.bounds import DEFAULT_MINIMUM_SPAN_ENU_M, DEFAULT_PADDING_RATIO_ENU, adaptive_axes_settings, bounds_as_player_dict
from real_fusion.visualization.colors import FUSED_TRACK_COLOR, build_source_color_map
_SHAPES = ('circle', 'triangle', 'cross', 'diamond', 'square')
MAX_PLAYER_DETECTIONS_PER_SENSOR = 2500
MAX_PLAYER_FUSED_STATES = 4000
MAX_PLAYER_TOTAL_DETECTIONS = 80000
MAX_PLAYER_TOTAL_FUSED_STATES = 60000

def _sample_evenly(items: Sequence[object], maximum: int) -> List[object]:
    if len(items) <= maximum:
        return list(items)
    if maximum <= 1:
        return [items[0]] if items else []
    stride = (len(items) - 1) / float(maximum - 1)
    indices = sorted({round(index * stride) for index in range(maximum)})
    return [items[index] for index in indices]

def _finite_bounds(point_sets: Iterable[Iterable[float]], padding_ratio: Sequence[float]=DEFAULT_PADDING_RATIO_ENU, minimum_span: Sequence[float]=DEFAULT_MINIMUM_SPAN_ENU_M) -> Dict[str, float]:
    return bounds_as_player_dict(point_sets, padding_ratio, minimum_span)

def _detection_record(item: NormalizedDetection, base_epoch_s: float, primary_source: str) -> list:
    return [round(float(item.corrected_time_s - base_epoch_s), 4), round(float(item.state_enu[0]), 4), round(float(item.state_enu[1]), 4), round(float(item.state_enu[2]), 4), round(float(item.score), 4), item.detection_id, item.source_track_id, item.source_track_id == primary_source]

def build_player_payload(result: ExperimentResult) -> dict:
    scenario = result.config['scenario']
    base_epoch_s = float(scenario['base_epoch_s'])
    target_order = sorted(result.config['scenario'].get('input_target_values', []))
    sensor_indexes = {sensor_id: index for (index, sensor_id) in enumerate(result.config['sensors'])}
    ordered_series = sorted({(item.target_id, item.sensor_id) for item in result.raw_detections})
    source_color_tokens = {(target_id, sensor_id): f'SW::{target_id}::{sensor_id}' for (target_id, sensor_id) in ordered_series}
    sparse_color_tokens = {(str(item.target_id), str(item.zbb), str(item.local_target_id)): f'SW-SPARSE::{item.target_id}::{item.zbb}::{item.local_target_id}' for item in result.source_tracks.sparse_groups}
    source_color_palette = build_source_color_map([*source_color_tokens.values(), *sparse_color_tokens.values()])
    sensor_series_count = len(ordered_series) + len(result.source_tracks.sparse_groups)
    per_sensor_detection_limit = min(MAX_PLAYER_DETECTIONS_PER_SENSOR, max(1, MAX_PLAYER_TOTAL_DETECTIONS // max(sensor_series_count, 1)))
    detections_by_series = {key: [] for key in ordered_series}
    for detection in result.normalized_detections:
        detections_by_series.setdefault((detection.target_id, detection.sensor_id), []).append(detection)
    sensor_payload = []
    primary_points = []
    primary_points_by_target = {target_id: [] for target_id in target_order}
    for (target_id, sensor_id) in ordered_series:
        detections = sorted(detections_by_series.get((target_id, sensor_id), []), key=lambda item: (item.corrected_time_s, item.detection_id))
        displayed_detections = _sample_evenly(detections, maximum=per_sensor_detection_limit)
        primary_source = str(detections[0].source_track_id if detections else f'UNKNOWN-{target_id}-{sensor_id}')
        records = [_detection_record(item, base_epoch_s, primary_source) for item in displayed_detections]
        series_primary_points = [(record[1], record[2], record[3]) for record in records if record[7]]
        primary_points.extend(series_primary_points)
        primary_points_by_target[target_id].extend(series_primary_points)
        sensor_config = result.config['sensors'][sensor_id]
        device_label = str(sensor_config.get('label', sensor_id))
        local_batches = sorted({str(item.local_target_id) for item in detections if item.local_target_id is not None})
        local_label = '/'.join(local_batches) if local_batches else '未知'
        label = f'全局目标={target_id}｜局部MBY={local_label}｜{device_label}'
        series_id = f'{target_id}|{sensor_id}'
        sensor_payload.append({'id': series_id, 'sensorId': sensor_id, 'targetId': target_id, 'label': label, 'shortLabel': device_label, 'shape': _SHAPES[sensor_indexes[sensor_id] % len(_SHAPES)], 'color': source_color_palette[source_color_tokens[target_id, sensor_id]], 'sourceTrackId': primary_source, 'samplePeriod': float(result.config['sensors'][sensor_id]['sample_period_s']), 'totalDetectionCount': len(detections), 'displayedDetectionCount': len(displayed_detections), 'detections': records})
    reference = result.config['scenario']['reference']
    converter = GeodeticConverter(float(reference['longitude_deg']), float(reference['latitude_deg']), float(reference['altitude_m']))
    raw_group_indices = result.sw_read.frame.groupby(['_mby', '_zbb'], sort=False).groups
    for sparse in sorted(result.source_tracks.sparse_groups, key=lambda item: (item.target_id, item.zbb)):
        indices = raw_group_indices.get((sparse.local_target_id, sparse.zbb), [])
        group = result.sw_read.frame.loc[indices].sort_values('_jdsc', kind='stable')
        if group.empty:
            continue
        displayed = group.iloc[np.unique(np.linspace(0, len(group) - 1, min(len(group), per_sensor_detection_limit), dtype=int))]
        points = converter.geodetic_many_to_enu(displayed['_mbj'].to_numpy(dtype=float), displayed['_mbw'].to_numpy(dtype=float), displayed['_mbg'].to_numpy(dtype=float))
        source_track_id = f'UNFORMED-{sparse.target_id}-{sparse.zbb}'
        records = []
        for (index, ((_, row), point)) in enumerate(zip(displayed.iterrows(), points)):
            records.append([round(float(row['_epoch_s'] - base_epoch_s), 4), round(float(point[0]), 4), round(float(point[1]), 4), round(float(point[2]), 4), 0.0, f'UNFORMED-{sparse.target_id}-{sparse.zbb}-{index:06d}', source_track_id, True])
        series_id = f'{sparse.target_id}|{sparse.sensor_id}'
        label_kind = '未成轨/虚警候选'
        label = f'{label_kind}｜局部MBY={sparse.local_target_id}｜装备={sparse.zbb}'
        series_points = [(record[1], record[2], record[3]) for record in records]
        primary_points.extend(series_points)
        primary_points_by_target[sparse.target_id].extend(series_points)
        sensor_payload.append({'id': series_id, 'sensorId': sparse.sensor_id, 'targetId': sparse.target_id, 'label': label, 'shortLabel': f'装备={sparse.zbb}（未成轨）', 'shape': 'cross', 'color': source_color_palette[sparse_color_tokens[str(sparse.target_id), str(sparse.zbb), str(sparse.local_target_id)]], 'sourceTrackId': source_track_id, 'samplePeriod': 0.0, 'totalDetectionCount': len(group), 'displayedDetectionCount': len(displayed), 'detections': records, 'unformed': True, 'classification': sparse.classification})
    estimates_by_track: Dict[str, List[object]] = {}
    for estimate in result.estimates:
        estimates_by_track.setdefault(estimate.track_id, []).append(estimate)
    fused_tracks_payload = []
    per_fused_track_limit = min(MAX_PLAYER_FUSED_STATES, max(1, MAX_PLAYER_TOTAL_FUSED_STATES // max(len(estimates_by_track), 1)))
    for (track_id, track_estimates) in sorted(estimates_by_track.items()):
        track_estimates = sorted(track_estimates, key=lambda item: item.event_time_s)
        displayed_estimates = _sample_evenly(track_estimates, maximum=per_fused_track_limit)
        fused_payload = []
        for estimate in displayed_estimates:
            state = estimate.state_enu
            fused_payload.append({'t': round(float(estimate.event_time_s - base_epoch_s), 4), 'state': [round(float(value), 4) for value in state[:6]], 'lifecycle': estimate.lifecycle_state, 'existence': round(float(estimate.existence_probability), 5), 'models': {str(key): round(float(value), 5) for (key, value) in estimate.model_probabilities.items()}, 'sources': [{'sensorId': str(source['sensor_id']), 'targetId': str(source['target_id']), 'sourceTrackId': str(source['source_track_id']), 'detectionId': str(source['detection_id']), 'probability': round(float(source['probability']), 5)} for source in estimate.associated_sources]})
        target_id = str(track_estimates[0].target_id)
        fused_tracks_payload.append({'trackId': track_id, 'targetId': target_id, 'color': FUSED_TRACK_COLOR, 'totalStateCount': len(track_estimates), 'displayedStateCount': len(displayed_estimates), 'states': fused_payload})
    bound_points = list(primary_points)
    bound_points.extend(((item['state'][0], item['state'][1], item['state'][2]) for track in fused_tracks_payload for item in track['states']))
    target_bound_points = {target_id: list(primary_points_by_target[target_id]) for target_id in target_order}
    for track in fused_tracks_payload:
        target_bound_points[track['targetId']].extend(((item['state'][0], item['state'][1], item['state'][2]) for item in track['states']))
    (padding_ratio, minimum_span) = adaptive_axes_settings(result.config)
    model_names = [str(name) for name in result.config['tracker']['model_names']]
    if 'single_source_passthrough' in result.target_fusion_modes.values():
        model_names.append('single_source_passthrough')
    return {'title': 'RealFusion：SW 多目标、多设备航迹融合全过程', 'duration': float(scenario['duration_s']), 'windowSeconds': float(scenario['window_s']), 'offlineAfter': float(scenario['offline_after_s']), 'bounds': _finite_bounds(bound_points, padding_ratio, minimum_span), 'targetBounds': {target_id: _finite_bounds(points, padding_ratio, minimum_span) for (target_id, points) in target_bound_points.items()}, 'targetIds': target_order, 'targetStatuses': {target_id: {'classification': status.classification, 'displayStatus': status.display_status, 'reason': status.reason} for (target_id, status) in result.target_statuses.items()}, 'sensors': sensor_payload, 'fusedTracks': fused_tracks_payload, 'totalFusedStateCount': len(result.estimates), 'displayedFusedStateCount': sum((int(track['displayedStateCount']) for track in fused_tracks_payload)), 'modelNames': model_names, 'trackIds': [track['trackId'] for track in fused_tracks_payload], 'fieldSchema': {'detection': ['relativeTime', 'east', 'north', 'up', 'score', 'detectionId', 'sourceTrackId', 'primary']}}

def create_fusion_player(result: ExperimentResult, output_path: str | Path) -> Path:
    template_path = Path(__file__).with_name('player_template.html')
    template = template_path.read_text(encoding='utf-8')
    payload = json.dumps(build_player_payload(result), ensure_ascii=False, separators=(',', ':'), allow_nan=False).replace('</', '<\\/')
    placeholder_count = template.count('__FUSION_DATA__')
    if placeholder_count != 1:
        raise ValueError(f'Visualization template must contain exactly one data placeholder; found {placeholder_count}.')
    html = template.replace('__FUSION_DATA__', payload)
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(html, encoding='utf-8')
    return destination

def _resolve_player_path(player_path: str | Path) -> Path:
    destination = Path(player_path).expanduser().resolve()
    if not destination.is_file():
        raise FileNotFoundError(f'Fusion player does not exist. Run the demo first or check the path: {destination}')
    return destination

def _create_fusion_player_server(player_path: str | Path, port: int=8765) -> tuple[ThreadingHTTPServer, str, Path]:
    destination = _resolve_player_path(player_path)
    requested_port = int(port)
    if not 0 <= requested_port <= 65535:
        raise ValueError('Player server port must be between 0 and 65535.')
    encoded_name = quote(destination.name)
    allowed_paths = {'/', f'/{encoded_name}'}

    class PlayerRequestHandler(BaseHTTPRequestHandler):

        def _send_player(self, include_body: bool) -> None:
            requested_path = urlsplit(self.path).path
            if requested_path == '/favicon.ico':
                self.send_response(204)
                self.end_headers()
                return
            if requested_path not in allowed_paths:
                self.send_error(404, 'Only the generated fusion player is available.')
                return
            payload = destination.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(payload)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            if include_body:
                self.wfile.write(payload)

        def do_GET(self) -> None:
            self._send_player(include_body=True)

        def do_HEAD(self) -> None:
            self._send_player(include_body=False)

        def log_message(self, format_string: str, *args: object) -> None:
            pass
    try:
        server = ThreadingHTTPServer(('127.0.0.1', requested_port), PlayerRequestHandler)
    except OSError:
        if requested_port == 0:
            raise
        server = ThreadingHTTPServer(('127.0.0.1', 0), PlayerRequestHandler)
    server.daemon_threads = True
    url = f'http://127.0.0.1:{server.server_port}/{encoded_name}'
    return (server, url, destination)

def serve_fusion_player(player_path: str | Path, port: int=8765, open_browser: bool=True) -> Path:
    (server, url, destination) = _create_fusion_player_server(player_path, port)
    print(f'player_url={url}')
    print('播放器服务正在运行；关闭播放器后在此终端按 Ctrl+C 停止服务。')
    if open_browser and (not webbrowser.open(url, new=2)):
        print(f'浏览器未能自动启动，请复制此地址打开：{url}')
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        print('\n播放器服务已停止。')
    finally:
        server.server_close()
    return destination

def open_fusion_player(player_path: str | Path) -> Path:
    return serve_fusion_player(player_path)
