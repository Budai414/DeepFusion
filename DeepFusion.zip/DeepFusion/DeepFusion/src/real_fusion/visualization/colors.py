from __future__ import annotations
import colorsys
from typing import Dict, Iterable
_GOLDEN_RATIO_CONJUGATE = 0.6180339887498949
_HUE_ORIGIN = 0.585
FUSED_TRACK_COLOR = '#2563eb'

def _rgb_hex(hue: float, saturation: float, value: float) -> str:
    (red, green, blue) = colorsys.hsv_to_rgb(hue % 1.0, saturation, value)
    return '#{:02x}{:02x}{:02x}'.format(round(red * 255), round(green * 255), round(blue * 255))

def build_target_color_map(target_ids: Iterable[object]) -> Dict[str, str]:
    ordered = sorted({str(value) for value in target_ids})
    used = set()
    result: Dict[str, str] = {}
    saturation_levels = (0.78, 0.66, 0.88, 0.72)
    value_levels = (0.78, 0.68, 0.86, 0.62)
    for (index, target_id) in enumerate(ordered):
        base_hue = (_HUE_ORIGIN + index * _GOLDEN_RATIO_CONJUGATE) % 1.0
        band = index // 24 % len(saturation_levels)
        saturation = saturation_levels[band]
        value = value_levels[band]
        color = ''
        for attempt in range(4096):
            hue = base_hue + attempt / 4096.0
            candidate = _rgb_hex(hue, saturation, value)
            if candidate not in used:
                color = candidate
                break
        if not color:
            raise ValueError('目标数量过多，无法继续生成唯一显示颜色。')
        used.add(color)
        result[target_id] = color
    return result

def build_source_color_map(source_ids: Iterable[object]) -> Dict[str, str]:
    palette = build_target_color_map(source_ids)
    used = {FUSED_TRACK_COLOR.casefold()}
    result: Dict[str, str] = {}
    for source_id in sorted(palette):
        candidate = palette[source_id]
        rgb_value = int(candidate[1:], 16)
        while candidate.casefold() in used:
            rgb_value = (rgb_value + 3108395) % 16777216
            candidate = f'#{rgb_value:06x}'
        used.add(candidate.casefold())
        result[source_id] = candidate
    return result
