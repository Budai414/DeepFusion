from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
from pathlib import Path
from typing import Dict, Iterable, List, Sequence
from urllib.parse import quote, unquote, urlsplit
import webbrowser
import numpy as np
from real_fusion.geometry import GeodeticConverter
from real_fusion.pipeline import ExperimentResult
from real_fusion.runtime_paths import deepfusion_project_root
from real_fusion.visualization.colors import FUSED_TRACK_COLOR, build_source_color_map, build_target_color_map
CESIUM_VERSION = '1.144.0'
PROJECT_ROOT = deepfusion_project_root(__file__)
OFFLINE_WEB_ROOT = PROJECT_ROOT / 'offline_web_assets'
OFFLINE_FONT_ROOT = OFFLINE_WEB_ROOT / 'fonts'
DEFAULT_CESIUM_ROOT = OFFLINE_WEB_ROOT / 'cesium' / CESIUM_VERSION / 'Cesium'

def _sample_evenly(items: Sequence[object], maximum: int) -> List[object]:
    if len(items) <= maximum:
        return list(items)
    if maximum <= 1:
        return [items[0]] if items else []
    indices = np.unique(np.linspace(0, len(items) - 1, maximum, dtype=int))
    return [items[int(index)] for index in indices]

def _iso_utc(epoch_s: float) -> str:
    return datetime.fromtimestamp(float(epoch_s), tz=timezone.utc).isoformat().replace('+00:00', 'Z')

def _finite_position(longitude: object, latitude: object, altitude: object) -> bool:
    try:
        values = np.asarray([longitude, latitude, altitude], dtype=float)
    except (TypeError, ValueError):
        return False
    return bool(np.isfinite(values).all())

def _position_record(epoch_s: float, longitude: float, latitude: float, altitude: float) -> list:
    return [round(float(epoch_s), 6), round(float(longitude), 9), round(float(latitude), 9), round(float(altitude), 4)]

def _realtime_lineage_key(prefix: str, lineage_keys: Iterable[object]) -> str:
    normalized = sorted({str(value) for value in lineage_keys if value is not None and str(value)})
    if not normalized:
        normalized = ['unknown']
    digest = hashlib.sha256('\x1f'.join(normalized).encode('utf-8')).hexdigest()[:20]
    return f'{prefix}-{digest}'

def _cesium_config(result: ExperimentResult) -> dict:
    return dict(result.config.get('visualization', {}).get('cesium', {}))

def _series_limits(result: ExperimentResult, source_count: int, track_count: int) -> tuple[int, int]:
    config = _cesium_config(result)
    per_source = max(2, int(config.get('maximum_source_points_per_series', 3000)))
    per_track = max(2, int(config.get('maximum_fused_points_per_track', 6000)))
    total_source = max(2, int(config.get('maximum_total_source_points', 60000)))
    total_track = max(2, int(config.get('maximum_total_fused_points', 60000)))
    return (min(per_source, max(2, total_source // max(source_count, 1))), min(per_track, max(2, total_track // max(track_count, 1))))

def _build_source_series(result: ExperimentResult, colors: Dict[str, str], *, sample: bool=True) -> list:
    zbb_by_sensor = {str(sensor_id): str(sensor.get('zbb', sensor_id)) for (sensor_id, sensor) in result.config['sensors'].items()}
    grouped = defaultdict(list)
    for item in result.raw_detections:
        grouped[str(item.target_id), str(item.sensor_id)].append(item)
    sparse_keys = {(str(item.target_id), str(item.zbb)): item for item in result.source_tracks.sparse_groups}
    source_count = len(grouped) + len(sparse_keys)
    (source_limit, _) = _series_limits(result, source_count, 1)
    series = []
    for ((target_id, sensor_id), items) in sorted(grouped.items()):
        items = sorted(items, key=lambda value: (value.measurement_time_s, value.detection_id))
        displayed = _sample_evenly(items, source_limit) if sample else items
        points = [_position_record(item.measurement_time_s, item.longitude_deg, item.latitude_deg, item.altitude_m) for item in displayed if _finite_position(item.longitude_deg, item.latitude_deg, item.altitude_m)]
        if not points:
            continue
        zbb = zbb_by_sensor.get(sensor_id, sensor_id)
        local_batches = sorted({str(item.local_target_id or '') for item in items})
        local_label = '/'.join((value for value in local_batches if value)) or '未知'
        lineage_keys = sorted({str(item.local_track_key or item.source_track_id) for item in items})
        series.append({'seriesId': f'SW-SOURCE-{target_id}-{zbb}', 'realtimeKey': _realtime_lineage_key('SW-SOURCE', lineage_keys), 'lineageKeys': lineage_keys, 'targetId': target_id, 'sensorId': sensor_id, 'zbb': zbb, 'label': f'SW源航迹｜全局目标={target_id}｜局部MBY={local_label}｜装备={zbb}', 'color': colors[f'SW::{target_id}::{sensor_id}'], 'unformed': False, 'totalPointCount': len(items), 'displayedPointCount': len(points), 'positions': points})
    raw_groups = result.sw_read.frame.groupby(['_mby', '_zbb'], sort=False).groups
    for ((target_id, zbb), sparse) in sorted(sparse_keys.items()):
        indices = raw_groups.get((sparse.local_target_id, zbb), [])
        group = result.sw_read.frame.loc[indices].sort_values('_jdsc', kind='stable')
        if group.empty:
            continue
        displayed = group.iloc[np.unique(np.linspace(0, len(group) - 1, min(len(group), source_limit), dtype=int))] if sample else group
        points = [_position_record(row['_epoch_s'], row['_mbj'], row['_mbw'], row['_mbg']) for (_, row) in displayed.iterrows() if _finite_position(row['_mbj'], row['_mbw'], row['_mbg'])]
        if not points:
            continue
        series.append({'seriesId': f'SW-UNFORMED-{target_id}-{zbb}', 'realtimeKey': _realtime_lineage_key('SW-UNFORMED', [sparse.local_track_key]), 'lineageKeys': [str(sparse.local_track_key)], 'targetId': target_id, 'sensorId': str(sparse.sensor_id), 'zbb': zbb, 'label': f'SW未成轨点迹｜局部MBY={sparse.local_target_id}｜装备={zbb}', 'color': colors[f'SW-SPARSE::{target_id}::{zbb}::{sparse.local_target_id}'], 'unformed': True, 'classification': str(sparse.classification), 'totalPointCount': len(group), 'displayedPointCount': len(points), 'positions': points})
    return series

def _build_track_series(result: ExperimentResult, colors: Dict[str, str], estimates: Iterable[object], series_kind: str, lineage_by_target: Dict[str, List[str]], *, sample: bool=True) -> list:
    grouped = defaultdict(list)
    for item in estimates:
        grouped[str(item.track_id)].append(item)
    (_, track_limit) = _series_limits(result, 1, len(grouped))
    tracks = []
    for (track_id, items) in sorted(grouped.items()):
        items = sorted(items, key=lambda value: value.event_time_s)
        displayed = _sample_evenly(items, track_limit) if sample else items
        states = []
        for item in displayed:
            if not _finite_position(item.longitude_deg, item.latitude_deg, item.altitude_m):
                continue
            states.append({'position': _position_record(item.event_time_s, item.longitude_deg, item.latitude_deg, item.altitude_m), 'lifecycle': str(item.lifecycle_state), 'existence': round(float(item.existence_probability), 5), 'ewUpdate': bool(series_kind == 'joint' and item.lifecycle_state == 'joint_confirmed' and item.associated_detection_ids), 'sourceIds': sorted({str(source.get('zbb', source.get('sensor_id', ''))) for source in item.associated_sources if source.get('zbb', source.get('sensor_id')) is not None})})
        if not states:
            continue
        target_id = str(items[0].target_id)
        lineage_keys = list(lineage_by_target.get(target_id, []))
        if not lineage_keys:
            lineage_keys = sorted({str(source.get('local_track_key') or source.get('source_track_id') or source.get('sensor_id') or '') for item in items for source in item.associated_sources if isinstance(source, dict)} - {''})
        if not lineage_keys:
            lineage_keys = [f'fallback:{track_id}:{target_id}']
        tracks.append({'trackId': track_id, 'realtimeKey': _realtime_lineage_key(f'TRACK-{series_kind.upper()}', lineage_keys), 'lineageKeys': lineage_keys, 'continuityAnchor': lineage_keys[0], 'targetId': target_id, 'kind': series_kind, 'label': f'SW+EW联合航迹｜{track_id}｜目标={target_id}' if series_kind == 'joint' else f'SW融合航迹｜{track_id}｜目标={target_id}', 'color': FUSED_TRACK_COLOR, 'totalStateCount': len(items), 'displayedStateCount': len(states), 'states': states})
    return tracks

def _build_ew_payload(result: ExperimentResult) -> tuple[list, list]:
    if result.ew_read is None:
        return ([], [])
    ew_config = result.config.get('ew', {})
    raw_sensors = {str(key): value for (key, value) in ew_config.get('sensors', {}).items()}
    sensors = []
    for zbb in sorted(result.ew_sensor_positions):
        item = raw_sensors.get(str(zbb))
        if not item:
            continue
        sensors.append({'zbb': str(zbb), 'longitude': float(item['longitude_deg']), 'latitude': float(item['latitude_deg']), 'altitude': float(item['altitude_m']), 'label': f'EW/SW共享装备={zbb}｜本区间含EW数据'})
    config = _cesium_config(result)
    maximum = max(1, int(config.get('maximum_ew_rays', 3000)))
    displayed = _sample_evenly(result.ew_measurements, maximum)
    reference = result.config['scenario']['reference']
    converter = GeodeticConverter(float(reference['longitude_deg']), float(reference['latitude_deg']), float(reference['altitude_m']))
    association_by_id = {item.measurement_id: item for item in result.ew_associations}
    ew_source_tokens = {}
    for measurement in result.ew_measurements:
        association = association_by_id.get(measurement.measurement_id)
        associated = association is not None and association.status == 'associated'
        display_target = str(association.matched_target_id) if associated and association.matched_target_id else str(measurement.target_id)
        key = (display_target, str(measurement.zbb), str(measurement.target_id))
        ew_source_tokens[key] = f'EW::{display_target}::{measurement.zbb}::{measurement.target_id}'
    ew_source_colors = build_source_color_map(ew_source_tokens.values())
    fallback = float(config.get('ew_ray_display_length_m', ew_config.get('joint_fusion', {}).get('ray_display_length_m', 5000.0)))
    rays = []
    for measurement in displayed:
        if measurement.sensor_enu is None:
            continue
        sensor_config = raw_sensors.get(str(measurement.zbb))
        if sensor_config is None:
            continue
        endpoint = measurement.endpoint_enu(fallback)
        if endpoint is None:
            continue
        (longitude, latitude, altitude) = converter.enu_to_geodetic(endpoint)
        association = association_by_id.get(measurement.measurement_id)
        associated = association is not None and association.status == 'associated'
        display_target = str(association.matched_target_id) if associated else str(measurement.target_id)
        rays.append({'measurementId': measurement.measurement_id, 'eventTime': round(float(measurement.event_time_s), 6), 'ewTargetId': str(measurement.target_id), 'displayTargetId': display_target, 'zbb': str(measurement.zbb), 'kind': str(measurement.kind), 'hasMeasuredRange': measurement.range_m is not None, 'associated': associated, 'associationStatus': None if association is None else association.status, 'associationProbability': 0.0 if association is None else round(float(association.association_probability), 5), 'color': ew_source_colors[ew_source_tokens[display_target, str(measurement.zbb), str(measurement.target_id)]], 'sensor': [float(sensor_config['longitude_deg']), float(sensor_config['latitude_deg']), float(sensor_config['altitude_m'])], 'endpoint': [longitude, latitude, altitude]})
    return (sensors, rays)

def build_cesium_player_payload(result: ExperimentResult, *, realtime: bool=False) -> dict:
    target_ids = sorted(result.config['scenario'].get('input_target_values', []))
    target_ids = sorted(set(target_ids) | {str(item.target_id) for item in result.estimates})
    colors = build_target_color_map(target_ids)
    source_tokens = {f'SW::{item.target_id}::{item.sensor_id}' for item in result.raw_detections} | {f'SW-SPARSE::{item.target_id}::{item.zbb}::{item.local_target_id}' for item in result.source_tracks.sparse_groups}
    source_colors = build_source_color_map(source_tokens)
    source_series = _build_source_series(result, source_colors, sample=not realtime)
    lineage_by_target: Dict[str, List[str]] = defaultdict(list)
    for membership in result.global_track_memberships:
        lineage_by_target[str(membership.global_target_id)].append(str(membership.local_track_key))
    lineage_by_target = {target_id: sorted(set(keys)) for (target_id, keys) in lineage_by_target.items()}
    sw_tracks = _build_track_series(result, colors, result.estimates, 'sw', lineage_by_target, sample=not realtime)
    joint_tracks = _build_track_series(result, colors, result.joint_estimates, 'joint', lineage_by_target, sample=not realtime)
    (ew_sensors, ew_rays) = _build_ew_payload(result)
    times = [point[0] for series in source_series for point in series['positions']]
    times.extend((state['position'][0] for track in sw_tracks + joint_tracks for state in track['states']))
    times.extend((ray['eventTime'] for ray in ew_rays))
    if not times:
        base = float(result.config['scenario'].get('base_epoch_s', 0.0))
        times = [base, base + max(1.0, float(result.config['scenario'].get('window_s', 0.5)))]
    start_epoch = float(min(times))
    track_end_grace_s = max(0.05, float(_cesium_config(result).get('track_end_grace_s', 0.5)))
    stop_epoch = max(float(max(times)) + track_end_grace_s, start_epoch + 1.0)
    reference = result.config['scenario']['reference']
    return {'title': 'RealFusion 离线 Cesium 动态三维回放', 'offline': True, 'cesiumVersion': str(_cesium_config(result).get('asset_version', CESIUM_VERSION)), 'timeStartEpochS': start_epoch, 'timeStopEpochS': stop_epoch, 'timeStartUtc': _iso_utc(start_epoch), 'timeStopUtc': _iso_utc(stop_epoch), 'displayTimeZone': str(result.config.get('sw', {}).get('timezone', 'Asia/Shanghai')), 'reference': {'longitude': float(reference['longitude_deg']), 'latitude': float(reference['latitude_deg']), 'altitude': float(reference['altitude_m'])}, 'heightDatum': str(_cesium_config(result).get('height_datum', 'ellipsoid_unverified')), 'map': {'imagery': {'mode': 'bundled_natural_earth'}, 'terrain': dict(_cesium_config(result).get('terrain', {}))}, 'historyTrailS': float(_cesium_config(result).get('history_trail_s', 3600.0)), 'trackEndGraceS': track_end_grace_s, 'ewRayVisibilityS': float(_cesium_config(result).get('ew_ray_visibility_s', 2.0)), 'targetIds': target_ids, 'targetColors': colors, 'targetStatuses': {str(target_id): {'classification': status.classification, 'displayStatus': status.display_status, 'reason': status.reason} for (target_id, status) in result.target_statuses.items()}, 'sourceSeries': source_series, 'swTracks': sw_tracks, 'jointTracks': joint_tracks, 'ewSensors': ew_sensors, 'ewRays': ew_rays, 'displaySampling': {'sourceInputPoints': sum((item['totalPointCount'] for item in source_series)), 'sourceDisplayedPoints': sum((item['displayedPointCount'] for item in source_series)), 'swInputStates': sum((item['totalStateCount'] for item in sw_tracks)), 'swDisplayedStates': sum((item['displayedStateCount'] for item in sw_tracks)), 'jointInputStates': sum((item['totalStateCount'] for item in joint_tracks)), 'jointDisplayedStates': sum((item['displayedStateCount'] for item in joint_tracks)), 'ewInputMeasurements': len(result.ew_measurements), 'ewDisplayedRays': len(ew_rays)}}

def _rgba(css_color: str, alpha: int=255) -> list:
    value = css_color.lstrip('#')
    return [int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16), int(alpha)]

def build_cesium_czml(result: ExperimentResult, payload: dict | None=None) -> list:
    data = payload or build_cesium_player_payload(result)
    start = float(data['timeStartEpochS'])
    stop = float(data['timeStopEpochS'])
    interval = f'{_iso_utc(start)}/{_iso_utc(stop)}'
    packets = [{'id': 'document', 'name': 'RealFusion离线Cesium航迹', 'version': '1.0', 'clock': {'interval': interval, 'currentTime': _iso_utc(start), 'multiplier': 1, 'range': 'CLAMPED', 'step': 'SYSTEM_CLOCK_MULTIPLIER'}}]
    for track in data['swTracks'] + data['jointTracks']:
        states = track['states']
        if not states:
            continue
        epoch = float(states[0]['position'][0])
        track_stop = float(states[-1]['position'][0]) + float(data.get('trackEndGraceS', 0.5))
        track_interval = f'{_iso_utc(epoch)}/{_iso_utc(track_stop)}'
        coordinates = []
        for state in states:
            (time_s, longitude, latitude, altitude) = state['position']
            coordinates.extend([float(time_s) - epoch, longitude, latitude, altitude])
        joint = track['kind'] == 'joint'
        packets.append({'id': f"{track['kind']}:{track['trackId']}", 'name': track['label'], 'availability': track_interval, 'position': {'epoch': _iso_utc(epoch), 'cartographicDegrees': coordinates, 'interpolationAlgorithm': 'LINEAR', 'interpolationDegree': 1, 'forwardExtrapolationType': 'NONE', 'forwardExtrapolationDuration': 0}, 'point': {'pixelSize': 11 if joint else 8, 'color': {'rgba': _rgba(track['color'])}, 'outlineColor': {'rgba': [255, 255, 255, 230]}, 'outlineWidth': 2}, 'path': {'show': True, 'width': 5 if joint else 3, 'material': {'solidColor': {'color': {'rgba': _rgba(track['color'], 235)}}}, 'leadTime': 0, 'trailTime': float(data['historyTrailS'])}, 'label': {'text': track['trackId'], 'font': '400 14px RealFusion Noto Sans CJK SC', 'fillColor': {'rgba': [255, 255, 255, 255]}, 'outlineColor': {'rgba': [0, 0, 0, 230]}, 'outlineWidth': 3, 'style': 'FILL_AND_OUTLINE', 'pixelOffset': {'cartesian2': [12, -18]}}, 'properties': {'trackId': track['trackId'], 'targetId': track['targetId'], 'seriesKind': track['kind']}})
    return packets

def _cesium_root(version: str=CESIUM_VERSION) -> Path:
    root = (OFFLINE_WEB_ROOT / 'cesium' / str(version) / 'Cesium').resolve()
    required = [root / 'Cesium.js', root / 'Widgets' / 'widgets.css', root / 'Workers']
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError('Cesium离线运行资源不完整，请重新复制项目的offline_web_assets目录。缺少：' + '；'.join(missing))
    return root

def _font_root() -> Path:
    root = OFFLINE_FONT_ROOT.resolve()
    required = [root / 'NotoSansCJKsc-Regular.otf', root / 'NotoSansCJKsc-Bold.otf']
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError('RealFusion中文字体资源不完整，请重新复制offline_web_assets/fonts。缺少：' + '；'.join(missing))
    return root

def create_cesium_player(result: ExperimentResult, output_path: str | Path) -> Path:
    payload = build_cesium_player_payload(result)
    _cesium_root(payload['cesiumVersion'])
    _font_root()
    template_path = Path(__file__).with_name('cesium_player_template.html')
    template = template_path.read_text(encoding='utf-8')
    encoded = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    encoded = encoded.replace('</', '<\\/')
    if template.count('__CESIUM_FUSION_DATA__') != 1:
        raise ValueError('Cesium播放器模板必须恰好包含一个数据占位符。')
    destination = Path(output_path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(template.replace('__CESIUM_FUSION_DATA__', encoded), encoding='utf-8')
    czml_path = destination.with_name('cesium_tracks.czml')
    czml_path.write_text(json.dumps(build_cesium_czml(result, payload), ensure_ascii=False, indent=2), encoding='utf-8')
    manifest = {'offline': True, 'cesium_version': payload['cesiumVersion'], 'player': destination.name, 'czml': czml_path.name, 'network_origin': 'http://127.0.0.1:<dynamic-port>', 'online_services_enabled': False, 'bundled_basemap': 'Cesium NaturalEarthII', 'imagery': payload['map']['imagery'], 'height_datum': payload['heightDatum']}
    destination.with_name('cesium_player_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    return destination

def _safe_static_path(root: Path, relative_url: str) -> Path | None:
    try:
        candidate = (root / unquote(relative_url).lstrip('/')).resolve()
        candidate.relative_to(root.resolve())
    except (ValueError, OSError):
        return None
    return candidate if candidate.is_file() else None

def _create_cesium_player_server(player_path: str | Path, port: int=8766) -> tuple[ThreadingHTTPServer, str, Path]:
    destination = Path(player_path).expanduser().resolve()
    if not destination.is_file():
        raise FileNotFoundError(f'Cesium真实地图播放器不存在：{destination}')
    manifest_path = destination.with_name('cesium_player_manifest.json')
    version = CESIUM_VERSION
    manifest: dict = {}
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        version = str(manifest.get('cesium_version', version))
    cesium_root = _cesium_root(version)
    font_root = _font_root()
    output_root = destination.parent.resolve()
    encoded_name = quote(destination.name)
    requested_port = int(port)
    if not 0 <= requested_port <= 65535:
        raise ValueError('Cesium播放器端口必须在0到65535之间。')

    class CesiumRequestHandler(BaseHTTPRequestHandler):

        def _resource(self) -> tuple[Path | None, str]:
            path = urlsplit(self.path).path
            if path in {'/', f'/{encoded_name}'}:
                return (destination, 'no-store')
            if path.startswith('/cesium/'):
                return (_safe_static_path(cesium_root, path[len('/cesium/'):]), 'public, max-age=31536000, immutable')
            if path.startswith('/fonts/'):
                return (_safe_static_path(font_root, path[len('/fonts/'):]), 'public, max-age=31536000, immutable')
            if path.startswith('/result/'):
                return (_safe_static_path(output_root, path[len('/result/'):]), 'no-store')
            return (None, 'no-store')

        def _send(self, include_body: bool) -> None:
            path = urlsplit(self.path).path
            if path == '/favicon.ico':
                self.send_response(204)
                self.end_headers()
                return
            if path == '/api/offline-status':
                payload_bytes = json.dumps({'offline': True, 'cesiumVersion': version, 'onlineServicesEnabled': False, 'mapMode': 'bundled_natural_earth', 'mapAvailable': True, 'mapReason': '', 'mapMetadata': {'name': 'Cesium Natural Earth II', 'bundled': True}}, ensure_ascii=False).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(payload_bytes)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                if include_body:
                    self.wfile.write(payload_bytes)
                return
            (resource, cache) = self._resource()
            if resource is None:
                self.send_error(404, 'Offline Cesium resource not found.')
                return
            payload_bytes = resource.read_bytes()
            content_type = mimetypes.guess_type(resource.name)[0] or 'application/octet-stream'
            if resource.suffix.lower() == '.wasm':
                content_type = 'application/wasm'
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(payload_bytes)))
            self.send_header('Cache-Control', cache)
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
            self.end_headers()
            if include_body:
                self.wfile.write(payload_bytes)

        def do_GET(self) -> None:
            self._send(True)

        def do_HEAD(self) -> None:
            self._send(False)

        def log_message(self, format_string: str, *args: object) -> None:
            pass
    try:
        server = ThreadingHTTPServer(('127.0.0.1', requested_port), CesiumRequestHandler)
    except OSError:
        if requested_port == 0:
            raise
        server = ThreadingHTTPServer(('127.0.0.1', 0), CesiumRequestHandler)
    server.daemon_threads = True
    return (server, f'http://127.0.0.1:{server.server_port}/{encoded_name}', destination)

def serve_cesium_player(player_path: str | Path, port: int=8766, open_browser: bool=True) -> Path:
    (server, url, destination) = _create_cesium_player_server(player_path, port)
    print(f'cesium_player_url={url}')
    print('Cesium离线地图服务正在运行；关闭页面后在此终端按Ctrl+C停止。')
    if open_browser and (not webbrowser.open(url, new=2)):
        print(f'浏览器未能自动启动，请复制此地址打开：{url}')
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        print('\nCesium离线地图服务已停止。')
    finally:
        server.server_close()
    return destination
