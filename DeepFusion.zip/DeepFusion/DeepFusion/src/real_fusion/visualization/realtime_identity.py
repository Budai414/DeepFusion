from __future__ import annotations
import copy
from dataclasses import dataclass
import math
from typing import Dict, FrozenSet, List, Optional, Tuple
_EPS = 1e-06
_LAYERS = ('sourceSeries', 'swTracks', 'jointTracks')
TERMINAL_STATES = frozenset(('deleted', 'terminated', 'ended', 'finished', 'dead', 'closed', 'completed'))
_GENERATION_FIELDS = ('generationId', 'incarnationId', 'trackEpoch', 'generation')
Point = Tuple[float, float, float, float]

def _distance_m(a: Point, b: Point) -> float:
    (lon1, lat1, lon2, lat2) = map(math.radians, (a[1], a[2], b[1], b[2]))
    value = math.sin((lat2 - lat1) / 2.0) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2.0) ** 2
    surface = 2.0 * 6371008.8 * math.asin(math.sqrt(min(1.0, max(0.0, value))))
    return math.hypot(surface, b[3] - a[3])

def _at(points: Tuple[Point, ...], timestamp: float) -> Point:
    if timestamp <= points[0][0]:
        return points[0]
    for (before, after) in zip(points, points[1:]):
        if timestamp <= after[0]:
            fraction = (timestamp - before[0]) / max(_EPS, after[0] - before[0])
            lon_delta = (after[1] - before[1] + 180.0) % 360.0 - 180.0
            return (timestamp, before[1] + fraction * lon_delta, before[2] + fraction * (after[2] - before[2]), before[3] + fraction * (after[3] - before[3]))
    return points[-1]

@dataclass(frozen=True)
class _Observation:
    lineage: FrozenSet[str]
    points: Tuple[Point, ...]
    generation: Tuple[Tuple[str, str], ...]
    closed_at: Optional[float]
    epoch_start: Optional[float]

@dataclass(frozen=True)
class _Record:
    key: str
    observation: _Observation
    last_seen: int

def _observe(item: dict, layer: str) -> _Observation:
    values = item.get('positions', []) if layer == 'sourceSeries' else [state.get('position', []) for state in item.get('states', [])]
    points_by_time: Dict[float, Point] = {}
    for raw in values:
        try:
            point = tuple((float(value) for value in raw[:4]))
        except (ValueError, TypeError, OverflowError):
            continue
        if len(point) == 4 and all((math.isfinite(value) for value in point)):
            points_by_time[point[0]] = point
    points = tuple((points_by_time[key] for key in sorted(points_by_time)))
    if len(points) > 64:
        indices = sorted({round(index * (len(points) - 1) / 63) for index in range(64)})
        points = tuple((points[index] for index in indices))
    lineage = frozenset((str(value) for value in item.get('lineageKeys', []) if value is not None and str(value) and (not str(value).startswith('fallback:'))))
    generation = tuple(((field, str(item[field])) for field in _GENERATION_FIELDS if item.get(field) is not None))
    terminals = []
    for state in item.get('states', []):
        if str(state.get('lifecycle', '')).lower() in TERMINAL_STATES:
            try:
                timestamp = float(state['position'][0])
            except (KeyError, IndexError, ValueError, TypeError, OverflowError):
                continue
            if math.isfinite(timestamp):
                terminals.append(timestamp)
    latest = points[-1][0] if points else float('-inf')
    if str(item.get('lifecycle', '')).lower() in TERMINAL_STATES and points:
        terminals.append(latest)
    closed_at = latest if any((abs(value - latest) <= _EPS for value in terminals)) else None
    interior = [value for value in terminals if value < latest - _EPS]
    return _Observation(lineage, points, generation, closed_at, max(interior) if interior else None)

class RealtimeDisplayIdentity:

    def __init__(self, *, maximum_gap_s: float=30.0, maximum_speed_mps: float=1200.0, maximum_jump_m: float=20000.0, maximum_overlap_distance_m: float=2000.0, maximum_records: int=4096, maximum_missing_snapshots: int=120, retain_missing: bool=False) -> None:
        self.maximum_gap_s = max(0.0, float(maximum_gap_s))
        self.maximum_speed_mps = max(0.0, float(maximum_speed_mps))
        self.maximum_jump_m = max(0.0, float(maximum_jump_m))
        self.maximum_overlap_distance_m = max(0.0, float(maximum_overlap_distance_m))
        self.maximum_records = max(1, int(maximum_records))
        self.maximum_missing_snapshots = max(1, int(maximum_missing_snapshots))
        self.retain_missing = bool(retain_missing)
        self._records: Dict[str, Dict[str, _Record]] = {layer: {} for layer in _LAYERS}
        self._sequence = 0
        self._revision = 0

    def clear(self) -> None:
        self._records = {layer: {} for layer in _LAYERS}
        self._revision = 0

    def _compatible(self, before: _Observation, after: _Observation) -> bool:
        if not before.points or not after.points or (not before.lineage.intersection(after.lineage)):
            return False
        if before.generation and after.generation and (before.generation != after.generation):
            return False
        if before.closed_at is not None and after.points[-1][0] > before.closed_at + _EPS:
            return False
        if after.epoch_start is not None and (before.epoch_start is None or after.epoch_start > before.epoch_start + _EPS):
            return False
        overlap_start = max(before.points[0][0], after.points[0][0])
        overlap_stop = min(before.points[-1][0], after.points[-1][0])
        if overlap_start <= overlap_stop + _EPS:
            probes = (overlap_start, (overlap_start + overlap_stop) / 2.0, overlap_stop)
            return all((_distance_m(_at(before.points, timestamp), _at(after.points, timestamp)) <= self.maximum_overlap_distance_m for timestamp in probes))
        gap = after.points[0][0] - before.points[-1][0]
        if gap <= _EPS or (self.maximum_gap_s > 0 and gap > self.maximum_gap_s):
            return False
        distance = _distance_m(before.points[-1], after.points[0])
        return (self.maximum_jump_m <= 0 or distance <= self.maximum_jump_m) and (self.maximum_speed_mps <= 0 or distance <= self.maximum_speed_mps * gap)

    def resolve(self, data: dict) -> dict:
        resolved = copy.deepcopy(data)
        self._revision += 1
        retired = set()
        counts = {'continued': 0, 'new': 0, 'ambiguous': 0, 'missingLineage': 0}
        for layer in _LAYERS:
            items = [copy.deepcopy(item) for item in resolved.get(layer, [])]
            resolved[layer] = items
            observations = [_observe(item, layer) for item in items]
            previous = self._records[layer]
            latest = max((observation.points[-1][0] for observation in observations if observation.points), default=float('-inf'))
            for (key, record) in list(previous.items()):
                if not record.observation.lineage:
                    retired.add(key)
                    del previous[key]
            by_lineage: Dict[str, set] = {}
            for (key, record) in previous.items():
                for lineage in record.observation.lineage:
                    by_lineage.setdefault(lineage, set()).add(key)
            relations: List[set] = []
            candidates: List[set] = []
            consumers: Dict[str, set] = {}
            for (index, observation) in enumerate(observations):
                related = set().union(*(by_lineage.get(value, set()) for value in observation.lineage)) if observation.lineage else set()
                compatible = {key for key in related if self._compatible(previous[key].observation, observation)}
                relations.append(related)
                candidates.append(compatible)
                for key in compatible:
                    consumers.setdefault(key, set()).add(index)
            assigned = set()
            updated: Dict[str, _Record] = {}
            for (index, (item, observation)) in enumerate(zip(items, observations)):
                compatible = candidates[index]
                unique_key = next(iter(compatible)) if len(compatible) == 1 else None
                if unique_key is not None and len(consumers[unique_key]) == 1:
                    key = unique_key
                    reason = 'lineage_temporal_continuation'
                    counts['continued'] += 1
                    old_observation = previous[key].observation
                    observation = _Observation(observation.lineage, observation.points, observation.generation or old_observation.generation, observation.closed_at if observation.closed_at is not None else old_observation.closed_at, observation.epoch_start if observation.epoch_start is not None else old_observation.epoch_start)
                else:
                    self._sequence += 1
                    key = f'DISPLAY-{layer}-{self._sequence:08d}'
                    reason = 'ambiguous_lineage_transition' if compatible else 'new_display_episode'
                    counts['new'] += 1
                    if compatible:
                        counts['ambiguous'] += 1
                    if not observation.lineage:
                        counts['missingLineage'] += 1
                    for old_key in relations[index]:
                        old_points = previous[old_key].observation.points
                        if observation.points and old_points and (observation.points[-1][0] >= old_points[-1][0] - _EPS):
                            retired.add(old_key)
                item['realtimeKey'] = key
                item['realtimeIdentityReason'] = reason
                assigned.add(key)
                updated[key] = _Record(key, observation, self._revision)
            retired.difference_update(assigned)
            previous = {key: record for (key, record) in previous.items() if key not in retired and key not in assigned}
            previous.update(updated)
            if not self.retain_missing:
                for (key, record) in list(previous.items()):
                    if key in assigned:
                        continue
                    too_old = self.maximum_gap_s > 0 and record.observation.points and (latest - record.observation.points[-1][0] > self.maximum_gap_s)
                    if too_old or self._revision - record.last_seen > self.maximum_missing_snapshots:
                        retired.add(key)
                        del previous[key]
            dormant = [key for key in previous if key not in assigned]
            if len(dormant) > self.maximum_records:
                oldest = sorted(dormant, key=lambda key: (previous[key].last_seen, key))
                for key in oldest[:len(dormant) - self.maximum_records]:
                    del previous[key]
                    retired.add(key)
            self._records[layer] = previous
        resolved['retiredRealtimeKeys'] = sorted(retired)
        resolved['realtimeIdentityDiagnostics'] = {**counts, 'retired': len(retired), 'cachedRecords': sum((len(records) for records in self._records.values())), 'fusionDataModified': False, 'unmarkedNumberReuseIsUnobservable': True}
        return resolved
