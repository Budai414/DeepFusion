from __future__ import annotations
import math
from typing import Dict, Iterable, Sequence, Tuple
DEFAULT_PADDING_RATIO_ENU = (0.08, 0.08, 0.12)
DEFAULT_MINIMUM_SPAN_ENU_M = (30.0, 30.0, 15.0)

def adaptive_axis_bounds(points: Iterable[Sequence[float]], padding_ratio: Sequence[float]=DEFAULT_PADDING_RATIO_ENU, minimum_span: Sequence[float]=DEFAULT_MINIMUM_SPAN_ENU_M) -> Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float]]:
    if len(padding_ratio) != 3 or len(minimum_span) != 3:
        raise ValueError('padding_ratio 和 minimum_span 都必须包含 E、N、U 三个值。')
    if any((float(value) < 0.0 for value in padding_ratio)):
        raise ValueError('坐标轴留白比例不能为负数。')
    if any((float(value) <= 0.0 for value in minimum_span)):
        raise ValueError('坐标轴最小跨度必须大于 0。')
    values = [[], [], []]
    for point in points:
        if len(point) < 3:
            continue
        coordinates = tuple((float(point[index]) for index in range(3)))
        if not all((math.isfinite(value) for value in coordinates)):
            continue
        for (index, value) in enumerate(coordinates):
            values[index].append(value)
    if not all(values):
        return tuple(((-float(span) / 2.0, float(span) / 2.0) for span in minimum_span))
    bounds = []
    for (index, axis_values) in enumerate(values):
        low = min(axis_values)
        high = max(axis_values)
        center = (low + high) / 2.0
        effective_span = max(high - low, float(minimum_span[index]))
        half_span = effective_span * (0.5 + float(padding_ratio[index]))
        bounds.append((center - half_span, center + half_span))
    return tuple(bounds)

def adaptive_axes_settings(config: dict) -> tuple[tuple[float, ...], tuple[float, ...]]:
    settings = config.get('visualization', {}).get('adaptive_axes', {})
    padding = tuple((float(value) for value in settings.get('padding_ratio_enu', DEFAULT_PADDING_RATIO_ENU)))
    minimum = tuple((float(value) for value in settings.get('minimum_span_enu_m', DEFAULT_MINIMUM_SPAN_ENU_M)))
    return (padding, minimum)

def bounds_as_player_dict(points: Iterable[Sequence[float]], padding_ratio: Sequence[float]=DEFAULT_PADDING_RATIO_ENU, minimum_span: Sequence[float]=DEFAULT_MINIMUM_SPAN_ENU_M) -> Dict[str, float]:
    (east, north, up) = adaptive_axis_bounds(points, padding_ratio, minimum_span)
    return {'eastMin': east[0], 'eastMax': east[1], 'northMin': north[0], 'northMax': north[1], 'upMin': up[0], 'upMax': up[1]}
