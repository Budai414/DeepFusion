from __future__ import annotations
import json
import os
import queue
import subprocess
import sys
import threading
import traceback
import webbrowser
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Sequence
import numpy as np
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from real_fusion.config import load_config, load_kafka_config
from real_fusion.font_support import configure_matplotlib_fonts, configure_tk_fonts
from real_fusion.ew import combine_ew_read_results, read_ew_file
from real_fusion.evaluation.metrics import compute_metrics
from real_fusion.geometry import GeodeticConverter
from real_fusion.pipeline import ExperimentResult, TargetFusionStatus, run_sw_experiment
from real_fusion.realtime import DemoRealtimeBridge, KafkaRealtimeBridge, RealtimeFusionService, RealtimeSnapshot, build_excel_realtime_messages, build_realtime_demo_messages, configure_realtime_demo
from real_fusion.runtime_paths import deepfusion_project_root
from real_fusion.runner import execute_sw, execute_sw_ew, save_experiment
from real_fusion.sw import SwReadResult, combine_sw_read_results, parse_time_range, read_sw_file
from real_fusion.visualization.bounds import adaptive_axis_bounds, adaptive_axes_settings
from real_fusion.visualization.colors import FUSED_TRACK_COLOR, build_source_color_map, build_target_color_map
from real_fusion.visualization.player import _create_fusion_player_server
from real_fusion.visualization.cesium_player import _create_cesium_player_server
from real_fusion.visualization.realtime_map import RealtimeCesiumMapServer

@dataclass(frozen=True)
class _GuiEvent:
    payload: object
    result_generation: Optional[int] = None
    realtime_generation: Optional[int] = None

def _open_local_path(path: Path) -> None:
    resolved = path.resolve()
    if os.name == 'nt':
        os.startfile(str(resolved))
        return
    command = 'open' if sys.platform == 'darwin' else 'xdg-open'
    subprocess.Popen([command, str(resolved)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
configure_matplotlib_fonts()
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
PROJECT_ROOT = deepfusion_project_root(__file__)
SW_FILE_TYPES = [('SW Excel 文件', '*.xls *.xlsx *.xlsm'), ('Excel 97-2003', '*.xls'), ('Excel 工作簿', '*.xlsx *.xlsm'), ('所有文件', '*.*')]
START_MARKER_COLOR = '#16a34a'
END_MARKER_COLOR = '#dc2626'
MAX_GUI_POINTS_PER_SERIES = 2500
MAX_GUI_TOTAL_POINTS = 40000
ALL_TARGETS_LABEL = '全部目标（总览）'
ALL_SOURCES_LABEL = '全部装备 / 全部MBY'
HETEROGENEOUS_FUSION_DEVICE_OPTION = '__heterogeneous_fusion__'
HETEROGENEOUS_FUSION_DEVICE_LABEL = '异构设备融合（已融合）'
TARGET_STATUS_COLORS = {'cross_sensor_over_gate': ('#7c2d12', '#ffedd5'), 'unformed_false_alarm': ('#991b1b', '#fee2e2'), 'source_time_not_overlapping': ('#854d0e', '#fef9c3'), 'fusion_not_formed': ('#6b21a8', '#f3e8ff'), 'single_source_passthrough': ('#166534', '#dcfce7'), 'multi_source_fused': ('#1e3a8a', '#dbeafe')}

@dataclass(frozen=True, order=True)
class PlotSourceOption:
    data_kind: str
    zbb: str
    local_mby: str
    target_id: str

    @property
    def device_key(self) -> tuple[str, str]:
        return (self.data_kind, self.zbb)

    @property
    def source_key(self) -> tuple[str, str, str]:
        return (self.data_kind, self.zbb, self.local_mby)

@dataclass(frozen=True, order=True)
class PlotFusionGroupOption:
    target_id: str
    track_id: str
    members: tuple[PlotSourceOption, ...]

def _visible_plot_source_options(available: Sequence[PlotSourceOption], selected_devices: set[tuple[str, str]], selected_sources: set[tuple[str, str, str]], selected_targets: Optional[set[str]]=None) -> List[PlotSourceOption]:
    target_filtered = [item for item in available if not selected_targets or item.target_id in selected_targets]
    device_filtered = [item for item in target_filtered if not selected_devices or item.device_key in selected_devices]
    available_source_keys = {item.source_key for item in device_filtered}
    effective_sources = selected_sources & available_source_keys
    if not effective_sources:
        return device_filtered
    return [item for item in device_filtered if item.source_key in effective_sources]

def _multi_source_fused_target_ids(statuses: Dict[str, TargetFusionStatus]) -> set[str]:
    return {str(target_id) for (target_id, status) in statuses.items() if status.classification == 'multi_source_fused' and len({str(zbb) for zbb in status.valid_zbb_values}) >= 2}

def _build_fusion_group_options(available: Sequence[PlotSourceOption], statuses: Dict[str, TargetFusionStatus]) -> List[PlotFusionGroupOption]:
    fused_target_ids = _multi_source_fused_target_ids(statuses)
    groups = []
    for target_id in sorted(fused_target_ids):
        members = tuple(sorted((item for item in available if item.target_id == target_id)))
        if not members:
            continue
        status = statuses[target_id]
        groups.append(PlotFusionGroupOption(target_id=target_id, track_id=str(status.track_id or target_id), members=members))
    return groups

def _build_track_color_maps(target_ids: Sequence[object], source_keys: Sequence[tuple[str, str, str, str]]) -> tuple[Dict[str, str], Dict[tuple[str, str, str, str], str]]:
    normalized_targets = sorted({str(value) for value in target_ids})
    normalized_sources = sorted({tuple((str(part) for part in source_key)) for source_key in source_keys})
    source_tokens = {source_key: 'SOURCE::' + json.dumps(source_key, ensure_ascii=False, separators=(',', ':')) for source_key in normalized_sources}
    palette = build_source_color_map(source_tokens.values())
    return ({target_id: FUSED_TRACK_COLOR for target_id in normalized_targets}, {source_key: palette[token] for (source_key, token) in source_tokens.items()})

def _format_detection_frequencies(frame) -> str:
    summaries = []
    for ((target_id, zbb), group) in frame.groupby(['_mby', '_zbb'], sort=True):
        times = np.unique(group['_epoch_s'].to_numpy(dtype=float))
        intervals = np.diff(times)
        intervals = intervals[np.isfinite(intervals) & (intervals > 0.0)]
        prefix = f'装备={zbb}/局部MBY={target_id}'
        if not len(intervals):
            summaries.append(f'{prefix}:不足2个唯一时戳')
            continue
        median_interval = float(np.median(intervals))
        summaries.append(f'{prefix}:{1.0 / median_interval:.3f}Hz(Δt中位数{median_interval:.3f}s)')
    return '；'.join(summaries) if summaries else '无有效目标/装备数据'

def build_zbb_analysis(read_result: SwReadResult, config: dict) -> List[Dict[str, object]]:
    del config
    if read_result.file_summaries:
        records = []
        for summary in read_result.file_summaries:
            source_path = str(summary['source_path'])
            file_frame = read_result.frame.loc[read_result.frame['_source_file'].astype(str) == source_path]
            local_pairs = sorted({(str(zbb), str(mby)) for (mby, zbb) in file_frame[['_mby', '_zbb']].itertuples(index=False, name=None)})
            records.append({'source_file': str(summary['source_file']), 'source_path': source_path, 'read_rows': int(summary['valid_rows']), 'target_count': len(local_pairs), 'target_values': '、'.join((f'装备={zbb}/MBY={mby}' for (zbb, mby) in local_pairs)), 'zbb_count': int(summary['zbb_count']), 'zbb_values': str(summary['zbb_values']), 'frequency_summary': _format_detection_frequencies(file_frame)})
        if len(read_result.file_summaries) > 1:
            local_pairs = sorted({(str(zbb), str(mby)) for (mby, zbb) in read_result.frame[['_mby', '_zbb']].itertuples(index=False, name=None)})
            records.append({'source_file': '全部分卷（合并）', 'source_path': '', 'read_rows': read_result.valid_rows, 'target_count': len(local_pairs), 'target_values': '、'.join((f'装备={zbb}/MBY={mby}' for (zbb, mby) in local_pairs)), 'zbb_count': len(read_result.device_values), 'zbb_values': '、'.join(sorted(read_result.device_values)), 'frequency_summary': _format_detection_frequencies(read_result.frame)})
        return records
    zbb_values = sorted(read_result.device_values)
    local_pairs = sorted({(str(zbb), str(mby)) for (mby, zbb) in read_result.frame[['_mby', '_zbb']].itertuples(index=False, name=None)})
    return [{'source_file': read_result.path.name, 'source_path': str(read_result.path), 'read_rows': read_result.valid_rows, 'target_count': len(local_pairs), 'target_values': '、'.join((f'装备={zbb}/MBY={mby}' for (zbb, mby) in local_pairs)), 'zbb_count': len(zbb_values), 'zbb_values': '、'.join(zbb_values), 'frequency_summary': _format_detection_frequencies(read_result.frame)}]

def build_ew_analysis(read_result) -> List[Dict[str, object]]:
    records = []
    for summary in read_result.file_summaries:
        file_frame = read_result.frame.loc[read_result.frame['_source_file'].astype(str) == str(summary['source_path'])]
        local_pairs = sorted({(str(zbb), str(mby)) for (mby, zbb) in file_frame[['_mby', '_zbb']].itertuples(index=False, name=None)})
        records.append({'source_file': f"EW｜{summary['source_file']}", 'source_path': str(summary['source_path']), 'read_rows': int(summary['valid_rows']), 'target_count': len(local_pairs), 'target_values': '、'.join((f'装备={zbb}/MBY={mby}' for (zbb, mby) in local_pairs)), 'zbb_count': int(summary['zbb_count']), 'zbb_values': str(summary['zbb_values']), 'frequency_summary': _format_detection_frequencies(file_frame)})
    return records

def _sample_indices(count: int, maximum: int=MAX_GUI_POINTS_PER_SERIES) -> np.ndarray:
    if count <= maximum:
        return np.arange(count, dtype=int)
    return np.unique(np.linspace(0, count - 1, maximum, dtype=int))

def _normalize_plot_target_selection(available_targets: Sequence[str], selected_targets: Sequence[str]) -> set[str]:
    available = {str(value) for value in available_targets}
    selected = {str(value) for value in selected_targets} & available
    return set() if not selected or selected == available else selected

def _format_target_option_label(target_id: str, status: Optional[TargetFusionStatus]=None) -> str:
    return str(target_id) if status is None else f'{target_id}（{status.display_status}）'

class RealFusionApp:

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title('RealFusion 多设备航迹分析与融合')
        self.root.geometry('1440x900')
        self.root.minsize(1120, 720)
        self.root.protocol('WM_DELETE_WINDOW', self._close)
        (self.ui_font_family, self.mono_font_family) = configure_tk_fonts(self.root)
        self.input_paths: List[Path] = []
        self.ew_input_paths: List[Path] = []
        self.analyzed_results: Dict[str, SwReadResult] = {}
        self.current_result: Optional[ExperimentResult] = None
        self.current_analysis_result: Optional[ExperimentResult] = None
        self.current_analysis_signature: Optional[tuple] = None
        self._fusion_statuses_released = False
        self.current_preview: Optional[SwReadResult] = None
        self.current_preview_statuses: Dict[str, TargetFusionStatus] = {}
        self.current_metrics: Optional[dict] = None
        self.current_output: Optional[Path] = None
        self._plot_context = 'empty'
        self._worker: Optional[threading.Thread] = None
        self._events: queue.Queue[tuple[str, object]] = queue.Queue()
        self._player_server = None
        self._realtime_service: Optional[RealtimeFusionService] = None
        self._kafka_bridge: Optional[KafkaRealtimeBridge | DemoRealtimeBridge] = None
        self._realtime_map_server: Optional[RealtimeCesiumMapServer] = None
        self._realtime_active_transport: Optional[str] = None
        self._realtime_replay_context: Optional[dict] = None
        self._realtime_export_thread: Optional[threading.Thread] = None
        self._realtime_generation = 0
        self._result_generation = 0
        self._realtime_export_generation: Optional[int] = None
        self._realtime_export_lock = threading.Lock()
        self._realtime_stopping = False
        self._realtime_completed = False
        self._realtime_stop_failed = False
        self._realtime_status_error = None
        self._realtime_stop_worker: Optional[threading.Thread] = None
        self._close_requested = False
        self._closing = False
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.config_var = tk.StringVar(value=str(PROJECT_ROOT / 'configs' / 'real_sw.yaml'))
        self.kafka_config_var = tk.StringVar(value=str(PROJECT_ROOT / 'configs' / 'kafka.yaml'))
        self.output_var = tk.StringVar(value=str(PROJECT_ROOT / 'output' / 'gui_runs' / timestamp))
        self.start_time_var = tk.StringVar()
        self.end_time_var = tk.StringVar()
        self.status_var = tk.StringVar(value='就绪：请选择一个或多个 SW 文件')
        self.realtime_host_var = tk.StringVar(value='127.0.0.1')
        self.realtime_transport_var = tk.StringVar(value='Kafka')
        self.realtime_sw_port_var = tk.StringVar(value='19001')
        self.realtime_ew_port_var = tk.StringVar(value='19002')
        self.realtime_status_var = tk.StringVar(value='实时服务未启动')
        self.realtime_input_hint_var = tk.StringVar()
        self.plot_target_summary_var = tk.StringVar(value=ALL_SOURCES_LABEL)
        self.plot_mode_var = tk.StringVar(value='SW融合')
        self.available_plot_targets: List[str] = []
        self.available_plot_sources: List[PlotSourceOption] = []
        self.plot_target_statuses: Dict[str, TargetFusionStatus] = {}
        self.plot_targets_by_source: Dict[tuple[str, str, str], set[str]] = {}
        self.plot_targets_by_device: Dict[tuple[str, str], set[str]] = {}
        self.selected_plot_devices: set[tuple[str, str]] = set()
        self.selected_plot_sources: set[tuple[str, str, str]] = set()
        self.selected_plot_fusion_targets: set[str] = set()
        self._target_selector_window: Optional[tk.Toplevel] = None
        self._configure_style()
        self._build_layout()
        self._draw_empty_plot()
        self.root.after(100, self._drain_events)

    def _configure_style(self) -> None:
        style = ttk.Style(self.root)
        available = style.theme_names()
        if 'vista' in available:
            style.theme_use('vista')
        style.configure('TLabel', font=(self.ui_font_family, 10, 'normal'))
        style.configure('TButton', font=(self.ui_font_family, 10, 'normal'))
        style.configure('TCheckbutton', font=(self.ui_font_family, 10, 'normal'))
        style.configure('TRadiobutton', font=(self.ui_font_family, 10, 'normal'))
        style.configure('TLabelframe.Label', font=(self.ui_font_family, 10, 'bold'))
        style.configure('Title.TLabel', font=(self.ui_font_family, 16, 'bold'))
        style.configure('Sub.TLabel', foreground='#475569')
        style.configure('Accent.TButton', font=(self.ui_font_family, 10, 'bold'))
        style.configure('Treeview', rowheight=26, font=(self.ui_font_family, 9, 'normal'))
        style.configure('Treeview.Heading', font=(self.ui_font_family, 9, 'bold'))

    def _build_layout(self) -> None:
        header = ttk.Frame(self.root, padding=(14, 10, 14, 8))
        header.pack(fill='x')
        ttk.Label(header, text='RealFusion 多设备航迹分析与融合', style='Title.TLabel').pack(anchor='w')
        ttk.Label(header, text='SW 主航迹 · EW 异步角度/可选距离约束 · 多目标 PDA/IMM-UKF 联合融合', style='Sub.TLabel').pack(anchor='w', pady=(3, 0))
        pane = ttk.Panedwindow(self.root, orient='horizontal')
        pane.pack(fill='both', expand=True, padx=12, pady=(0, 8))
        controls_shell = ttk.Frame(pane, width=405)
        workspace = ttk.Frame(pane, padding=(6, 8, 8, 8))
        pane.add(controls_shell, weight=0)
        pane.add(workspace, weight=1)
        controls = self._build_controls_scroller(controls_shell)
        self._build_controls(controls)
        self._build_workspace(workspace)
        status = ttk.Frame(self.root, padding=(14, 4, 14, 10))
        status.pack(fill='x')
        self.progress = ttk.Progressbar(status, mode='indeterminate', length=180)
        self.progress.pack(side='right')
        ttk.Label(status, textvariable=self.status_var).pack(side='left', fill='x', expand=True)

    def _build_controls_scroller(self, parent: ttk.Frame) -> ttk.Frame:
        parent.rowconfigure(0, weight=1)
        parent.columnconfigure(0, weight=1)
        self.controls_canvas = tk.Canvas(parent, highlightthickness=0, borderwidth=0)
        controls_scroll = ttk.Scrollbar(parent, orient='vertical', command=self.controls_canvas.yview)
        self.controls_canvas.configure(yscrollcommand=controls_scroll.set)
        self.controls_canvas.grid(row=0, column=0, sticky='nsew')
        controls_scroll.grid(row=0, column=1, sticky='ns')
        controls = ttk.Frame(self.controls_canvas, padding=(8, 8, 10, 16))
        controls_window = self.controls_canvas.create_window((0, 0), window=controls, anchor='nw')

        def resize_scroll_region(_event=None) -> None:
            self.controls_canvas.configure(scrollregion=self.controls_canvas.bbox('all'))

        def resize_controls(event) -> None:
            self.controls_canvas.itemconfigure(controls_window, width=event.width)
        controls.bind('<Configure>', resize_scroll_region)
        self.controls_canvas.bind('<Configure>', resize_controls)
        self.root.bind('<MouseWheel>', self._scroll_controls_with_wheel, add='+')
        return controls

    def _scroll_controls_with_wheel(self, event) -> Optional[str]:
        widget = event.widget
        if isinstance(widget, (tk.Listbox, tk.Text, ttk.Treeview, ttk.Combobox)):
            return None
        if not str(widget).startswith(str(self.controls_canvas)) or not event.delta:
            return None
        self.controls_canvas.yview_scroll(-3 if event.delta > 0 else 3, 'units')
        return 'break'

    def _build_controls(self, parent: ttk.Frame) -> None:
        realtime = ttk.LabelFrame(parent, text='0. 实时接收（与离线文件模式并存）', padding=9)
        realtime.pack(fill='x')
        transport_row = ttk.Frame(realtime)
        transport_row.pack(fill='x')
        ttk.Label(transport_row, text='输入方式', width=8).pack(side='left')
        self.realtime_transport_combo = ttk.Combobox(transport_row, textvariable=self.realtime_transport_var, values=('Kafka', 'TCP JSONL', 'Excel实时回放', '本地实时演示'), state='readonly', width=12)
        self.realtime_transport_combo.pack(side='left')
        self.realtime_transport_combo.bind('<<ComboboxSelected>>', self._on_realtime_transport_changed)
        kafka_row = ttk.Frame(realtime)
        kafka_row.pack(fill='x', pady=(6, 0))
        ttk.Label(kafka_row, text='Kafka配置', width=8).pack(side='left')
        self.kafka_config_entry = ttk.Entry(kafka_row, textvariable=self.kafka_config_var)
        self.kafka_config_entry.pack(side='left', fill='x', expand=True)
        self.kafka_config_button = ttk.Button(kafka_row, text='浏览', width=6, command=self._choose_kafka_config)
        self.kafka_config_button.pack(side='left', padx=(5, 0))
        host_row = ttk.Frame(realtime)
        host_row.pack(fill='x', pady=(6, 0))
        ttk.Label(host_row, text='监听地址', width=8).pack(side='left')
        self.realtime_host_entry = ttk.Entry(host_row, textvariable=self.realtime_host_var, width=14)
        self.realtime_host_entry.pack(side='left', fill='x', expand=True)
        port_row = ttk.Frame(realtime)
        port_row.pack(fill='x', pady=(6, 0))
        ttk.Label(port_row, text='SW端口', width=8).pack(side='left')
        self.realtime_sw_port_entry = ttk.Entry(port_row, textvariable=self.realtime_sw_port_var, width=8)
        self.realtime_sw_port_entry.pack(side='left')
        ttk.Label(port_row, text='EW端口', padding=(10, 0, 4, 0)).pack(side='left')
        self.realtime_ew_port_entry = ttk.Entry(port_row, textvariable=self.realtime_ew_port_var, width=8)
        self.realtime_ew_port_entry.pack(side='left')
        realtime_buttons = ttk.Frame(realtime)
        realtime_buttons.pack(fill='x', pady=(7, 0))
        self.start_realtime_button = ttk.Button(realtime_buttons, text='启动实时接收与融合', command=self._start_realtime, style='Accent.TButton')
        self.start_realtime_button.pack(side='left', fill='x', expand=True)
        self.stop_realtime_button = ttk.Button(realtime_buttons, text='停止', command=self._stop_realtime, state='disabled')
        self.stop_realtime_button.pack(side='left', padx=(6, 0))
        ttk.Label(realtime, textvariable=self.realtime_status_var, wraplength=350, foreground='#475569').pack(fill='x', pady=(6, 0))
        ttk.Label(realtime, textvariable=self.realtime_input_hint_var, wraplength=350, foreground='#64748b').pack(fill='x', pady=(3, 0))
        self._refresh_realtime_input_state()
        files = ttk.LabelFrame(parent, text='1. SW 输入文件（支持多选）', padding=9)
        files.pack(fill='both', expand=False)
        list_frame = ttk.Frame(files)
        list_frame.pack(fill='both', expand=True)
        self.file_list = tk.Listbox(list_frame, height=9, selectmode='extended', font=(self.ui_font_family, 9, 'normal'), activestyle='dotbox')
        file_scroll = ttk.Scrollbar(list_frame, orient='vertical', command=self.file_list.yview)
        self.file_list.configure(yscrollcommand=file_scroll.set)
        self.file_list.bind('<<ListboxSelect>>', self._on_file_selected)
        self.file_list.pack(side='left', fill='both', expand=True)
        file_scroll.pack(side='right', fill='y')
        button_row = ttk.Frame(files)
        button_row.pack(fill='x', pady=(8, 0))
        self.add_button = ttk.Button(button_row, text='选择/追加文件', command=self._choose_files)
        self.add_button.pack(side='left', expand=True, fill='x')
        self.remove_button = ttk.Button(button_row, text='移除选中', command=self._remove_selected)
        self.remove_button.pack(side='left', expand=True, fill='x', padx=5)
        self.clear_button = ttk.Button(button_row, text='清空', command=self._clear_files)
        self.clear_button.pack(side='left', expand=True, fill='x')
        ew_files = ttk.LabelFrame(parent, text='1B. EW 输入文件（可选，支持多选）', padding=9)
        ew_files.pack(fill='both', expand=False, pady=(10, 0))
        ew_list_frame = ttk.Frame(ew_files)
        ew_list_frame.pack(fill='both', expand=True)
        self.ew_file_list = tk.Listbox(ew_list_frame, height=5, selectmode='extended', font=(self.ui_font_family, 9, 'normal'), activestyle='dotbox')
        ew_scroll = ttk.Scrollbar(ew_list_frame, orient='vertical', command=self.ew_file_list.yview)
        self.ew_file_list.configure(yscrollcommand=ew_scroll.set)
        self.ew_file_list.pack(side='left', fill='both', expand=True)
        ew_scroll.pack(side='right', fill='y')
        ew_buttons = ttk.Frame(ew_files)
        ew_buttons.pack(fill='x', pady=(8, 0))
        self.add_ew_button = ttk.Button(ew_buttons, text='选择/追加EW', command=self._choose_ew_files)
        self.add_ew_button.pack(side='left', expand=True, fill='x')
        self.remove_ew_button = ttk.Button(ew_buttons, text='移除选中', command=self._remove_selected_ew)
        self.remove_ew_button.pack(side='left', expand=True, fill='x', padx=5)
        self.clear_ew_button = ttk.Button(ew_buttons, text='清空EW', command=self._clear_ew_files)
        self.clear_ew_button.pack(side='left', expand=True, fill='x')
        settings = ttk.LabelFrame(parent, text='2. 配置和输出', padding=9)
        settings.pack(fill='x', pady=(10, 0))
        ttk.Label(settings, text='融合参数 YAML').pack(anchor='w')
        config_row = ttk.Frame(settings)
        config_row.pack(fill='x', pady=(3, 8))
        self.config_entry = ttk.Entry(config_row, textvariable=self.config_var)
        self.config_entry.pack(side='left', fill='x', expand=True)
        self.config_button = ttk.Button(config_row, text='浏览', width=6, command=self._choose_config)
        self.config_button.pack(side='left', padx=(5, 0))
        ttk.Label(settings, text='结果输出目录').pack(anchor='w')
        output_row = ttk.Frame(settings)
        output_row.pack(fill='x', pady=(3, 0))
        self.output_entry = ttk.Entry(output_row, textvariable=self.output_var)
        self.output_entry.pack(side='left', fill='x', expand=True)
        self.output_button = ttk.Button(output_row, text='浏览', width=6, command=self._choose_output)
        self.output_button.pack(side='left', padx=(5, 0))
        time_filter = ttk.LabelFrame(parent, text='3. 可选绝对时戳区间', padding=9)
        time_filter.pack(fill='x', pady=(10, 0))
        ttk.Label(time_filter, text='开始时戳（含）').pack(anchor='w')
        self.start_time_entry = ttk.Entry(time_filter, textvariable=self.start_time_var)
        self.start_time_entry.pack(fill='x', pady=(3, 6))
        ttk.Label(time_filter, text='结束时戳（含）').pack(anchor='w')
        self.end_time_entry = ttk.Entry(time_filter, textvariable=self.end_time_var)
        self.end_time_entry.pack(fill='x', pady=(3, 0))
        ttk.Label(time_filter, text='格式与绝对时戳列相同，例如 2026-08-13 12:00:00.000000；均留空=分析全部数据。', wraplength=350, foreground='#64748b').pack(fill='x', pady=(6, 0))
        actions = ttk.LabelFrame(parent, text='4. 分析与融合', padding=9)
        actions.pack(fill='x', pady=(10, 0))
        self.analyze_button = ttk.Button(actions, text='读取文件信息并分析局部MBY/装备编号', command=self._analyze_inputs)
        self.analyze_button.pack(fill='x')
        self.fuse_all_button = ttk.Button(actions, text='融合列表中的全部文件（默认）', command=self._run_all_fusion, style='Accent.TButton')
        self.fuse_all_button.pack(fill='x', pady=(6, 0))
        self.fuse_selected_button = ttk.Button(actions, text='融合选中的文件（可单选/多选）', command=self._run_selected_fusion)
        self.fuse_selected_button.pack(fill='x', pady=(6, 0))
        results = ttk.LabelFrame(parent, text='5. 结果操作', padding=9)
        results.pack(fill='x', pady=(10, 0))
        self.player_button = ttk.Button(results, text='打开 SW 动态三维回放', command=self._open_player, state='disabled')
        self.player_button.pack(fill='x')
        self.cesium_player_button = ttk.Button(results, text='打开 Cesium 离线真实地图回放', command=self._open_cesium_player, state='disabled')
        self.cesium_player_button.pack(fill='x', pady=(6, 0))
        self.summary_button = ttk.Button(results, text='打开融合总结文档', command=self._open_summary, state='disabled')
        self.summary_button.pack(fill='x', pady=(6, 0))
        self.folder_button = ttk.Button(results, text='打开结果目录', command=self._open_output, state='disabled')
        self.folder_button.pack(fill='x', pady=(6, 0))
        note = '说明：SW、EW 各自的多个文件均视为同一数据集的同表头分卷。SW 必选、EW 可选；绝对时戳区间同时作用于两类数据。EW 不要求与 SW 时戳完全相同。'
        ttk.Label(parent, text=note, wraplength=350, foreground='#64748b').pack(fill='x', pady=(10, 0))

    def _build_workspace(self, parent: ttk.Frame) -> None:
        self.notebook = ttk.Notebook(parent)
        self.notebook.pack(fill='both', expand=True)
        plot_tab = ttk.Frame(self.notebook)
        zbb_tab = ttk.Frame(self.notebook, padding=8)
        metrics_tab = ttk.Frame(self.notebook, padding=8)
        log_tab = ttk.Frame(self.notebook, padding=8)
        self.notebook.add(plot_tab, text='三维航迹')
        self.notebook.add(zbb_tab, text='文件、目标与装备概览')
        self.notebook.add(metrics_tab, text='融合指标')
        self.notebook.add(log_tab, text='运行日志')
        toolbar_frame = ttk.Frame(plot_tab)
        toolbar_frame.pack(side='bottom', fill='x')
        plot_body = ttk.Frame(plot_tab)
        plot_body.pack(side='top', fill='both', expand=True)
        self.figure = Figure(figsize=(8.4, 7.2), dpi=100)
        self.axis = self.figure.add_subplot(111, projection='3d')
        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_body)
        plot_body.rowconfigure(0, weight=1)
        plot_body.rowconfigure(1, weight=0)
        plot_body.columnconfigure(0, weight=1)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky='nsew')
        self.legend_panel = ttk.LabelFrame(plot_body, text='航迹图例（结果区右下角，滚轮/滚动条查看）', padding=5, width=610, height=170)
        self.legend_panel.grid(row=1, column=0, sticky='e', padx=8, pady=(4, 2))
        self.legend_panel.grid_propagate(False)
        legend_body = ttk.Frame(self.legend_panel)
        legend_body.grid(row=0, column=0, sticky='nsew')
        self.legend_panel.rowconfigure(0, weight=1)
        self.legend_panel.columnconfigure(0, weight=1)
        self.plot_legend = tk.Listbox(legend_body, selectmode='browse', activestyle='none', exportselection=False, font=(self.ui_font_family, 8, 'normal'), background='#ffffff')
        legend_y_scroll = ttk.Scrollbar(legend_body, orient='vertical', command=self.plot_legend.yview)
        legend_x_scroll = ttk.Scrollbar(legend_body, orient='horizontal', command=self.plot_legend.xview)
        self.plot_legend.configure(yscrollcommand=legend_y_scroll.set, xscrollcommand=legend_x_scroll.set)
        self.plot_legend.grid(row=0, column=0, sticky='nsew')
        legend_y_scroll.grid(row=0, column=1, sticky='ns')
        legend_x_scroll.grid(row=1, column=0, sticky='ew')
        legend_body.rowconfigure(0, weight=1)
        legend_body.columnconfigure(0, weight=1)
        self.plot_legend.bind('<MouseWheel>', self._scroll_plot_legend)
        self.toolbar = NavigationToolbar2Tk(self.canvas, toolbar_frame, pack_toolbar=False)
        self.toolbar.update()
        self.toolbar.pack(side='left', fill='x')
        ttk.Label(toolbar_frame, text='鼠标左键拖动旋转，滚轮缩放', foreground='#64748b').pack(side='right', padx=8)
        self.plot_mode_combo = ttk.Combobox(toolbar_frame, textvariable=self.plot_mode_var, values=('SW融合', 'EW单独', 'SW+EW联合'), state='readonly', width=12)
        self.plot_mode_combo.bind('<<ComboboxSelected>>', self._on_plot_mode_changed)
        self.plot_mode_combo.pack(side='right', padx=(6, 0))
        self.plot_target_button = ttk.Button(toolbar_frame, textvariable=self.plot_target_summary_var, command=self._open_plot_target_selector, state='disabled', width=28)
        self.plot_target_button.pack(side='right', padx=(4, 0))
        ttk.Label(toolbar_frame, text='装备/目标筛选（均可多选）').pack(side='right', padx=(8, 0))
        columns = ('file', 'rows', 'target_count', 'target_values', 'zbb_count', 'zbb_values', 'frequency')
        self.zbb_tree = ttk.Treeview(zbb_tab, columns=columns, show='headings')
        headings = {'file': '数据类型/文件', 'rows': '区间内分析条数', 'target_count': '装备内局部航迹数', 'target_values': '装备/局部MBY', 'zbb_count': '装备编号数量', 'zbb_values': '读取到的装备编号', 'frequency': '各装备/局部MBY探测频率（相邻唯一时戳中位数）'}
        widths = {'file': 190, 'rows': 90, 'target_count': 90, 'target_values': 230, 'zbb_count': 110, 'zbb_values': 260, 'frequency': 560}
        for name in columns:
            self.zbb_tree.heading(name, text=headings[name])
            self.zbb_tree.column(name, width=widths[name], anchor='center', stretch=name in {'file', 'target_values', 'zbb_values', 'frequency'})
        y_scroll = ttk.Scrollbar(zbb_tab, orient='vertical', command=self.zbb_tree.yview)
        x_scroll = ttk.Scrollbar(zbb_tab, orient='horizontal', command=self.zbb_tree.xview)
        self.zbb_tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
        self.zbb_tree.grid(row=0, column=0, sticky='nsew')
        y_scroll.grid(row=0, column=1, sticky='ns')
        x_scroll.grid(row=1, column=0, sticky='ew')
        zbb_tab.rowconfigure(0, weight=1)
        zbb_tab.columnconfigure(0, weight=1)
        self.metrics_text = ScrolledText(metrics_tab, wrap='none', font=(self.mono_font_family, 10, 'normal'))
        self.metrics_text.pack(fill='both', expand=True)
        self.metrics_text.insert('1.0', '完成融合后将在这里显示输入质量、目标编号、装备编号、频率和多航迹指标。')
        self.metrics_text.configure(state='disabled')
        self.log_text = ScrolledText(log_tab, wrap='word', font=(self.mono_font_family, 10, 'normal'))
        self.log_text.pack(fill='both', expand=True)
        self._append_log('RealFusion 图形界面已启动，全程可在离线环境运行。')

    def _on_realtime_transport_changed(self, _event=None) -> None:
        self._refresh_realtime_input_state()

    def _refresh_realtime_input_state(self) -> None:
        if not hasattr(self, 'kafka_config_entry') or self._realtime_service is not None:
            return
        transport = self.realtime_transport_var.get()
        kafka_state = 'normal' if transport in {'Kafka', 'Excel实时回放', '本地实时演示'} else 'disabled'
        tcp_state = 'normal' if transport == 'TCP JSONL' else 'disabled'
        self.kafka_config_entry.configure(state=kafka_state)
        self.kafka_config_button.configure(state=kafka_state)
        for widget in (self.realtime_host_entry, self.realtime_sw_port_entry, self.realtime_ew_port_entry):
            widget.configure(state=tcp_state)
        if transport == 'Kafka':
            self.realtime_input_hint_var.set('统一Kafka消费入口：既可接收本机excel-to-kafka回放命令发送的报文，也可同时接收其他机器向相同SW/EW Topic发送的同协议报文。')
        elif transport == 'TCP JSONL':
            self.realtime_input_hint_var.set('TCP JSONL模式使用监听地址和两个端口；Kafka配置不参与运行。')
        elif transport == 'Excel实时回放':
            self.realtime_input_hint_var.set('读取下方已选SW/EW Excel；每行转为[{宽对象}]实时数组，只识别Kafka配置的SW 38项/EW 37项，额外字段允许存在。')
        else:
            self.realtime_input_hint_var.set('本地实时演示使用Kafka配置中的字段规则，但不连接brokers，也不使用TCP端口。')

    def _start_realtime(self) -> None:
        if self._realtime_service is not None or self._kafka_bridge is not None or self._realtime_map_server is not None or self._realtime_stopping:
            messagebox.showinfo('实时服务', '实时接收与融合服务已经启动。', parent=self.root)
            return
        if self._worker is not None:
            messagebox.showinfo('任务正在运行', '请等待当前分析或融合任务完成。', parent=self.root)
            return
        self._realtime_generation += 1
        self._result_generation += 1
        self._realtime_completed = False
        self._realtime_stop_failed = False
        self._realtime_status_error = None
        realtime_generation = self._realtime_generation
        result_generation = self._result_generation

        def emit(kind: str, payload: object) -> None:
            self._events.put((kind, _GuiEvent(payload, result_generation, realtime_generation)))
        service = None
        bridge = None
        realtime_map = None
        self._realtime_replay_context = None
        try:
            config_path = Path(self.config_var.get()).expanduser().resolve()
            config = load_config(config_path)
            transport = self.realtime_transport_var.get()
            if transport == '本地实时演示':
                config = configure_realtime_demo(config)
            service = RealtimeFusionService(config, on_snapshot=lambda snapshot: emit('realtime_snapshot', snapshot), on_log=lambda message: emit('log', message))
            if transport == 'Kafka':
                kafka_config = load_kafka_config(Path(self.kafka_config_var.get()).expanduser())
                service.start(start_tcp=False)
                bridge = KafkaRealtimeBridge(service, kafka_config, on_log=lambda message: emit('log', message))
                bridge.start()
            elif transport == '本地实时演示':
                kafka_config = load_kafka_config(Path(self.kafka_config_var.get()).expanduser())
                service.start(start_tcp=False)
                demo_messages = build_realtime_demo_messages(config, kafka_config)
                bridge = DemoRealtimeBridge(service, kafka_config, demo_messages, playback_scale=0.38, on_log=lambda message: emit('log', message), on_complete=lambda : emit('realtime_complete', '本地实时演示'))
                bridge.start()
            elif transport == 'Excel实时回放':
                if not self.input_paths:
                    raise ValueError('Excel实时回放至少需要在下方选择一个SW Excel文件。')
                kafka_config = load_kafka_config(Path(self.kafka_config_var.get()).expanduser())
                (replay_start, replay_end) = parse_time_range(self.start_time_var.get(), self.end_time_var.get())
                conversion = build_excel_realtime_messages(config, kafka_config, self.input_paths, self.ew_input_paths, seed=20260913, maximum_gap_s=None, start_time=replay_start, end_time=replay_end)
                output_text = self.output_var.get().strip()
                if not output_text:
                    raise ValueError('结果输出目录不能为空。')
                self._realtime_replay_context = {'config_path': config_path, 'sw_paths': tuple((Path(path).resolve() for path in self.input_paths)), 'ew_paths': tuple((Path(path).resolve() for path in self.ew_input_paths)), 'output': Path(output_text).expanduser().resolve() / 'realtime_replay_result', 'start_time': replay_start, 'end_time': replay_end, 'realtime_generation': realtime_generation, 'result_generation': result_generation}
                service.start(start_tcp=False)
                bridge = DemoRealtimeBridge(service, kafka_config, conversion.messages, playback_scale=1.0, startup_delay_s=1.0, on_log=lambda message: emit('log', message), on_complete=lambda : emit('realtime_complete', 'Excel实时回放'))
                replay_duration_s = (conversion.messages[-1].event_time - conversion.messages[0].event_time).total_seconds() if len(conversion.messages) > 1 else 0.0
                self._events.put(('log', f'Excel实时回放转换完成：SW {conversion.sw_rows}行（原表{conversion.source_field_count_sw}列/识别{conversion.recognized_field_count_sw}项），EW {conversion.ew_rows}行（原表{conversion.source_field_count_ew}列/识别{conversion.recognized_field_count_ew}项）；外层格式=[{{宽对象}}]；事件时间跨度约{replay_duration_s:.3f}秒，按1.0倍速回放（另含1秒启动等待）。'))
                bridge.start()
            else:
                host = self.realtime_host_var.get().strip()
                sw_port = int(self.realtime_sw_port_var.get().strip())
                ew_port = int(self.realtime_ew_port_var.get().strip())
                service.start(host=host, sw_port=sw_port, ew_port=ew_port)

            def realtime_map_status() -> Dict[str, object]:
                return self._read_realtime_status(service, bridge, transport)
            realtime_map = RealtimeCesiumMapServer(config, port=8770, status_provider=realtime_map_status, finite_replay=transport in {'Excel实时回放', '本地实时演示'})
            realtime_map_url = realtime_map.start(open_browser=False)
            browser_opened = webbrowser.open(realtime_map_url, new=2)
        except Exception as error:
            self._realtime_service = service
            self._kafka_bridge = bridge
            self._realtime_map_server = realtime_map
            self._stop_realtime()
            messagebox.showerror('无法启动实时服务', str(error), parent=self.root)
            self._append_log(f'实时服务启动失败：{error}\n{traceback.format_exc()}')
            return
        self._realtime_service = service
        self._kafka_bridge = bridge
        self._realtime_map_server = realtime_map
        self._realtime_active_transport = transport
        self._append_log(f'实时融合地图地址：{realtime_map_url}')
        if not browser_opened:
            messagebox.showinfo('实时融合地图', f'浏览器未自动打开，请在本机浏览器中输入：\n{realtime_map_url}', parent=self.root)
        if transport == 'TCP JSONL':
            self.realtime_sw_port_var.set(str(service.sw_port))
            self.realtime_ew_port_var.set(str(service.ew_port))
        self.start_realtime_button.configure(state='disabled')
        self.stop_realtime_button.configure(state='normal')
        for widget in (self.realtime_host_entry, self.realtime_sw_port_entry, self.realtime_ew_port_entry, self.config_entry, self.config_button, self.kafka_config_entry, self.kafka_config_button):
            widget.configure(state='disabled')
        self.realtime_transport_combo.configure(state='disabled')
        if transport == 'Kafka' and bridge is not None:
            kafka_config = bridge.config
            self.realtime_status_var.set(f"Kafka运行中：SW={kafka_config['input_topic']}；EW={kafka_config['input_topic_1']}；输出={kafka_config['output_topic']}")
            self._append_log('Kafka统一消费入口已就绪：本机Excel实时回放与其他机器实时上报使用相同Topic和38/37字段规则，可并行进入融合队列。')
        elif transport == '本地实时演示':
            self.realtime_status_var.set('本地实时演示运行中：2个目标，3组SW装备，2组EW共享装备')
        elif transport == 'Excel实时回放':
            self.realtime_status_var.set(f'Excel实时回放运行中：SW={len(self.input_paths)}个文件；EW={len(self.ew_input_paths)}个文件；宽对象额外字段自动忽略')
        else:
            host = self.realtime_host_var.get().strip()
            self.realtime_status_var.set(f'TCP运行中：SW {host}:{service.sw_port}；EW {host}:{service.ew_port}；等待报文')
        self.status_var.set('实时服务与融合地图已启动，正在等待 SW/EW 报文')

    def _stop_realtime(self) -> None:
        if self._realtime_stopping:
            return
        self._realtime_generation += 1
        stop_generation = self._realtime_generation
        self._realtime_replay_context = None
        bridge = self._kafka_bridge
        service = self._realtime_service
        realtime_map = self._realtime_map_server
        if bridge is None and service is None and (realtime_map is None):
            self._finish_realtime_stop()
            return
        self._realtime_stopping = True
        self._realtime_stop_failed = False
        self.start_realtime_button.configure(state='disabled')
        self.stop_realtime_button.configure(state='disabled')
        self.realtime_status_var.set('正在停止接收并排空实时融合尾批……')

        def worker() -> None:
            try:
                if bridge is not None:
                    bridge.stop_receiving()
                if service is not None:
                    service.stop()
                if bridge is not None:
                    bridge.stop()
                if realtime_map is not None:
                    realtime_map.stop()
            except Exception as error:
                self._events.put(('realtime_stop_error', _GuiEvent((str(error), traceback.format_exc()), realtime_generation=stop_generation)))
            else:
                self._events.put(('realtime_stopped', _GuiEvent(None, realtime_generation=stop_generation)))
        self._realtime_stop_worker = threading.Thread(target=worker, name='DeepFusionRealtimeStop', daemon=True)
        self._realtime_stop_worker.start()

    def _finish_realtime_stop(self) -> None:
        self._realtime_stopping = False
        self._realtime_completed = False
        self._realtime_stop_failed = False
        self._realtime_stop_worker = None
        self._kafka_bridge = None
        self._realtime_service = None
        self._realtime_map_server = None
        self._realtime_active_transport = None
        self.start_realtime_button.configure(state='normal')
        self.stop_realtime_button.configure(state='disabled')
        for widget in (self.realtime_host_entry, self.realtime_sw_port_entry, self.realtime_ew_port_entry, self.config_entry, self.config_button, self.kafka_config_entry, self.kafka_config_button):
            widget.configure(state='normal')
        self.realtime_transport_combo.configure(state='readonly')
        self._refresh_realtime_input_state()
        self.realtime_status_var.set('实时服务未启动')
        if self._close_requested:
            self._finish_close()

    def _handle_realtime_snapshot(self, snapshot: RealtimeSnapshot, *, update_result: bool=True) -> None:
        if self._realtime_map_server is not None:
            try:
                self._realtime_map_server.update_snapshot(snapshot)
            except Exception as error:
                self._append_log(f'更新实时融合地图失败：{error}')
        if not update_result:
            return
        result = snapshot.result
        metrics = snapshot.metrics
        self.current_result = result
        self.current_metrics = metrics
        self.current_preview = result.sw_read
        self.current_preview_statuses = dict(result.target_statuses)
        self._fusion_statuses_released = True
        records = build_zbb_analysis(result.sw_read, result.config)
        if result.ew_read is not None:
            records.extend(build_ew_analysis(result.ew_read))
        self._populate_zbb_table(records)
        modes = ('SW融合',) if result.ew_read is None else ('SW融合', 'EW单独', 'SW+EW联合')
        self.plot_mode_combo.configure(values=modes)
        if self.plot_mode_var.get() not in modes:
            self.plot_mode_var.set(modes[-1])
        self._draw_result(result)
        self._set_metrics(metrics)
        self._refresh_realtime_status()
        self.status_var.set(f"实时融合已更新：全局目标={len(result.config['scenario'].get('target_track_ids', {}))}，SW融合航迹={len({item.track_id for item in result.estimates})}，EW成功关联={sum((item.status == 'associated' for item in result.ew_associations))}")

    @staticmethod
    def _read_realtime_status(service, bridge, transport: str) -> Dict[str, object]:
        current = service.status()
        status: Dict[str, object] = {'receivedSw': current.received_sw, 'receivedEw': current.received_ew, 'bufferedSw': current.buffered_sw, 'bufferedEw': current.buffered_ew, 'fusionRuns': current.fusion_run_count, 'rejected': current.rejected_messages, 'lateDropped': current.late_dropped_messages, 'fusionErrors': current.fusion_error_count, 'lastFusionDurationS': current.last_fusion_duration_s, 'meanFusionDurationS': current.mean_fusion_duration_s, 'lastSnapshotIntervalS': current.last_snapshot_interval_s, 'lastError': current.last_error or '', 'journalError': getattr(current, 'journal_error', None) or '', 'transport': transport}
        if bridge is not None:
            delivery = bridge.status()
            status.update({'kafkaConsumed': delivery.consumed_messages, 'kafkaRejected': delivery.rejected_messages, 'kafkaPublished': delivery.published_snapshots, 'kafkaPendingOutputs': getattr(delivery, 'pending_outputs', 0), 'kafkaPendingInputs': getattr(delivery, 'pending_inputs', 0), 'kafkaFailedOutputs': getattr(delivery, 'failed_outputs', 0), 'kafkaLastError': delivery.last_error or '', 'kafkaLastDeliveryError': getattr(delivery, 'last_delivery_error', None) or '', 'kafkaLastInputError': getattr(delivery, 'last_input_error', None) or ''})
        return status

    def _refresh_realtime_status(self) -> None:
        if self._realtime_service is None or self._realtime_stopping or getattr(self, '_realtime_stop_failed', False):
            return
        transport = self._realtime_active_transport or 'TCP JSONL'
        status = self._read_realtime_status(self._realtime_service, self._kafka_bridge, transport)
        prefix = f'{transport}已完成：地图动态航迹已清除；' if getattr(self, '_realtime_completed', False) else f'{transport}运行中：'
        text = f"{prefix}已收 SW={status['receivedSw']}、EW={status['receivedEw']}；窗口内 SW={status['bufferedSw']}、EW={status['bufferedEw']}；融合次数={status['fusionRuns']}；迟到丢弃={status['lateDropped']}；融合错误={status['fusionErrors']}"
        if self._kafka_bridge is not None:
            text += f"；已输出快照={status['kafkaPublished']}；待确认输出={status['kafkaPendingOutputs']}；已隔离输出={status['kafkaFailedOutputs']}"
        for (label, key) in (('融合/输入错误', 'lastError'), ('审计写入错误', 'journalError'), ('Kafka错误', 'kafkaLastError'), ('Kafka交付错误', 'kafkaLastDeliveryError'), ('最近拒收', 'kafkaLastInputError')):
            if status.get(key):
                text += f'；{label}：{status[key]}'
        self.realtime_status_var.set(text)
        self._realtime_status_error = None

    def _handle_realtime_complete(self, transport: str, *, update_result: bool=True) -> None:
        if transport != self._realtime_active_transport:
            return
        self._realtime_completed = True
        if self._realtime_map_server is not None:
            try:
                self._realtime_map_server.clear_tracks(f'{transport}已完成；原始航迹、融合航迹和动态EW约束已退出地图。')
            except Exception as error:
                self._append_log(f'完成回放后清理实时地图失败：{error}')
        self.realtime_status_var.set(f'{transport}已完成：地图动态航迹已清除')
        if update_result:
            self.status_var.set(f'{transport}已完成，已结束航迹不再显示')
        self._append_log(f'{transport}已完成：融合结果仍保留在结果页，地图上的已结束动态航迹已清除。')
        if transport == 'Excel实时回放':
            self._start_realtime_replay_export()

    def _start_realtime_replay_export(self) -> None:
        context = self._realtime_replay_context
        if context is None:
            self._append_log('Excel实时回放没有可用的完整文件导出上下文，已跳过对比图生成。')
            return
        context = dict(context)
        realtime_generation = context['realtime_generation']
        result_generation = context['result_generation']
        if self._realtime_export_thread is not None and self._realtime_export_thread.is_alive() and (self._realtime_export_generation == realtime_generation):
            self._append_log('完整回放结果与对比图正在生成，无需重复启动。')
            return
        if result_generation == self._result_generation:
            self.status_var.set('Excel回放完成，正在用完整文件生成本次数据的对比图……')
        self._append_log('开始生成本次Excel数据的完整结果与动态对比图；此步骤会重新读取完整文件，图表不是固定图片。')

        def worker() -> None:
            try:
                with self._realtime_export_lock:
                    config = load_config(context['config_path'])
                    if context['ew_paths']:
                        (result, metrics) = execute_sw_ew(config, context['sw_paths'], context['ew_paths'], context['output'], start_time=context['start_time'], end_time=context['end_time'])
                    else:
                        (result, metrics) = execute_sw(config, context['sw_paths'], context['output'], start_time=context['start_time'], end_time=context['end_time'])
                self._events.put(('realtime_export_success', _GuiEvent({'result': result, 'metrics': metrics, 'output': context['output']}, result_generation, realtime_generation)))
            except Exception as error:
                self._events.put(('realtime_export_error', _GuiEvent((str(error), traceback.format_exc()), result_generation, realtime_generation)))
        self._realtime_export_generation = realtime_generation
        self._realtime_export_thread = threading.Thread(target=worker, name='DeepFusionRealtimeReplayExport', daemon=True)
        self._realtime_export_thread.start()

    def _choose_files(self) -> None:
        selected = filedialog.askopenfilenames(parent=self.root, title='选择一个或多个 DS-SW Excel 文件', initialdir=str(PROJECT_ROOT), filetypes=SW_FILE_TYPES)
        existing = {str(path).casefold() for path in self.input_paths}
        for value in selected:
            path = Path(value).resolve()
            if str(path).casefold() not in existing:
                self.input_paths.append(path)
                existing.add(str(path).casefold())
        self._refresh_file_list()

    def _choose_ew_files(self) -> None:
        selected = filedialog.askopenfilenames(parent=self.root, title='选择一个或多个 DS-EW Excel 文件', initialdir=str(PROJECT_ROOT), filetypes=SW_FILE_TYPES)
        existing = {str(path).casefold() for path in self.ew_input_paths}
        for value in selected:
            path = Path(value).resolve()
            if str(path).casefold() not in existing:
                self.ew_input_paths.append(path)
                existing.add(str(path).casefold())
        self._refresh_ew_file_list()

    def _remove_selected_ew(self) -> None:
        selected = set(self.ew_file_list.curselection())
        self.ew_input_paths = [path for (index, path) in enumerate(self.ew_input_paths) if index not in selected]
        self._refresh_ew_file_list()

    def _clear_ew_files(self) -> None:
        self.ew_input_paths.clear()
        self._refresh_ew_file_list()

    def _refresh_ew_file_list(self) -> None:
        self.ew_file_list.delete(0, 'end')
        for path in self.ew_input_paths:
            self.ew_file_list.insert('end', str(path))
        self.status_var.set(f'已选择 {len(self.input_paths)} 个 SW 文件、{len(self.ew_input_paths)} 个 EW 文件')

    def _remove_selected(self) -> None:
        selected = set(self.file_list.curselection())
        self.input_paths = [path for (index, path) in enumerate(self.input_paths) if index not in selected]
        self._refresh_file_list()

    def _clear_files(self) -> None:
        self.input_paths.clear()
        self._refresh_file_list()

    def _refresh_file_list(self) -> None:
        self._fusion_statuses_released = False
        self.current_preview_statuses = {}
        self.file_list.delete(0, 'end')
        for path in self.input_paths:
            self.file_list.insert('end', str(path))
        if self.input_paths:
            self.file_list.selection_set(0)
        self.status_var.set(f'已选择 {len(self.input_paths)} 个 SW 文件、{len(self.ew_input_paths)} 个 EW 文件')

    def _on_file_selected(self, _event=None) -> None:
        selected = self.file_list.curselection()
        if not selected:
            return
        path = self.input_paths[selected[0]]
        read_result = self.analyzed_results.get(str(path).casefold())
        if read_result is not None:
            self._draw_input_preview(read_result, statuses=self.current_result.target_statuses if self._fusion_statuses_released and self.current_result is not None else None)
            suffix = '' if len(selected) == 1 else f'（当前共选中 {len(selected)} 个文件）'
            self.status_var.set(f'当前预览：{path.name}{suffix}；全部融合按钮仍处理列表内全部文件')

    def _choose_config(self) -> None:
        value = filedialog.askopenfilename(parent=self.root, title='选择 RealFusion YAML 配置', initialdir=str(PROJECT_ROOT / 'configs'), filetypes=[('YAML 配置', '*.yaml *.yml'), ('所有文件', '*.*')])
        if value:
            self.config_var.set(value)

    def _choose_kafka_config(self) -> None:
        value = filedialog.askopenfilename(parent=self.root, title='选择 Kafka YAML 配置', initialdir=str(PROJECT_ROOT / 'configs'), filetypes=[('YAML 配置', '*.yaml *.yml'), ('所有文件', '*.*')])
        if value:
            self.kafka_config_var.set(value)

    def _choose_output(self) -> None:
        value = filedialog.askdirectory(parent=self.root, title='选择结果输出目录', initialdir=str(PROJECT_ROOT / 'output'), mustexist=False)
        if value:
            self.output_var.set(value)

    def _validated_common(self, require_inputs: bool=True) -> tuple[List[Path], Path, Path, object, object]:
        paths = list(self.input_paths)
        if require_inputs and (not paths):
            raise ValueError('请先点击“选择/追加文件”，至少选择一个 SW 文件。')
        config_path = Path(self.config_var.get().strip()).expanduser().resolve()
        if not config_path.is_file():
            raise FileNotFoundError(f'配置文件不存在：{config_path}')
        output_text = self.output_var.get().strip()
        if not output_text:
            raise ValueError('结果输出目录不能为空。')
        (start_time, end_time) = parse_time_range(self.start_time_var.get(), self.end_time_var.get())
        return (paths, config_path, Path(output_text).expanduser().resolve(), start_time, end_time)

    def _selected_inputs_for_fusion(self, paths: Sequence[Path]) -> List[Path]:
        if len(paths) == 1:
            return [paths[0]]
        selected = self.file_list.curselection()
        if not selected:
            raise ValueError('请在文件列表中选择一个或多个要融合的 SW 分卷；可按 Ctrl/Shift 多选。')
        return [paths[index] for index in selected]

    @staticmethod
    def _analysis_signature(paths: Sequence[Path], config_path: Path, start_time: object, end_time: object, ew_paths: Sequence[Path]=()) -> tuple:
        file_state = tuple(((str(path.resolve()).casefold(), int(path.stat().st_size), int(path.stat().st_mtime_ns)) for path in paths))
        config_state = (str(config_path.resolve()).casefold(), int(config_path.stat().st_size), int(config_path.stat().st_mtime_ns))
        ew_file_state = tuple(((str(path.resolve()).casefold(), int(path.stat().st_size), int(path.stat().st_mtime_ns)) for path in ew_paths))
        return (file_state, ew_file_state, config_state, str(start_time or ''), str(end_time or ''))

    def _analyze_inputs(self) -> None:
        try:
            (paths, config_path, _, start_time, end_time) = self._validated_common(require_inputs=True)
        except Exception as error:
            messagebox.showerror('无法开始分析', str(error), parent=self.root)
            return
        ew_paths = list(self.ew_input_paths)

        def task() -> dict:
            range_label = f"[{start_time or '不限制'}, {end_time or '不限制'}]" if start_time is not None or end_time is not None else '全部时间'
            self._events.put(('log', f'开始读取 {len(paths)} 个 SW 文件、{len(ew_paths)} 个 EW 文件；分析时戳范围={range_label}。'))
            config = load_config(config_path)
            analysis_signature = self._analysis_signature(paths, config_path, start_time, end_time, ew_paths)
            read_results = []
            failures = []
            for path in paths:
                try:
                    read_result = read_sw_file(path, config['sw'], start_time=start_time, end_time=end_time)
                    read_results.append(read_result)
                    schema_status = '完整表头匹配' if not read_result.schema_missing_columns and (not read_result.schema_extra_columns) else f'表头提示：缺少 {len(read_result.schema_missing_columns)} 列，多出 {len(read_result.schema_extra_columns)} 列'
                    self._events.put(('log', f'读取成功：{path.name}；总行数={read_result.total_rows}；质量有效行={read_result.quality_valid_rows}；区间外行={read_result.time_filtered_rows}；区间内分析行={read_result.valid_rows}；拒绝行={read_result.rejected_rows}；完整列数={len(read_result.input_columns)}；原始MBY值数量={len(read_result.target_values)}；装备编号数量={len(read_result.device_values)}；{schema_status}。'))
                except Exception as error:
                    failures.append({'path': str(path), 'error': str(error)})
                    self._events.put(('log', f'文件读取失败：{path}；{error}'))
            if not read_results:
                raise ValueError('所选文件全部读取失败，请查看运行日志中的逐文件原因。')
            combined_read = combine_sw_read_results(read_results, max_rejected_examples=int(config['sw'].get('max_rejected_examples', 20)))
            self._events.put(('log', '正在按全部成功分卷统一分析源航迹阈值、跨装备时段和出生融合门控……'))
            analysis_result = run_sw_experiment(config, paths, prepared_read=combined_read)
            ew_read_results = []
            if ew_paths:
                if 'ew' not in config:
                    raise ValueError('YAML 中缺少 ew 区段，无法分析已选择的 EW 文件。')
                for path in ew_paths:
                    try:
                        read_result = read_ew_file(path, config['ew'], start_time=start_time, end_time=end_time)
                        ew_read_results.append(read_result)
                        self._events.put(('log', f'EW读取成功：{path.name}；总行数={read_result.total_rows}；区间内有效={read_result.valid_rows}；拒绝={read_result.rejected_rows}；目标={read_result.target_values}；装备={read_result.device_values}。'))
                    except Exception as error:
                        failures.append({'path': str(path), 'error': str(error), 'kind': 'EW'})
                        self._events.put(('log', f'EW文件读取失败：{path}；{error}'))
                if not ew_read_results:
                    raise ValueError('已选择 EW 文件，但全部读取失败；请检查55列表头和配置。')
                combined_ew = combine_ew_read_results(ew_read_results, int(config['ew'].get('max_rejected_examples', 20)))
                analysis_result.ew_read = combined_ew
            records = build_zbb_analysis(combined_read, config)
            for ew_result in ew_read_results:
                records.extend(build_ew_analysis(ew_result))
            return {'kind': 'analysis', 'read_results': read_results, 'analysis_result': analysis_result, 'analysis_signature': analysis_signature if not failures else None, 'failures': failures, 'records': records}
        self._start_task('正在读取文件并分析局部MBY/装备编号……', task)

    def _run_all_fusion(self) -> None:
        try:
            (paths, config_path, output, start_time, end_time) = self._validated_common(require_inputs=True)
        except Exception as error:
            messagebox.showerror('无法开始融合', str(error), parent=self.root)
            return
        self._start_fusion(paths, config_path, output, '列表中的全部文件', start_time, end_time)

    def _run_selected_fusion(self) -> None:
        try:
            (paths, config_path, output, start_time, end_time) = self._validated_common(require_inputs=True)
            selected_paths = self._selected_inputs_for_fusion(paths)
        except Exception as error:
            messagebox.showerror('无法开始融合', str(error), parent=self.root)
            return
        self._start_fusion(selected_paths, config_path, output, '列表中选中的文件', start_time, end_time)

    def _start_fusion(self, fusion_paths: Sequence[Path], config_path: Path, output: Path, scope_label: str, start_time: object, end_time: object) -> None:
        selected_paths = list(fusion_paths)
        selected_ew_paths = list(self.ew_input_paths)
        requested_signature = self._analysis_signature(selected_paths, config_path, start_time, end_time, selected_ew_paths)
        cached_result = self.current_analysis_result if not selected_ew_paths and self.current_analysis_result is not None and (self.current_analysis_signature == requested_signature) else None

        def task() -> dict:
            self._events.put(('log', f"开始融合{scope_label}：分卷数={len(selected_paths)}；EW分卷数={len(selected_ew_paths)}；各文件将先独立校验，再按绝对时戳统一排序；时戳范围=[{start_time or '不限制'}, {end_time or '不限制'}]；配置={config_path}"))
            if cached_result is not None:
                self._events.put(('log', '输入文件、配置和时戳区间均未变化，复用刚才的完整分析结果，避免大型数据重复计算。'))
                result = cached_result
                metrics = compute_metrics(result)
                save_experiment(result, metrics, output)
            else:
                config = load_config(config_path)
                if selected_ew_paths:
                    (result, metrics) = execute_sw_ew(config, selected_paths, selected_ew_paths, output, start_time=start_time, end_time=end_time)
                else:
                    (result, metrics) = execute_sw(config, selected_paths, output, start_time=start_time, end_time=end_time)
            records = build_zbb_analysis(result.sw_read, result.config)
            if result.ew_read is not None:
                records.extend(build_ew_analysis(result.ew_read))
            return {'kind': 'fusion', 'result': result, 'metrics': metrics, 'output': output, 'records': records}
        self._start_task(f'正在融合 {len(selected_paths)} 个 SW 分卷和 {len(selected_ew_paths)} 个 EW 分卷……', task)

    def _start_task(self, status: str, target) -> None:
        if self._worker is not None:
            messagebox.showinfo('任务正在运行', '请等待当前分析或融合任务完成。', parent=self.root)
            return
        self._result_generation += 1
        result_generation = self._result_generation
        self._set_busy(True, status)

        def wrapper() -> None:
            try:
                payload = target()
            except Exception as error:
                self._events.put(('error', _GuiEvent((str(error), traceback.format_exc()), result_generation)))
            else:
                self._events.put(('success', _GuiEvent(payload, result_generation)))
        self._worker = threading.Thread(target=wrapper, name='RealFusionWorker', daemon=True)
        self._worker.start()

    def _drain_events(self) -> None:
        if self._closing:
            return
        try:
            while not self._closing:
                try:
                    queued_event = self._events.get_nowait()
                except queue.Empty:
                    break
                kind = 'unknown'
                try:
                    (kind, payload) = queued_event
                    update_result = True
                    if isinstance(payload, _GuiEvent):
                        event = payload
                        if event.realtime_generation is not None and event.realtime_generation != self._realtime_generation:
                            if kind == 'log':
                                self._append_log(f'[先前实时会话 {event.realtime_generation}] {event.payload}')
                            continue
                        update_result = event.result_generation is None or event.result_generation == self._result_generation
                        if not update_result and kind not in {'log', 'realtime_snapshot', 'realtime_complete'}:
                            continue
                        payload = event.payload
                    self._dispatch_event(kind, payload, update_result=update_result)
                except Exception as error:
                    try:
                        self._append_log(f'处理界面事件 {kind} 失败，后续事件继续处理：{error}\n{traceback.format_exc()}')
                    except Exception:
                        pass
        finally:
            if not self._closing:
                try:
                    self._refresh_realtime_status()
                except Exception as error:
                    message = str(error)
                    try:
                        self.realtime_status_var.set(f'实时状态读取失败：{message}')
                        if message != getattr(self, '_realtime_status_error', None):
                            self._append_log(f'实时状态读取失败，下一轮重试：{message}')
                        self._realtime_status_error = message
                    except Exception:
                        pass
                self.root.after(100, self._drain_events)

    def _dispatch_event(self, kind: str, payload: object, *, update_result: bool) -> None:
        if kind == 'log':
            self._append_log(str(payload))
        elif kind == 'realtime_snapshot':
            self._handle_realtime_snapshot(payload, update_result=update_result)
        elif kind == 'realtime_complete':
            self._handle_realtime_complete(str(payload), update_result=update_result)
        elif kind == 'realtime_stopped':
            self._finish_realtime_stop()
        elif kind == 'realtime_stop_error':
            self._realtime_stopping = False
            self._realtime_stop_failed = True
            self._realtime_stop_worker = None
            self.start_realtime_button.configure(state='disabled')
            self.stop_realtime_button.configure(state='normal')
            self.realtime_status_var.set('实时服务停止未完成，请重试停止')
            (message, details) = payload
            self._append_log(f'实时服务停止未完成，保留连接以便继续排空：{message}\n{details}')
        elif kind == 'realtime_export_success':
            result = payload['result']
            output = Path(payload['output'])
            self.current_result = result
            self.current_metrics = payload['metrics']
            self.current_output = output
            self.player_button.configure(state='normal')
            self.cesium_player_button.configure(state='normal')
            self.summary_button.configure(state='normal')
            self.folder_button.configure(state='normal')
            note = self._report_comparison_status(payload['metrics'], output)
            self.status_var.set(f'本次Excel回放的完整结果已生成{note}')
        elif kind == 'realtime_export_error':
            (message, details) = payload
            self.status_var.set('Excel回放完成，但完整文件结果导出失败')
            self._append_log(f'完整回放结果导出失败：{message}\n{details}')
        elif kind == 'error':
            self._worker = None
            (message, details) = payload
            self._set_busy(False, '运行失败，请查看运行日志')
            self._append_log(f'错误：{message}\n{details}')
            self.notebook.select(3)
            messagebox.showerror('RealFusion 运行失败', message, parent=self.root)
        elif kind == 'success':
            self._worker = None
            self._handle_success(payload)

    def _report_comparison_status(self, metrics: dict, output: Path) -> str:
        report = metrics.get('reports', {}).get('observable_comparison', {})
        status = report.get('status')
        if status == 'failed':
            self._append_log(f"核心融合结果、播放器和总结已完成；附加对比图生成失败：{report.get('error', '请查看report_status.json')}")
            return '；附加对比图失败，核心结果可用'
        if status == 'complete':
            self._append_log(f"本次数据对比图已生成：{output / 'comparison_dashboard'}；无独立真值时只解释连续性、平滑性和内部不确定性，不能解释为真实精度提升。")
            return '；动态对比图已生成'
        if status == 'disabled':
            self._append_log('附加对比图已按配置关闭；核心结果已完成。')
        return ''

    def _handle_success(self, payload: dict) -> None:
        self._set_busy(False, '处理完成')
        self._populate_zbb_table(payload['records'])
        if payload['kind'] == 'analysis':
            read_results = payload['read_results']
            analysis_result = payload['analysis_result']
            failures = payload['failures']
            self.analyzed_results = {str(read_result.path).casefold(): read_result for read_result in read_results}
            self.current_analysis_result = analysis_result
            self.current_analysis_signature = payload['analysis_signature']
            self._fusion_statuses_released = False
            self.current_preview_statuses = {}
            self._draw_input_preview(analysis_result.sw_read, statuses={})
            total_rows = sum((item.total_rows for item in read_results))
            analyzed_rows = sum((item.valid_rows for item in read_results))
            time_filtered_rows = sum((item.time_filtered_rows for item in read_results))
            self._append_log(f'多文件信息读取完成：成功文件={len(read_results)}，失败文件={len(failures)}，原始条数={total_rows}，区间外条数={time_filtered_rows}，实际分析条数={analyzed_rows}；原始MBY值={sorted(analysis_result.sw_read.target_values)}；装备内有效局部航迹={len(analysis_result.source_tracks.summaries)}；运动学解析的全局目标={len({item.global_target_id for item in analysis_result.global_track_memberships})}组；EW有效行={(analysis_result.ew_read.valid_rows if analysis_result.ew_read is not None else 0)}。融合状态将在执行融合后显示。')
            self.status_var.set(f'信息分析完成：{len(read_results)} 个成功，{len(failures)} 个失败；可点击“全部融合”')
            self.notebook.select(0)
            return
        result = payload['result']
        metrics = payload['metrics']
        output = Path(payload['output'])
        self.current_result = result
        self._fusion_statuses_released = True
        self.current_metrics = metrics
        self.current_output = output
        if result.ew_read is None:
            self.plot_mode_var.set('SW融合')
            self.plot_mode_combo.configure(values=('SW融合',))
        else:
            self.plot_mode_var.set('SW+EW联合')
            self.plot_mode_combo.configure(values=('SW融合', 'EW单独', 'SW+EW联合'))
        self._draw_result(result)
        self._set_metrics(metrics)
        self.player_button.configure(state='normal')
        self.cesium_player_button.configure(state='normal')
        self.summary_button.configure(state='normal')
        self.folder_button.configure(state='normal')
        self._append_log(f"融合完成：分卷数={len(result.sw_read.source_paths or [result.sw_read.path])}，合计读取条数={result.sw_read.total_rows}，完整列数={len(result.sw_read.input_columns)}，区间内有效条数={result.sw_read.valid_rows}，区间外条数={result.sw_read.time_filtered_rows}，原始MBY值={result.sw_read.target_values}，装备编号={result.sw_read.device_values}，装备内局部航迹={len(result.global_track_memberships)}，全局目标={sorted(result.config['scenario'].get('target_track_ids', {}))}，融合航迹数={len({item.track_id for item in result.estimates})}，融合点数={len(result.estimates)}，EW有效量测={len(result.ew_measurements)}，EW成功关联={sum((item.status == 'associated' for item in result.ew_associations))}，EW关联率={metrics.get('joint_fusion', {}).get('association_rate', 0.0):.2%}，方位绝对残差中位数={metrics.get('joint_fusion', {}).get('absolute_azimuth_residual_deg_summary', {}).get('median')}度，EW局部批号历史关联={metrics.get('joint_fusion', {}).get('history_prior_associated_count', 0)}，联合航迹点={len(result.joint_estimates)}，单源直通目标={sorted((k for (k, v) in result.target_fusion_modes.items() if v == 'single_source_passthrough'))}，跨装备不兼容局部航迹对={metrics.get('global_identity', {}).get('incompatible_pair_count', 0)}，虚警目标={metrics['fusion']['sparse_handling']['false_alarm_target_ids']}，虚警/稀疏报告行={metrics['fusion']['sparse_handling']['report_row_count']}，融合总结={output / 'fusion_summary.html'}，输出={output}")
        report_note = self._report_comparison_status(metrics, output)
        self.status_var.set(f"融合完成：{len(result.sw_read.source_paths or [result.sw_read.path])} 个分卷，{len(result.global_track_memberships)} 条装备内局部航迹，{len(result.config['scenario'].get('target_track_ids', {}))} 个全局目标，{len(result.sw_read.device_values)} 个装备编号，{len({item.track_id for item in result.estimates})} 条融合航迹，{metrics.get('global_identity', {}).get('incompatible_pair_count', 0)} 对跨装备不兼容局部航迹，{len(metrics['fusion']['sparse_handling']['false_alarm_target_ids'])} 个未成轨虚警目标{report_note}")
        self.notebook.select(0)

    def _set_busy(self, busy: bool, status: str) -> None:
        self.status_var.set(status)
        state = 'disabled' if busy else 'normal'
        for button in (self.add_button, self.remove_button, self.clear_button, self.config_button, self.add_ew_button, self.remove_ew_button, self.clear_ew_button, self.output_button, self.analyze_button, self.fuse_all_button, self.fuse_selected_button):
            button.configure(state=state)
        self.start_time_entry.configure(state=state)
        self.end_time_entry.configure(state=state)
        self.plot_target_button.configure(state='disabled' if busy or not self.available_plot_targets else 'normal')
        if busy:
            self.progress.start(12)
        else:
            self.progress.stop()

    def _populate_zbb_table(self, records: Sequence[dict]) -> None:
        for item in self.zbb_tree.get_children():
            self.zbb_tree.delete(item)
        for record in records:
            self.zbb_tree.insert('', 'end', values=(record['source_file'], record['read_rows'], record['target_count'], record['target_values'], record['zbb_count'], record['zbb_values'], record['frequency_summary']))

    def _draw_empty_plot(self) -> None:
        self._plot_context = 'empty'
        self.current_preview = None
        self.available_plot_targets = []
        self.available_plot_sources = []
        self.plot_target_statuses = {}
        self.plot_targets_by_source = {}
        self.plot_targets_by_device = {}
        self.selected_plot_devices.clear()
        self.selected_plot_sources.clear()
        self.selected_plot_fusion_targets.clear()
        self.plot_target_summary_var.set(ALL_SOURCES_LABEL)
        self.plot_target_button.configure(state='disabled')
        self.axis.clear()
        self.axis.text2D(0.5, 0.53, '请选择 SW 文件并点击“分析局部MBY/装备编号”或“融合列表中的全部文件”', transform=self.axis.transAxes, ha='center', va='center', fontsize=12, color='#64748b')
        self.axis.set_axis_off()
        self._set_plot_legend([])
        self.canvas.draw_idle()

    @staticmethod
    def _preview_plot_sources(read_result: SwReadResult) -> List[PlotSourceOption]:
        return sorted({PlotSourceOption(data_kind='SW', zbb=str(zbb), local_mby=str(mby), target_id=f'LOCAL-{str(zbb)}-MBY-{str(mby)}') for (mby, zbb) in read_result.frame[['_mby', '_zbb']].itertuples(index=False, name=None)})

    @staticmethod
    def _result_plot_sources(result: ExperimentResult, mode: str) -> List[PlotSourceOption]:
        options: set[PlotSourceOption] = set()
        if mode in {'SW融合', 'SW+EW联合'}:
            for item in result.global_track_memberships:
                options.add(PlotSourceOption(data_kind='SW', zbb=str(item.zbb), local_mby=str(item.local_target_id), target_id=str(item.global_target_id)))
            for item in result.source_tracks.sparse_groups:
                options.add(PlotSourceOption(data_kind='SW', zbb=str(item.zbb), local_mby=str(item.local_target_id), target_id=str(item.target_id)))
        if mode in {'EW单独', 'SW+EW联合'} and result.ew_read is not None:
            association_by_id = {item.measurement_id: item for item in result.ew_associations}
            for measurement in result.ew_measurements:
                association = association_by_id.get(measurement.measurement_id)
                target_id = association.matched_target_id if association is not None and association.status == 'associated' and association.matched_target_id else measurement.target_id
                options.add(PlotSourceOption(data_kind='EW', zbb=str(measurement.zbb), local_mby=str(measurement.target_id), target_id=str(target_id)))
        return sorted(options)

    @staticmethod
    def _result_fusion_plot_sources(result: ExperimentResult) -> List[PlotSourceOption]:
        options = {item for item in RealFusionApp._result_plot_sources(result, 'SW+EW联合') if item.data_kind == 'SW'}
        if result.ew_read is None:
            return sorted(options)
        association_by_id = {item.measurement_id: item for item in result.ew_associations}
        for measurement in result.ew_measurements:
            association = association_by_id.get(measurement.measurement_id)
            if association is None or association.status != 'associated' or (not association.matched_target_id):
                continue
            options.add(PlotSourceOption(data_kind='EW', zbb=str(measurement.zbb), local_mby=str(measurement.target_id), target_id=str(association.matched_target_id)))
        return sorted(options)

    def _configure_plot_sources(self, sources: Sequence[PlotSourceOption], context: str, statuses: Optional[Dict[str, TargetFusionStatus]]=None) -> None:
        options = sorted(set(sources))
        self._plot_context = context
        self.available_plot_sources = options
        self.available_plot_targets = sorted({item.target_id for item in options})
        self.plot_targets_by_source = {}
        self.plot_targets_by_device = {}
        for item in options:
            self.plot_targets_by_source.setdefault(item.source_key, set()).add(item.target_id)
            self.plot_targets_by_device.setdefault(item.device_key, set()).add(item.target_id)
        self.plot_target_statuses = {str(target_id): status for (target_id, status) in (statuses or {}).items() if str(target_id) in self.available_plot_targets}
        self.selected_plot_devices.clear()
        self.selected_plot_sources.clear()
        self.selected_plot_fusion_targets.clear()
        self._update_plot_target_summary()
        self.plot_target_button.configure(state='normal' if options else 'disabled')

    def _update_plot_target_summary(self) -> None:
        if not self.available_plot_sources:
            self.plot_target_summary_var.set(ALL_SOURCES_LABEL)
            return
        if not self.selected_plot_devices and (not self.selected_plot_sources) and (not self.selected_plot_fusion_targets):
            self.plot_target_summary_var.set(ALL_SOURCES_LABEL)
            return
        visible = _visible_plot_source_options(self.available_plot_sources, self.selected_plot_devices, set() if self.selected_plot_fusion_targets else self.selected_plot_sources, self.selected_plot_fusion_targets)
        devices = {item.device_key for item in visible}
        zbb_values = {item.zbb for item in visible}
        sources = {item.source_key for item in visible}
        targets = {item.target_id for item in visible}
        if self.selected_plot_fusion_targets:
            summary = f'{HETEROGENEOUS_FUSION_DEVICE_LABEL}｜{len(targets)}个目标 / {len(zbb_values)}种装备'
            if self.selected_plot_sources:
                summary += f' / 由{len(self.selected_plot_sources)}个MBY定位'
            self.plot_target_summary_var.set(summary)
            return
        if len(sources) == 1:
            (kind, zbb, local_mby) = next(iter(sources))
            prefix = f'{kind} ' if len({item.data_kind for item in self.available_plot_sources}) > 1 else ''
            self.plot_target_summary_var.set(f'{prefix}装备={zbb} / MBY={local_mby}')
        elif self.selected_plot_sources:
            self.plot_target_summary_var.set(f'已选 {len(devices)} 个装备 / {len(sources)} 个MBY')
        else:
            self.plot_target_summary_var.set(f'已选 {len(devices)} 个装备 / 全部MBY')

    def _target_display_label(self, target_id: str) -> str:
        return _format_target_option_label(target_id, self.plot_target_statuses.get(str(target_id)))

    def _selected_plot_targets(self) -> Optional[set[str]]:
        if not self.selected_plot_devices and (not self.selected_plot_sources) and (not self.selected_plot_fusion_targets):
            return None
        if self.selected_plot_fusion_targets:
            return set(self.selected_plot_fusion_targets)
        return {item.target_id for item in _visible_plot_source_options(self.available_plot_sources, self.selected_plot_devices, self.selected_plot_sources, self.selected_plot_fusion_targets)}

    def _plot_source_is_visible(self, data_kind: str, zbb: str, local_mby: str) -> bool:
        if not self.selected_plot_devices and (not self.selected_plot_sources) and (not self.selected_plot_fusion_targets):
            return True
        device_key = (str(data_kind), str(zbb))
        source_key = (*device_key, str(local_mby))
        if self.selected_plot_fusion_targets:
            source_targets = self.plot_targets_by_source.get(source_key, set())
            return bool(source_targets.intersection(self.selected_plot_fusion_targets))
        if self.selected_plot_devices and device_key not in self.selected_plot_devices:
            return False
        eligible_sources = {item for item in self.selected_plot_sources if not self.selected_plot_devices or item[:2] in self.selected_plot_devices}
        return not eligible_sources or source_key in eligible_sources

    def _plot_device_is_visible(self, data_kind: str, zbb: str) -> bool:
        device_key = (str(data_kind), str(zbb))
        if self.selected_plot_fusion_targets:
            device_targets = self.plot_targets_by_device.get(device_key, set())
            return bool(device_targets.intersection(self.selected_plot_fusion_targets))
        if self.selected_plot_devices and device_key not in self.selected_plot_devices:
            return False
        eligible_sources = {item for item in self.selected_plot_sources if not self.selected_plot_devices or item[:2] in self.selected_plot_devices}
        return not eligible_sources or any((item[:2] == device_key for item in eligible_sources))

    def _plot_source_label(self, source_key: tuple[str, str, str]) -> str:
        (kind, zbb, local_mby) = source_key
        mixed_kinds = len({item.data_kind for item in self.available_plot_sources}) > 1
        prefix = f'{kind}｜' if mixed_kinds else ''
        labels = sorted({self.plot_target_statuses[item.target_id].display_status for item in self.available_plot_sources if item.source_key == source_key and item.target_id in self.plot_target_statuses})
        suffix = f"（{'、'.join(labels)}）" if labels else ''
        return f'{prefix}装备={zbb}｜MBY={local_mby}{suffix}'

    @staticmethod
    def _plot_fusion_group_label(option: PlotFusionGroupOption) -> str:
        mixed_kinds = len({item.data_kind for item in option.members}) > 1
        member_labels = []
        for item in option.members:
            kind = f'{item.data_kind}:' if mixed_kinds else ''
            member_labels.append(f'{kind}{item.zbb}/{item.local_mby}')
        device_count = len({item.zbb for item in option.members})
        return f"融合航迹={option.track_id}｜目标={option.target_id}（已融合）｜{len(option.members)}个SW/EW成员源/{device_count}种共享装备 → 1条融合航迹｜成员：{'、'.join(member_labels)}"

    def _open_plot_target_selector(self) -> None:
        if not self.available_plot_sources:
            return
        if self._target_selector_window is not None and self._target_selector_window.winfo_exists():
            self._target_selector_window.lift()
            self._target_selector_window.focus_force()
            return
        popup = tk.Toplevel(self.root)
        self._target_selector_window = popup
        popup.title('按装备和目标原始批号筛选')
        popup.transient(self.root)
        popup.resizable(True, True)
        popup.protocol('WM_DELETE_WINDOW', lambda : self._close_plot_target_selector(popup))
        heterogeneous_target_ids = _multi_source_fused_target_ids(self.plot_target_statuses) if any((item.data_kind == 'SW' for item in self.available_plot_sources)) else set()
        fusion_source_catalog = self._result_fusion_plot_sources(self.current_result) if self._plot_context == 'result' and self.current_result is not None else list(self.available_plot_sources)
        fusion_group_options = _build_fusion_group_options(fusion_source_catalog, self.plot_target_statuses) if heterogeneous_target_ids else []
        ttk.Label(popup, text='第一层多选装备编号；第二层只列出所选装备内部的目标原始批号MBY。选择“异构设备融合（已融合）”后，第二层改为每条融合航迹一行；选中一行即可同时显示该结果的SW三维源航迹、已关联EW二维约束和融合航迹。任一层不选择表示该层全部。', wraplength=650, foreground='#64748b').pack(fill='x', padx=10, pady=(10, 6))
        lists = ttk.Frame(popup)
        lists.pack(fill='both', expand=True, padx=10)
        device_frame = ttk.LabelFrame(lists, text='1. 参测设备（EW/SW共享装备编号ZBB，可多选）', padding=6)
        source_frame = ttk.LabelFrame(lists, text='2. 目标原始批号（MBY，可多选）', padding=6)
        device_frame.pack(side='left', fill='both', expand=True, padx=(0, 5))
        source_frame.pack(side='left', fill='both', expand=True, padx=(5, 0))
        device_body = ttk.Frame(device_frame)
        device_body.pack(fill='both', expand=True)
        device_list = tk.Listbox(device_body, selectmode='multiple', exportselection=False, width=24, height=min(max(len({item.zbb for item in self.available_plot_sources}) + int(bool(heterogeneous_target_ids)), 6), 18), font=(self.ui_font_family, 9, 'normal'))
        device_scroll = ttk.Scrollbar(device_body, orient='vertical', command=device_list.yview)
        device_list.configure(yscrollcommand=device_scroll.set)
        device_list.pack(side='left', fill='both', expand=True)
        device_scroll.pack(side='right', fill='y')
        source_body = ttk.Frame(source_frame)
        source_body.pack(fill='both', expand=True)
        source_list = tk.Listbox(source_body, selectmode='multiple', exportselection=False, width=42, height=18, font=(self.ui_font_family, 9, 'normal'))
        source_y_scroll = ttk.Scrollbar(source_body, orient='vertical', command=source_list.yview)
        source_x_scroll = ttk.Scrollbar(source_body, orient='horizontal', command=source_list.xview)
        source_list.configure(yscrollcommand=source_y_scroll.set, xscrollcommand=source_x_scroll.set)
        source_list.grid(row=0, column=0, sticky='nsew')
        source_y_scroll.grid(row=0, column=1, sticky='ns')
        source_x_scroll.grid(row=1, column=0, sticky='ew')
        source_body.rowconfigure(0, weight=1)
        source_body.columnconfigure(0, weight=1)
        real_device_options = sorted({item.zbb for item in self.available_plot_sources})
        device_options = [HETEROGENEOUS_FUSION_DEVICE_OPTION] + real_device_options if heterogeneous_target_ids else list(real_device_options)
        heterogeneous_device_count = len({item.zbb for item in fusion_source_catalog if item.target_id in heterogeneous_target_ids})
        data_kinds_by_zbb = {zbb: sorted({item.data_kind for item in self.available_plot_sources if item.zbb == zbb}) for zbb in real_device_options}
        for (index, option) in enumerate(device_options):
            if option == HETEROGENEOUS_FUSION_DEVICE_OPTION:
                device_list.insert('end', f'{HETEROGENEOUS_FUSION_DEVICE_LABEL}｜{len(heterogeneous_target_ids)}个目标 / {heterogeneous_device_count}种装备')
                device_list.itemconfigure(index, foreground='#1e3a8a', background='#dbeafe', selectforeground='#ffffff', selectbackground='#1e3a8a')
                if self.selected_plot_fusion_targets:
                    device_list.selection_set(index)
                continue
            zbb = option
            returned_kinds = '+'.join(data_kinds_by_zbb.get(zbb, [])) or '无'
            device_list.insert('end', f'装备编号={zbb}｜本区间数据={returned_kinds}')
            if any((key[1] == zbb for key in self.selected_plot_devices)):
                device_list.selection_set(index)
        source_options: List[object] = []
        fusion_mode_was_selected = bool(self.selected_plot_fusion_targets)

        def selected_device_options() -> set[str]:
            return {device_options[index] for index in device_list.curselection() if index < len(device_options)}

        def selected_fusion_targets() -> set[str]:
            return set(heterogeneous_target_ids) if HETEROGENEOUS_FUSION_DEVICE_OPTION in selected_device_options() else set()

        def selected_device_keys() -> set[tuple[str, str]]:
            options = selected_device_options()
            if HETEROGENEOUS_FUSION_DEVICE_OPTION in options:
                return set()
            selected_zbbs = options - {HETEROGENEOUS_FUSION_DEVICE_OPTION}
            return {item.device_key for item in self.available_plot_sources if item.zbb in selected_zbbs}

        def refresh_sources(_event=None) -> None:
            nonlocal source_options, fusion_mode_was_selected
            current_entries = {source_options[index] for index in source_list.curselection() if index < len(source_options)}
            selected_devices = selected_device_keys()
            fusion_targets = selected_fusion_targets()
            fusion_mode_is_selected = bool(fusion_targets)
            mode_changed = fusion_mode_is_selected != fusion_mode_was_selected
            fusion_mode_was_selected = fusion_mode_is_selected
            source_list.delete(0, 'end')
            if fusion_mode_is_selected:
                source_frame.configure(text='2. 已融合航迹（每行包含全部成员装备，可多选）')
                source_options = list(fusion_group_options)
                selected_group_targets = {item.target_id for item in current_entries if isinstance(item, PlotFusionGroupOption)}
                if not selected_group_targets and (not mode_changed):
                    if self.selected_plot_fusion_targets != heterogeneous_target_ids:
                        selected_group_targets = set(self.selected_plot_fusion_targets)
                for (index, group_option) in enumerate(fusion_group_options):
                    source_list.insert('end', self._plot_fusion_group_label(group_option))
                    if group_option.target_id in selected_group_targets:
                        source_list.selection_set(index)
                    source_list.itemconfigure(index, foreground='#1e3a8a', background='#dbeafe', selectforeground='#ffffff', selectbackground='#1e3a8a')
                return
            source_frame.configure(text='2. 目标原始批号（MBY，可多选）')
            previously_selected = {item for item in current_entries if isinstance(item, tuple)} | set(self.selected_plot_sources)
            if mode_changed:
                previously_selected = set()
            ordinary_options = sorted({item.source_key for item in self.available_plot_sources if not selected_devices or item.device_key in selected_devices})
            source_options = list(ordinary_options)
            for (index, source_key) in enumerate(ordinary_options):
                source_list.insert('end', self._plot_source_label(source_key))
                if source_key in previously_selected:
                    source_list.selection_set(index)
                statuses = [self.plot_target_statuses[item.target_id] for item in self.available_plot_sources if item.source_key == source_key and item.target_id in self.plot_target_statuses]
                if not statuses:
                    continue
                status = statuses[0]
                (foreground, background) = TARGET_STATUS_COLORS.get(status.classification, ('#334155', '#ffffff'))
                source_list.itemconfigure(index, foreground=foreground, background=background, selectforeground='#ffffff', selectbackground=foreground)
        device_list.bind('<<ListboxSelect>>', refresh_sources)
        refresh_sources()
        selectors = ttk.Frame(popup)
        selectors.pack(fill='x', padx=10, pady=(6, 0))
        select_all_source_label = tk.StringVar(value='全部融合航迹' if fusion_mode_was_selected else '全部MBY')
        ttk.Button(selectors, text='全部装备', command=lambda : (device_list.selection_clear(0, 'end'), refresh_sources())).pack(side='left')
        ttk.Button(selectors, textvariable=select_all_source_label, command=lambda : source_list.selection_clear(0, 'end')).pack(side='right')

        def update_source_mode_label(_event=None) -> None:
            select_all_source_label.set('全部融合航迹' if HETEROGENEOUS_FUSION_DEVICE_OPTION in selected_device_options() else '全部MBY')
        device_list.bind('<<ListboxSelect>>', update_source_mode_label, add='+')
        buttons = ttk.Frame(popup)
        buttons.pack(fill='x', padx=10, pady=10)
        ttk.Button(buttons, text='取消', command=lambda : self._close_plot_target_selector(popup)).pack(side='right')
        ttk.Button(buttons, text='确定', style='Accent.TButton', command=lambda : self._apply_plot_target_selection(device_list, device_options, source_list, source_options, heterogeneous_target_ids, popup)).pack(side='right', padx=6)
        popup.update_idletasks()
        x = self.plot_target_button.winfo_rootx()
        y = self.plot_target_button.winfo_rooty() - popup.winfo_reqheight() - 4
        if y < 0:
            y = self.plot_target_button.winfo_rooty() + self.plot_target_button.winfo_height() + 4
        popup.geometry(f'+{x}+{y}')
        popup.grab_set()
        device_list.focus_set()

    def _close_plot_target_selector(self, popup: tk.Toplevel) -> None:
        if popup.winfo_exists():
            try:
                popup.grab_release()
            except tk.TclError:
                pass
            popup.destroy()
        self._target_selector_window = None

    def _apply_plot_target_selection(self, device_list: tk.Listbox, device_options: Sequence[str], source_list: tk.Listbox, source_options: Sequence[object], heterogeneous_target_ids: set[str], popup: tk.Toplevel) -> None:
        selected_device_options = {device_options[index] for index in device_list.curselection()}
        aggregate_selected = HETEROGENEOUS_FUSION_DEVICE_OPTION in selected_device_options
        all_zbbs = set(device_options) - {HETEROGENEOUS_FUSION_DEVICE_OPTION}
        selected_zbbs = set() if aggregate_selected else selected_device_options - {HETEROGENEOUS_FUSION_DEVICE_OPTION}
        self.selected_plot_devices = set() if not selected_zbbs or selected_zbbs == all_zbbs else {item.device_key for item in self.available_plot_sources if item.zbb in selected_zbbs}
        selected_entries = {source_options[index] for index in source_list.curselection()}
        if aggregate_selected:
            selected_group_targets = {item.target_id for item in selected_entries if isinstance(item, PlotFusionGroupOption)}
            self.selected_plot_fusion_targets = selected_group_targets or set(heterogeneous_target_ids)
            self.selected_plot_sources = set()
            if self.current_result is not None and self.current_result.ew_read is not None:
                selected_fusion_targets = set(self.selected_plot_fusion_targets)
                self.plot_mode_var.set('SW+EW联合')
                self._configure_plot_sources(self._result_plot_sources(self.current_result, 'SW+EW联合'), 'result', self.current_result.target_statuses)
                self.selected_plot_fusion_targets = selected_fusion_targets
        else:
            all_sources = {item for item in source_options if isinstance(item, tuple)}
            selected_sources = {item for item in selected_entries if isinstance(item, tuple)}
            self.selected_plot_sources = set() if not selected_sources or selected_sources == all_sources else selected_sources
            self.selected_plot_fusion_targets = set()
        self._update_plot_target_summary()
        self._close_plot_target_selector(popup)
        self._redraw_plot_targets()

    def _on_plot_mode_changed(self, _event=None) -> None:
        if self._plot_context == 'result' and self.current_result is not None:
            self._configure_plot_sources(self._result_plot_sources(self.current_result, self.plot_mode_var.get()), 'result', self.current_result.target_statuses)
        self._redraw_plot_targets()

    def _redraw_plot_targets(self) -> None:
        if self._plot_context == 'result' and self.current_result is not None:
            self._draw_result(self.current_result, refresh_targets=False)
        elif self._plot_context == 'preview' and self.current_preview is not None:
            self._draw_input_preview(self.current_preview, refresh_targets=False)

    def _prepare_axis(self, title: str, labels: tuple[str, str, str]) -> None:
        self.axis.clear()
        self._set_plot_legend([])
        self.axis.set_axis_on()
        self.axis.set_xlabel(labels[0], labelpad=9)
        self.axis.set_ylabel(labels[1], labelpad=9)
        self.axis.set_zlabel(labels[2], labelpad=7)
        self.axis.set_title(title, pad=18)
        self.axis.grid(alpha=0.22)
        self.axis.view_init(elev=24, azim=-58)
        self.axis.set_box_aspect((1.35, 1.55, 0.72))

    def _set_plot_legend(self, entries: Sequence[tuple[str, str]]) -> None:
        self.plot_legend.delete(0, 'end')
        if not entries:
            self.plot_legend.insert('end', '暂无可显示航迹')
            self.plot_legend.itemconfigure(0, foreground='#64748b')
            return
        fixed_entries = (('▲  起点', START_MARKER_COLOR), ('✕  终点', END_MARKER_COLOR))
        for (text, color) in (*fixed_entries, *entries):
            self.plot_legend.insert('end', text)
            self.plot_legend.itemconfigure(self.plot_legend.size() - 1, foreground=color)

    def _scroll_plot_legend(self, event: tk.Event) -> str:
        if event.delta:
            self.plot_legend.yview_scroll(-3 if event.delta > 0 else 3, 'units')
        return 'break'

    def _draw_track_endpoints(self, points: np.ndarray) -> None:
        if not len(points):
            return
        start = points[0]
        end = points[-1]
        self.axis.scatter([start[0]], [start[1]], [start[2]], marker='^', s=62, c=START_MARKER_COLOR, edgecolors='#14532d', linewidths=0.9, depthshade=False, zorder=20)
        self.axis.scatter([end[0]], [end[1]], [end[2]], marker='X', s=68, c=END_MARKER_COLOR, edgecolors='#7f1d1d', linewidths=0.9, depthshade=False, zorder=21)

    def _draw_input_preview(self, read_result: SwReadResult, refresh_targets: bool=True, statuses: Optional[Dict[str, TargetFusionStatus]]=None) -> None:
        self.current_preview = read_result
        if statuses is not None:
            self.current_preview_statuses = dict(statuses)
        preview_sources = self._preview_plot_sources(read_result)
        preview_target_ids = sorted({item.target_id for item in preview_sources})
        if refresh_targets:
            self._configure_plot_sources(preview_sources, 'preview', self.current_preview_statuses)
        target_filter = self._selected_plot_targets()
        if target_filter is None:
            title_scope = '全部目标总览'
        elif len(target_filter) == 1:
            title_scope = f'目标={next(iter(target_filter))}｜坐标轴自动聚焦'
        else:
            title_scope = f'已选{len(target_filter)}个目标｜坐标轴按所选目标自动聚焦'
        self._prepare_axis(f'{read_result.path.name}：{title_scope}（三维经纬高预览）', ('经度 / °', '纬度 / °', '高度 / m'))
        target_colors = build_target_color_map(preview_target_ids)
        line_styles = ('-', '--', '-.', ':')
        legend_patterns = ('━━━━', '┄┄┄┄', '━·━·', '······')
        visible_points = []
        legend_entries = []
        visible_groups = [((f'LOCAL-{str(zbb)}-MBY-{str(local_mby)}', str(local_mby), str(zbb)), group) for ((local_mby, zbb), group) in read_result.frame.groupby(['_mby', '_zbb'], sort=True) if self._plot_source_is_visible('SW', str(zbb), str(local_mby))]
        per_series_limit = min(MAX_GUI_POINTS_PER_SERIES, max(1, MAX_GUI_TOTAL_POINTS // max(len(visible_groups), 1)))
        for (index, ((target_id, local_mby, zbb), group)) in enumerate(visible_groups):
            group = group.sort_values('_jdsc', kind='stable')
            group = group.iloc[_sample_indices(len(group), per_series_limit)]
            color = target_colors[str(target_id)]
            visible_points.extend(group[['_mbj', '_mbw', '_mbg']].to_numpy(dtype=float))
            self.axis.plot(group['_mbj'], group['_mbw'], group['_mbg'], color=color, linestyle=line_styles[index % len(line_styles)], linewidth=1.5, marker='o', markersize=2.2, alpha=0.76, label=f'局部航迹={target_id}｜装备={zbb}｜局部MBY={local_mby}')
            points = group[['_mbj', '_mbw', '_mbg']].to_numpy(dtype=float)
            self._draw_track_endpoints(points)
            legend_entries.append((f'{legend_patterns[index % len(legend_patterns)]} 实测｜装备={zbb}｜局部MBY={local_mby}', color))
        (longitude, latitude, altitude) = adaptive_axis_bounds(visible_points, padding_ratio=(0.06, 0.06, 0.1), minimum_span=(0.0001, 0.0001, 10.0))
        self.axis.set_xlim(*longitude)
        self.axis.set_ylim(*latitude)
        self.axis.set_zlim(*altitude)
        self._set_plot_legend(legend_entries)
        if not legend_entries:
            self.axis.text2D(0.5, 0.52, '当前绝对时戳区间内没有可显示的数据', transform=self.axis.transAxes, ha='center', va='center', fontsize=11, color='#64748b')
        self.figure.tight_layout()
        self.canvas.draw_idle()

    def _draw_result(self, result: ExperimentResult, refresh_targets: bool=True) -> None:
        if refresh_targets:
            self._configure_plot_sources(self._result_plot_sources(result, self.plot_mode_var.get()), 'result', result.target_statuses)
        if result.ew_read is not None and (self.selected_plot_fusion_targets or self.plot_mode_var.get() != 'SW融合'):
            self._draw_ew_result(result, 'SW+EW联合' if self.selected_plot_fusion_targets else self.plot_mode_var.get())
            return
        target_filter = self._selected_plot_targets()
        if self.selected_plot_fusion_targets:
            title = f'{HETEROGENEOUS_FUSION_DEVICE_LABEL}｜{len(target_filter or set())}个目标｜全部成员源航迹与融合航迹'
        elif target_filter is None:
            title = '全部目标总览（三维 E-N-U，保留目标间相对位置）'
        elif len(target_filter) == 1:
            title = f'目标={next(iter(target_filter))}｜源航迹与融合航迹（坐标轴自动聚焦）'
        else:
            title = f'已选{len(target_filter)}个目标｜源航迹与融合航迹（共同自适应范围）'
        self._prepare_axis(title, ('东向 E / m', '北向 N / m', '高度 U / m'))
        detections_by_series: Dict[tuple[str, str], list] = {}
        for detection in result.normalized_detections:
            detections_by_series.setdefault((detection.target_id, detection.sensor_id), []).append(detection)

        def detection_source(detections: Sequence[object]) -> tuple[str, str]:
            first = detections[0]
            sensor = result.config['sensors'][first.sensor_id]
            zbb = str(sensor.get('zbb', first.sensor_id))
            local_mby = str(first.local_target_id or first.target_id)
            return (zbb, local_mby)
        sparse_keys = {(item.target_id, item.zbb): item for item in result.source_tracks.sparse_groups}
        source_color_keys = {('SW', str(target_id), *detection_source(detections)) for ((target_id, _), detections) in detections_by_series.items() if detections} | {('SW', str(target_id), str(zbb), str(summary.local_target_id)) for ((target_id, zbb), summary) in sparse_keys.items()}
        target_values = sorted(set(result.config['scenario'].get('input_target_values', [])) | {item.target_id for item in self.available_plot_sources})
        (target_colors, source_colors) = _build_track_color_maps(target_values, source_color_keys)
        line_styles = ('--', '-.', ':', (0, (5, 2, 1, 2)))
        legend_patterns = ('┄┄┄┄', '━·━·', '······', '━··━')
        display_was_sampled = False
        visible_points = []
        legend_entries = []
        visible_detection_series_count = sum((bool(detections) and self._plot_source_is_visible('SW', *detection_source(detections)) for ((target_id, _), detections) in detections_by_series.items()))
        per_series_limit = min(MAX_GUI_POINTS_PER_SERIES, max(1, MAX_GUI_TOTAL_POINTS // max(visible_detection_series_count, 1)))
        for (series_index, ((target_id, sensor_id), detections)) in enumerate(sorted(detections_by_series.items())):
            if not detections:
                continue
            (zbb, local_mby) = detection_source(detections)
            if not self._plot_source_is_visible('SW', zbb, local_mby):
                continue
            detections = sorted(detections, key=lambda item: (item.corrected_time_s, item.detection_id))
            display_was_sampled = display_was_sampled or len(detections) > per_series_limit
            displayed = [detections[item] for item in _sample_indices(len(detections), per_series_limit)]
            states = np.asarray([item.state_enu for item in displayed])
            visible_points.extend(states[:, :3])
            sensor = result.config['sensors'][sensor_id]
            configured_label = str(sensor.get('label', f'设备 {sensor_id}'))
            device_label = configured_label if zbb in configured_label else f'装备={zbb}｜{configured_label}'
            label = f'目标={target_id}｜{device_label}｜局部MBY={local_mby}'
            color = source_colors['SW', str(target_id), zbb, local_mby]
            self.axis.plot(states[:, 0], states[:, 1], states[:, 2], color=color, linestyle=line_styles[series_index % len(line_styles)], linewidth=1.25, alpha=0.62, label=label)
            self.axis.scatter(states[:, 0], states[:, 1], states[:, 2], color=color, s=6, alpha=0.18)
            self._draw_track_endpoints(states[:, :3])
            legend_entries.append((f'{legend_patterns[series_index % len(legend_patterns)]} 实测｜{label}', color))
        reference = result.config['scenario']['reference']
        converter = GeodeticConverter(float(reference['longitude_deg']), float(reference['latitude_deg']), float(reference['altitude_m']))
        raw_group_indices = result.sw_read.frame.groupby(['_mby', '_zbb'], sort=False).groups
        for (sparse_index, ((target_id, zbb), sparse_summary)) in enumerate(sorted(sparse_keys.items())):
            if not self._plot_source_is_visible('SW', str(zbb), str(sparse_summary.local_target_id)):
                continue
            indices = raw_group_indices.get((sparse_summary.local_target_id, zbb), [])
            group = result.sw_read.frame.loc[indices].sort_values('_jdsc', kind='stable')
            if group.empty:
                continue
            display_was_sampled = display_was_sampled or len(group) > MAX_GUI_POINTS_PER_SERIES
            group = group.iloc[_sample_indices(len(group))]
            points = converter.geodetic_many_to_enu(group['_mbj'].to_numpy(dtype=float), group['_mbw'].to_numpy(dtype=float), group['_mbg'].to_numpy(dtype=float))
            visible_points.extend(points)
            color = source_colors['SW', str(target_id), str(zbb), str(sparse_summary.local_target_id)]
            if len(points) > 1:
                self.axis.plot(points[:, 0], points[:, 1], points[:, 2], color=color, linestyle=(0, (1, 3)), linewidth=1.0, alpha=0.52)
            self.axis.scatter(points[:, 0], points[:, 1], points[:, 2], color=color, marker='x', s=38, linewidths=1.5, alpha=0.9)
            if len(points) > 1:
                self._draw_track_endpoints(points)
            point_kind = '未成轨/虚警候选点迹'
            legend_entries.append((f'× {point_kind}｜局部MBY={sparse_summary.local_target_id}｜装备={zbb}｜{len(group)}点', color))
        estimates_by_track: Dict[str, list] = {}
        for estimate in result.estimates:
            estimates_by_track.setdefault(estimate.track_id, []).append(estimate)
        visible_track_count = sum((bool(values) and (target_filter is None or str(values[0].target_id) in target_filter) for values in estimates_by_track.values()))
        per_fused_limit = min(MAX_GUI_POINTS_PER_SERIES, max(1, MAX_GUI_TOTAL_POINTS // max(visible_track_count, 1)))
        for (track_id, track_estimates) in sorted(estimates_by_track.items()):
            if target_filter is not None and str(track_estimates[0].target_id) not in target_filter:
                continue
            track_estimates = sorted(track_estimates, key=lambda item: item.event_time_s)
            display_was_sampled = display_was_sampled or len(track_estimates) > per_fused_limit
            displayed_estimates = [track_estimates[item] for item in _sample_indices(len(track_estimates), per_fused_limit)]
            fused = np.asarray([item.state_enu for item in displayed_estimates])
            visible_points.extend(fused[:, :3])
            target_id = str(displayed_estimates[0].target_id)
            self.axis.plot(fused[:, 0], fused[:, 1], fused[:, 2], color=target_colors[target_id], linewidth=3.6, label=f'融合航迹 {track_id}｜目标={target_id}')
            self._draw_track_endpoints(fused[:, :3])
            legend_entries.append((f'━━━━ 融合｜{track_id}｜目标={target_id}', target_colors[target_id]))
        (padding_ratio, minimum_span) = adaptive_axes_settings(result.config)
        (east, north, up) = adaptive_axis_bounds(visible_points, padding_ratio=padding_ratio, minimum_span=minimum_span)
        self.axis.set_xlim(*east)
        self.axis.set_ylim(*north)
        self.axis.set_zlim(*up)
        self._set_plot_legend(legend_entries)
        if not legend_entries:
            self.axis.text2D(0.5, 0.52, '当前区间没有可成轨目标；请查看 false_alarm_report.csv', transform=self.axis.transAxes, ha='center', va='center', fontsize=11, color='#b45309')
        if target_filter is None and len(result.config['scenario'].get('input_target_values', [])) > 1:
            self.axis.text2D(0.99, 0.985, '目标相距较远时，请在下方“目标选择”中选择一个或多个目标查看自适应细节', transform=self.axis.transAxes, ha='right', va='top', fontsize=8, color='#64748b')
        if display_was_sampled:
            self.axis.text2D(0.99, 0.01, f'界面总计约显示不超过 {MAX_GUI_TOTAL_POINTS} 点、单系列不超过 {MAX_GUI_POINTS_PER_SERIES} 点；融合使用全部数据', transform=self.axis.transAxes, ha='right', va='bottom', fontsize=8, color='#64748b')
        self.figure.tight_layout()
        self.canvas.draw_idle()

    def _draw_ew_result(self, result: ExperimentResult, mode: str) -> None:
        target_filter = self._selected_plot_targets()
        self._prepare_axis(f'{HETEROGENEOUS_FUSION_DEVICE_LABEL}｜SW 主航迹 + EW 异步约束' if self.selected_plot_fusion_targets else 'EW/SW 共享装备与二维角度射线' if mode == 'EW单独' else 'SW 主航迹 + EW 异步约束联合融合', ('东向 E / m', '北向 N / m', '高度 U / m'))
        association_by_id = {item.measurement_id: item for item in result.ew_associations}
        source_series: Dict[tuple[str, str], list] = {}
        for detection in result.normalized_detections:
            source_series.setdefault((str(detection.target_id), str(detection.sensor_id)), []).append(detection)

        def ew_display_target(measurement) -> str:
            association = association_by_id.get(measurement.measurement_id)
            return str(association.matched_target_id if association is not None and association.status == 'associated' and association.matched_target_id else measurement.target_id)
        target_values = sorted({item.target_id for item in result.estimates} | {item.target_id for item in result.ew_measurements} | {item.target_id for item in result.joint_estimates} | {ew_display_target(item) for item in result.ew_measurements})
        source_color_keys: set[tuple[str, str, str, str]] = set()
        for ((target_id, sensor_id), items) in source_series.items():
            if not items:
                continue
            sensor = result.config['sensors'][sensor_id]
            zbb = str(sensor.get('zbb', sensor_id))
            local_mby = str(items[0].local_target_id or target_id)
            source_color_keys.add(('SW', target_id, zbb, local_mby))
        for measurement in result.ew_measurements:
            source_color_keys.add(('EW', ew_display_target(measurement), str(measurement.zbb), str(measurement.target_id)))
        (colors, source_colors) = _build_track_color_maps(target_values, source_color_keys)
        sw_points = np.asarray([item.state_enu[:3] for item in result.estimates], dtype=float)
        configured_length = float(result.config['ew']['joint_fusion'].get('ray_display_length_m', 5000.0))
        if mode == 'SW+EW联合' and len(sw_points):
            span = np.maximum(np.ptp(sw_points, axis=0), 1.0)
            ray_length = min(configured_length, max(200.0, float(np.linalg.norm(span)) * 0.65))
        else:
            ray_length = configured_length
        joint_config = result.config['ew']['joint_fusion']
        maximum = int(joint_config.get('maximum_visualized_ew_reports', 5000))
        if mode == 'SW+EW联合':
            per_source = max(1, int(joint_config.get('combined_view_constraints_per_source', 2)))
            combined_limit = max(1, min(maximum, int(joint_config.get('maximum_combined_view_constraints', 24))))
            grouped_constraints: Dict[tuple[str, str, str], list] = {}
            for measurement in result.ew_measurements:
                association = association_by_id.get(measurement.measurement_id)
                if association is None or association.status != 'associated' or (not association.matched_target_id):
                    continue
                display_target = str(association.matched_target_id)
                if target_filter is not None and display_target not in target_filter:
                    continue
                grouped_constraints.setdefault((display_target, str(measurement.zbb), str(measurement.target_id)), []).append(measurement)
            displayed_measurements = []
            for items in grouped_constraints.values():
                displayed_measurements.extend(sorted(items, key=lambda item: (item.event_time_s, item.measurement_id))[-per_source:])
            displayed_measurements.sort(key=lambda item: (item.event_time_s, item.measurement_id))
            if len(displayed_measurements) > combined_limit:
                displayed_measurements = [displayed_measurements[int(index)] for index in _sample_indices(len(displayed_measurements), combined_limit)]
        else:
            standalone_limit = max(1, min(maximum, int(joint_config.get('maximum_standalone_view_constraints', 120))))
            displayed_measurements = [result.ew_measurements[int(index)] for index in _sample_indices(len(result.ew_measurements), standalone_limit)]
        anchor_series: Dict[str, list] = {}
        for item in result.joint_estimates or result.estimates:
            anchor_series.setdefault(str(item.target_id), []).append(item)
        for items in anchor_series.values():
            items.sort(key=lambda item: item.event_time_s)
        local_constraint_length = max(60.0, min(400.0, float(np.linalg.norm(span)) * 0.12)) if mode == 'SW+EW联合' and len(sw_points) else ray_length
        visible_points = []
        legend_entries = []
        labelled = set()
        if mode == 'SW+EW联合' and self.selected_plot_fusion_targets:
            visible_source_count = sum((bool(items) and (target_filter is None or target_id in target_filter) for ((target_id, _), items) in source_series.items()))
            source_limit = min(MAX_GUI_POINTS_PER_SERIES, max(1, MAX_GUI_TOTAL_POINTS // max(visible_source_count, 1)))
            source_styles = ('--', '-.', ':', (0, (5, 2, 1, 2)))
            for (source_index, ((target_id, sensor_id), items)) in enumerate(sorted(source_series.items())):
                if not items or (target_filter is not None and target_id not in target_filter):
                    continue
                sensor = result.config['sensors'][sensor_id]
                zbb = str(sensor.get('zbb', sensor_id))
                local_mby = str(items[0].local_target_id or target_id)
                if not self._plot_source_is_visible('SW', zbb, local_mby):
                    continue
                items = sorted(items, key=lambda item: (item.corrected_time_s, item.detection_id))
                displayed = [items[item] for item in _sample_indices(len(items), source_limit)]
                values = np.asarray([item.state_enu for item in displayed])
                color = source_colors['SW', target_id, zbb, local_mby]
                self.axis.plot(values[:, 0], values[:, 1], values[:, 2], color=color, linestyle=source_styles[source_index % len(source_styles)], linewidth=1.2, alpha=0.58)
                self._draw_track_endpoints(values[:, :3])
                visible_points.extend(values[:, :3])
                legend_entries.append((f'┄┄ SW成员源航迹｜目标={target_id}｜装备={zbb}｜MBY={local_mby}', color))
        for measurement in displayed_measurements:
            if measurement.sensor_enu is None:
                continue
            association = association_by_id.get(measurement.measurement_id)
            display_target = ew_display_target(measurement)
            if self.selected_plot_fusion_targets and (association is None or association.status != 'associated' or display_target not in self.selected_plot_fusion_targets):
                continue
            if not self._plot_source_is_visible('EW', str(measurement.zbb), str(measurement.target_id)):
                continue
            endpoint = measurement.endpoint_enu(ray_length)
            if endpoint is None:
                continue
            color = source_colors['EW', str(display_target), str(measurement.zbb), str(measurement.target_id)]
            if mode == 'SW+EW联合' and anchor_series.get(display_target):
                anchor_item = min(anchor_series[display_target], key=lambda item: abs(item.event_time_s - measurement.event_time_s))
                anchor = np.asarray(anchor_item.state_enu[:3], dtype=float)
                sensor = np.asarray(measurement.sensor_enu, dtype=float)
                direction = np.asarray(endpoint, dtype=float) - sensor
                direction_norm = float(np.linalg.norm(direction))
                if direction_norm <= 1e-09:
                    continue
                direction /= direction_norm
                closest = sensor + max(0.0, float(np.dot(anchor - sensor, direction))) * direction
                half = local_constraint_length * 0.5
                local_start = closest - direction * half
                local_end = closest + direction * half
                self.axis.plot([local_start[0], local_end[0]], [local_start[1], local_end[1]], [local_start[2], local_end[2]], color=color, linewidth=0.8, alpha=0.2, linestyle=':', zorder=2)
            else:
                self.axis.plot([measurement.sensor_enu[0], endpoint[0]], [measurement.sensor_enu[1], endpoint[1]], [measurement.sensor_enu[2], endpoint[2]], color=color, linewidth=0.8, alpha=0.18, linestyle='-' if measurement.range_m is not None else ':')
                visible_points.extend([measurement.sensor_enu, endpoint])
            label = f'EW关联｜EW目标={measurement.target_id}→SW目标={display_target}｜装备={measurement.zbb}' if association is not None and association.status == 'associated' else f'EW未关联｜目标={measurement.target_id}｜装备={measurement.zbb}'
            label = ('局部角度约束｜' if mode == 'SW+EW联合' else '实距线｜' if measurement.range_m is not None else '方向射线｜') + label
            if label not in labelled:
                legend_entries.append((f'╱ {label}', color))
                labelled.add(label)
        equipment_kinds: Dict[str, set[str]] = {}
        if mode == 'SW+EW联合':
            for ((target_id, sensor_id), items) in source_series.items():
                if not items or (target_filter is not None and target_id not in target_filter):
                    continue
                sensor = result.config['sensors'][sensor_id]
                zbb = str(sensor.get('zbb', sensor_id))
                local_mby = str(items[0].local_target_id or target_id)
                if self._plot_source_is_visible('SW', zbb, local_mby):
                    equipment_kinds.setdefault(zbb, set()).add('SW')
        for measurement in result.ew_measurements:
            display_target = ew_display_target(measurement)
            association = association_by_id.get(measurement.measurement_id)
            if self.selected_plot_fusion_targets and (association is None or association.status != 'associated' or display_target not in self.selected_plot_fusion_targets):
                continue
            if target_filter is not None and display_target not in target_filter:
                continue
            if self._plot_source_is_visible('EW', str(measurement.zbb), str(measurement.target_id)):
                equipment_kinds.setdefault(str(measurement.zbb), set()).add('EW')
        for (zbb, position) in sorted(result.ew_sensor_positions.items()):
            zbb = str(zbb)
            if zbb not in equipment_kinds:
                continue
            self.axis.scatter([position[0]], [position[1]], [position[2]], marker='s', s=52, color='#111827', depthshade=False)
            if mode == 'EW单独':
                visible_points.append(position)
            returned_kinds = '+'.join(sorted(equipment_kinds[zbb]))
            legend_entries.append((f'■ 共享装备={zbb}｜本区间数据={returned_kinds}', '#111827'))
        if mode == 'SW+EW联合':
            baseline = {}
            for item in result.estimates:
                baseline.setdefault(item.track_id, []).append(item)
            for (track_id, items) in sorted(baseline.items()):
                target_id = str(items[0].target_id)
                if target_filter is not None and target_id not in target_filter:
                    continue
                values = np.asarray([x.state_enu for x in sorted(items, key=lambda x: x.event_time_s)])
                self.axis.plot(values[:, 0], values[:, 1], values[:, 2], color=colors[target_id], linestyle='--', linewidth=1.4, alpha=0.58)
                visible_points.extend(values[:, :3])
                legend_entries.append((f'┄┄ SW主航迹｜{track_id}｜目标={target_id}', colors[target_id]))
            joint = {}
            for item in result.joint_estimates:
                joint.setdefault(item.track_id, []).append(item)
            for (track_id, items) in sorted(joint.items()):
                target_id = str(items[0].target_id)
                if target_filter is not None and target_id not in target_filter:
                    continue
                values = np.asarray([x.state_enu for x in sorted(items, key=lambda x: x.event_time_s)])
                self.axis.plot(values[:, 0], values[:, 1], values[:, 2], color=colors[target_id], linewidth=3.6)
                ew_updates = np.asarray([item.state_enu[:3] for item in items if item.lifecycle_state == 'joint_confirmed' and item.associated_detection_ids], dtype=float)
                if len(ew_updates):
                    self.axis.scatter(ew_updates[:, 0], ew_updates[:, 1], ew_updates[:, 2], marker='o', s=28, color=colors[target_id], edgecolors='white', linewidths=0.7, depthshade=False)
                    legend_entries.append((f'● EW更新状态点｜目标={target_id}', colors[target_id]))
                self._draw_track_endpoints(values[:, :3])
                visible_points.extend(values[:, :3])
                legend_entries.append((f'━━━━ SW+EW联合｜{track_id}｜目标={target_id}', colors[target_id]))
        (padding, minimum) = adaptive_axes_settings(result.config)
        (east, north, up) = adaptive_axis_bounds(visible_points, padding_ratio=padding, minimum_span=minimum)
        self.axis.set_xlim(*east)
        self.axis.set_ylim(*north)
        self.axis.set_zlim(*up)
        self._set_plot_legend(legend_entries)
        if not legend_entries:
            self.axis.text2D(0.5, 0.52, '当前选择下没有可显示的 EW 数据', transform=self.axis.transAxes, ha='center', va='center', color='#64748b')
        self.figure.tight_layout()
        self.canvas.draw_idle()

    def _set_metrics(self, metrics: dict) -> None:
        self.metrics_text.configure(state='normal')
        self.metrics_text.delete('1.0', 'end')
        self.metrics_text.insert('1.0', json.dumps(metrics, ensure_ascii=False, indent=2))
        self.metrics_text.configure(state='disabled')

    def _append_log(self, message: str) -> None:
        stamp = datetime.now().strftime('%H:%M:%S')
        self.log_text.configure(state='normal')
        self.log_text.insert('end', f'[{stamp}] {message}\n')
        self.log_text.see('end')
        self.log_text.configure(state='disabled')

    def _open_output(self) -> None:
        if self.current_output is None or not self.current_output.is_dir():
            messagebox.showwarning('没有结果目录', '请先完成一次融合。', parent=self.root)
            return
        try:
            _open_local_path(self.current_output)
        except (AttributeError, OSError) as error:
            messagebox.showerror('无法打开目录', str(error), parent=self.root)

    def _open_summary(self) -> None:
        if self.current_output is None:
            messagebox.showwarning('没有融合总结', '请先完成一次融合。', parent=self.root)
            return
        summary_path = self.current_output / 'fusion_summary.html'
        if not summary_path.is_file():
            messagebox.showerror('融合总结不存在', f'未找到：{summary_path}', parent=self.root)
            return
        try:
            _open_local_path(summary_path)
        except (AttributeError, OSError) as error:
            messagebox.showerror('无法打开融合总结', str(error), parent=self.root)

    def _open_player(self) -> None:
        if self.current_output is None:
            messagebox.showwarning('没有融合结果', '请先完成一次融合。', parent=self.root)
            return
        player_path = self.current_output / 'fusion_player.html'
        try:
            self._stop_player()
            (server, url, _) = _create_fusion_player_server(player_path, port=8765)
            thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.2}, daemon=True)
            thread.start()
            self._player_server = server
            opened = webbrowser.open(url, new=2)
            self._append_log(f'动态播放器地址：{url}')
            if not opened:
                messagebox.showinfo('播放器地址', f'请在浏览器中打开：\n{url}', parent=self.root)
        except Exception as error:
            messagebox.showerror('无法打开播放器', str(error), parent=self.root)

    def _open_cesium_player(self) -> None:
        if self.current_output is None:
            messagebox.showwarning('没有融合结果', '请先完成一次融合。', parent=self.root)
            return
        player_path = self.current_output / 'cesium_map_player.html'
        try:
            self._stop_player()
            (server, url, _) = _create_cesium_player_server(player_path, port=8766)
            thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.2}, daemon=True)
            thread.start()
            self._player_server = server
            opened = webbrowser.open(url, new=2)
            self._append_log(f'Cesium离线真实地图播放器地址：{url}')
            if not opened:
                messagebox.showinfo('Cesium播放器地址', f'请在本机现代浏览器中打开：\n{url}', parent=self.root)
        except Exception as error:
            messagebox.showerror('无法打开Cesium离线地图', str(error), parent=self.root)

    def _stop_player(self) -> None:
        if self._player_server is not None:
            self._player_server.shutdown()
            self._player_server.server_close()
            self._player_server = None

    def _close(self) -> None:
        self._close_requested = True
        self._stop_realtime()

    def _finish_close(self) -> None:
        self._closing = True
        self._stop_player()
        self.root.destroy()

def main() -> None:
    root = tk.Tk()
    RealFusionApp(root)
    root.mainloop()
if __name__ == '__main__':
    main()
