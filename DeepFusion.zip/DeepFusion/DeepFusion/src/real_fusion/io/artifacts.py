from __future__ import annotations
import csv
import json
from pathlib import Path
from typing import Iterable, Mapping, Optional, Sequence

def _serializable_record(record: Mapping[str, object]) -> dict:
    return {key: value if not isinstance(value, (dict, list)) else json.dumps(value, ensure_ascii=False) for (key, value) in record.items()}

def write_jsonl(records: Iterable[Mapping[str, object]], path: str | Path) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', encoding='utf-8') as handle:
        for record in records:
            handle.write(json.dumps(dict(record), ensure_ascii=False) + '\n')

def write_csv(records: Iterable[Mapping[str, object]], path: str | Path, fieldnames: Optional[Sequence[str]]=None) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    iterator = iter(records)
    try:
        first = _serializable_record(next(iterator))
    except StopIteration:
        if fieldnames:
            with output.open('w', encoding='utf-8-sig', newline='') as handle:
                csv.DictWriter(handle, fieldnames=list(fieldnames)).writeheader()
        else:
            output.write_text('', encoding='utf-8-sig')
        return
    with output.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fieldnames or first))
        writer.writeheader()
        writer.writerow(first)
        for record in iterator:
            writer.writerow(_serializable_record(record))

def write_json(data: Mapping[str, object], path: str | Path) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', encoding='utf-8') as handle:
        json.dump(dict(data), handle, ensure_ascii=False, indent=2)
