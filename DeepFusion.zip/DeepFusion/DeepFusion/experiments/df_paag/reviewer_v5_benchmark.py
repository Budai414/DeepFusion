from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import time
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'outputs/research/df_paag/reviewer_response_20261007'
METHODS = ('full', 'neural_constrained', 'neural_cc', 'B0', 'GNN-assignment', 'JPDA-exact-assignment', 'single_model', 'ensemble3')
NEURAL = {'full', 'neural_constrained', 'neural_cc', 'single_model', 'ensemble3'}
CONFIG = {'splits': ['test', 'ood'], 'indices': list(range(5)), 'warmups': 1, 'repetitions': 3, 'torch_threads': 2, 'methods': list(METHODS), 'method_order': 'cyclic rotation by task ordinal; each method has its own warmup', 'shared_compute_reuse': False, 'excluded': ['simulate', 'disk_IO', 'model_loading', 'training', 'truth_metrics', 'state_backend', 'counterfactual_truth_audit', 'sequence_baselines', 'legacy_full'], 'quantiles': 'pooled descriptive median/p95 over 30 timed runs per method, not a confidence interval'}

def read(path):
    with Path(path).open(encoding='utf-8') as stream:
        return json.load(stream)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def observed_task(saved):
    histories = [{key: np.asarray(value) for key, value in row.items() if key in ('t', 'p', 'v', 'sigma_pos', 'sigma_vel', 'rcs')} for row in saved['histories']]
    return {'histories': histories, 'sensor': np.asarray(saved['sensor'], dtype=np.int64), 'meta': {'decision_cutoff_s': float(saved['meta']['decision_cutoff_s'])}}

def hardware(torch):
    result = {'os': platform.platform(), 'machine': platform.machine(), 'processor': platform.processor() or os.environ.get('PROCESSOR_IDENTIFIER', 'unknown'), 'logical_cpus': os.cpu_count(), 'python': platform.python_version(), 'numpy': np.__version__, 'torch': torch.__version__, 'torch_threads': torch.get_num_threads(), 'torch_interop_threads': torch.get_num_interop_threads(), 'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(), 'thread_environment': {key: os.environ.get(key) for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS')}}
    try:
        import psutil
        result['physical_cpus'] = psutil.cpu_count(logical=False)
        result['memory_total_bytes'] = psutil.virtual_memory().total
    except ImportError:
        result['physical_cpus'] = None
    try:
        from threadpoolctl import threadpool_info
        result['native_threadpools'] = [{key: row.get(key) for key in ('internal_api', 'num_threads', 'version', 'architecture')} for row in threadpool_info()]
    except ImportError:
        result['native_threadpools'] = None
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=BASE / 'refinement_v5')
    parser.add_argument('--old-directory', type=Path, default=BASE / 'full_simulation_v4')
    parser.add_argument('--confirm-completed-run', action='store_true', help='Explicitly confirm the main evaluation is finished and no heavy jobs overlap')
    args = parser.parse_args()
    if not args.confirm_completed_run:
        parser.error('Wait for orchestration permission, then pass --confirm-completed-run')
    directory, old_directory = (args.directory.resolve(), args.old_directory.resolve())
    result_path = directory / 'results.json'
    selection_path = directory / 'frozen_selection.json'
    output = directory / 'end_to_end_benchmark.json'
    if not result_path.exists() or not selection_path.exists():
        raise FileNotFoundError('Both completed results.json and frozen_selection.json are required')
    if output.exists():
        raise FileExistsError('Refusing to overwrite completed runtime evidence')
    result = read(result_path)
    result_declared_sha256 = result.get('sha256')
    del result
    frozen = read(selection_path)
    for name, expected in frozen['source_hashes'].items():
        if sha(ROOT / name) != expected:
            raise RuntimeError(f'Frozen v5 source changed: {name}')
    old_selection = read(old_directory / 'frozen_selection.json')
    aliases = {'runner': 'experiments/df_paag/reviewer_full_simulation_v4.py', 'baseline_v4': 'research/df_paag/reviewer_baselines_v4.py'}
    for name, expected in old_selection.get('source_hashes_final', {}).items():
        if sha(ROOT / aliases.get(name, name)) != expected:
            raise RuntimeError(f'Frozen v4 dependency changed: {name}')
    import torch
    from scipy.special import expit
    from research.df_paag import reviewer_association_v4 as a
    from research.df_paag.reviewer_baselines_v4 import association_scores
    from research.df_paag.reviewer_decoder_v5 import decode, partition_labels, route
    from research.df_paag.reviewer_simulation_v3 import build_candidate_graph
    torch.set_num_threads(CONFIG['torch_threads'])
    torch.use_deterministic_algorithms(True)
    scaler_path = old_directory / 'normalization.json'
    scaler = {key: np.asarray(value, dtype=np.float32) for key, value in read(scaler_path).items()}
    models = []
    checkpoint_hashes = []
    for k, seed in enumerate(a.SEEDS):
        path = old_directory / f'checkpoint_full_{seed}.pt'
        checkpoint_hashes.append(sha(path))
        if checkpoint_hashes[-1] != frozen['checkpoint_hashes']['full'][k]:
            raise RuntimeError('Full-model checkpoint differs from the v5 source lock')
        checkpoint = torch.load(path, weights_only=False, map_location='cpu')
        if checkpoint['training_signature'] != old_selection['training_signature']:
            raise RuntimeError('Full-model checkpoint training signature mismatch')
        model = a.make_model('full')
        model.load_state_dict(checkpoint['state'])
        models.append(model.eval())

    def neural_scores(task, count):
        if not len(task['edges']):
            return np.zeros((count, 0), dtype=np.float64)
        x = (task['x'] - scaler['x_mean']) / scaler['x_std']
        x[~task['mask']] = 0
        physical = (np.column_stack([task['physics'], task['physical_logits']]) - scaler['p_mean']) / scaler['p_std']
        tensors = {'x': torch.tensor(x, dtype=torch.float32), 'mask': torch.tensor(task['mask']), 'edges': torch.tensor(task['edges'], dtype=torch.long), 'physics': torch.tensor(physical[:, :6], dtype=torch.float32), 'physical_logits': torch.tensor(physical[:, 6], dtype=torch.float32), 'sensor': torch.tensor(task['sensor'], dtype=torch.long)}
        with torch.no_grad():
            return np.stack([expit(a.forward(model, tensors).numpy()).astype(np.float64) for model in models[:count]])

    def pipeline(original, name):
        start = time.perf_counter()
        graph = build_candidate_graph(original['histories'], original['sensor'], original['meta']['decision_cutoff_s'])
        task = {**original, **graph}
        candidate_end = time.perf_counter()
        if name in NEURAL:
            task = a.prepare_features(task)
            feature_end = time.perf_counter()
        else:
            feature_end = candidate_end
        if name in NEURAL:
            count = 1 if name == 'single_model' else 3 if name == 'ensemble3' else 5
            native = neural_scores(task, count)
        elif name == 'B0':
            native = expit(task['physical_logits'])[None]
        else:
            fit = frozen['baselines'][name]['old_internal_parameters']
            native = association_scores(task, name, null_score=fit['null_score'], temperature=fit['temperature'])[None]
        score_end = time.perf_counter()
        if name in NEURAL:
            members = a.calibrate_members(native, frozen['calibration']['full'][:len(native)])
        else:
            members = a.calibrate_members(native, frozen['calibration']['physical' if name == 'B0' else name])
        probability = members.mean(0)
        routed = name in ('full', 'single_model', 'ensemble3')
        b0p = a.calibrate(expit(task['physical_logits']), frozen['calibration']['physical'][0]) if routed else None
        calibration_end = time.perf_counter()
        if routed:
            spec = frozen['methods']['full']
            selected, _ = route(task, probability, members, spec['threshold'], spec['policy'], b0p)
        elif name in ('neural_cc', 'neural_constrained'):
            spec = frozen['factorial'][name]
            selected = decode(task, probability, spec['threshold'], spec['decoder'])
        elif name == 'B0':
            selected = np.asarray(task['physical_logits']) >= 0
        else:
            selected = decode(task, probability, frozen['baselines'][name]['threshold'], 'threshold_cc')
        decoder_end = time.perf_counter()
        labels = partition_labels(len(task['sensor']), task['edges'], selected)
        end = time.perf_counter()
        return (task, selected, probability, labels, {'candidate_ms': (candidate_end - start) * 1000, 'feature_ms': (feature_end - candidate_end) * 1000 if name in NEURAL else 0.0, 'score_ms': (score_end - feature_end) * 1000, 'calibration_ms': (calibration_end - score_end) * 1000, 'decode_route_ms': (decoder_end - calibration_end) * 1000, 'partition_ms': (end - decoder_end) * 1000, 'total_ms': (end - start) * 1000})
    records = []
    decision_checks = 0
    warmup_checks = 0
    probability_max_error = 0.0
    task_hashes = {}
    started_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    for split_index, split in enumerate(CONFIG['splits']):
        for index in CONFIG['indices']:
            key = f'{split}_{index:03d}'
            task_path = directory / 'tasks' / f'{key}.json'
            record_path = directory / 'records' / f'{key}.json'
            saved_task, saved_record = (read(task_path), read(record_path))
            task_hashes[key] = {'task_sha256': sha(task_path), 'record_sha256': sha(record_path)}
            original = observed_task(saved_task)
            offset = (split_index * len(CONFIG['indices']) + index) % len(METHODS)
            order = METHODS[offset:] + METHODS[:offset]
            for name in order:
                method_record = saved_record['methods'][name]
                expected = np.asarray(method_record['selected'], dtype=bool)
                expected_probability = np.asarray(method_record['probabilities'], dtype=np.float64)
                timings = []
                for repetition in range(-CONFIG['warmups'], CONFIG['repetitions']):
                    rebuilt, selected, probability, labels, elapsed = pipeline(original, name)
                    for column, dtype in (('edges', np.int64), ('physics', np.float32), ('physical_logits', np.float32)):
                        expected_graph = np.asarray(saved_task[column], dtype=dtype)
                        if column == 'edges':
                            expected_graph = expected_graph.reshape(-1, 2)
                        elif column == 'physics':
                            expected_graph = expected_graph.reshape(-1, 6)
                        if not np.array_equal(rebuilt[column], expected_graph):
                            raise RuntimeError(f'Candidate replay mismatch: {key}/{column}')
                    if not np.array_equal(selected, expected):
                        raise RuntimeError(f'Selected decisions differ from lock: {key}/{name}')
                    if not np.allclose(probability, expected_probability, rtol=0, atol=1e-07):
                        raise RuntimeError(f'Calibrated probabilities differ from lock: {key}/{name}')
                    if len(probability):
                        probability_max_error = max(probability_max_error, float(np.max(np.abs(probability - expected_probability))))
                    expected_labels = partition_labels(len(original['sensor']), rebuilt['edges'], expected)
                    if not np.array_equal(labels, expected_labels):
                        raise RuntimeError(f'Partition replay mismatch: {key}/{name}')
                    if repetition >= 0:
                        timings.append(elapsed)
                        decision_checks += 1
                    else:
                        warmup_checks += 1
                records.append({'split': split, 'index': index, 'method': name, 'nodes': len(original['sensor']), 'edges': len(expected), 'member_count': 1 if name == 'single_model' else 3 if name == 'ensemble3' else 5 if name in NEURAL else 0, 'timings': timings})
            print(f'benchmarked {key} ({split_index * 5 + index + 1}/10)', flush=True)
    summary = {}
    for name in METHODS:
        values = [timing for row in records if row['method'] == name for timing in row['timings']]
        summary[name] = {'tasks': 10, 'repetitions': len(values), 'feature_cost_included': name in NEURAL, 'stages': {}}
        for stage in values[0]:
            array = np.asarray([row[stage] for row in values])
            summary[name]['stages'][stage] = {'median': float(np.median(array)), 'p95': float(np.quantile(array, 0.95)), 'mean': float(np.mean(array)), 'min': float(np.min(array)), 'max': float(np.max(array))}
    report = {'config': CONFIG, 'started_utc': started_utc, 'finished_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'hardware': hardware(torch), 'source_hashes': frozen['source_hashes'], 'script_sha256': sha(Path(__file__)), 'result_file_sha256': sha(result_path), 'result_declared_sha256': result_declared_sha256, 'selection_file_sha256': sha(selection_path), 'selection_declared_sha256': frozen.get('sha256'), 'normalization_sha256': sha(scaler_path), 'scaler_dtype': 'float32', 'full_checkpoint_hashes': checkpoint_hashes, 'task_record_hashes': task_hashes, 'summary': summary, 'records': records, 'decision_equivalence_checks': decision_checks, 'warmup_equivalence_checks': warmup_checks, 'maximum_calibrated_probability_absolute_error': probability_max_error, 'limitations': 'Single CPU process, fixed ten tasks, descriptive runtime only; no state fusion, sequence algorithms or legacy pipeline. Task histories are assumed already materialized and clipped. System scheduling noise remains possible.'}
    report['sha256'] = a.digest(report)
    with output.open('x', encoding='utf-8') as stream:
        json.dump(a.jsonable(report), stream, ensure_ascii=False, allow_nan=False)
    print('BENCHMARK', output, 'SHA256', report['sha256'], flush=True)
if __name__ == '__main__':
    main()
