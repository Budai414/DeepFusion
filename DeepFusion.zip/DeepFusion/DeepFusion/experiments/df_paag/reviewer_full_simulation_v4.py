from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import platform
import time
import numpy as np
import scipy
from scipy.special import expit
import torch
from research.df_paag import reviewer_association_v4 as a
from research.df_paag.reviewer_simulation_v3 import generate_task, PROTOCOL
from research.df_paag.reviewer_baselines_v3 import sequence_scores, hypothesis_scores
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/research/df_paag/reviewer_response_20261007/full_simulation_v4'
NONE = {'mode': 'none', 'aggregation': 'max', 'threshold': 1.0, 'gate': None, 'name': 'none'}

def source_hashes():
    names = ['research/df_paag/reviewer_association_v4.py', 'research/df_paag/reviewer_simulation_v3.py', 'research/df_paag/sequence_v2.py', 'research/df_paag/reviewer_baselines_v3.py', 'research/df_paag/reviewer_baselines_v4.py', 'experiments/df_paag/reviewer_full_simulation_v4.py']
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}

def get_development():
    lock = {'training_config': a.TRAIN_CONFIG, 'simulation': PROTOCOL, 'risk_protocol': a.RISK_CONFIG, 'threshold_grid': a.DECISION_GRID, 'source_hashes': source_hashes(), 'seed_stride': 17, 'test_generation': 'only after frozen_selection.json', 'prefix_fractions': [0.25, 0.5, 0.75, 1.0], 'primary': 'task-mean PWE5', 'secondary': 'PWE4, partition/Bcubed/edge F1, probability quality', 'baseline_search': 'sequence tolerance/quantization 20/30/50m; hypothesis null -3/0/3 and temperature .5/1/2', 'baseline_additions': 'GNN-assignment and JPDA-exact-assignment interval-layer adapter from reviewer_baselines_v4; approximation audit mandatory'}
    lock['sha256'] = a.digest(lock)
    path = OUT / 'prelock.json'
    if path.exists() and json.loads(path.read_text(encoding='utf-8')) != lock:
        raise RuntimeError('Prelock changed')
    a.save_json(path, lock)
    cache = OUT / 'development_corpus.pt'
    if cache.exists():
        bundle = torch.load(cache, weights_only=False)
        if bundle['prelock_hash'] != lock['sha256']:
            raise RuntimeError('Development provenance changed')
        datasets = bundle['datasets']
    else:
        datasets = {}
        for split in ('train', 'tune', 'calibration'):
            base, count = a.SPLITS[split]
            datasets[split] = []
            for i in range(count):
                task = a.prepare_features(generate_task(base + 17 * i, split))
                datasets[split].append(task)
                a.save_json(OUT / 'tasks' / f'{split}_{i:03d}.json', task)
            print(f'generated {split} {count} tasks', flush=True)
        torch.save({'prelock_hash': lock['sha256'], 'datasets': datasets}, cache)
    hashes = {s: [a.digest(a.jsonable(t)) for t in tasks] for s, tasks in datasets.items()}
    signature = a.digest({'prelock': lock['sha256'], 'development_corpus_hashes': hashes})
    a.save_json(OUT / 'development_hashes.json', {'tasks': hashes, 'training_signature': signature})
    return (datasets, lock, signature)

def train_all(datasets, signature):
    scaler = a.scaler_from_train(datasets['train'])
    a.save_json(OUT / 'normalization.json', scaler)
    models, histories = ({}, {})
    for variant in a.VARIANTS:
        models[variant], histories[variant] = ([], [])
        for seed in a.SEEDS:
            model, history = a.train(variant, seed, datasets, scaler, OUT, signature)
            models[variant].append(model)
            histories[variant].append(history)
    a.save_json(OUT / 'training_history.json', histories)
    return (models, scaler, histories)

def learn_baselines(datasets):
    from research.df_paag.reviewer_baselines_v4 import association_scores
    tune, calibration = (datasets['tune'], datasets['calibration'][:24])
    fits, audit = ({}, {})
    seq_cache = {width: {s: [sequence_scores(t, lcss_epsilon_m=width, quantization_m=width) for t in tasks] for s, tasks in (('tune', tune), ('cal', calibration))} for width in (20.0, 30.0, 50.0)}
    for method in ('DTW', 'discrete-Frechet', 'LCSS', 'LCS-quantized'):
        options = []
        for width in (30.0,) if method in ('DTW', 'discrete-Frechet') else (20.0, 30.0, 50.0):
            ss = seq_cache[width]
            scores = np.concatenate([x[method] for x in ss['cal']])
            location, scale = (float(scores.mean()), max(float(scores.std()), 1e-06))
            cf = a.fit_calibration(calibration, [expit((x[method] - location) / scale) for x in ss['cal']])
            pp = [a.calibrate(expit((x[method] - location) / scale), cf) for x in ss['tune']]
            decision, rows = a.tune_decision(tune, pp)
            value = float(np.mean([a.pwe(t, p >= decision) for t, p in zip(tune, pp)]))
            options.append({'kind': 'sequence', 'width': width, 'location': location, 'scale': scale, 'calibration': cf, 'decision': decision, 'tune_pwe5': value, 'threshold_search': rows})
        fits[method] = min(options, key=lambda x: (x['tune_pwe5'], x['width']))
        audit[method] = options
        print(f"baseline selected {method}: {fits[method]['tune_pwe5']:.5f}", flush=True)
    for method in ('JPDA-style', 'MHT-beam32', 'JPDA-exact-assignment', 'GNN-assignment'):
        options = []
        for null in (-3.0, 0.0, 3.0):
            for temperature in (1.0,) if method == 'GNN-assignment' else (0.5, 1.0, 2.0):
                fn = association_scores if method in ('JPDA-exact-assignment', 'GNN-assignment') else hypothesis_scores
                pc = [fn(t, method, null_score=null, temperature=temperature) for t in calibration]
                pt = [fn(t, method, null_score=null, temperature=temperature) for t in tune]
                cf = a.fit_calibration(calibration, pc)
                pp = [a.calibrate(p, cf) for p in pt]
                decision, rows = a.tune_decision(tune, pp)
                value = float(np.mean([a.pwe(t, p >= decision) for t, p in zip(tune, pp)]))
                options.append({'kind': 'hypothesis', 'null_score': null, 'temperature': temperature, 'calibration': cf, 'decision': decision, 'tune_pwe5': value, 'threshold_search': rows})
        fits[method] = min(options, key=lambda x: (x['tune_pwe5'], x['null_score'], x['temperature']))
        audit[method] = options
        print(f"baseline selected {method}: {fits[method]['tune_pwe5']:.5f}", flush=True)
    return (fits, audit)

def develop(datasets, models, scaler, lock, signature):
    cal = datasets['calibration']
    preds = {v: {s: [a.infer(ms, t, scaler) for t in datasets[s]] for s in ('tune', 'calibration')} for v, ms in models.items()}
    b0fit = a.fit_calibration(cal[:24], [expit(t['physical_logits']) for t in cal[:24]])
    fits, decisions, policies, original, development = ({}, {}, {}, {}, {})
    for variant in a.VARIANTS:
        fits[variant] = [a.fit_calibration(cal[:24], [m[k] for m in preds[variant]['calibration'][:24]]) for k in range(5)]
        cm = {s: [a.calibrate_members(m, fits[variant]) for m in preds[variant][s]] for s in ('tune', 'calibration')}
        decisions[variant], threshold_rows = a.tune_decision(datasets['tune'], [m.mean(0) for m in cm['tune']])
        policies[variant], original[variant], risk_rows = a.develop_risk_policy(datasets['tune'], cm['tune'], cal[24:], cm['calibration'][24:], decisions[variant], b0fit)
        development[variant] = {'threshold_search': threshold_rows, 'risk_search': risk_rows}
        print(f"developed {variant}: threshold={decisions[variant]} policy={policies[variant]['name']}", flush=True)
    members_extra = {}
    for k, seed in enumerate(a.SEEDS):
        cm = {s: [a.calibrate_members(m, fits['full'])[k:k + 1] for m in preds['full'][s]] for s in ('tune', 'calibration')}
        decision, rows = a.tune_decision(datasets['tune'], [m.mean(0) for m in cm['tune']])
        policy, old, risks = a.develop_risk_policy(datasets['tune'], cm['tune'], cal[24:], cm['calibration'][24:], decision, b0fit)
        members_extra[str(seed)] = {'decision': decision, 'policy': policy, 'threshold_search': rows, 'risk_search': risks}
    rawcm = preds['full']
    rawdecision, rawrows = a.tune_decision(datasets['tune'], [m.mean(0) for m in rawcm['tune']])
    rawpolicy, _, rawrisks = a.develop_risk_policy(datasets['tune'], rawcm['tune'], cal[24:], rawcm['calibration'][24:], rawdecision, b0fit)
    baseline_fits, baseline_audit = learn_baselines(datasets)
    selection = {'prelock_hash': lock['sha256'], 'training_signature': signature, 'member_calibration': fits, 'decisions': decisions, 'policies': policies, 'original_max_policies': original, 'B0_calibration': b0fit, 'single_refit': members_extra, 'uncalibrated_refit': {'decision': rawdecision, 'policy': rawpolicy}, 'baseline_fits': baseline_fits, 'source_hashes_final': {**source_hashes(), 'runner': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'baseline_v4': hashlib.sha256((ROOT / 'research/df_paag/reviewer_baselines_v4.py').read_bytes()).hexdigest()}}
    selection['sha256'] = a.digest(selection)
    a.save_json(OUT / 'development_comparison.json', {'models': development, 'single_members': members_extra, 'uncalibrated_refit': {'threshold_search': rawrows, 'risk_search': rawrisks}, 'classical_baselines': baseline_audit})
    a.save_json(OUT / 'development_predictions.json', preds)
    a.save_json(OUT / 'frozen_selection.json', selection)
    print(f"FROZEN_SELECTION {selection['sha256']}; held-out generation may now begin", flush=True)
    return selection

def evaluate_task(task, models, scaler, frozen, all_methods=True):
    from research.df_paag.reviewer_baselines_v4 import association_scores
    methods = {}
    b0native = expit(task['physical_logits'])
    b0p = a.calibrate(b0native, frozen['B0_calibration'])
    fullraw, fullcal = (None, None)
    for variant, ms in models.items():
        raw = a.infer(ms, task, scaler)
        cm = a.calibrate_members(raw, frozen['member_calibration'][variant])
        p = cm.mean(0)
        if variant == 'full':
            fullraw, fullcal = (raw, cm)
        methods[variant] = a.method_record(task, p, cm, frozen['decisions'][variant], frozen['policies'][variant], b0p, raw.mean(0))
    decision, policy = (frozen['decisions']['full'], frozen['policies']['full'])
    for name, cm, dd, pp in (('no_calibration', fullraw, decision, policy), ('single_model', fullcal[:1], decision, policy), ('no_risk_fallback', fullcal, decision, NONE), ('original_max_risk', fullcal, decision, frozen['original_max_policies']['full']), ('uncalibrated_refit', fullraw, frozen['uncalibrated_refit']['decision'], frozen['uncalibrated_refit']['policy'])):
        methods[name] = a.method_record(task, cm.mean(0), cm, dd, pp, b0p)
    for k, seed in enumerate(a.SEEDS):
        spec = frozen['single_refit'][str(seed)]
        methods[f'single_refit_{seed}'] = a.method_record(task, fullcal[k], fullcal[k:k + 1], spec['decision'], spec['policy'], b0p)
    b0selected = b0native >= 0.5
    methods['B0'] = {'probabilities': b0p.tolist(), 'selected': b0selected.astype(int).tolist(), 'raw_selected': b0selected.astype(int).tolist(), 'route': None, 'raw': a.metrics(task, b0p, b0selected), 'final': a.metrics(task, b0p, b0selected), 'native_probability_metrics': a.metrics(task, b0native, b0selected)}
    seq_cache = {}
    for name, fit in frozen['baseline_fits'].items():
        audit = None
        if fit['kind'] == 'sequence':
            width = fit['width']
            if width not in seq_cache:
                seq_cache[width] = sequence_scores(task, lcss_epsilon_m=width, quantization_m=width)
            rawp = expit((seq_cache[width][name] - fit['location']) / fit['scale'])
        elif name in ('GNN-assignment', 'JPDA-exact-assignment'):
            rawp, audit = association_scores(task, name, null_score=fit['null_score'], temperature=fit['temperature'], return_audit=True)
        else:
            rawp = hypothesis_scores(task, name, null_score=fit['null_score'], temperature=fit['temperature'])
        p = a.calibrate(rawp, fit['calibration'])
        methods[name] = a.method_record(task, p, p[None], fit['decision'], NONE, b0p, rawp)
        methods[name]['route'] = None
        methods[name]['baseline_audit'] = audit
    return methods

def aggregate(records, name, stage):
    rows = [r['methods'][name][stage] for r in records]
    keys = list(rows[0])
    result = {'tasks': len(rows)}
    rng = np.random.default_rng(20261008)
    ix = rng.integers(0, len(rows), (5000, len(rows)))
    for key in keys:
        values = np.array([row[key] for row in rows if row[key] is not None], dtype=float)
        if key in ('tp', 'fp', 'fn', 'tn', 'partition_tp', 'partition_fp', 'partition_fn', 'positive_pairs', 'negative_pairs'):
            result[key] = int(values.sum())
        else:
            result[key + '_mean'] = float(values.mean()) if len(values) else None
        if key in ('pwe5', 'pwe4', 'partition_f1', 'bcubed_f1', 'edge_f1') and len(values) == len(rows):
            result[key + '_sd'] = float(values.std(ddof=1))
            result[key + '_mcse'] = float(values.std(ddof=1) / np.sqrt(len(values)))
            result[key + '_ci95'] = np.quantile(values[ix].mean(1), [0.025, 0.975]).tolist()
    for prefix in ('', 'partition_'):
        tp, fp, fn = (result[prefix + 'tp'], result[prefix + 'fp'], result[prefix + 'fn'])
        result[('edge' if not prefix else 'partition') + '_f1_pooled'] = 2 * tp / max(2 * tp + fp + fn, 1)
    routes = [r['methods'][name].get('route') for r in records]
    result['route'] = None if all((x is None for x in routes)) else {key: sum(((row or {}).get(key, 0) for row in routes)) for key in ('components', 'fallback_components', 'fallback_edges', 'takeover_edges')}
    if result['route'] is not None:
        result['route']['fallback_outcomes'] = {outcome: sum((d.get('outcome') == outcome for row in routes if row for d in row['component_details'])) for outcome in ('helps', 'harms', 'unchanged')}
    return result

def paired_summary(records, methods):
    rng = np.random.default_rng(20261008)
    ix = rng.integers(0, len(records), (5000, len(records)))
    result = {}
    for name in methods:
        result[name] = {}
        for stage in ('raw', 'final'):
            result[name][stage] = {}
            for metric in ('pwe5', 'pwe4', 'partition_f1', 'bcubed_f1', 'edge_f1', 'edge_brier', 'edge_nll'):
                valid = [r for r in records if r['methods'][name][stage][metric] is not None and r['methods']['full'][stage][metric] is not None]
                d = np.array([r['methods'][name][stage][metric] - r['methods']['full'][stage][metric] for r in valid])
                if not len(d):
                    result[name][stage][metric] = {'tasks': 0, 'difference': None, 'ci95': None}
                    continue
                use_ix = ix if len(valid) == len(records) else np.random.default_rng(20261008).integers(0, len(valid), (5000, len(valid)))
                result[name][stage][metric] = {'tasks': len(valid), 'difference': float(d.mean()), 'ci95': np.quantile(d[use_ix].mean(1), [0.025, 0.975]).tolist(), 'positive_tasks': int((d > 1e-12).sum()), 'equal_tasks': int((abs(d) <= 1e-12).sum()), 'negative_tasks': int((d < -1e-12).sum())}
    return result

def mechanism_audit(task, models, scaler, frozen):
    t = a.tensor_task(task, scaler)
    swapped = dict(t)
    swapped['edges'] = t['edges'][:, [1, 0]]
    results = {}
    for variant in ('full', 'asymmetric', 'two_sided_history'):
        with torch.no_grad():
            original = np.stack([expit(a.forward(m, t).numpy()) for m in models[variant]])
            reversed_p = np.stack([expit(a.forward(m, swapped).numpy()) for m in models[variant]])
        p = a.calibrate_members(original, frozen['member_calibration'][variant]).mean(0)
        q = a.calibrate_members(reversed_p, frozen['member_calibration'][variant]).mean(0)
        threshold = frozen['decisions'][variant]
        results[variant] = {'swap_probability_max': float(abs(p - q).max()) if len(p) else 0.0, 'swap_probability_mean': float(abs(p - q).mean()) if len(p) else 0.0, 'swap_decision_flips': int(((p >= threshold) != (q >= threshold)).sum())}
    return results

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('train', 'evaluate'), default='evaluate')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    datasets, lock, signature = get_development()
    models, scaler, histories = train_all(datasets, signature)
    if args.stage == 'train':
        print('TRAINING COMPLETE. No test/OOD task generated.', flush=True)
        return
    frozen = develop(datasets, models, scaler, lock, signature)
    records, latency, prefix_index = ([], {}, [])
    for split in ('test', 'ood'):
        base, count = a.SPLITS[split]
        datasets[split] = []
        for i in range(count):
            task = a.prepare_features(generate_task(base + 17 * i, split))
            datasets[split].append(task)
            a.save_json(OUT / 'tasks' / f'{split}_{i:03d}.json', task)
            start = time.perf_counter()
            methods = evaluate_task(task, models, scaler, frozen)
            row = {'split': split, 'index': i, 'meta': task['meta'], 'nodes': len(task['x']), 'edges': task['edges'].tolist(), 'y': task['y'].tolist(), 'methods': methods, 'candidate_oracle': a.oracle(task), 'mechanisms': mechanism_audit(task, models, scaler, frozen), 'all_method_evaluation_ms': (time.perf_counter() - start) * 1000}
            a.save_json(OUT / 'records' / f'{split}_{i:03d}.json', row)
            records.append(row)
            for fraction in (0.25, 0.5, 0.75, 1.0):
                prefix = a.prefix_task(task, fraction)
                if len(prefix['x']) == 0:
                    continue
                pm = methods if fraction == 1.0 else evaluate_task(prefix, models, scaler, frozen)
                pp = OUT / 'prefix' / f'{split}_{i:03d}_{fraction:.2f}.json'
                a.save_json(pp, {'task': prefix, 'methods': pm, 'split': split, 'index': i, 'fraction': fraction})
                prefix_index.append(str(pp.relative_to(OUT)))
            if (i + 1) % 10 == 0:
                print(f'evaluated {split} {i + 1}/{count}, prefix snapshots saved', flush=True)
    method_names = list(records[0]['methods'])
    summaries = {}
    paired = {}
    for split in ('test', 'ood'):
        rr = [r for r in records if r['split'] == split]
        summaries[split] = {m: {stage: aggregate(rr, m, stage) for stage in ('raw', 'final')} for m in method_names}
        paired[split] = paired_summary(rr, method_names)
    for variant in a.VARIANTS:
        values = []
        for task in datasets['test'] + datasets['ood']:
            a.infer(models[variant], task, scaler)
            start = time.perf_counter()
            a.infer(models[variant], task, scaler)
            values.append((time.perf_counter() - start) * 1000)
        latency[variant] = {'median_ms': float(np.median(values)), 'p95_ms': float(np.quantile(values, 0.95)), 'tasks': len(values)}
    result = {'prelock': lock, 'frozen_selection': frozen, 'training_signature': signature, 'dataset_manifest': {s: [t['meta'] for t in ts] for s, ts in datasets.items()}, 'summary': summaries, 'paired': paired, 'records': records, 'training': histories, 'latency': latency, 'prefix_files': prefix_index, 'parameter_counts': {v: sum((p.numel() for p in models[v][0].parameters())) for v in a.VARIANTS}, 'environment': {'python': platform.python_version(), 'torch': torch.__version__, 'numpy': np.__version__, 'scipy': scipy.__version__, 'torch_threads': 2}, 'scope': 'new confirmatory simulation version; candidate same-sensor disjoint-fragment extension; HTG surrogate remains inspired; neither state metrics nor real-data accuracy claimed here'}
    result['sha256'] = a.digest(result)
    a.save_json(OUT / 'results.json', result)
    torch.save(datasets, OUT / 'simulated_corpus.pt')
    a.save_json(OUT / 'corpus_hashes.json', {s: [a.digest(a.jsonable(t)) for t in ts] for s, ts in datasets.items()})
    for split, ss in summaries.items():
        print(split, {m: round(v['final']['pwe5_mean'], 6) for m, v in ss.items()}, flush=True)
    print(f"RESULT {OUT / 'results.json'} SHA256 {result['sha256']}", flush=True)
if __name__ == '__main__':
    main()
