from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from research.df_paag.reviewer_state_fusion_v4 import PROTOCOL, _plain, canonical_hash, evaluate_states, method_states, source_receipt, truth_states, verified_truth_for_task, verify_prefix
ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'outputs/research/df_paag/reviewer_response_20261007'
ASSOCIATION = BASE / 'full_simulation_v4'
OUT = BASE / 'state_validation_v4'
SPLITS = {'test': [840000, 60], 'ood': [850000, 60]}
SENSOR_SETS = {'012': [0, 1, 2], '01': [0, 1], '02': [0, 2], '12': [1, 2], '0': [0], '1': [1], '2': [2]}

def load_json(path):
    with path.open(encoding='utf-8') as handle:
        return json.load(handle)

def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as handle:
        json.dump(_plain(value), handle, ensure_ascii=False, indent=2, allow_nan=False)

def file_hash(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(65536), b''):
            digest.update(block)
    return digest.hexdigest()

def prepare():
    receipt = {'protocol': PROTOCOL, 'splits': SPLITS, 'sensor_sets': SENSOR_SETS, 'sources': {**source_receipt(), 'runner_sha256': file_hash(Path(__file__))}}
    receipt['sha256'] = canonical_hash(receipt)
    path = OUT / 'prelock.json'
    if path.exists() and load_json(path) != receipt:
        raise RuntimeError('State protocol/source changed; preserve existing prelock and audit before further evaluation')
    save_json(path, receipt)
    return receipt

def aggregate(rows):
    output = {'independent_tasks': len(rows)}
    for key in ('truth_count', 'output_count', 'matched_count', 'missed_count', 'false_output_count', 'nees95_hits', 'identity_pure_matched_count', 'identity_mixed_or_wrong_matched_count'):
        output[key] = sum((row[key] for row in rows if row[key] is not None))
    for key in ('position_rmse_m', 'velocity_rmse_mps', 'state_nll_nats', 'nees_mean', 'nees95_coverage', 'ospa_position_m', 'target_coverage'):
        vals = np.array([row[key] for row in rows if row[key] is not None], dtype=np.float64)
        if len(vals):
            ix = np.random.default_rng(PROTOCOL['bootstrap_seed']).integers(0, len(vals), (PROTOCOL['bootstrap_replicates'], len(vals)))
            output[key] = {'mean': float(vals.mean()), 'ci95': np.quantile(vals[ix].mean(1), [0.025, 0.975]).tolist(), 'defined_tasks': len(vals), 'undefined_tasks': len(rows) - len(vals)}
        else:
            output[key] = {'mean': None, 'ci95': None, 'defined_tasks': 0, 'undefined_tasks': len(rows)}
    matched = output['matched_count']
    output['pooled_target_coverage'] = matched / output['truth_count'] if output['truth_count'] else None
    output['pooled_nees95_coverage'] = output['nees95_hits'] / matched if matched else None
    output['pooled_position_rmse_m'] = float(np.sqrt(sum((sum(r['position_squared_errors']) for r in rows)) / matched)) if matched else None
    output['pooled_velocity_rmse_mps'] = float(np.sqrt(sum((sum(r['velocity_squared_errors']) for r in rows)) / matched)) if matched else None
    return output

def prefix_item_or_empty(task, path, method_names, fraction):
    if path.exists():
        return (load_json(path), False)
    cutoff = float(task['meta']['decision_cutoff_s']) * fraction
    if any((np.count_nonzero(np.asarray(h['t']) <= cutoff) >= 3 for h in task['histories'])):
        raise RuntimeError(f'Nonempty prefix export missing: {path}')
    empty = {'histories': [], 'sensor': [], 'identities': [], 'edges': [], 'original_node_indices': [], 'meta': {**task['meta'], 'decision_cutoff_s': cutoff}}
    return ({'task': empty, 'methods': {name: {'selected': [], 'probabilities': []} for name in method_names}}, True)

def run():
    prelock = prepare()
    freeze = ASSOCIATION / 'frozen_selection.json'
    if not freeze.exists():
        raise RuntimeError('Association selection has not been frozen; held-out state evaluation is prohibited')
    missing = []
    for split, (_, count) in SPLITS.items():
        for i in range(count):
            required = [ASSOCIATION / 'tasks' / f'{split}_{i:03d}.json', ASSOCIATION / 'records' / f'{split}_{i:03d}.json']
            missing.extend((str(p) for p in required if not p.exists()))
    if missing:
        raise RuntimeError(f'Association prefix export incomplete ({len(missing)} missing): {missing[0]}')
    results = []
    provenance = []
    for split, (seed_base, count) in SPLITS.items():
        for i in range(count):
            task_path = ASSOCIATION / 'tasks' / f'{split}_{i:03d}.json'
            task = load_json(task_path)
            endpoint_record = load_json(ASSOCIATION / 'records' / f'{split}_{i:03d}.json')
            if task['meta']['seed'] != seed_base + 17 * i or task['meta']['split'] != split:
                raise ValueError('Unexpected held-out task: refusing a changed evaluation cohort')
            truth, receipt = verified_truth_for_task(task)
            receipt['task_file_sha256'] = file_hash(task_path)
            receipt['prefix_file_sha256'] = {}
            receipt['empty_prefix_receipts'] = []
            task_records = []
            for fraction in PROTOCOL['query_fractions']:
                prefix_path = ASSOCIATION / 'prefix' / f'{split}_{i:03d}_{fraction:.2f}.json'
                item, is_empty_export = prefix_item_or_empty(task, prefix_path, endpoint_record['methods'], fraction)
                prefix = item['task']
                query = truth['duration_s'] * fraction
                original_indices = item.get('original_node_indices', prefix.get('original_node_indices'))
                if original_indices is None:
                    raise ValueError('Prefix export lacks source-node mapping')
                verify_prefix(task, prefix, original_indices, query)
                receipt['prefix_file_sha256'][f'{fraction:.2f}'] = None if is_empty_export else file_hash(prefix_path)
                if is_empty_export:
                    receipt['empty_prefix_receipts'].append({'fraction': fraction, 'query_s': query, 'verified_no_source_with_three_reports': True, 'treatment': 'empty estimates; all generated targets missed'})
                actual_truth = truth_states(truth, query)
                evaluated = {}
                estimates = {}
                for name, decision in item['methods'].items():
                    prediction = method_states(prefix, decision['selected'], query)
                    estimates[name] = prediction
                    evaluated[name] = evaluate_states(prediction, actual_truth, truth_ids=truth['target_ids'], node_identities=prefix['identities'])
                oracle = method_states(prefix, None, query, oracle=True)
                estimates['oracle-identity'] = oracle
                evaluated['oracle-identity'] = evaluate_states(oracle, actual_truth, truth_ids=truth['target_ids'], node_identities=prefix['identities'])
                sensor_controls = {}
                for label, sensors in SENSOR_SETS.items():
                    predictions = oracle if label == '012' else method_states(prefix, None, query, oracle=True, sensors=sensors)
                    sensor_controls[label] = evaluate_states(predictions, actual_truth, truth_ids=truth['target_ids'], node_identities=prefix['identities'])
                row = {'split': split, 'index': i, 'seed': seed_base + 17 * i, 'fraction': fraction, 'query_time_s': query, 'methods': evaluated, 'oracle_sensor_controls': sensor_controls}
                results.append(row)
                task_records.append({**row, 'truth_ids': truth['target_ids'], 'truth_states': actual_truth, 'estimates': estimates})
            save_json(OUT / 'records' / f'{split}_{i:03d}.json', {'receipt': receipt, 'queries': task_records})
            provenance.append(receipt)
            print(f'state validated {split} {i + 1}/{count}', flush=True)
    names = list(results[0]['methods'])
    if any((list(row['methods']) != names for row in results)):
        raise RuntimeError('Methods differ across task prefixes')
    summary, controls, paired = ({}, {}, {})
    for split in SPLITS:
        summary[split] = {}
        controls[split] = {}
        for fraction in PROTOCOL['query_fractions']:
            rows = [row for row in results if row['split'] == split and row['fraction'] == fraction]
            summary[split][f'{fraction:.2f}'] = {name: aggregate([r['methods'][name] for r in rows]) for name in names}
            controls[split][f'{fraction:.2f}'] = {label: aggregate([r['oracle_sensor_controls'][label] for r in rows]) for label in SENSOR_SETS}
        endpoint = [r for r in results if r['split'] == split and r['fraction'] == 1.0]
        paired[split] = {}
        if 'full' in names:
            ix = np.random.default_rng(PROTOCOL['bootstrap_seed']).integers(0, len(endpoint), (PROTOCOL['bootstrap_replicates'], len(endpoint)))
            for name in names:
                delta = np.array([r['methods'][name]['ospa_position_m'] - r['methods']['full']['ospa_position_m'] for r in endpoint])
                paired[split][name] = {'difference_method_minus_full_m': float(delta.mean()), 'ci95': np.quantile(delta[ix].mean(1), [0.025, 0.975]).tolist()}
    output = {'prelock': prelock, 'association_frozen_selection_sha256': file_hash(freeze), 'provenance': provenance, 'summary': summary, 'oracle_sensor_contribution': controls, 'paired_endpoint_ospa': paired, 'records': results, 'statistical_scope': 'scene bootstrap conditional on fitted association models; conditional RMSE/NLL/NEES alongside unconditional OSPA and coverage; unadjusted exploratory comparisons'}
    output['sha256'] = canonical_hash(output)
    save_json(OUT / 'results.json', output)
    print('STATE RESULT', OUT / 'results.json', output['sha256'], flush=True)

def plot():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    result = load_json(OUT / 'results.json')
    available = list(result['summary']['test']['1.00'])
    chosen = [n for n in available if n in ('full', 'no_risk_fallback', 'B0', 'oracle-identity')]
    chosen += [n for n in available if ('JPDA' in n or 'MHT' in n) and n not in chosen]
    colors = plt.get_cmap('tab10')
    fig, axes = plt.subplots(2, 3, figsize=(12, 6.4), sharex=True)
    labels = [('position_rmse_m', 'Matched position RMSE (m)'), ('velocity_rmse_mps', 'Matched velocity RMSE (m/s)'), ('ospa_position_m', 'OSPA position (m), c=150')]
    for row_index, split in enumerate(('test', 'ood')):
        for column, (key, title) in enumerate(labels):
            ax = axes[row_index, column]
            for method_index, name in enumerate(chosen):
                values = [result['summary'][split][f'{fraction:.2f}'][name][key]['mean'] for fraction in PROTOCOL['query_fractions']]
                ax.plot(PROTOCOL['query_fractions'], values, marker='o', markersize=3, color=colors(method_index % 10), label=name, linewidth=1.4)
            ax.set_title(('ID' if split == 'test' else 'OOD') + ' | ' + title, fontsize=9)
            ax.grid(alpha=0.2)
            ax.tick_params(labelsize=8)
            if row_index == 1:
                ax.set_xlabel('Fraction of observation window', fontsize=9)
    handles, names = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, names, loc='lower center', ncol=min(4, len(names)), fontsize=8)
    fig.suptitle('Frozen prefix associations + common causal CV/CI backend', fontsize=12)
    fig.tight_layout(rect=(0, 0.1, 1, 0.96))
    fig.savefig(OUT / 'state_time_curves_v4.png', dpi=160)
    fig.savefig(OUT / 'state_time_curves_v4.pdf')
    plt.close(fig)
    print(OUT / 'state_time_curves_v4.png')
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--plot-only', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        print('STATE PRELOCK', prepare()['sha256'])
    if args.run:
        run()
    if args.plot_only:
        plot()
    if not any((args.prepare, args.run, args.plot_only)):
        parser.error('Specify --prepare, --run or --plot-only')
