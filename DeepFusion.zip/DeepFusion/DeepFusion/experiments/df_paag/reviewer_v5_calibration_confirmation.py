from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DIRECTORY = ROOT / 'outputs/research/df_paag/reviewer_response_20261007/refinement_v5'

def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def main(directory=DEFAULT_DIRECTORY):
    directory = Path(directory)
    if directory.resolve() != DEFAULT_DIRECTORY.resolve():
        raise ValueError('This audit uses the frozen refinement_v5 experiment directory')
    if not (directory / 'results.json').exists():
        raise RuntimeError('Main confirmation results are not complete; postpone this serial audit')
    import torch
    from experiments.df_paag import reviewer_refinement_v5 as runner
    from research.df_paag import reviewer_state_fusion_v4 as state4
    from research.df_paag import reviewer_state_fusion_v5 as state5
    torch.set_num_threads(1)
    frozen = runner.load(directory / 'frozen_selection.json')
    if runner.a.digest({key: value for key, value in frozen.items() if key != 'sha256'}) != frozen['sha256']:
        raise RuntimeError('Frozen selection payload hash mismatch')
    for name, expected in frozen['source_hashes'].items():
        if file_hash(ROOT / name) != expected:
            raise RuntimeError('Frozen source changed: ' + name)
    protected_paths = [directory / 'frozen_selection.json', directory / 'results.json', directory / 'development.pt', directory / 'development_scores.pt']
    before = {path.name: file_hash(path) for path in protected_paths}
    data = torch.load(directory / 'development.pt', weights_only=False)
    score_bundle = torch.load(directory / 'development_scores.pt', weights_only=False)
    provenance, scores = (score_bundle['weights'], score_bundle['scores'])
    if provenance['tasks'] != frozen['development_task_hashes']:
        raise RuntimeError('Cached scores belong to different development tasks')
    if provenance['weights'] != frozen['checkpoint_hashes']:
        raise RuntimeError('Cached scores belong to different frozen models')
    for name, expected in provenance['sources'].items():
        if file_hash(ROOT / name) != expected:
            raise RuntimeError('Cached score implementation changed: ' + name)
    if provenance.get('scaler_dtype') != 'float32' or file_hash(runner.OLD / 'normalization.json') != provenance['scaler_sha256']:
        raise RuntimeError('Cached normalization mismatch')
    old = runner.load(runner.OLD / 'frozen_selection.json')
    if provenance['baselines'] != old['baseline_fits']:
        raise RuntimeError('Cached baseline fits changed')
    rows = []
    for role, domain in (('cal_id', 'id'), ('cal_shift', 'known_shift')):
        base, count, generator_split = runner.COHORTS[role]
        if count != 32 or len(data[role]) != 32 or len(scores[role]) != 32:
            raise RuntimeError('Expected 32 calibration tasks per domain')
        for index in range(16, 32):
            task = data[role][index]
            if task['meta']['seed'] != base + 19 * index or task['meta']['split'] != generator_split or task['meta'].get('cohort_role') != role:
                raise RuntimeError('Wrong risk-calibration cohort member')
            task_hash = runner.a.digest(runner.a.jsonable(task))
            if task_hash != frozen['development_task_hashes'][role][index]:
                raise RuntimeError('Task cache hash mismatch')
            path = directory / 'tasks' / f'{role}_{index:03d}.json'
            if runner.a.digest(runner.load(path)) != task_hash:
                raise RuntimeError('Serialized calibration task differs from cached task')
            truth, truth_receipt = state4.verified_truth_for_task(task)
            methods = runner.methods_for(task, scores[role][index], frozen, old)
            query = float(task['meta']['decision_cutoff_s'])
            actual = state4.truth_states(truth, query)
            metrics = {}
            for name in ('full', 'B0'):
                estimates = state5.method_states(task, methods[name]['selected'], query, frozen['state_config'])
                metrics[name] = state5.evaluate_states(estimates, actual, truth_ids=truth['target_ids'], node_identities=task['identities'])
            rows.append({'cohort_role': role, 'domain': domain, 'index': index, 'seed': int(task['meta']['seed']), 'query_s': query, 'task_sha256': task_hash, 'truth_replay': truth_receipt, 'methods': metrics})
        print('STATE_CALIBRATION_CONFIRMED', role, 16, flush=True)
    summary = {}
    for group in ('pooled_domains', 'id', 'known_shift'):
        selected = rows if group == 'pooled_domains' else [row for row in rows if row['domain'] == group]
        summary[group] = {name: runner.state_summary([row['methods'][name] for row in selected]) for name in ('full', 'B0')}
    after = {path.name: file_hash(path) for path in protected_paths}
    if before != after:
        raise RuntimeError('Protected experiment evidence changed during read-only calibration check')
    output = {'version': 'v5-state-calibration-confirmation', 'frozen_selection_sha256': frozen['sha256'], 'source_file_sha256': before, 'script_sha256': file_hash(__file__), 'state_source_receipt': state5.source_receipt(), 'selected_state_config': frozen['state_config'], 'cohort': {'roles': ['cal_id', 'cal_shift'], 'indices_inclusive': [16, 31], 'tasks_per_domain': 16, 'total_independent_tasks': 32, 'query': 'decision cutoff / endpoint only'}, 'scope': 'Independent of state-filter/covariance fitting; not independent of association-risk quantile construction. No refit, no parameter search, no replacement for the new confirmation cohorts.', 'covariance_fitting_role': 'probability_calibration (indices 0..15 per domain)', 'this_role': 'risk_calibration, state-coverage confirmation only', 'nominal_nees_coverage': 0.95, 'statistical_scope': 'Scene-macro matched NLL/NEES with bootstrap CIs; unconditional OSPA/GOSPA and all misses/false outputs retained. Undefined conditional scores are counted, not set to zero.', 'no_parameters_reselected': True, 'protected_source_files_unchanged': True, 'summary': summary, 'records': rows}
    output['sha256'] = runner.a.digest(output)
    destination = directory / 'calibration_confirmation.json'
    runner.a.save_json(destination, output)
    print('CALIBRATION_CONFIRMATION', destination, output['sha256'], flush=True)
    for domain, methods in summary.items():
        print(domain, {name: {key: value[key]['mean'] for key in ('state_nll_nats', 'nees95_coverage', 'ospa_position_m')} for name, value in methods.items()}, flush=True)
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, default=DEFAULT_DIRECTORY)
    main(parser.parse_args().directory)
