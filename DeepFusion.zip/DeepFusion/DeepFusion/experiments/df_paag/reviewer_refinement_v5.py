from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from scipy.special import expit
import torch
from research.df_paag import reviewer_association_v4 as a
from research.df_paag.reviewer_simulation_v3 import generate_task, PROTOCOL
from research.df_paag.reviewer_baselines_v3 import sequence_scores, hypothesis_scores
from research.df_paag.reviewer_baselines_v4 import association_scores
from experiments.df_paag.reviewer_full_simulation_v4 import aggregate, paired_summary
from research.df_paag import reviewer_state_fusion_v4 as state4
ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'outputs/research/df_paag/reviewer_response_20261007'
OLD = BASE / 'full_simulation_v4'
OUT = BASE / 'refinement_v5'
GRID = [0.05, 0.1, 0.2, 0.35, 0.5, 0.65, 0.8, 0.9, 0.95, 0.975, 0.99]
COHORTS = {'dev_id': (910000, 48, 'test'), 'dev_shift': (920000, 48, 'ood'), 'cal_id': (930000, 32, 'test'), 'cal_shift': (940000, 32, 'ood'), 'test': (950000, 80, 'test'), 'ood': (960000, 80, 'ood')}
VARIANTS = ['full', 'no_diagnostics', 'asymmetric', 'GNN-neural', 'HTG-TA-inspired', 'equal_history']

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    protocol = {'cohorts': COHORTS, 'stride': 19, 'thresholds': GRID, 'simulation': PROTOCOL, 'protocol_sha256': sha(Path(__file__).with_name('reviewer_refinement_v5_protocol.md')), 'old_selection_sha256': sha(OLD / 'frozen_selection.json'), 'old_test_used_for_hypotheses_only': True, 'new_test_generated_after_freeze': True, 'new_unknown_domain_claim': False}
    path = OUT / 'prelock.json'
    if path.exists() and load(path) != a.jsonable(protocol):
        raise RuntimeError('Prelock changed')
    a.save_json(path, protocol)
    cache = OUT / 'development.pt'
    if cache.exists():
        data = torch.load(cache, weights_only=False)
        check_development(data)
        return data
    data = {}
    for role, (base, count, split) in COHORTS.items():
        if role in ('test', 'ood'):
            continue
        data[role] = []
        for i in range(count):
            task = a.prepare_features(generate_task(base + 19 * i, split))
            task['meta']['cohort_role'] = role
            data[role].append(task)
            a.save_json(OUT / 'tasks' / f'{role}_{i:03d}.json', task)
        print('generated', role, count, flush=True)
    torch.save(data, cache)
    check_development(data)
    return data

def check_development(data):
    receipt = {'tasks': {role: [a.digest(a.jsonable(t)) for t in tasks] for role, tasks in data.items()}, 'sources': {n: sha(ROOT / n) for n in ['research/df_paag/reviewer_simulation_v3.py', 'research/df_paag/reviewer_association_v4.py', 'research/df_paag/sequence_v2.py']}, 'prelock_hash': sha(OUT / 'prelock.json')}
    path = OUT / 'development_receipt.json'
    if path.exists() and load(path) != receipt:
        raise RuntimeError('Development cache provenance changed')
    for role, tasks in data.items():
        for i, task in enumerate(tasks):
            if a.digest(load(OUT / 'tasks' / f'{role}_{i:03d}.json')) != receipt['tasks'][role][i]:
                raise RuntimeError('Development task serialization mismatch')
    a.save_json(path, receipt)

def models_and_scaler(control=False):
    models = {}
    for v in VARIANTS:
        if v == 'equal_history':
            if not control:
                continue
            from research.df_paag.reviewer_temporal_control_v5 import make_model
            make = lambda: make_model()
            directory = OUT
        else:
            make = lambda v=v: a.make_model(v)
            directory = OLD
        models[v] = []
        for seed in a.SEEDS:
            ckpt = torch.load(directory / f'checkpoint_{v}_{seed}.pt', weights_only=False)
            model = make()
            model.load_state_dict(ckpt['state'])
            model.eval()
            models[v].append(model)
    scaler = {k: np.asarray(v, dtype=np.float32) for k, v in load(OLD / 'normalization.json').items()}
    return (models, scaler)

def train_control():
    from research.df_paag import reviewer_temporal_control_v5 as control
    data = torch.load(OLD / 'development_corpus.pt', weights_only=False)['datasets']
    scaler = {k: np.asarray(v, dtype=np.float32) for k, v in load(OLD / 'normalization.json').items()}
    signature = a.digest({'source': sha(Path(control.__file__)), 'old_training': load(OLD / 'development_hashes.json'), 'control': 'equal_history', 'training_config': a.TRAIN_CONFIG, 'scaler_dtype': 'float32', 'scaler_sha256': sha(OLD / 'normalization.json')})
    for seed in a.SEEDS:
        control.train('equal_history', seed, data, scaler, OUT, signature)

def native_scores(task, models, scaler, old):
    out = {v: a.infer(ms, task, scaler) for v, ms in models.items()}
    out['physical'] = expit(task['physical_logits'])[None]
    seq = {}
    for name, fit in old['baseline_fits'].items():
        if fit['kind'] == 'sequence':
            width = fit['width']
            if width not in seq:
                seq[width] = sequence_scores(task, lcss_epsilon_m=width, quantization_m=width)
            p = expit((seq[width][name] - fit['location']) / fit['scale'])
        else:
            fn = association_scores if name in ('GNN-assignment', 'JPDA-exact-assignment') else hypothesis_scores
            p = fn(task, name, null_score=fit['null_score'], temperature=fit['temperature'])
        out[name] = p[None]
    return out

def score_development(data, models, scaler, old):
    cache = OUT / 'development_scores.pt'
    provenance = {'weights': {v: [sha((OUT if v == 'equal_history' else OLD) / f'checkpoint_{v}_{s}.pt') for s in a.SEEDS] for v in models}, 'tasks': {role: [a.digest(a.jsonable(t)) for t in tasks] for role, tasks in data.items()}, 'scaler_sha256': sha(OLD / 'normalization.json'), 'scaler_dtype': 'float32', 'baselines': old['baseline_fits'], 'sources': {n: sha(ROOT / n) for n in ['research/df_paag/reviewer_association_v4.py', 'research/df_paag/reviewer_temporal_control_v5.py', 'research/df_paag/reviewer_baselines_v3.py', 'research/df_paag/reviewer_baselines_v4.py']}}
    if cache.exists():
        bundle = torch.load(cache, weights_only=False)
        if bundle['weights'] != provenance:
            raise RuntimeError('Prediction checkpoint changed')
        return bundle['scores']
    scores = {}
    for role, tasks in data.items():
        scores[role] = []
        for i, t in enumerate(tasks):
            scores[role].append(native_scores(t, models, scaler, old))
            if (i + 1) % 16 == 0:
                print('scored', role, i + 1, flush=True)
    torch.save({'weights': provenance, 'scores': scores}, cache)
    return scores

def interleave(xs, ys):
    return [z for pair in zip(xs, ys) for z in pair]

def choose_threshold(tasks, probs, mode):
    from research.df_paag.reviewer_decoder_v5 import decode
    rows = []
    for threshold in GRID:
        values = [a.pwe(t, decode(t, p, threshold, mode)) for t, p in zip(tasks, probs)]
        rows.append({'threshold': threshold, 'pwe5': float(np.mean(values)), 'per_task': values})
    best = min(rows, key=lambda x: (x['pwe5'], -x['threshold']))
    return (best['threshold'], rows)

def policies_for(tasks, members, b0probs):
    policies = [{'mode': 'none', 'decoder': 'constrained_agglomerative', 'aggregation': 'max', 'threshold': 1.0, 'name': 'none'}]
    for agg in ('max', 'q90', 'mean'):
        values = []
        for t, m, b in zip(tasks, members, b0probs):
            risk, _ = a.risk_values(m, m.mean(0), b)
            values.extend((a.aggregate_risk(risk[g], agg) for g in a.risk_groups(t)))
        for q in (0.5, 0.8, 0.95):
            policies.append({'mode': 'cost_aware', 'decoder': 'constrained_agglomerative', 'aggregation': agg, 'threshold': float(np.quantile(values, q)), 'quantile': q, 'name': f'{agg}-q{q}', 'reference_weight': 0.5, 'cost': 5.0, 'min_gain': 0.0})
    return policies

def choose_policy(tasks, members, b0probs, decision, policies):
    from research.df_paag.reviewer_decoder_v5 import route
    rows = []
    for policy in policies:
        values = []
        fallback = 0
        for t, m, b in zip(tasks, members, b0probs):
            s, rr = route(t, m.mean(0), m, decision, policy, b)
            values.append(a.pwe(t, s))
            fallback += rr['fallback_edges']
        rows.append({'policy': policy, 'pwe5': float(np.mean(values)), 'fallback_edges': fallback, 'per_task': values})
    best = min(rows, key=lambda x: (x['pwe5'], x['fallback_edges'], x['policy']['name']))
    return (best['policy'], rows)

def probabilities(scores, calibration):
    return {name: a.calibrate_members(raw, calibration[name]) for name, raw in scores.items()}

def make_record(task, p, members, decision, policy, b0p, mode='constrained_agglomerative'):
    from research.df_paag.reviewer_decoder_v5 import decode, route
    raw = decode(task, p, decision, mode)
    if policy is None:
        selected = raw
        rr = None
    else:
        selected, rr = route(task, p, members, decision, policy, b0p)
        for detail in rr['component_details']:
            if detail['fallback']:
                idx = np.asarray(detail['edges'], dtype=int)
                counter = raw.copy()
                counter[idx] = selected[idx]
                delta = a.pwe(task, counter) - a.pwe(task, raw)
                detail['isolated_fallback_pwe5_delta'] = delta
                detail['outcome'] = 'helps' if delta < -1e-12 else 'harms' if delta > 1e-12 else 'unchanged'
    return {'probabilities': p.tolist(), 'member_probabilities': members.tolist(), 'decision_threshold': decision, 'raw_selected': raw.astype(int).tolist(), 'selected': selected.astype(int).tolist(), 'route': rr, 'raw': a.metrics(task, p, raw), 'final': a.metrics(task, p, selected)}

def methods_for(task, scores, frozen, old):
    cm = probabilities(scores, frozen['calibration'])
    b0p = cm['physical'][0]
    methods = {}
    for v in VARIANTS:
        m = cm[v]
        spec = frozen['methods'][v]
        methods[v] = make_record(task, m.mean(0), m, spec['threshold'], spec['policy'], b0p)
    spec = frozen['methods']['full']
    full = cm['full']
    none = {**spec['policy'], 'mode': 'none', 'name': 'none'}
    for name, m, pol in [('no_calibration', scores['full'], spec['policy']), ('single_model', full[:1], spec['policy']), ('ensemble3', full[:3], spec['policy']), ('no_risk_fallback', full, none)]:
        methods[name] = make_record(task, m.mean(0), m, spec['threshold'], pol, b0p)
    for k, seed in enumerate(a.SEEDS):
        name = f'single_refit_{seed}'
        ss = frozen['methods'][name]
        m = full[k:k + 1]
        methods[name] = make_record(task, m.mean(0), m, ss['threshold'], ss['policy'], b0p)
    ss = frozen['methods']['uncalibrated_refit']
    m = scores['full']
    methods['uncalibrated_refit'] = make_record(task, m.mean(0), m, ss['threshold'], ss['policy'], b0p)
    for label, v, mode in [('physical_cc', 'physical', 'threshold_cc'), ('physical_constrained', 'physical', 'constrained_agglomerative'), ('neural_cc', 'full', 'threshold_cc'), ('neural_constrained', 'full', 'constrained_agglomerative')]:
        m = cm[v]
        ss = frozen['factorial'][label]
        methods[label] = make_record(task, m.mean(0), m, ss['threshold'], None, b0p, mode)
    b0selected = np.asarray(task['physical_logits']) >= 0
    bm = a.metrics(task, b0p, b0selected)
    methods['B0'] = {'probabilities': b0p.tolist(), 'raw_selected': b0selected.astype(int).tolist(), 'selected': b0selected.astype(int).tolist(), 'raw': bm, 'final': bm, 'route': None}
    oldm = a.calibrate_members(scores['full'], old['member_calibration']['full'])
    methods['legacy_full'] = a.method_record(task, oldm.mean(0), oldm, old['decisions']['full'], old['policies']['full'], a.calibrate(scores['physical'][0], old['B0_calibration']))
    for name in old['baseline_fits']:
        m = cm[name]
        ss = frozen['baselines'][name]
        methods[name] = make_record(task, m[0], m, ss['threshold'], None, b0p, 'threshold_cc')
    return methods

def develop_state(tasks, cal_tasks, task_methods, cal_methods):
    from research.df_paag import reviewer_state_fusion_v5 as st
    configs = [{'min_reports': r, 'max_age_s': age, 'covariance_scale': 1.0} for r in (3, 5, 8) for age in (2.0, 5.0)]
    reference = ['B0', 'neural_constrained']
    truths = [state4.verified_truth_for_task(t)[0] for t in tasks]
    rows = []
    for config in configs:
        values = []
        for t, ms, truth in zip(tasks, task_methods, truths):
            query = t['meta']['decision_cutoff_s']
            actual = state4.truth_states(truth, query)
            for name in reference:
                pred = st.method_states(t, ms[name]['selected'], query, config)
                values.append(st.evaluate_states(pred, actual)['ospa_position_m'])
        rows.append({'config': config, 'reference_mean_ospa_m': float(np.mean(values))})
    winner = min(rows, key=lambda x: (x['reference_mean_ospa_m'], x['config']['min_reports'], -x['config']['max_age_s']))['config']
    ctruth = [state4.verified_truth_for_task(t)[0] for t in cal_tasks]
    scale_rows = []
    for scale in (1.0, 2.0, 4.0, 8.0, 16.0):
        config = {**winner, 'covariance_scale': scale}
        values = []
        for t, ms, truth in zip(cal_tasks, cal_methods, ctruth):
            query = t['meta']['decision_cutoff_s']
            actual = state4.truth_states(truth, query)
            for name in reference:
                pred = st.method_states(t, ms[name]['selected'], query, config)
                value = st.evaluate_states(pred, actual)['state_nll_nats']
                if value is not None:
                    values.append(value)
        scale_rows.append({'config': config, 'reference_mean_state_nll': float(np.mean(values))})
    best = min(scale_rows, key=lambda x: (x['reference_mean_state_nll'], x['config']['covariance_scale']))['config']
    return (best, {'filter_search': rows, 'scale_search': scale_rows, 'reference_methods': reference})

def develop():
    if (OUT / 'frozen_selection.json').exists():
        print('Selection already frozen; will not refit', flush=True)
        return
    data = prepare()
    models, scaler = models_and_scaler(True)
    old = load(OLD / 'frozen_selection.json')
    scores = score_development(data, models, scaler, old)
    tune = interleave(data['dev_id'], data['dev_shift'])
    ts = interleave(scores['dev_id'], scores['dev_shift'])
    cal = interleave(data['cal_id'][:16], data['cal_shift'][:16])
    cs = interleave(scores['cal_id'][:16], scores['cal_shift'][:16])
    risk = interleave(data['cal_id'][16:], data['cal_shift'][16:])
    rs = interleave(scores['cal_id'][16:], scores['cal_shift'][16:])
    fits = {v: [a.fit_calibration(cal, [r[v][k] for r in cs]) for k in range(len(cs[0][v]))] for v in cs[0]}
    tc = [probabilities(s, fits) for s in ts]
    rc = [probabilities(s, fits) for s in rs]
    b = [x['physical'][0] for x in tc]
    rb = [x['physical'][0] for x in rc]
    frozen = {'calibration': fits, 'methods': {}, 'factorial': {}, 'baselines': {}, 'prelock_sha256': sha(OUT / 'prelock.json')}
    audit = {'methods': {}, 'factorial': {}, 'baselines': {}}
    for name in VARIANTS + [f'single_refit_{s}' for s in a.SEEDS] + ['uncalibrated_refit']:
        if name.startswith('single_refit_'):
            k = a.SEEDS.index(int(name.split('_')[-1]))
            members = [x['full'][k:k + 1] for x in tc]
            rm = [x['full'][k:k + 1] for x in rc]
        elif name == 'uncalibrated_refit':
            members = [x['full'] for x in ts]
            rm = [x['full'] for x in rs]
        else:
            members = [x[name] for x in tc]
            rm = [x[name] for x in rc]
        decision, dd = choose_threshold(tune, [x.mean(0) for x in members], 'constrained_agglomerative')
        policies = policies_for(risk, rm, rb)
        policy, pr = choose_policy(tune, members, b, decision, policies)
        frozen['methods'][name] = {'threshold': decision, 'policy': policy, 'risk_policies': policies}
        audit['methods'][name] = {'threshold_search': dd, 'policy_search': pr}
        print('developed', name, decision, policy['name'], flush=True)
    for label, v, mode in [('physical_cc', 'physical', 'threshold_cc'), ('physical_constrained', 'physical', 'constrained_agglomerative'), ('neural_cc', 'full', 'threshold_cc'), ('neural_constrained', 'full', 'constrained_agglomerative')]:
        d, rows = choose_threshold(tune, [x[v].mean(0) for x in tc], mode)
        frozen['factorial'][label] = {'threshold': d, 'decoder': mode, 'score': v}
        audit['factorial'][label] = rows
    for name in old['baseline_fits']:
        d, rows = choose_threshold(tune, [x[name][0] for x in tc], 'threshold_cc')
        frozen['baselines'][name] = {'threshold': d, 'old_internal_parameters': old['baseline_fits'][name]}
        audit['baselines'][name] = rows
    tm = [methods_for(t, s, frozen, old) for t, s in zip(tune, ts)]
    cm = [methods_for(t, s, frozen, old) for t, s in zip(cal, cs)]
    config, sa = develop_state(tune, cal, tm, cm)
    frozen['state_config'] = config
    audit['state'] = sa
    names = ['research/df_paag/reviewer_decoder_v5.py', 'research/df_paag/reviewer_temporal_control_v5.py', 'research/df_paag/reviewer_state_fusion_v5.py', 'research/df_paag/reviewer_simulation_v3.py', 'research/df_paag/reviewer_association_v4.py', 'experiments/df_paag/reviewer_refinement_v5.py']
    frozen['source_hashes'] = {n: sha(ROOT / n) for n in names}
    frozen['checkpoint_hashes'] = {v: [sha((OUT if v == 'equal_history' else OLD) / f'checkpoint_{v}_{s}.pt') for s in a.SEEDS] for v in models}
    frozen['development_task_hashes'] = {role: [a.digest(a.jsonable(t)) for t in tasks] for role, tasks in data.items()}
    frozen['primary_comparisons'] = {'methods': ['B0', 'legacy_full'], 'reference': 'full', 'metric': 'pwe5', 'ci_quantiles': [0.0125, 0.9875]}
    frozen['sha256'] = a.digest(frozen)
    a.save_json(OUT / 'development_comparison.json', audit)
    a.save_json(OUT / 'frozen_selection.json', frozen)
    print('FROZEN', frozen['sha256'], 'state', config, flush=True)

def state_summary(rows):
    from experiments.df_paag.reviewer_state_validation_v4 import aggregate as sa
    result = sa(rows)
    for key in ('gospa_position_m', 'gospa_squared_m2', 'gospa_localization_squared_m2', 'gospa_missed_squared_m2', 'gospa_false_squared_m2'):
        vals = np.array([r[key] for r in rows], dtype=float)
        ix = np.random.default_rng(20261009).integers(0, len(vals), (2000, len(vals)))
        result[key] = {'mean': float(vals.mean()), 'ci95': np.quantile(vals[ix].mean(1), [0.025, 0.975]).tolist()}
    return result

def state_evaluate(task, methods, truth, config):
    from research.df_paag import reviewer_state_fusion_v5 as st
    query = task['meta']['decision_cutoff_s']
    actual = state4.truth_states(truth, query)
    out = {}
    for name, m in methods.items():
        pred = st.method_states(task, m['selected'], query, config)
        out[name] = st.evaluate_states(pred, actual, truth_ids=truth['target_ids'], node_identities=task['identities'])
    for label, cfg in [('full_original_backend', {'min_reports': 1, 'max_age_s': 5.0, 'covariance_scale': 1.0}), ('full_filter_only', {**config, 'covariance_scale': 1.0})]:
        pred = st.method_states(task, methods['full']['selected'], query, cfg)
        out[label] = st.evaluate_states(pred, actual, truth_ids=truth['target_ids'], node_identities=task['identities'])
    for label, sensors in [('oracle-identity', (0, 1, 2)), ('oracle-source0', (0,)), ('oracle-source1', (1,)), ('oracle-source2', (2,)), ('oracle-source01', (0, 1)), ('oracle-source02', (0, 2)), ('oracle-source12', (1, 2))]:
        pred = st.method_states(task, None, query, config, sensors=sensors, oracle=True)
        out[label] = st.evaluate_states(pred, actual, truth_ids=truth['target_ids'], node_identities=task['identities'])
    return out

def evaluate():
    from research.df_paag.reviewer_decoder_v5 import constraint_violations
    frozen = load(OUT / 'frozen_selection.json')
    if a.digest({k: v for k, v in frozen.items() if k != 'sha256'}) != frozen['sha256']:
        raise RuntimeError('Freeze corrupted')
    for name, value in frozen['source_hashes'].items():
        if sha(ROOT / name) != value:
            raise RuntimeError('Frozen source changed: ' + name)
    for v, hashes in frozen['checkpoint_hashes'].items():
        actual = [sha((OUT if v == 'equal_history' else OLD) / f'checkpoint_{v}_{s}.pt') for s in a.SEEDS]
        if actual != hashes:
            raise RuntimeError('Frozen checkpoint changed')
    models, scaler = models_and_scaler(True)
    old = load(OLD / 'frozen_selection.json')
    records = []
    prefix_records = []
    for split in ('test', 'ood'):
        base, count, domain = COHORTS[split]
        for i in range(count):
            cache = OUT / 'records' / f'{split}_{i:03d}.json'
            if cache.exists():
                row = load(cache)
                if row['frozen_sha256'] != frozen['sha256']:
                    raise RuntimeError('Record freeze mismatch')
                records.append(row)
                prefix_records.extend(load(OUT / 'prefix' / f'{split}_{i:03d}.json'))
                continue
            task = a.prepare_features(generate_task(base + 19 * i, domain))
            task['meta']['cohort_role'] = split
            a.save_json(OUT / 'tasks' / f'{split}_{i:03d}.json', task)
            truth, receipt = state4.verified_truth_for_task(task)
            scores = native_scores(task, models, scaler, old)
            methods = methods_for(task, scores, frozen, old)
            states = state_evaluate(task, methods, truth, frozen['state_config'])
            row = {'split': split, 'index': i, 'meta': task['meta'], 'nodes': len(task['x']), 'edges': task['edges'].tolist(), 'y': task['y'].tolist(), 'methods': methods, 'states': states, 'candidate_oracle': a.oracle(task), 'truth_replay': receipt, 'frozen_sha256': frozen['sha256']}
            row['constraint_violations'] = {name: constraint_violations(task, m['selected']) for name, m in methods.items()}
            cm = probabilities(scores, frozen['calibration'])
            spec = frozen['methods']['full']
            row['risk_curve'] = {pol['name']: make_record(task, cm['full'].mean(0), cm['full'], spec['threshold'], pol, cm['physical'][0]) for pol in spec['risk_policies']}
            pp = []
            for fraction in (0.25, 0.5, 0.75, 1.0):
                if fraction == 1.0:
                    prefix = task
                    pm = methods
                    ps = states
                else:
                    prefix = a.prefix_task(task, fraction)
                    sm = native_scores(prefix, models, scaler, old)
                    pm = methods_for(prefix, sm, frozen, old)
                    keep = ['full', 'B0', 'legacy_full', 'GNN-assignment', 'JPDA-exact-assignment', 'no_risk_fallback']
                    pm = {k: pm[k] for k in keep}
                    ps = state_evaluate(prefix, pm, truth, frozen['state_config'])
                pp.append({'split': split, 'index': i, 'fraction': fraction, 'query_s': prefix['meta']['decision_cutoff_s'], 'state': ps, 'association': {k: v['final'] for k, v in pm.items()}, 'frozen_sha256': frozen['sha256']})
            a.save_json(OUT / 'prefix' / f'{split}_{i:03d}.json', pp)
            prefix_records.extend(pp)
            a.save_json(cache, row)
            records.append(row)
            if (i + 1) % 10 == 0:
                print('confirmed', split, i + 1, '/', count, flush=True)
    names = list(records[0]['methods'])
    summary = {}
    paired = {}
    ss = {}
    sp = {}
    curves = {}
    strata = {}
    for split in ('test', 'ood'):
        rows = [r for r in records if r['split'] == split]
        summary[split] = {m: {stage: aggregate(rows, m, stage) for stage in ('raw', 'final')} for m in names}
        paired[split] = paired_summary(rows, names)
        for name in ('B0', 'legacy_full'):
            d = np.array([r['methods'][name]['final']['pwe5'] - r['methods']['full']['final']['pwe5'] for r in rows])
            ix = np.random.default_rng(20261009).integers(0, len(d), (5000, len(d)))
            paired[split][name]['final']['pwe5']['ci975_two_primary'] = np.quantile(d[ix].mean(1), [0.0125, 0.9875]).tolist()
        ss[split] = {m: state_summary([r['states'][m] for r in rows]) for m in rows[0]['states']}
        sp[split] = {}
        for m in rows[0]['states']:
            sp[split][m] = {}
            for metric in ('ospa_position_m', 'gospa_position_m', 'position_rmse_m', 'state_nll_nats', 'nees95_coverage'):
                d = np.array([r['states'][m][metric] - r['states']['full'][metric] for r in rows if r['states'][m][metric] is not None and r['states']['full'][metric] is not None])
                if not len(d):
                    sp[split][m][metric] = {'difference': None, 'ci95': None, 'tasks': 0}
                    continue
                ix = np.random.default_rng(20261009).integers(0, len(d), (2000, len(d)))
                sp[split][m][metric] = {'difference': float(d.mean()), 'ci95': np.quantile(d[ix].mean(1), [0.025, 0.975]).tolist(), 'tasks': len(d)}
        curves[split] = {}
        for f in (0.25, 0.5, 0.75, 1.0):
            pr = [r for r in prefix_records if r['split'] == split and r['fraction'] == f]
            common = set.intersection(*(set(r['state']) for r in pr))
            curves[split][str(f)] = {m: state_summary([r['state'][m] for r in pr]) for m in sorted(common)}
        strata[split] = {}
        groups = {'targets3to5': lambda m: m['generated_target_count'] <= 5, 'targets6to8': lambda m: m['generated_target_count'] >= 6, 'crossing': lambda m: m['crossing_pair_generated'], 'noncrossing': lambda m: not m['crossing_pair_generated'], 'fragmented': lambda m: m['extra_retained_target_fragments'] > 0, 'unfragmented': lambda m: m['extra_retained_target_fragments'] == 0}
        for label, pred in groups.items():
            rr = [r for r in rows if pred(r['meta'])]
            if rr:
                strata[split][label] = {m: aggregate(rr, m, 'final') for m in ('full', 'legacy_full', 'B0', 'GNN-assignment')}
    result = {'frozen_selection': frozen, 'summary': summary, 'paired': paired, 'state_summary': ss, 'state_paired': sp, 'prefix_summary': curves, 'stratified': strata, 'records': records, 'new_task_count': 320, 'simulation_unchanged': True, 'scope': 'frozen scoring weights; new decoder routing and shared state backend; known-shift family', 'timestamp_ns': time.time_ns()}
    result['sha256'] = a.digest(result)
    a.save_json(OUT / 'results.json', result)
    print('RESULT', result['sha256'], flush=True)
    for split in summary:
        print(split, {m: round(summary[split][m]['final']['pwe5_mean'], 5) for m in ['full', 'legacy_full', 'B0', 'neural_cc', 'neural_constrained', 'GNN-assignment']}, flush=True)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--stage', choices=['prepare', 'train', 'develop', 'evaluate'], required=True)
    args = p.parse_args()
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    if args.stage == 'prepare':
        prepare()
    elif args.stage == 'train':
        train_control()
    elif args.stage == 'develop':
        develop()
    else:
        evaluate()
if __name__ == '__main__':
    main()
