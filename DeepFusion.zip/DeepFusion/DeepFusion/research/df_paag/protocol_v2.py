from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
from typing import Dict, List, Mapping, Optional, Sequence, Tuple
import real_fusion
import yaml
from real_fusion.runtime_paths import deepfusion_project_root
from research.df_paag.runtime_guard_v2 import DeepFusionRuntimeGuardError, expected_venv_python, verify_deepfusion_runtime
PROJECT_ROOT = deepfusion_project_root(__file__)
EXPECTED_PYTHON = expected_venv_python(PROJECT_ROOT)
PROTOCOL_SCHEMA_VERSION = 'deepfusion.df-paag-experiment-protocol.v2'
TASK_POOL_SCHEMA_VERSION = 'deepfusion.identity-task-pool.v2'
SPLIT_MANIFEST_SCHEMA_VERSION = 'deepfusion.identity-split-manifest.v2'
SPLIT_NAMES: Tuple[str, ...] = ('train', 'tune', 'calibration', 'test', 'ood')
IN_DOMAIN_SPLITS: Tuple[str, ...] = SPLIT_NAMES[:-1]
EXPECTED_ROLES = {'fit': 'train', 'model_selection': 'tune', 'calibration': 'calibration', 'locked_test': 'test', 'ood': 'ood'}
_SAFE_ID = re.compile('^[A-Za-z0-9][A-Za-z0-9_.:-]{0,255}$')
_SHA256 = re.compile('^[0-9a-f]{64}$')

class ProtocolValidationError(ValueError):

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = str(code)

def _inside_project(path: str | Path, *, must_exist: bool=True) -> Path:
    candidate = Path(path).expanduser()
    if not candidate.is_absolute():
        candidate = PROJECT_ROOT / candidate
    resolved = candidate.resolve()
    try:
        resolved.relative_to(PROJECT_ROOT.resolve())
    except ValueError as error:
        raise ProtocolValidationError('path_outside_deepfusion', f'协议输入与输出必须位于DeepFusion目录内: {resolved}') from error
    if must_exist and (not resolved.is_file()):
        raise ProtocolValidationError('file_missing', f'文件不存在: {resolved}')
    return resolved

def _verify_runtime() -> None:
    try:
        verify_deepfusion_runtime(PROJECT_ROOT, real_fusion.__file__)
    except DeepFusionRuntimeGuardError as error:
        raise ProtocolValidationError(error.code, str(error)) from error

def _canonical_bytes(value: object) -> bytes:
    try:
        rendered = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    except (TypeError, ValueError) as error:
        raise ProtocolValidationError('not_canonical_json', '对象不能确定性JSON序列化') from error
    return rendered.encode('utf-8')

def object_sha256(value: object) -> str:
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()

def _mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ProtocolValidationError('protocol_invalid', f'{label}必须是映射')
    return value

def _safe_id(value: object, label: str) -> str:
    normalized = str(value).strip()
    if not _SAFE_ID.fullmatch(normalized):
        raise ProtocolValidationError('identifier_invalid', f'{label}不是合法稳定标识: {normalized!r}')
    return normalized

def _strict_bool(value: object, label: str) -> bool:
    if type(value) is not bool:
        raise ProtocolValidationError('boolean_invalid', f'{label}必须是JSON布尔值')
    return bool(value)

def _sha256(value: object, label: str) -> str:
    normalized = str(value).strip().lower()
    if not _SHA256.fullmatch(normalized):
        raise ProtocolValidationError('hash_invalid', f'{label}必须是64位SHA-256')
    return normalized

def _fraction_mapping(value: object) -> Dict[str, float]:
    mapping = _mapping(value, 'reproducibility.fractions')
    if set(mapping) != set(IN_DOMAIN_SPLITS):
        raise ProtocolValidationError('split_fraction_invalid', 'fractions必须且只能包含train/tune/calibration/test')
    fractions: Dict[str, float] = {}
    for name in IN_DOMAIN_SPLITS:
        raw = mapping[name]
        if isinstance(raw, bool):
            raise ProtocolValidationError('split_fraction_invalid', f'{name}比例非法')
        try:
            number = float(raw)
        except (TypeError, ValueError) as error:
            raise ProtocolValidationError('split_fraction_invalid', f'{name}比例必须是数值') from error
        if not math.isfinite(number) or number <= 0.0:
            raise ProtocolValidationError('split_fraction_invalid', f'{name}比例必须是有限正数')
        fractions[name] = number
    if not math.isclose(sum(fractions.values()), 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise ProtocolValidationError('split_fraction_invalid', '四段比例之和必须为1')
    return fractions

def validate_protocol(value: object) -> Dict[str, object]:
    root = _mapping(value, 'protocol')
    if str(root.get('schema_version')) != PROTOCOL_SCHEMA_VERSION:
        raise ProtocolValidationError('protocol_schema_mismatch', '论文协议版本不兼容')
    experiment = _mapping(root.get('experiment'), 'experiment')
    protocol_id = _safe_id(experiment.get('id'), 'experiment.id')
    status = str(experiment.get('status', '')).strip()
    if status not in {'preregistered_draft', 'frozen'}:
        raise ProtocolValidationError('protocol_status_invalid', 'experiment.status只能是preregistered_draft或frozen')
    if status == 'frozen' and (not str(experiment.get('frozen_on', '')).strip()):
        raise ProtocolValidationError('protocol_status_invalid', '冻结协议必须记录frozen_on')
    reproducibility = _mapping(root.get('reproducibility'), 'reproducibility')
    if str(reproducibility.get('split_unit')) != 'independence_group_id':
        raise ProtocolValidationError('split_unit_invalid', 'v2必须按independence_group_id整体划分')
    raw_seed = reproducibility.get('primary_seed')
    if isinstance(raw_seed, bool) or not isinstance(raw_seed, int):
        raise ProtocolValidationError('seed_invalid', 'primary_seed必须是整数')
    fractions = _fraction_mapping(reproducibility.get('fractions'))
    roles = _mapping(reproducibility.get('roles'), 'reproducibility.roles')
    normalized_roles = {str(key): str(item) for key, item in roles.items()}
    if normalized_roles != EXPECTED_ROLES:
        raise ProtocolValidationError('split_roles_invalid', 'v2划分职责必须严格分离且不能使用validation别名')
    candidate_domain = _mapping(root.get('candidate_domain'), 'candidate_domain')
    if str(candidate_domain.get('search_topology')) != 'S0-model':
        raise ProtocolValidationError('candidate_domain_invalid', '搜索拓扑必须标记为S0-model')
    _strict_bool(candidate_domain.get('identity_independent'), 'candidate_domain.identity_independent')
    if candidate_domain.get('identity_independent') is not True:
        raise ProtocolValidationError('candidate_domain_invalid', 'S0-model必须身份无关')
    audit_only = candidate_domain.get('audit_only')
    if not isinstance(audit_only, list) or 'A-MBY' not in map(str, audit_only):
        raise ProtocolValidationError('candidate_domain_invalid', 'A-MBY必须只作为审计域登记')
    if audit_only != ['A-MBY']:
        raise ProtocolValidationError('candidate_domain_invalid', 'audit_only必须严格且仅包含A-MBY')
    h1 = _mapping(candidate_domain.get('future_hard_domain'), 'candidate_domain.future_hard_domain')
    if str(h1.get('id')) != 'H1' or _strict_bool(h1.get('enabled'), 'H1.enabled'):
        raise ProtocolValidationError('candidate_domain_invalid', 'H1在独立验证前必须登记为disabled')
    fallback = _mapping(root.get('fallback'), 'fallback')
    if str(fallback.get('binding')) != 'B_fallback':
        raise ProtocolValidationError('fallback_invalid', '必须显式绑定B_fallback')
    if str(fallback.get('initial')) != 'B0':
        raise ProtocolValidationError('fallback_invalid', '首轮B_fallback必须为B0')
    requirements = fallback.get('m1a_rebind_requires')
    if not isinstance(requirements, list) or set(map(str, requirements)) != {'independent_validation', 'frozen_artifact', 'explicit_authorization'}:
        raise ProtocolValidationError('fallback_invalid', 'M1a改绑必须同时要求独立验证、冻结和明确授权')
    blinding = _mapping(root.get('blinding'), 'blinding')
    forbidden = blinding.get('training_outputs_forbidden_splits')
    if not isinstance(forbidden, list) or set(map(str, forbidden)) != {'test', 'ood'}:
        raise ProtocolValidationError('blinding_invalid', '训练/选择/校准报告必须禁止输出test与ood结果')
    if not _strict_bool(blinding.get('test_may_only_report'), 'blinding.test_may_only_report'):
        raise ProtocolValidationError('blinding_invalid', '锁定test只能用于最终报告')
    truth = _mapping(root.get('truth'), 'truth')
    allowed_truth_levels = truth.get('allowed_truth_levels')
    if allowed_truth_levels != ['d1', 'd2', 'd3']:
        raise ProtocolValidationError('truth_protocol_invalid', '真值等级必须严格登记为d1/d2/d3')
    if truth.get('pair_labels') != ['same', 'different', 'ambiguous']:
        raise ProtocolValidationError('truth_protocol_invalid', 'pair标签必须严格为same/different/ambiguous')
    if str(truth.get('ambiguous_policy')) != 'exclude_from_supervised_loss_and_binary_metrics_but_count':
        raise ProtocolValidationError('truth_protocol_invalid', 'ambiguous必须排除二值监督与指标但保留计数')
    if str(truth.get('graph_claim_requires')) != 'partition_complete':
        raise ProtocolValidationError('truth_protocol_invalid', '图级结论必须要求partition_complete')
    if str(truth.get('state_accuracy_claim_requires')) != 'd3':
        raise ProtocolValidationError('truth_protocol_invalid', '绝对状态精度结论必须要求D3真值')
    data_governance = _mapping(root.get('data_governance'), 'data_governance')
    required_data_governance = {'real_flight_data_available', 'access_mode', 'raw_data_transfer_required', 'accepted_static_inputs', 'accepted_realtime_inputs', 'research_replay_policy', 'source_binding', 'raw_data_commit_forbidden', 'raw_data_export_forbidden', 'source_paths_must_remain_inside_deepfusion', 'receipt_must_record', 'note'}
    if set(data_governance) != required_data_governance:
        raise ProtocolValidationError('data_governance_invalid', '真实数据本地治理字段不完整或包含未知字段')
    for key in ('real_flight_data_available', 'raw_data_transfer_required', 'raw_data_commit_forbidden', 'raw_data_export_forbidden', 'source_paths_must_remain_inside_deepfusion'):
        _strict_bool(data_governance.get(key), f'data_governance.{key}')
    if data_governance.get('real_flight_data_available') is not True:
        raise ProtocolValidationError('data_governance_invalid', 'v2协议必须登记真实飞行数据可在用户本地使用')
    if data_governance.get('access_mode') != 'owner_local_only':
        raise ProtocolValidationError('data_governance_invalid', '真实数据访问模式必须是owner_local_only')
    if data_governance.get('raw_data_transfer_required') is not False:
        raise ProtocolValidationError('data_governance_invalid', '协议不能要求上传真实原始数据')
    if data_governance.get('raw_data_commit_forbidden') is not True or data_governance.get('raw_data_export_forbidden') is not True:
        raise ProtocolValidationError('data_governance_invalid', '真实原始数据必须禁止提交和导出')
    if data_governance.get('source_paths_must_remain_inside_deepfusion') is not True:
        raise ProtocolValidationError('data_governance_invalid', '真实输入路径必须留在DeepFusion目录内')
    if data_governance.get('accepted_static_inputs') != ['sw_excel_56_column', 'ew_excel_55_column'] or data_governance.get('accepted_realtime_inputs') != ['tcp_json_lines', 'kafka_json_object', 'kafka_object_batch', 'kafka_position_value_array']:
        raise ProtocolValidationError('data_governance_invalid', '静态SW/EW与动态报文输入枚举不完整')
    if data_governance.get('research_replay_policy') != 'immutable_local_journal_before_training_or_test':
        raise ProtocolValidationError('data_governance_invalid', '训练/测试实时数据必须先封存不可变本地journal')
    if data_governance.get('source_binding') != 'input_source_manifest_v2_plus_local_hash_verification':
        raise ProtocolValidationError('data_governance_invalid', '输入必须绑定InputSourceManifestV2与哈希核验')
    if data_governance.get('receipt_must_record') != ['source_hash', 'config_hash', 'code_hash', 'environment_hash', 'decision_cutoff', 'failure_indices']:
        raise ProtocolValidationError('data_governance_invalid', '运行回执字段不完整')
    minimum_groups = _mapping(reproducibility.get('minimum_independence_groups'), 'reproducibility.minimum_independence_groups')
    normalized_minimum: Dict[str, int] = {}
    if set(minimum_groups) != set(SPLIT_NAMES):
        raise ProtocolValidationError('minimum_groups_invalid', '必须为全部五个集合登记最少独立组数')
    for split in SPLIT_NAMES:
        raw = minimum_groups[split]
        if isinstance(raw, bool) or not isinstance(raw, int) or raw < 1:
            raise ProtocolValidationError('minimum_groups_invalid', f'{split}最少独立组数必须是正整数')
        normalized_minimum[split] = int(raw)
    return {'protocol_id': protocol_id, 'protocol_status': status, 'primary_seed': int(raw_seed), 'fractions': fractions, 'roles': dict(EXPECTED_ROLES), 'minimum_independence_groups': normalized_minimum, 'truth_pair_labels': ['same', 'different', 'ambiguous'], 'graph_claim_requires': 'partition_complete', 'protocol_sha256': object_sha256(root)}

def load_protocol(path: str | Path) -> Tuple[Dict[str, object], Dict[str, object]]:
    protocol_path = _inside_project(path)
    try:
        value = yaml.safe_load(protocol_path.read_text(encoding='utf-8-sig'))
    except (OSError, UnicodeError, yaml.YAMLError) as error:
        raise ProtocolValidationError('protocol_unreadable', '论文协议YAML无法解析') from error
    if not isinstance(value, dict):
        raise ProtocolValidationError('protocol_invalid', '论文协议根必须是映射')
    return (value, validate_protocol(value))

def validate_task_pool(value: object) -> Dict[str, object]:
    root = _mapping(value, 'task_pool')
    if str(root.get('schema_version')) != TASK_POOL_SCHEMA_VERSION:
        raise ProtocolValidationError('task_pool_schema_mismatch', '任务池版本不兼容')
    required_root_keys = {'schema_version', 'dataset_id', 'source_manifest_sha256', 'tasks'}
    if set(map(str, root)) != required_root_keys:
        raise ProtocolValidationError('task_pool_keys_invalid', f'任务池字段必须严格为{sorted(required_root_keys)}')
    dataset_id = _safe_id(root.get('dataset_id'), 'dataset_id')
    source_manifest_sha256 = _sha256(root.get('source_manifest_sha256'), 'source_manifest_sha256')
    raw_tasks = root.get('tasks')
    if not isinstance(raw_tasks, list) or not raw_tasks:
        raise ProtocolValidationError('task_pool_invalid', 'tasks必须是非空数组')
    normalized_tasks: List[Dict[str, object]] = []
    seen_tasks = set()
    group_domain: Dict[str, str] = {}
    for index, raw_task in enumerate(raw_tasks):
        task = _mapping(raw_task, f'tasks[{index}]')
        required_task_keys = {'task_id', 'independence_group_id', 'domain', 'stratum', 'truth_level', 'partition_complete', 'temporal_identity_complete', 'label_version'}
        if set(map(str, task)) != required_task_keys:
            raise ProtocolValidationError('task_keys_invalid', f'tasks[{index}]字段必须严格为{sorted(required_task_keys)}')
        task_id = _safe_id(task.get('task_id'), f'tasks[{index}].task_id')
        group_id = _safe_id(task.get('independence_group_id'), f'tasks[{index}].independence_group_id')
        if task_id in seen_tasks:
            raise ProtocolValidationError('task_duplicate', f'task_id重复: {task_id}')
        seen_tasks.add(task_id)
        domain = str(task.get('domain', '')).strip()
        if domain not in {'in_distribution', 'ood'}:
            raise ProtocolValidationError('task_domain_invalid', f'任务{task_id}的domain必须是in_distribution或ood')
        stratum = str(task.get('stratum', 'unspecified')).strip() or 'unspecified'
        previous_domain = group_domain.setdefault(group_id, domain)
        if previous_domain != domain:
            raise ProtocolValidationError('independence_group_inconsistent', f'独立组{group_id}不能跨in-distribution/OOD域')
        truth_level = str(task.get('truth_level', '')).lower().strip()
        if truth_level not in {'d1', 'd2', 'd3'}:
            raise ProtocolValidationError('truth_level_invalid', f'任务{task_id}必须声明d1/d2/d3真值等级')
        partition_complete = _strict_bool(task.get('partition_complete'), f'任务{task_id}.partition_complete')
        temporal_complete = _strict_bool(task.get('temporal_identity_complete'), f'任务{task_id}.temporal_identity_complete')
        label_version = _safe_id(task.get('label_version'), f'任务{task_id}.label_version')
        normalized_tasks.append({'task_id': task_id, 'independence_group_id': group_id, 'domain': domain, 'stratum': stratum, 'truth_level': truth_level, 'partition_complete': partition_complete, 'temporal_identity_complete': temporal_complete, 'label_version': label_version})
    normalized_tasks.sort(key=lambda item: str(item['task_id']))
    return {'schema_version': TASK_POOL_SCHEMA_VERSION, 'dataset_id': dataset_id, 'source_manifest_sha256': source_manifest_sha256, 'tasks': normalized_tasks}

def load_task_pool(path: str | Path) -> Dict[str, object]:
    task_pool_path = _inside_project(path)
    try:
        value = json.loads(task_pool_path.read_text(encoding='utf-8-sig'))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ProtocolValidationError('task_pool_unreadable', '任务池JSON无法解析') from error
    return validate_task_pool(value)

def _positive_fraction_counts(item_count: int, fractions: Mapping[str, float]) -> Dict[str, int]:
    if item_count < len(IN_DOMAIN_SPLITS):
        raise ProtocolValidationError('too_few_independence_groups', f'域内至少需要{len(IN_DOMAIN_SPLITS)}个独立组')
    raw = {name: item_count * float(fractions[name]) for name in IN_DOMAIN_SPLITS}
    counts = {name: max(1, int(math.floor(raw[name]))) for name in IN_DOMAIN_SPLITS}
    while sum(counts.values()) > item_count:
        candidates = [name for name in IN_DOMAIN_SPLITS if counts[name] > 1]
        selected = max(candidates, key=lambda name: (counts[name] - raw[name], counts[name], -IN_DOMAIN_SPLITS.index(name)))
        counts[selected] -= 1
    while sum(counts.values()) < item_count:
        selected = max(IN_DOMAIN_SPLITS, key=lambda name: (raw[name] - counts[name], float(fractions[name]), -IN_DOMAIN_SPLITS.index(name)))
        counts[selected] += 1
    return counts

def create_split_manifest(protocol: object, task_pool: object) -> Dict[str, object]:
    protocol_summary = validate_protocol(protocol)
    normalized_pool = validate_task_pool(task_pool)
    tasks = list(normalized_pool['tasks'])
    tasks_by_group: Dict[str, List[Mapping[str, object]]] = defaultdict(list)
    for task in tasks:
        tasks_by_group[str(task['independence_group_id'])].append(task)
    domain_by_group = {group_id: str(group_tasks[0]['domain']) for group_id, group_tasks in tasks_by_group.items()}
    in_domain_groups = sorted((group_id for group_id, domain in domain_by_group.items() if domain == 'in_distribution'))
    ood_groups = sorted((group_id for group_id, domain in domain_by_group.items() if domain == 'ood'))
    minimum = protocol_summary['minimum_independence_groups']
    if len(ood_groups) < int(minimum['ood']):
        raise ProtocolValidationError('too_few_ood_groups', f"OOD独立组数{len(ood_groups)}低于协议要求{minimum['ood']}")
    fractions = protocol_summary['fractions']
    counts = _positive_fraction_counts(len(in_domain_groups), fractions)
    seed = int(protocol_summary['primary_seed'])
    ordered_groups = sorted(in_domain_groups, key=lambda group_id: (hashlib.sha256(f'{seed}:{group_id}'.encode('utf-8')).hexdigest(), group_id))
    groups_by_split: Dict[str, List[str]] = {}
    start = 0
    for split in IN_DOMAIN_SPLITS:
        stop = start + counts[split]
        groups_by_split[split] = sorted(ordered_groups[start:stop])
        start = stop
    groups_by_split['ood'] = ood_groups
    for split in SPLIT_NAMES:
        if len(groups_by_split[split]) < int(minimum[split]):
            raise ProtocolValidationError('minimum_groups_not_met', f'{split}独立组数低于协议要求')
    tasks_by_split = {split: sorted((str(task['task_id']) for group_id in groups_by_split[split] for task in tasks_by_group[group_id])) for split in SPLIT_NAMES}
    in_domain_task_count = sum((len(tasks_by_split[name]) for name in IN_DOMAIN_SPLITS))
    in_domain_group_count = len(in_domain_groups)
    strata_by_split: Dict[str, Dict[str, int]] = {}
    truth_by_split: Dict[str, Dict[str, int]] = {}
    task_by_id = {str(task['task_id']): task for task in tasks}
    for split in SPLIT_NAMES:
        selected = [task_by_id[task_id] for task_id in tasks_by_split[split]]
        strata_by_split[split] = dict(sorted(Counter((str(task['stratum']) for task in selected)).items()))
        truth_counts = Counter((str(task['truth_level']) for task in selected))
        truth_by_split[split] = {'d1': int(truth_counts.get('d1', 0)), 'd2': int(truth_counts.get('d2', 0)), 'd3': int(truth_counts.get('d3', 0)), 'partition_complete': sum((bool(task['partition_complete']) for task in selected)), 'temporal_identity_complete': sum((bool(task['temporal_identity_complete']) for task in selected))}
    realized = {}
    for split in SPLIT_NAMES:
        group_count = len(groups_by_split[split])
        task_count = len(tasks_by_split[split])
        realized[split] = {'independence_group_count': group_count, 'task_count': task_count, 'in_domain_group_fraction': float(group_count / in_domain_group_count) if split != 'ood' and in_domain_group_count else None, 'in_domain_task_fraction': float(task_count / in_domain_task_count) if split != 'ood' and in_domain_task_count else None}
    return {'schema_version': SPLIT_MANIFEST_SCHEMA_VERSION, 'protocol_id': protocol_summary['protocol_id'], 'protocol_sha256': protocol_summary['protocol_sha256'], 'task_pool_schema_version': TASK_POOL_SCHEMA_VERSION, 'task_pool_sha256': object_sha256(normalized_pool), 'dataset_id': normalized_pool['dataset_id'], 'source_manifest_sha256': normalized_pool['source_manifest_sha256'], 'seed': seed, 'grouping_unit': 'independence_group_id', 'assignment_method': 'stable_sha256_group_order_then_fixed_counts', 'fractions_target_group_level': dict(fractions), 'roles': dict(EXPECTED_ROLES), 'groups': groups_by_split, 'splits': tasks_by_split, 'realized': realized, 'strata_audit': strata_by_split, 'truth_qualification_audit': truth_by_split, 'blinding': {'training_outputs_forbidden_splits': ['test', 'ood'], 'validation_alias_allowed': False}}

def validate_split_manifest(manifest: object, protocol: object, task_pool: object) -> Dict[str, object]:
    root = _mapping(manifest, 'split_manifest')
    if str(root.get('schema_version')) != SPLIT_MANIFEST_SCHEMA_VERSION:
        raise ProtocolValidationError('split_manifest_schema_mismatch', '划分manifest版本不兼容')
    expected = create_split_manifest(protocol, task_pool)
    if _canonical_bytes(root) != _canonical_bytes(expected):
        raise ProtocolValidationError('split_manifest_mismatch', '划分manifest与冻结协议/任务池不一致，拒绝静默重划分或手工改写')
    all_tasks = [task for split in SPLIT_NAMES for task in root['splits'][split]]
    all_groups = [group for split in SPLIT_NAMES for group in root['groups'][split]]
    if len(all_tasks) != len(set(all_tasks)) or len(all_groups) != len(set(all_groups)):
        raise ProtocolValidationError('split_leakage', '任务或独立组跨split泄漏')
    return {'status': 'valid', 'protocol_id': root['protocol_id'], 'protocol_sha256': root['protocol_sha256'], 'task_pool_sha256': root['task_pool_sha256'], 'split_manifest_sha256': object_sha256(root), 'realized': root['realized']}

def _load_json(path: str | Path, label: str) -> Dict[str, object]:
    input_path = _inside_project(path)
    try:
        value = json.loads(input_path.read_text(encoding='utf-8-sig'))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ProtocolValidationError(f'{label}_unreadable', f'{label} JSON无法解析') from error
    if not isinstance(value, dict):
        raise ProtocolValidationError(f'{label}_invalid', f'{label}根必须是对象')
    return value

def _write_json(path: str | Path, value: object, *, overwrite: bool) -> Path:
    output = _inside_project(path, must_exist=False)
    if output.exists() and (not overwrite):
        raise ProtocolValidationError('output_exists', f'输出已存在；应新建版本或显式--overwrite: {output}')
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(f'.{output.name}.{os.getpid()}.tmp')
    try:
        temporary.write_bytes(_canonical_bytes(value) + b'\n')
        os.replace(str(temporary), str(output))
    finally:
        if temporary.exists():
            temporary.unlink()
    return output

def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='验证DF-PAAG论文v2协议并冻结任务级划分')
    subparsers = parser.add_subparsers(dest='command', required=True)
    validate = subparsers.add_parser('validate-protocol', help='只读验证协议')
    validate.add_argument('--protocol', required=True)
    create = subparsers.add_parser('create-split', help='由固定任务池生成v2划分manifest')
    create.add_argument('--protocol', required=True)
    create.add_argument('--task-pool', required=True)
    create.add_argument('--output', required=True)
    create.add_argument('--overwrite', action='store_true')
    check = subparsers.add_parser('validate-split', help='只读复核冻结划分')
    check.add_argument('--protocol', required=True)
    check.add_argument('--task-pool', required=True)
    check.add_argument('--split-manifest', required=True)
    return parser

def main(argv: Optional[Sequence[str]]=None) -> int:
    args = _parser().parse_args(argv)
    try:
        _verify_runtime()
        protocol, protocol_summary = load_protocol(args.protocol)
        if args.command == 'validate-protocol':
            result: Mapping[str, object] = {'status': 'valid', **protocol_summary}
        else:
            task_pool = load_task_pool(args.task_pool)
            if args.command == 'create-split':
                manifest = create_split_manifest(protocol, task_pool)
                output = _write_json(args.output, manifest, overwrite=bool(args.overwrite))
                result = {'status': 'created', 'output': str(output.relative_to(PROJECT_ROOT)), 'split_manifest_sha256': object_sha256(manifest), 'realized': manifest['realized']}
            else:
                manifest = _load_json(args.split_manifest, 'split_manifest')
                result = validate_split_manifest(manifest, protocol, task_pool)
    except ProtocolValidationError as error:
        print(json.dumps({'status': 'error', 'code': error.code, 'message': str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
__all__ = ['EXPECTED_ROLES', 'IN_DOMAIN_SPLITS', 'PROTOCOL_SCHEMA_VERSION', 'ProtocolValidationError', 'SPLIT_MANIFEST_SCHEMA_VERSION', 'SPLIT_NAMES', 'TASK_POOL_SCHEMA_VERSION', 'create_split_manifest', 'load_protocol', 'load_task_pool', 'main', 'object_sha256', 'validate_protocol', 'validate_split_manifest', 'validate_task_pool']
