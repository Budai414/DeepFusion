from __future__ import annotations
import copy
import math
import time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from research.df_paag import reviewer_association_v4 as v4
VARIANT = 'equal_history'
CONTROL_CONFIG = {'version': 'equal-history-temporal-architecture-control-v5', 'variant': VARIANT, 'formal_name': 'two_sided_equal_history', 'causal_reference_dilations': [1, 1, 2, 2], 'symmetric_control_dilations': [1, 2, 3, 6], 'kernel_size': 3, 'endpoint_feature_lags': list(range(13)), 'readout': 'last valid feature step, same observation cutoff as causal reference', 'parameterization': 'exactly the v4 PairNetwork tensors; no additional trainable parameters', 'scope': 'temporal architecture control, not future-information or information-causality ablation', 'physical_diagnostics': 'unchanged; endpoint feature support does not bound total raw-history use', 'training': 'same v4 train/tune roles, loss, optimizer, batching, stopping and five seeds'}

class SymmetricMixedDilationBlock(nn.Module):

    def __init__(self, original, dilation1, dilation2):
        super().__init__()
        self.conv1 = original.conv1
        self.conv2 = original.conv2
        self.dropout = original.dropout
        self.conv1.dilation = (int(dilation1),)
        self.conv2.dilation = (int(dilation2),)
        self.pad1 = (int(dilation1), int(dilation1))
        self.pad2 = (int(dilation2), int(dilation2))

    def forward(self, z, mask):
        u = self.dropout(F.gelu(self.conv1(F.pad(z, self.pad1))))
        u = self.dropout(self.conv2(F.pad(u, self.pad2)))
        return F.gelu(z + u) * mask.unsqueeze(1)

class EqualHistoryPairNetwork(v4.PairNetwork):

    def __init__(self):
        super().__init__(variant=VARIANT)
        self.blocks = nn.ModuleList([SymmetricMixedDilationBlock(self.blocks[0], 1, 2), SymmetricMixedDilationBlock(self.blocks[1], 3, 6)])

def make_model(variant=VARIANT):
    if variant != VARIANT:
        raise ValueError(f'This module owns only {VARIANT}, not {variant}')
    return EqualHistoryPairNetwork()

def train(variant, seed, datasets, scaler, out, signature):
    if variant != VARIANT:
        raise ValueError(f'Expected variant {VARIANT}')
    path = out / f'checkpoint_{variant}_{seed}.pt'
    if path.exists():
        ckpt = torch.load(path, weights_only=False)
        if ckpt['training_signature'] != signature:
            raise RuntimeError('Training provenance changed')
        if ckpt.get('temporal_control') != CONTROL_CONFIG or ckpt.get('variant') != variant:
            raise RuntimeError('Temporal control protocol changed')
        model = make_model(variant)
        model.load_state_dict(ckpt['state'])
        print(f'loaded {variant} seed={seed}', flush=True)
        return (model.eval(), ckpt['history'])
    torch.manual_seed(seed)
    model = make_model(variant)
    opt = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.0001)
    prepared = {s: [v4.tensor_task(t, scaler) for t in datasets[s]] for s in ('train', 'tune')}
    rng = np.random.default_rng(seed)
    best, history, state, stale = (math.inf, [], None, 0)
    start = time.perf_counter()
    for epoch in range(80):
        model.train()
        order = rng.permutation(len(prepared['train']))
        losses = []
        for index in range(0, len(order), 8):
            t = v4.collate([prepared['train'][int(i)] for i in order[index:index + 8]])
            if not len(t['y']):
                continue
            opt.zero_grad()
            loss = F.binary_cross_entropy_with_logits(v4.forward(model, t), t['y'], reduction='none')
            loss = (loss * torch.where(t['y'] > 0, 1.0, 5.0)).mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            losses.append(float(loss.detach()))
        model.eval()
        tl = []
        with torch.no_grad():
            for t in prepared['tune']:
                if not len(t['y']):
                    continue
                loss = F.binary_cross_entropy_with_logits(v4.forward(model, t), t['y'], reduction='none')
                tl.append(float((loss * torch.where(t['y'] > 0, 1.0, 5.0)).mean()))
        score = float(np.mean(tl))
        history.append({'epoch': epoch + 1, 'train_loss': float(np.mean(losses)), 'tune_loss': score})
        if score < best - 1e-05:
            best, state, stale = (score, copy.deepcopy(model.state_dict()), 0)
        else:
            stale += 1
        if (epoch + 1) % 10 == 0:
            print(f'progress {variant} seed={seed} epoch={epoch + 1} tune={score:.5f}', flush=True)
        if stale >= 12:
            break
    if state is None:
        raise RuntimeError('No finite tune loss; no checkpoint may be accepted')
    model.load_state_dict(state)
    out.mkdir(parents=True, exist_ok=True)
    torch.save({'state': state, 'training_signature': signature, 'history': history, 'scaler': scaler, 'variant': variant, 'seed': seed, 'training_config': v4.TRAIN_CONFIG, 'temporal_control': CONTROL_CONFIG}, path)
    print(f'trained {variant} seed={seed} epochs={len(history)} best={best:.5f} seconds={time.perf_counter() - start:.1f}', flush=True)
    return (model.eval(), history)
