from __future__ import annotations
import hashlib
import math
from pathlib import Path
from typing import Mapping, Sequence
import numpy as np
from scipy.optimize import linear_sum_assignment
from research.df_paag import reviewer_state_fusion_v4 as v4
CONTROL_CONFIG = {'min_reports': 1, 'max_age_s': 5.0, 'covariance_scale': 1.0}
COVARIANCE_SCALE_GRID = (1.0, 2.0, 4.0, 8.0, 16.0)
PROTOCOL = {'version': 'state-fusion-v5-observable-quality-calibration', 'backend': 'unchanged v4 causal CV propagation and simultaneous equal-weight CI', 'control': CONTROL_CONFIG.copy(), 'maturity_rule': 'minimum number of distinct report times <= query, per source tracklet; no future reports counted', 'freshness_rule': 'query minus latest eligible report time <= max_age_s', 'filter_grid': {'min_reports': [3, 5, 8], 'max_age_s': [2.0, 5.0], 'include_equalCI_control': True}, 'filter_selection': 'one global configuration selected by scene-macro development OSPA; all methods share it', 'covariance_scale_grid': list(COVARIANCE_SCALE_GRID), 'covariance_calibration': 'one positive scalar multiplies the final 6D CI covariance, not its mean; select scene-macro matched NLL on the declared pretest fitting split (development or probability_calibration); the v5 runner uses probability_calibration and risk_calibration only confirms coverage without reselecting', 'covariance_fit_allowed_roles': ['development', 'probability_calibration'], 'covariance_fit_forbidden_roles': ['test', 'confirmation', 'risk_calibration'], 'covariance_fit_tie_break': 'smaller scale when scene-macro NLL is exactly tied', 'covariance_fit_no_matches': 'fail rather than manufacture a calibrated scale', 'calibration_scope': 'conditional Gaussian uncertainty on accepted matches; no guarantee under model mismatch or OOD', 'shared_backend': 'same frozen maturity, age and covariance scale for every association method; unmodified equalCI remains a separate control', 'per_component_source_rule': v4.PROTOCOL['per_component_source_rule'], 'no_proximity_deduplication': True, 'gospa': {'p': 2, 'cutoff_m': 150.0, 'alpha': 2, 'base_distance': '3D Euclidean position distance', 'assignment': 'Hungarian on cutoff-squared costs, retaining only distances strictly below cutoff', 'localization_squared_m2': 'sum of squared distances over optimal accepted pairs', 'missed_squared_m2': '(150^2/2) * number of unassigned truth targets', 'false_squared_m2': '(150^2/2) * number of unassigned estimates', 'normalization': 'none; GOSPA^2 = localization_squared + missed_squared + false_squared', 'aggregation': 'mean GOSPA and root-mean-square GOSPA differ; additive scene-averaged decomposition uses squared terms', 'reference': 'https://arxiv.org/abs/1601.05585 (Proposition 1)'}, 'v4_metrics': 'all v4 OSPA, coverage, conditional RMSE/NLL/NEES, matched contamination and raw error arrays are retained'}

def canonical_config(config: Mapping | None=None) -> dict:
    supplied = dict(config or {})
    for alias, key in (('cov_scale', 'covariance_scale'), ('maximum_report_age_s', 'max_age_s')):
        if alias in supplied:
            if key in supplied and supplied[key] != supplied[alias]:
                raise ValueError(f'Conflicting {alias} and {key}')
            supplied[key] = supplied.pop(alias)
    unknown = set(supplied) - set(CONTROL_CONFIG)
    if unknown:
        raise ValueError(f'Unknown backend configuration fields: {sorted(unknown)}')
    values = {**CONTROL_CONFIG, **supplied}
    reports = values['min_reports']
    if isinstance(reports, bool) or not isinstance(reports, (int, np.integer)) or reports < 1:
        raise ValueError('min_reports must be a positive integer')
    age = values['max_age_s']
    if age is not None and (not math.isfinite(float(age)) or float(age) < 0):
        raise ValueError('max_age_s must be nonnegative and finite, or None to disable freshness filtering')
    scale = float(values['covariance_scale'])
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('covariance_scale must be positive and finite')
    return {'min_reports': int(reports), 'max_age_s': None if age is None else float(age), 'covariance_scale': scale}

def development_filter_grid() -> list[dict]:
    return [CONTROL_CONFIG.copy()] + [{'min_reports': count, 'max_age_s': age, 'covariance_scale': 1.0} for count in PROTOCOL['filter_grid']['min_reports'] for age in PROTOCOL['filter_grid']['max_age_s']]

def fuse_partition(histories, sensor, groups, query_s: float, config=None, *, sensors=(0, 1, 2)) -> list[dict]:
    cfg = canonical_config(config)
    query_s = float(query_s)
    if not math.isfinite(query_s):
        raise ValueError('Query time must be finite')
    sensor = np.asarray(sensor, dtype=int)
    if len(sensor) != len(histories):
        raise ValueError('Sensor/history lengths differ')
    allowed = set(map(int, sensors))
    output = []
    for group in groups:
        latest = {}
        counts = {'sensor_excluded': 0, 'no_past_report': 0, 'immature': 0, 'stale': 0}
        for node in group:
            node = int(node)
            sid = int(sensor[node])
            if sid not in allowed:
                counts['sensor_excluded'] += 1
                continue
            history = histories[node]
            times = np.asarray(history['t'], dtype=float)
            if np.any(~np.isfinite(times)) or np.any(np.diff(times) < 0):
                raise ValueError('History timestamps must be finite and nondecreasing')
            eligible = np.flatnonzero(times <= query_s + 1e-10)
            if not len(eligible):
                counts['no_past_report'] += 1
                continue
            if len(np.unique(times[eligible])) < cfg['min_reports']:
                counts['immature'] += 1
                continue
            k = int(eligible[-1])
            age = max(0.0, query_s - float(times[k]))
            if cfg['max_age_s'] is not None and age > cfg['max_age_s']:
                counts['stale'] += 1
                continue
            candidate = (float(times[k]), -node, k)
            if sid not in latest or candidate > latest[sid]:
                latest[sid] = candidate
        if not latest:
            continue
        states, covariances, used = ([], [], [])
        for sid in sorted(latest):
            timestamp, negative_node, k = latest[sid]
            node = -negative_node
            state, covariance = v4.propagate_report(histories[node], k, query_s)
            states.append(state)
            covariances.append(covariance)
            used.append({'node': node, 'sensor': sid, 'report_index': k, 'report_time_s': timestamp})
        mean, covariance = v4.equal_weight_ci(states, covariances)
        output.append({'mean': mean, 'covariance': covariance * cfg['covariance_scale'], 'used_reports': used, 'component_nodes': list(map(int, group)), 'backend_config': cfg.copy(), 'source_filter_counts': counts})
    return output

def method_states(task, selected, query_s, config=None, *, sensors=(0, 1, 2), oracle=False):
    groups = v4.oracle_identity_components(task['identities']) if oracle else v4.selected_components(len(task['histories']), task['edges'], selected)
    return fuse_partition(task['histories'], task['sensor'], groups, query_s, config, sensors=sensors)

def gospa_decomposition(estimates: Sequence[Mapping], truth: np.ndarray, *, cutoff_m=150.0) -> dict:
    cutoff = float(cutoff_m)
    if not math.isfinite(cutoff) or cutoff <= 0:
        raise ValueError('GOSPA cutoff must be positive and finite')
    truth = np.asarray(truth, dtype=float).reshape(-1, 6)
    predicted = np.asarray([value['mean'] for value in estimates], dtype=float).reshape(-1, 6)
    if np.any(~np.isfinite(truth)) or np.any(~np.isfinite(predicted)):
        raise ValueError('Nonfinite states cannot be evaluated')
    n, m = (len(truth), len(predicted))
    if n and m:
        distances = np.linalg.norm(truth[:, None, :3] - predicted[None, :, :3], axis=2)
        rows, cols = linear_sum_assignment(np.minimum(distances, cutoff) ** 2)
        pairs = [(int(i), int(j)) for i, j in zip(rows, cols) if distances[i, j] < cutoff]
        localization = float(sum((distances[i, j] ** 2 for i, j in pairs)))
    else:
        pairs, localization = ([], 0.0)
    matched = len(pairs)
    missed, false = (n - matched, m - matched)
    missed_cost, false_cost = (float(cutoff ** 2 / 2 * missed), float(cutoff ** 2 / 2 * false))
    total = localization + missed_cost + false_cost
    return {'gospa_position_m': float(np.sqrt(total)), 'gospa_squared_m2': total, 'gospa_localization_squared_m2': localization, 'gospa_missed_squared_m2': missed_cost, 'gospa_false_squared_m2': false_cost, 'gospa_localization_m': float(np.sqrt(localization)), 'gospa_missed_m': float(np.sqrt(missed_cost)), 'gospa_false_m': float(np.sqrt(false_cost)), 'gospa_matched_count': matched, 'gospa_missed_count': missed, 'gospa_false_output_count': false, 'gospa_matched_pairs': pairs, 'gospa_parameters': {'p': 2, 'c_m': cutoff, 'alpha': 2}}

def evaluate_states(estimates, truth, *, truth_ids=None, node_identities=None) -> dict:
    result = v4.evaluate_states(estimates, truth, truth_ids=truth_ids, node_identities=node_identities)
    result.update(gospa_decomposition(estimates, truth, cutoff_m=PROTOCOL['gospa']['cutoff_m']))
    return result

def fit_covariance_scale(development_rows, *, scale_grid=COVARIANCE_SCALE_GRID, base_scale=1.0, role='development') -> dict:
    if role not in ('development', 'probability_calibration'):
        raise ValueError('Covariance selection requires development or probability_calibration data')
    base_scale = float(base_scale)
    if not math.isfinite(base_scale) or base_scale <= 0:
        raise ValueError('base_scale must be positive and finite')
    scales = sorted(set((float(value) for value in scale_grid)))
    if not scales or any((not math.isfinite(value) or value <= 0 for value in scales)):
        raise ValueError('Scale grid must contain positive finite values')
    rows = list(development_rows)
    groups, prepared, undefined = (set(), [], 0)
    for index, row in enumerate(rows):
        group = str(row.get('independence_group_id', row.get('seed', f'row-{index}')))
        groups.add(group)
        nll = np.asarray(row['nll_values'], dtype=float)
        nees = np.asarray(row['nees_values'], dtype=float)
        if nll.shape != nees.shape or nll.ndim != 1:
            raise ValueError('Per-match NLL and NEES arrays must have equal vector shapes')
        if np.any(~np.isfinite(nll)) or np.any(~np.isfinite(nees)) or np.any(nees < 0):
            raise ValueError('Invalid development error arrays')
        if not len(nll):
            undefined += 1
            continue
        prepared.append((group, nll, nees))
    if not prepared:
        raise ValueError('No matched development states: covariance calibration is undefined')
    candidates = []
    for scale in scales:
        ratio = scale / base_scale
        by_group = {}
        for group, nll, nees in prepared:
            value = float(np.mean(nll + 0.5 * (6 * np.log(ratio) + nees * (1 / ratio - 1))))
            by_group.setdefault(group, []).append(value)
        per_group = {group: float(np.mean(values)) for group, values in by_group.items()}
        candidates.append({'covariance_scale': scale, 'scene_macro_state_nll_nats': float(np.mean(list(per_group.values()))), 'defined_groups': len(per_group), 'undefined_groups': len(groups) - len(per_group)})
    chosen = min(candidates, key=lambda value: (value['scene_macro_state_nll_nats'], value['covariance_scale']))
    return {'covariance_scale': chosen['covariance_scale'], 'base_scale': base_scale, 'selection_metric': 'scene-macro matched six-dimensional Gaussian NLL', 'selection_role': role, 'grid_results': candidates, 'development_rows': len(rows), 'undefined_nll_rows': undefined, 'defined_groups': chosen['defined_groups'], 'undefined_groups': chosen['undefined_groups'], 'independent_calibration_confirmation_required': True}

def source_receipt() -> dict:
    current_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return {**v4.source_receipt(), 'state_module_sha256': current_hash, 'state_v4_module_sha256': hashlib.sha256(Path(v4.__file__).read_bytes()).hexdigest(), 'state_v5_module_sha256': current_hash, 'state_v5_protocol_sha256': v4.canonical_hash(PROTOCOL)}
