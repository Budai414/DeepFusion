from __future__ import annotations
import copy
import hashlib
import json
import math
import time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit, logit
import torch
from torch import nn
from torch.nn import functional as F
from research.df_paag.sequence_v2 import _feature_row, TRACK_NODE_SEQUENCE_FEATURE_NAMES
from research.df_paag.reviewer_simulation_v3 import build_candidate_graph
from research.df_paag.reviewer_baselines_v3 import GraphAssociationV3
SEEDS = [11, 23, 37, 53, 71]
VARIANTS = ['full', 'no_diagnostics', 'asymmetric', 'two_sided_history', 'GNN-neural', 'HTG-TA-inspired']
SPLITS = {'train': [810000, 192], 'tune': [820000, 32], 'calibration': [830000, 48], 'test': [840000, 60], 'ood': [850000, 60]}
TRAIN_CONFIG = {'version': 'reviewer-confirmation-v4', 'seeds': SEEDS, 'splits': SPLITS, 'epochs': 80, 'patience': 12, 'batch_tasks': 8, 'learning_rate': 0.001, 'weight_decay': 0.0001, 'negative_loss_weight': 5.0, 'hidden': 32, 'residual_blocks': 2, 'convolutions_per_block': 2, 'dilations': [1, 2], 'kernel': 3, 'dropout': 0.1, 'edge_hidden': 64, 'feature_names': list(TRACK_NODE_SEQUENCE_FEATURE_NAMES), 'max_steps': 32, 'selection': 'most recent observed reports before cutoff, then right padding', 'quality': 'constant 1; covariance is declared nominal report noise, not truth residual', 'readout': 'last valid time step', 'training_threads': 2}
DECISION_GRID = [0.2, 0.35, 0.5, 0.65, 0.8, 0.9, 0.95]
RISK_CONFIG = {'aggregations': ['max', 'q90', 'mean'], 'quantiles': [0.5, 0.65, 0.8, 0.9, 0.95], 'gates': [None, 0.8, 0.9], 'allow_no_fallback': True, 'selection': 'minimum tune mean PWE5; ties prefer less fallback, then name', 'B0_gate': 'minimum calibrated confidence in native B0 decisions >= gate and mean >= learned decisions', 'calibration': 'first24 member/B0 probability calibration; last24 risk quantiles', 'risk': 'max(normalized binary entropy, calibrated-member variance/0.25, |p-pB0|)', 'B0_decision': 'native frozen physical logit >=0, independent of candidate gate'}

def digest(value):
    h = hashlib.sha256()
    for chunk in json.JSONEncoder(sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).iterencode(value):
        h.update(chunk.encode())
    return h.hexdigest()

def jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [jsonable(v) for v in value]
    return value

def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        json.dump(jsonable(value), f, ensure_ascii=False, allow_nan=False)

def prepare_features(task):
    result = dict(task)
    cutoff = float(task['meta']['decision_cutoff_s'])
    x = np.zeros((len(task['histories']), 32, 24), dtype=np.float32)
    mask = np.zeros(x.shape[:2], dtype=bool)
    for i, history in enumerate(task['histories']):
        eligible = np.flatnonzero(np.asarray(history['t']) <= cutoff)[-32:]
        previous = None
        for j, k in enumerate(eligible):
            sp, sv = (float(history['sigma_pos'][k]), float(history['sigma_vel'][k]))
            item = SimpleNamespace(state_enu=np.r_[history['p'][k], history['v'][k]], covariance=np.diag([sp * sp, sp * sp, (0.65 * sp) ** 2, sv * sv, sv * sv, sv * sv]), corrected_time_s=float(history['t'][k]), score=1.0, rcs_dbsm=float(history['rcs'][k]))
            x[i, j] = _feature_row(item, previous, cutoff_s=cutoff)
            mask[i, j] = True
            previous = item
    if len(mask) and (not np.all(mask.any(1))):
        raise ValueError('Empty pre-cutoff node')
    result['x'], result['mask'] = (x, mask)
    result['meta'] = {**task['meta'], 'feature_version': 'exact-sequence-v2-row-nominal-covariance-adapter-v4', 'model_sample_count': int(mask.sum())}
    return result

def prefix_task(task, fraction):
    cutoff = float(task['meta']['decision_cutoff_s']) * fraction
    histories, original = ([], [])
    for i, history in enumerate(task['histories']):
        keep = np.asarray(history['t']) <= cutoff
        if int(keep.sum()) >= 3:
            histories.append({k: np.asarray(v)[keep].copy() for k, v in history.items()})
            original.append(i)
    sensor = np.asarray(task['sensor'])[original]
    identities = [task['identities'][i] for i in original]
    graph = build_candidate_graph(histories, sensor, cutoff)
    y = np.array([identities[i] == identities[j] for i, j in graph['edges']], dtype=np.int64)
    pos = sum((identities[i] == identities[j] for i in range(len(identities)) for j in range(i + 1, len(identities))))
    meta = {**task['meta'], 'decision_cutoff_s': cutoff, 'prefix_fraction': fraction, 'node_count': len(histories), 'candidate_count': len(y), 'candidate_positive_count': int(y.sum()), 'candidate_negative_count': int(len(y) - y.sum()), 'universe_positive_pairs': pos, 'candidate_recall': float(y.sum() / pos) if pos else None, 'candidate_audit': graph['candidate_audit']}
    result = {'histories': histories, 'sensor': sensor, 'identities': identities, 'y': y, 'meta': meta, 'original_node_indices': original, **graph}
    return prepare_features(result)

def components(n, edges):
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for a, b in edges:
        parent[find(int(a))] = find(int(b))
    return np.array([find(i) for i in range(n)])

def partition_counts(task, selected):
    ids = np.asarray(task['identities'])
    i, j = np.triu_indices(len(ids), 1)
    truth = ids[i] == ids[j]
    labels = components(len(ids), np.asarray(task['edges'])[selected])
    pred = labels[i] == labels[j]
    return (int(np.sum(pred & ~truth)), int(np.sum(~pred & truth)), int(truth.sum()), int((~truth).sum()))

def pwe(task, selected, cost=5):
    fp, fn, pos, neg = partition_counts(task, selected)
    return (cost * fp + fn) / max(cost * neg + pos, 1)

class ResidualBlock(nn.Module):

    def __init__(self, dilation, two_sided=False):
        super().__init__()
        self.pad = (dilation, dilation) if two_sided else (2 * dilation, 0)
        self.conv1 = nn.Conv1d(32, 32, 3, dilation=dilation)
        self.conv2 = nn.Conv1d(32, 32, 3, dilation=dilation)
        self.dropout = nn.Dropout(0.1)

    def forward(self, z, mask):
        u = self.dropout(F.gelu(self.conv1(F.pad(z, self.pad))))
        u = self.dropout(self.conv2(F.pad(u, self.pad)))
        return F.gelu(z + u) * mask.unsqueeze(1)

class PairNetwork(nn.Module):

    def __init__(self, variant='full'):
        super().__init__()
        self.variant = variant
        self.proj = nn.Linear(24, 32)
        self.blocks = nn.ModuleList([ResidualBlock(d, variant == 'two_sided_history') for d in (1, 2)])
        self.head = nn.Sequential(nn.Linear(135, 64), nn.GELU(), nn.Linear(64, 1))

    def encode_sequence(self, x, mask):
        z = (self.proj(x) * mask.unsqueeze(-1)).transpose(1, 2)
        for block in self.blocks:
            z = block(z, mask)
        return z.transpose(1, 2)

    def forward(self, x, mask, edges, physics, physical_logits, sensor=None):
        sequence = self.encode_sequence(x, mask)
        h = sequence[torch.arange(len(x)), mask.sum(1).clamp_min(1).long() - 1]
        a, b = (h[edges[:, 0]], h[edges[:, 1]])
        diag = torch.cat([physics, physical_logits[:, None]], 1)
        if self.variant == 'no_diagnostics':
            diag = diag * 0

        def directed(u, v):
            return self.head(torch.cat([u, v, u - v, u * v, diag], 1)).squeeze(-1)
        z = directed(a, b)
        return z if self.variant == 'asymmetric' else 0.5 * (z + directed(b, a))

def make_model(variant):
    if variant in ('GNN-neural', 'HTG-TA-inspired'):
        return GraphAssociationV3(hetero=variant == 'HTG-TA-inspired', input_size=24)
    return PairNetwork(variant)

def scaler_from_train(tasks):
    x = np.concatenate([t['x'][t['mask']] for t in tasks])
    p = np.concatenate([np.column_stack([t['physics'], t['physical_logits']]) for t in tasks])
    return {'x_mean': x.mean(0), 'x_std': np.maximum(x.std(0), 0.001), 'p_mean': p.mean(0), 'p_std': np.maximum(p.std(0), 0.001)}

def tensor_task(task, scaler):
    x = (task['x'] - scaler['x_mean']) / scaler['x_std']
    x[~task['mask']] = 0
    p = (np.column_stack([task['physics'], task['physical_logits']]) - scaler['p_mean']) / scaler['p_std']
    return {'x': torch.tensor(x, dtype=torch.float32), 'mask': torch.tensor(task['mask']), 'edges': torch.tensor(task['edges'], dtype=torch.long), 'physics': torch.tensor(p[:, :6], dtype=torch.float32), 'physical_logits': torch.tensor(p[:, 6], dtype=torch.float32), 'sensor': torch.tensor(task['sensor'], dtype=torch.long), 'y': torch.tensor(task['y'], dtype=torch.float32)}

def collate(tasks):
    offset, edges = (0, [])
    for t in tasks:
        edges.append(t['edges'] + offset)
        offset += len(t['x'])
    return {k: torch.cat(edges) if k == 'edges' else torch.cat([t[k] for t in tasks]) for k in tasks[0]}

def forward(model, t):
    return model(t['x'], t['mask'], t['edges'], t['physics'], t['physical_logits'], sensor=t['sensor'])

def train(variant, seed, datasets, scaler, out, signature):
    path = out / f'checkpoint_{variant}_{seed}.pt'
    if path.exists():
        ckpt = torch.load(path, weights_only=False)
        if ckpt['training_signature'] != signature:
            raise RuntimeError('Training provenance changed')
        model = make_model(variant)
        model.load_state_dict(ckpt['state'])
        print(f'loaded {variant} seed={seed}', flush=True)
        return (model.eval(), ckpt['history'])
    torch.manual_seed(seed)
    model = make_model(variant)
    opt = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.0001)
    prepared = {s: [tensor_task(t, scaler) for t in datasets[s]] for s in ('train', 'tune')}
    rng = np.random.default_rng(seed)
    best, history, state, stale = (math.inf, [], None, 0)
    start = time.perf_counter()
    for epoch in range(80):
        model.train()
        order = rng.permutation(len(prepared['train']))
        losses = []
        for index in range(0, len(order), 8):
            t = collate([prepared['train'][int(i)] for i in order[index:index + 8]])
            if not len(t['y']):
                continue
            opt.zero_grad()
            loss = F.binary_cross_entropy_with_logits(forward(model, t), t['y'], reduction='none')
            loss = (loss * torch.where(t['y'] > 0, 1.0, 5.0)).mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            losses.append(float(loss.detach()))
        model.eval()
        tl = []
        with torch.no_grad():
            for t in prepared['tune']:
                if not len(t['y']):
                    continue
                loss = F.binary_cross_entropy_with_logits(forward(model, t), t['y'], reduction='none')
                tl.append(float((loss * torch.where(t['y'] > 0, 1.0, 5.0)).mean()))
        score = float(np.mean(tl))
        history.append({'epoch': epoch + 1, 'train_loss': float(np.mean(losses)), 'tune_loss': score})
        if score < best - 1e-05:
            best, state, stale = (score, copy.deepcopy(model.state_dict()), 0)
        else:
            stale += 1
        if (epoch + 1) % 10 == 0:
            print(f'progress {variant} seed={seed} epoch={epoch + 1} tune={score:.5f}', flush=True)
        if stale >= 12:
            break
    model.load_state_dict(state)
    torch.save({'state': state, 'training_signature': signature, 'history': history, 'scaler': scaler, 'variant': variant, 'seed': seed, 'training_config': TRAIN_CONFIG}, path)
    print(f'trained {variant} seed={seed} epochs={len(history)} best={best:.5f} seconds={time.perf_counter() - start:.1f}', flush=True)
    return (model.eval(), history)

def infer(models, task, scaler):
    if len(task['edges']) == 0:
        return np.zeros((len(models), 0), dtype=np.float64)
    t = tensor_task(task, scaler)
    with torch.no_grad():
        return np.stack([expit(forward(m, t).numpy()).astype(np.float64) for m in models])

def fit_calibration(tasks, probabilities):
    y = np.concatenate([t['y'] for t in tasks]).astype(np.float64)
    z = logit(np.clip(np.concatenate(probabilities).astype(np.float64), 1e-07, 1 - 1e-07))

    def objective(a):
        q = z / np.exp(a[0]) + a[1]
        return float(np.mean(np.logaddexp(0, q) - y * q))

    def gradient(a):
        q = z / np.exp(a[0])
        e = expit(q + a[1]) - y
        return np.array([np.mean(-q * e), np.mean(e)])
    result = minimize(objective, [0.0, 0.0], jac=gradient, method='L-BFGS-B', bounds=[(-2.3, 2.3), (-6, 6)])
    if not result.success:
        raise RuntimeError(f'Calibration failed: {result.message}')
    return {'temperature': float(np.exp(result.x[0])), 'bias': float(result.x[1]), 'objective': float(result.fun), 'success': bool(result.success)}

def calibrate(p, fit):
    return expit(logit(np.clip(np.asarray(p, dtype=np.float64), 1e-07, 1 - 1e-07)) / fit['temperature'] + fit['bias'])

def calibrate_members(members, fits):
    return np.stack([calibrate(p, fit) for p, fit in zip(members, fits)])

def tune_decision(tasks, probabilities):
    rows = [{'threshold': th, 'pwe5_mean': float(np.mean([pwe(t, p >= th) for t, p in zip(tasks, probabilities)]))} for th in DECISION_GRID]
    winner = min(rows, key=lambda row: (row['pwe5_mean'], -row['threshold']))
    return (winner['threshold'], rows)

def risk_groups(task):
    labels = components(len(task['histories']), task['edges'])
    return [np.flatnonzero(labels[task['edges'][:, 0]] == c) for c in np.unique(labels) if np.any(labels[task['edges'][:, 0]] == c)]

def risk_values(members, p, b0p):
    q = np.clip(np.asarray(p, dtype=np.float64), 1e-09, 1 - 1e-09)
    entropy = -(q * np.log(q) + (1 - q) * np.log1p(-q)) / np.log(2)
    variance = members.var(0) / 0.25
    disagreement = abs(p - b0p)
    return (np.maximum.reduce([entropy, variance, disagreement]), {'entropy': entropy, 'variance': variance, 'disagreement': disagreement})

def aggregate_risk(values, aggregation):
    if aggregation == 'max':
        return float(values.max())
    if aggregation == 'q90':
        return float(np.quantile(values, 0.9))
    if aggregation == 'mean':
        return float(values.mean())
    raise ValueError(aggregation)

def route(task, p, members, decision, policy, b0p, audit_truth=False):
    raw = np.asarray(p >= decision)
    selected = raw.copy()
    b0selected = np.asarray(task['physical_logits']) >= 0
    risk, terms = risk_values(members, p, b0p)
    details, fallback = ([], np.zeros(len(p), dtype=bool))
    for idx in risk_groups(task):
        r = aggregate_risk(risk[idx], policy.get('aggregation', 'max'))
        b0confidence = np.where(b0selected[idx], b0p[idx], 1 - b0p[idx])
        learnedconfidence = np.where(raw[idx], p[idx], 1 - p[idx])
        gate = policy.get('gate')
        evidence = gate is None or (float(b0confidence.min()) >= gate and float(b0confidence.mean()) >= float(learnedconfidence.mean()))
        rejected = policy['mode'] != 'none' and r > policy['threshold'] and evidence
        if rejected:
            selected[idx] = b0selected[idx]
            fallback[idx] = True
        info = {'edges': idx.tolist(), 'size': len(idx), 'risk': r, 'fallback': bool(rejected), 'B0_min_confidence': float(b0confidence.min()), 'B0_mean_confidence': float(b0confidence.mean()), 'learned_mean_confidence': float(learnedconfidence.mean()), 'B0_evidence_pass': bool(evidence)}
        if audit_truth and rejected:
            counterfactual = raw.copy()
            counterfactual[idx] = b0selected[idx]
            delta = pwe(task, counterfactual) - pwe(task, raw)
            info['isolated_fallback_pwe5_delta'] = delta
            info['outcome'] = 'helps' if delta < -1e-12 else 'harms' if delta > 1e-12 else 'unchanged'
        details.append(info)
    return (selected, {'policy': policy, 'components': len(details), 'fallback_components': sum((d['fallback'] for d in details)), 'fallback_edges': int(fallback.sum()), 'takeover_edges': int((~fallback).sum()), 'fallback_mask': fallback.astype(int).tolist(), 'component_details': details, 'edge_risk': risk.tolist(), 'risk_terms': {k: v.tolist() for k, v in terms.items()}})

def develop_risk_policy(tune_tasks, tune_members, risk_tasks, risk_members, decision, b0fit):
    none = {'mode': 'none', 'aggregation': 'max', 'threshold': 1.0, 'gate': None, 'name': 'none'}
    policies = [none]
    for aggregation in RISK_CONFIG['aggregations']:
        values = []
        for task, members in zip(risk_tasks, risk_members):
            r, _ = risk_values(members, members.mean(0), calibrate(expit(task['physical_logits']), b0fit))
            values.extend((aggregate_risk(r[g], aggregation) for g in risk_groups(task)))
        for quantile in RISK_CONFIG['quantiles']:
            threshold = float(np.quantile(values, quantile))
            for gate in RISK_CONFIG['gates']:
                policies.append({'mode': 'fallback', 'aggregation': aggregation, 'threshold': threshold, 'quantile': quantile, 'gate': gate, 'name': f'{aggregation}-q{quantile}-gate{gate}'})
    rows = []
    for policy in policies:
        losses, edges = ([], 0)
        for task, members in zip(tune_tasks, tune_members):
            selected, rr = route(task, members.mean(0), members, decision, policy, calibrate(expit(task['physical_logits']), b0fit))
            losses.append(pwe(task, selected))
            edges += rr['fallback_edges']
        rows.append({'policy': policy, 'pwe5_mean': float(np.mean(losses)), 'fallback_edges': edges, 'per_task_pwe5': losses})
    winner = min(rows, key=lambda row: (row['pwe5_mean'], row['fallback_edges'], row['policy']['name']))
    original = next((p for p in policies if p.get('quantile') == 0.8 and p['aggregation'] == 'max' and (p['gate'] is None)))
    return (winner['policy'], original, rows)

def metrics(task, p, selected):
    p = np.asarray(p, dtype=np.float64)
    selected = np.asarray(selected, dtype=bool)
    y = task['y'].astype(bool)
    tp, fp, fn, tn = [int(x.sum()) for x in (selected & y, selected & ~y, ~selected & y, ~selected & ~y)]
    pfp, pfn, pos, neg = partition_counts(task, selected)
    ptp = pos - pfn
    pp = np.clip(p, 1e-09, 1 - 1e-09)
    ece = 0.0
    for k in range(10):
        ix = (p >= k / 10) & (p < (k + 1) / 10 if k < 9 else p <= 1)
        if ix.any():
            ece += ix.mean() * abs(p[ix].mean() - y[ix].mean())
    labels = components(len(task['identities']), task['edges'][selected])
    ids = np.asarray(task['identities'])
    bprecision, brecall = ([], [])
    for i in range(len(ids)):
        both = int(((labels == labels[i]) & (ids == ids[i])).sum())
        bprecision.append(both / int((labels == labels[i]).sum()))
        brecall.append(both / int((ids == ids[i]).sum()))
    bp = float(np.mean(bprecision)) if bprecision else None
    br = float(np.mean(brecall)) if brecall else None
    ap = None
    if y.any():
        order = np.argsort(-p, kind='stable')
        yy, pp_order = (y[order], p[order])
        ends = np.r_[np.flatnonzero(np.diff(pp_order)), len(p) - 1]
        cumulative = np.cumsum(yy)[ends]
        ap = float(np.sum(np.diff(np.r_[0, cumulative]) / y.sum() * cumulative / (ends + 1)))
    return {'tp': tp, 'fp': fp, 'fn': fn, 'tn': tn, 'partition_tp': ptp, 'partition_fp': pfp, 'partition_fn': pfn, 'positive_pairs': pos, 'negative_pairs': neg, 'pwe5': (5 * pfp + pfn) / max(5 * neg + pos, 1), 'pwe4': (4 * pfp + pfn) / max(4 * neg + pos, 1), 'partition_f1': 2 * ptp / max(2 * ptp + pfp + pfn, 1), 'partition_precision': ptp / (ptp + pfp) if ptp + pfp else None, 'partition_recall': ptp / pos if pos else None, 'bcubed_precision': bp, 'bcubed_recall': br, 'bcubed_f1': 2 * bp * br / (bp + br) if bp is not None and bp + br else None, 'partition_false_merge_rate': pfp / neg if neg else None, 'partition_miss_rate': pfn / pos if pos else None, 'edge_precision': tp / (tp + fp) if tp + fp else None, 'edge_recall': tp / (tp + fn) if tp + fn else None, 'edge_ap': ap, 'edge_f1': 2 * tp / max(2 * tp + fp + fn, 1), 'edge_brier': float(np.mean((p - y) ** 2)) if len(p) else None, 'edge_nll': float(-np.mean(y * np.log(pp) + (1 - y) * np.log1p(-pp))) if len(p) else None, 'edge_ece': float(ece) if len(p) else None}

def method_record(task, p, members, decision, policy, b0p, native_p=None):
    raw = p >= decision
    selected, rr = route(task, p, members, decision, policy, b0p, audit_truth=True)
    return {'probabilities': p.tolist(), 'member_probabilities': members.tolist(), 'decision_threshold': decision, 'selected': selected.astype(int).tolist(), 'raw_selected': raw.astype(int).tolist(), 'route': rr, 'raw': metrics(task, p, raw), 'final': metrics(task, p, selected), 'native_probability_metrics': metrics(task, native_p, raw) if native_p is not None else None}

def oracle(task):
    selected = task['y'].astype(bool)
    return {'candidate_positive_pairs': int(selected.sum()), 'candidate_edges': len(selected), 'all_positive_pairs': task['meta']['universe_positive_pairs'], 'truth_candidate_connectivity': metrics(task, selected.astype(float), selected), 'all_reject': metrics(task, np.zeros(len(selected)), np.zeros(len(selected), dtype=bool))}
