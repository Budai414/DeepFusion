from __future__ import annotations
from dataclasses import dataclass
import math
import re
from typing import Dict, Mapping, Sequence, Tuple
import numpy as np
from real_fusion.models import NormalizedDetection
from research.df_paag.contracts_v2 import IdentityDataContractError, canonical_sha256
TRACK_NODE_SEQUENCE_SCHEMA_VERSION = 'deepfusion.track-node-sequence.v2'
TRACK_NODE_SEQUENCE_FEATURE_VERSION = 'df-paag.se2-invariant-causal-node.v1'
TRACK_NODE_SEQUENCE_SELECTION_POLICY = 'event-time-causal-most-recent-k-v1'
TRACK_NODE_SEQUENCE_FEATURE_NAMES: Tuple[str, ...] = ('log1p_age_to_cutoff_s', 'log1p_delta_t_s', 'log1p_horizontal_step_m', 'signed_log1p_vertical_step_m', 'step_velocity_alignment_cos', 'step_velocity_alignment_sin', 'log1p_horizontal_speed_mps', 'signed_log1p_vertical_speed_mps', 'log1p_horizontal_acceleration_mps2', 'signed_log1p_vertical_acceleration_mps2', 'turn_cos', 'turn_sin', 'log1p_position_cov_horizontal_trace', 'log1p_position_cov_horizontal_det', 'log1p_position_cov_horizontal_condition', 'log1p_position_cov_vertical', 'log1p_velocity_cov_horizontal_trace', 'log1p_velocity_cov_horizontal_det', 'log1p_velocity_cov_horizontal_condition', 'log1p_velocity_cov_vertical', 'quality_score', 'rcs_scaled', 'rcs_present_mask', 'low_speed_mask')
_LOW_SPEED_MPS = 0.001
_SOURCE_ROUND_DECIMALS = 12
_FEATURE_ROUND_DECIMALS = 9
_SHA256 = re.compile('^[0-9a-f]{64}$')

def _finite(value: object, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float, np.integer, np.floating)):
        raise IdentityDataContractError('sequence_number_invalid', f'{label}必须是有限数值')
    result = float(value)
    if not math.isfinite(result):
        raise IdentityDataContractError('sequence_number_invalid', f'{label}必须是有限数值')
    return result

def _positive_integer(value: object, label: str) -> int:
    if type(value) is not int or value < 1:
        raise IdentityDataContractError('sequence_integer_invalid', f'{label}必须是正整数')
    return value

def _safe_join_text(value: object, label: str) -> str:
    if type(value) is not str or not value or value != value.strip():
        raise IdentityDataContractError('sequence_identifier_invalid', f'{label}必须是非空字符串')
    if any((ord(character) < 32 for character in value)):
        raise IdentityDataContractError('sequence_identifier_invalid', f'{label}含控制字符')
    return value

def _time_us(value: object) -> int:
    return int(round(_finite(value, 'corrected_time_s') * 1000000.0))

def _signed_log1p(value: float) -> float:
    return math.copysign(math.log1p(abs(float(value))), float(value))

def _round_float(value: float, *, decimals: int=_SOURCE_ROUND_DECIMALS) -> float:
    result = float(np.round(float(value), decimals=decimals))
    return 0.0 if result == 0.0 else result

def _optional_rcs(value: object) -> tuple[float, bool]:
    if isinstance(value, bool) or not isinstance(value, (int, float, np.integer, np.floating)):
        raise IdentityDataContractError('sequence_number_invalid', 'rcs_dbsm必须是数值或NaN')
    result = float(value)
    if math.isnan(result):
        return (0.0, False)
    if not math.isfinite(result):
        raise IdentityDataContractError('sequence_number_invalid', 'rcs_dbsm不能是无穷值')
    return (result, True)

def _item_track_key(item: NormalizedDetection) -> str:
    value = item.local_track_key if item.local_track_key is not None else item.source_track_id
    return _safe_join_text(value, 'item.local_track_key')

def _array(value: object, shape: tuple[int, ...], label: str) -> np.ndarray:
    try:
        result = np.asarray(value, dtype=float)
    except (TypeError, ValueError) as error:
        raise IdentityDataContractError('sequence_array_invalid', f'{label}不能转为数值数组') from error
    if result.shape != shape or not np.all(np.isfinite(result)):
        raise IdentityDataContractError('sequence_array_invalid', f'{label}必须是有限的{shape}数组')
    return result

def _validate_covariance(value: object) -> np.ndarray:
    covariance = _array(value, (6, 6), 'covariance')
    if not np.allclose(covariance, covariance.T, atol=1e-08, rtol=1e-08):
        raise IdentityDataContractError('sequence_covariance_invalid', 'covariance必须对称')
    covariance = 0.5 * (covariance + covariance.T)
    eigenvalues = np.linalg.eigvalsh(covariance)
    if float(eigenvalues.min()) < -1e-08:
        raise IdentityDataContractError('sequence_covariance_invalid', 'covariance不能有显著负特征值')
    return covariance

def _horizontal_covariance_features(block: np.ndarray) -> tuple[float, float, float]:
    symmetric = 0.5 * (block + block.T)
    eigenvalues = np.clip(np.linalg.eigvalsh(symmetric), 0.0, None)
    trace = float(eigenvalues.sum())
    determinant = float(eigenvalues.prod())
    denominator = max(float(eigenvalues.min()), 1e-12)
    condition = float(eigenvalues.max()) / denominator
    return (math.log1p(trace), math.log1p(determinant), math.log1p(condition))

def _cos_sin(left: np.ndarray, right: np.ndarray) -> tuple[float, float, bool]:
    left_norm = float(np.linalg.norm(left))
    right_norm = float(np.linalg.norm(right))
    low_speed = left_norm < _LOW_SPEED_MPS or right_norm < _LOW_SPEED_MPS
    if low_speed:
        return (0.0, 0.0, True)
    scale = left_norm * right_norm
    cosine = float(np.clip(np.dot(left, right) / scale, -1.0, 1.0))
    sine = float(np.clip((left[0] * right[1] - left[1] * right[0]) / scale, -1.0, 1.0))
    return (cosine, sine, False)

def _numeric_history_row(item: NormalizedDetection) -> Dict[str, object]:
    state = _array(item.state_enu, (6,), 'state_enu')
    covariance = _validate_covariance(item.covariance)
    rcs, rcs_present = _optional_rcs(item.rcs_dbsm)
    return {'corrected_time_us': _time_us(item.corrected_time_s), 'arrival_time_us': _time_us(item.arrival_time_s), 'state_enu': [_round_float(value) for value in state], 'covariance': [[_round_float(value) for value in row] for row in covariance], 'score': _round_float(_finite(item.score, 'score')), 'rcs_dbsm': _round_float(rcs) if rcs_present else None}

def _numeric_sort_key(item: NormalizedDetection) -> tuple[int, str]:
    record = _numeric_history_row(item)
    model_record = {key: value for key, value in record.items() if key != 'arrival_time_us'}
    return (int(record['corrected_time_us']), canonical_sha256(model_record))

def _feature_row(item: NormalizedDetection, previous: NormalizedDetection | None, *, cutoff_s: float) -> tuple[float, ...]:
    state = _array(item.state_enu, (6,), 'state_enu')
    covariance = _validate_covariance(item.covariance)
    time_s = _time_us(item.corrected_time_s) / 1000000.0
    normalized_cutoff_s = _time_us(cutoff_s) / 1000000.0
    age = max(0.0, normalized_cutoff_s - time_s)
    horizontal_velocity = state[3:5]
    horizontal_speed = float(np.linalg.norm(horizontal_velocity))
    delta_t = 0.0
    horizontal_step = 0.0
    vertical_step = 0.0
    step_cos = 0.0
    step_sin = 0.0
    horizontal_acceleration = 0.0
    vertical_acceleration = 0.0
    turn_cos = 0.0
    turn_sin = 0.0
    low_speed = horizontal_speed < _LOW_SPEED_MPS
    if previous is not None:
        previous_state = _array(previous.state_enu, (6,), 'previous.state_enu')
        previous_time = _time_us(previous.corrected_time_s) / 1000000.0
        delta_t = max(0.0, time_s - previous_time)
        step = state[:3] - previous_state[:3]
        horizontal_step_vector = step[:2]
        horizontal_step = float(np.linalg.norm(horizontal_step_vector))
        vertical_step = float(step[2])
        step_cos, step_sin, step_low = _cos_sin(horizontal_velocity, horizontal_step_vector)
        previous_velocity = previous_state[3:5]
        turn_cos, turn_sin, turn_low = _cos_sin(previous_velocity, horizontal_velocity)
        low_speed = low_speed or step_low or turn_low
        if delta_t > 1e-09:
            horizontal_acceleration = float(np.linalg.norm(horizontal_velocity - previous_velocity) / delta_t)
            vertical_acceleration = float((state[5] - previous_state[5]) / delta_t)
    pos_trace, pos_det, pos_condition = _horizontal_covariance_features(covariance[:2, :2])
    vel_trace, vel_det, vel_condition = _horizontal_covariance_features(covariance[3:5, 3:5])
    rcs, rcs_present = _optional_rcs(item.rcs_dbsm)
    values = (math.log1p(age), math.log1p(delta_t), math.log1p(horizontal_step), _signed_log1p(vertical_step), step_cos, step_sin, math.log1p(horizontal_speed), _signed_log1p(float(state[5])), math.log1p(horizontal_acceleration), _signed_log1p(vertical_acceleration), turn_cos, turn_sin, pos_trace, pos_det, pos_condition, math.log1p(max(0.0, float(covariance[2, 2]))), vel_trace, vel_det, vel_condition, math.log1p(max(0.0, float(covariance[5, 5]))), float(np.clip(_finite(item.score, 'score'), 0.0, 1.0)), float(np.clip(rcs / 50.0, -2.0, 2.0)) if rcs_present else 0.0, 1.0 if rcs_present else 0.0, 1.0 if low_speed else 0.0)
    if len(values) != len(TRACK_NODE_SEQUENCE_FEATURE_NAMES) or not np.all(np.isfinite(values)):
        raise IdentityDataContractError('sequence_feature_invalid', '序列特征包含非有限数值')
    return tuple((_round_float(value, decimals=_FEATURE_ROUND_DECIMALS) for value in values))

@dataclass(frozen=True)
class TrackNodeSequenceV2:
    task_id: str
    local_track_key: str
    decision_cutoff_us: int
    source_report_count: int
    selected_report_count: int
    truncated_report_count: int
    event_time_us: Tuple[int, ...]
    values: Tuple[Tuple[float, ...], ...]
    source_history_sha256: str

    def __post_init__(self) -> None:
        _safe_join_text(self.task_id, 'task_id')
        _safe_join_text(self.local_track_key, 'local_track_key')
        if type(self.decision_cutoff_us) is not int:
            raise IdentityDataContractError('sequence_time_invalid', 'decision_cutoff_us必须是整数')
        if type(self.source_report_count) is not int or type(self.selected_report_count) is not int:
            raise IdentityDataContractError('sequence_count_invalid', '序列报告数必须是整数')
        if type(self.truncated_report_count) is not int:
            raise IdentityDataContractError('sequence_count_invalid', 'truncated报告数必须是整数')
        if self.source_report_count < 1 or self.selected_report_count < 1:
            raise IdentityDataContractError('sequence_count_invalid', '序列报告数必须为正')
        if self.truncated_report_count < 0:
            raise IdentityDataContractError('sequence_count_invalid', 'truncated报告数不能为负')
        if self.selected_report_count > self.source_report_count:
            raise IdentityDataContractError('sequence_count_invalid', 'selected不能超过source')
        if self.truncated_report_count != self.source_report_count - self.selected_report_count:
            raise IdentityDataContractError('sequence_count_invalid', 'truncated计数不一致')
        if type(self.event_time_us) is not tuple or type(self.values) is not tuple:
            raise IdentityDataContractError('sequence_container_invalid', '事件时刻和特征必须是不可变tuple')
        if any((type(value) is not int for value in self.event_time_us)):
            raise IdentityDataContractError('sequence_time_invalid', 'event_time_us必须是整数tuple')
        if any((type(row) is not tuple for row in self.values)):
            raise IdentityDataContractError('sequence_container_invalid', '每个特征行必须是不可变tuple')
        if len(self.event_time_us) != self.selected_report_count or len(self.values) != self.selected_report_count:
            raise IdentityDataContractError('sequence_count_invalid', '序列长度与计数不一致')
        if tuple(sorted(self.event_time_us)) != self.event_time_us:
            raise IdentityDataContractError('sequence_time_invalid', 'event_time必须非降序')
        if any((value > self.decision_cutoff_us for value in self.event_time_us)):
            raise IdentityDataContractError('sequence_cutoff_violation', '序列含decision cutoff之后的报告')
        for row in self.values:
            if any((isinstance(value, bool) or not isinstance(value, (int, float, np.integer, np.floating)) for value in row)):
                raise IdentityDataContractError('sequence_feature_invalid', '序列特征必须是数值')
        matrix = np.asarray(self.values, dtype=float)
        if matrix.shape != (self.selected_report_count, len(TRACK_NODE_SEQUENCE_FEATURE_NAMES)):
            raise IdentityDataContractError('sequence_feature_invalid', '序列特征维度不一致')
        if not np.all(np.isfinite(matrix)):
            raise IdentityDataContractError('sequence_feature_invalid', '序列特征必须有限')
        if type(self.source_history_sha256) is not str or not _SHA256.fullmatch(self.source_history_sha256):
            raise IdentityDataContractError('sequence_hash_invalid', 'source_history_sha256无效')

    @property
    def model_tensor_sha256(self) -> str:
        relative_time_us = tuple((value - self.decision_cutoff_us for value in self.event_time_us))
        return canonical_sha256({'feature_version': TRACK_NODE_SEQUENCE_FEATURE_VERSION, 'feature_names': list(TRACK_NODE_SEQUENCE_FEATURE_NAMES), 'relative_time_us': list(relative_time_us), 'values': [list(row) for row in self.values]})

    def model_tensor(self) -> np.ndarray:
        return np.asarray(self.values, dtype=float).copy()

    def to_record(self) -> Dict[str, object]:
        body: Dict[str, object] = {'schema_version': TRACK_NODE_SEQUENCE_SCHEMA_VERSION, 'feature_version': TRACK_NODE_SEQUENCE_FEATURE_VERSION, 'selection_policy': TRACK_NODE_SEQUENCE_SELECTION_POLICY, 'task_id': self.task_id, 'local_track_key': self.local_track_key, 'decision_cutoff_us': self.decision_cutoff_us, 'source_report_count': self.source_report_count, 'selected_report_count': self.selected_report_count, 'truncated_report_count': self.truncated_report_count, 'event_time_us': list(self.event_time_us), 'feature_names': list(TRACK_NODE_SEQUENCE_FEATURE_NAMES), 'values': [list(row) for row in self.values], 'source_history_sha256': self.source_history_sha256, 'model_tensor_sha256': self.model_tensor_sha256}
        body['record_sha256'] = canonical_sha256(body)
        return body

def build_track_node_sequence_v2(*, task_id: str, local_track_key: str, items: Sequence[NormalizedDetection], decision_cutoff_s: float, max_steps: int) -> TrackNodeSequenceV2:
    normalized_task_id = _safe_join_text(task_id, 'task_id')
    normalized_key = _safe_join_text(local_track_key, 'local_track_key')
    limit = _positive_integer(max_steps, 'max_steps')
    cutoff_s = _finite(decision_cutoff_s, 'decision_cutoff_s')
    cutoff_us = _time_us(cutoff_s)
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes)) or (not items):
        raise IdentityDataContractError('sequence_items_invalid', 'items必须是非空航迹序列')
    eligible = []
    for index, item in enumerate(items):
        if not isinstance(item, NormalizedDetection):
            raise IdentityDataContractError('sequence_item_type_invalid', f'items[{index}]必须是NormalizedDetection')
        event_time_s = _finite(item.corrected_time_s, 'corrected_time_s')
        if event_time_s > cutoff_s:
            continue
        item_key = _item_track_key(item)
        if item_key != normalized_key:
            raise IdentityDataContractError('sequence_track_mismatch', 'items含其他局部航迹')
        _numeric_history_row(item)
        eligible.append(item)
    if not eligible:
        raise IdentityDataContractError('sequence_empty_before_cutoff', 'cutoff前没有有效报告')
    ordered = sorted(eligible, key=_numeric_sort_key)
    previous_time_us: int | None = None
    previous_model_hash: str | None = None
    for item in ordered:
        time_us, model_hash = _numeric_sort_key(item)
        if time_us == previous_time_us and model_hash != previous_model_hash:
            raise IdentityDataContractError('sequence_event_time_collision', '同一局部航迹含量化后同事件时刻的不同报告')
        previous_time_us = time_us
        previous_model_hash = model_hash
    selected = ordered[-limit:]
    rows = tuple((_feature_row(item, selected[index - 1] if index > 0 else None, cutoff_s=cutoff_s) for index, item in enumerate(selected)))
    history_records = sorted((_numeric_history_row(item) for item in ordered), key=lambda record: (int(record['corrected_time_us']), canonical_sha256(record)))
    return TrackNodeSequenceV2(task_id=normalized_task_id, local_track_key=normalized_key, decision_cutoff_us=cutoff_us, source_report_count=len(ordered), selected_report_count=len(selected), truncated_report_count=len(ordered) - len(selected), event_time_us=tuple((_time_us(item.corrected_time_s) for item in selected)), values=rows, source_history_sha256=canonical_sha256(history_records))

def build_task_node_sequences_v2(*, task_id: str, histories: Mapping[str, Sequence[NormalizedDetection]], decision_cutoff_s: float, max_steps: int) -> Tuple[TrackNodeSequenceV2, ...]:
    if not isinstance(histories, Mapping) or not histories:
        raise IdentityDataContractError('sequence_histories_invalid', 'histories必须是非空映射')
    for key in histories:
        _safe_join_text(key, 'histories.local_track_key')
    return tuple((build_track_node_sequence_v2(task_id=task_id, local_track_key=key, items=histories[key], decision_cutoff_s=decision_cutoff_s, max_steps=max_steps) for key in sorted(histories)))
__all__ = ['TRACK_NODE_SEQUENCE_FEATURE_NAMES', 'TRACK_NODE_SEQUENCE_FEATURE_VERSION', 'TRACK_NODE_SEQUENCE_SCHEMA_VERSION', 'TRACK_NODE_SEQUENCE_SELECTION_POLICY', 'TrackNodeSequenceV2', 'build_task_node_sequences_v2', 'build_track_node_sequence_v2']
