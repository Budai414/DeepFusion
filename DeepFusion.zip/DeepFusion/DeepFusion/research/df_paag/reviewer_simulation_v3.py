from __future__ import annotations
import hashlib
import json
import math
from typing import Any, Mapping, Sequence
import numpy as np
PROTOCOL = {'schema': 'reviewer-enriched-simulation-v3', 'scope': 'source-track identity association; not raw-detection filtering', 'random_generator': 'numpy.random.default_rng(PCG64); one independent task per seed', 'target_count_inclusive': [3, 8], 'sensor_count': 3, 'duration_seconds': [18.0, 60.0], 'model_max_steps': 32, 'model_step_selection': 'evenly spaced observed indices; no interpolation; right zero padding', 'input_columns': ['time_minus_decision_cutoff_s', 'east_m', 'north_m', 'up_m', 'velocity_east_mps', 'velocity_north_mps', 'velocity_up_mps', 'log_nominal_position_sigma_m', 'log_nominal_velocity_sigma_mps', 'rcs_db'], 'base_sampling_interval_seconds': [0.42, 0.73, 1.09], 'sampling_interval_multiplier': [0.85, 1.25], 'sampling_jitter_fraction': 0.1, 'base_position_sigma_m': [3.5, 7.0, 12.0], 'base_velocity_sigma_mps': [0.65, 1.1, 1.8], 'position_vertical_noise_multiplier': 0.65, 'nominal_speed_mps': [8.0, 26.0], 'rcs_target_db': [-12.0, 3.0], 'rcs_sensor_bias_sigma_db': 1.3, 'rcs_observation_sigma_db': 1.8, 'target_lifecycle_start_fraction': [0.0, 0.15], 'target_lifecycle_end_trim_fraction': [0.0, 0.1], 'crossing_pair_probability': 0.65, 'close_parallel_pair_probability': 0.55, 'crossing_offset_m': [12.0, 40.0], 'parallel_separation_m': [20.0, 65.0], 'clutter_tracks_per_sensor_inclusive': [0, 2], 'clutter_lifetime_fraction': [0.25, 0.8], 'minimum_reports_per_retained_tracklet': 3, 'maximum_breaks_per_source_track': 2, 'break_gap_seconds': [0.6, 2.4], 'id': {'noise_multiplier': [0.65, 1.65], 'bias_sigma_m': [2.0, 6.0], 'velocity_bias_sigma_mps': [0.1, 0.45], 'point_dropout_probability': [0.03, 0.25], 'source_absence_probability': [0.03, 0.2], 'outlier_probability': [0.01, 0.08], 'outlier_sigma_multiplier': [2.0, 5.0], 'break_count_probabilities': [0.72, 0.22, 0.06], 'maneuver_amplitude_m': [10.0, 55.0], 'maneuver_angular_frequency_rad_s': [0.045, 0.16], 'acceleration_mps2': [-0.12, 0.12], 'motion_families': ['straight', 'smooth_turn', 'accelerating', 's_turn']}, 'ood': {'noise_multiplier': [1.5, 2.8], 'bias_sigma_m': [6.0, 16.0], 'velocity_bias_sigma_mps': [0.35, 1.1], 'point_dropout_probability': [0.18, 0.42], 'source_absence_probability': [0.12, 0.35], 'outlier_probability': [0.05, 0.14], 'outlier_sigma_multiplier': [3.0, 7.0], 'break_count_probabilities': [0.5, 0.34, 0.16], 'maneuver_amplitude_m': [30.0, 100.0], 'maneuver_angular_frequency_rad_s': [0.16, 0.3], 'acceleration_mps2': [-0.3, 0.3], 'motion_families': ['tight_turn', 'chirp_turn', 'accelerating_s_turn']}, 'outlier_distribution': 'Student t with df=3 added to Gaussian state noise', 'bias_drift': 'linear drift with final displacement Normal(0, 0.45*bias_sigma)', 'candidate_policy': {'eligible_pairs': 'all cross-sensor pairs and same-sensor strictly nonoverlapping pairs', 'maximum_disjoint_gap_seconds': 'min(8,0.30*decision_cutoff)', 'overlap_alignment': '8 equally spaced times in common observed interval; linear interpolation', 'disjoint_alignment': 'nearest endpoints propagated with observed velocity to gap midpoint', 'position_d2': 'mean(||delta_p||^2)/(3*(sigma_pi^2+sigma_pj^2+16+(0.8*gap)^2))', 'velocity_d2': 'mean(||delta_v||^2)/(3*(sigma_vi^2+sigma_vj^2+0.5+(0.35*gap)^2))', 'position_d2_gate': 49.0, 'velocity_d2_gate': 36.0, 'mutual_top_k': 4, 'neighbor_rank': 'ascending position_d2+0.6*velocity_d2, node index breaks ties', 'truth_used': False}, 'physics_columns': ['position_d2', 'velocity_d2', 'overlap_over_union_time', 'gap_over_duration', 'absolute_median_rcs_difference_over_4', 'minimum_sample_count_over_32_capped_1'], 'b0_logit': '3 - 0.5*position_d2 - 0.3*velocity_d2', 'b0_probability_threshold': 0.5, 'b0_role': 'fixed conventional residual reference; its threshold is not candidate generation', 'truth_scope': 'all pairs of retained tracklets; candidate recall counts all same-identity pairs', 'causality': 'every history and model sample has timestamp <= decision cutoff; no future state supplied', 'result_selection': 'none; all predeclared seeds retained including empty candidate graphs'}

def protocol_hash() -> str:
    payload = json.dumps(PROTOCOL, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()

def _trajectory(rng: np.random.Generator, cfg: Mapping[str, Any], center: np.ndarray, ood: bool) -> dict:
    heading = rng.uniform(-math.pi, math.pi)
    speed = rng.uniform(*PROTOCOL['nominal_speed_mps'])
    direction = np.array([math.cos(heading), math.sin(heading), 0.0])
    sideways = np.array([-direction[1], direction[0], 0.0])
    family = str(rng.choice(cfg['motion_families']))
    amplitude = rng.uniform(*cfg['maneuver_amplitude_m'])
    frequency = rng.uniform(*cfg['maneuver_angular_frequency_rad_s'])
    acceleration = direction * rng.uniform(*cfg['acceleration_mps2'])
    if family == 'straight':
        amplitude, acceleration = (0.0, np.zeros(3))
    elif family == 'smooth_turn':
        acceleration = np.zeros(3)
    elif family == 'accelerating':
        amplitude *= 0.25
    return {'p0': center + np.array([rng.normal(0, 150), rng.normal(0, 150), rng.normal(0, 20)]), 'v0': speed * direction + np.array([0.0, 0.0, rng.uniform(-0.35, 0.35)]), 'sideways': sideways, 'acceleration': acceleration, 'amplitude': amplitude, 'frequency': frequency, 'phase': rng.uniform(-math.pi, math.pi), 'vertical_amplitude': rng.uniform(1.0, 5.0), 'chirp': 0.0015 if family == 'chirp_turn' else 0.0, 'harmonic': 0.3 if 's_turn' in family else 0.0, 'family': family, 'rcs': rng.uniform(*PROTOCOL['rcs_target_db'])}

def _state(motion: Mapping[str, Any], t: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    t = np.asarray(t, dtype=np.float64)
    angle = motion['frequency'] * t + motion['chirp'] * t ** 2 + motion['phase']
    rate = motion['frequency'] + 2 * motion['chirp'] * t
    phase = motion['phase']
    curve = np.sin(angle) - math.sin(phase)
    slope = rate * np.cos(angle)
    curve += motion['harmonic'] * (np.sin(2 * angle) - math.sin(2 * phase))
    slope += 2 * motion['harmonic'] * rate * np.cos(2 * angle)
    p = motion['p0'] + t[:, None] * motion['v0'] + 0.5 * t[:, None] ** 2 * motion['acceleration']
    v = np.broadcast_to(motion['v0'], p.shape).copy() + t[:, None] * motion['acceleration']
    p += motion['amplitude'] * curve[:, None] * motion['sideways']
    v += motion['amplitude'] * slope[:, None] * motion['sideways']
    p[:, 2] += motion['vertical_amplitude'] * np.sin(0.07 * t)
    v[:, 2] += motion['vertical_amplitude'] * 0.07 * np.cos(0.07 * t)
    return (p, v)

def _sensor_parameters(rng: np.random.Generator, sensor: int, cfg: Mapping[str, Any]) -> dict:
    noise = rng.uniform(*cfg['noise_multiplier'])
    bias_sigma = rng.uniform(*cfg['bias_sigma_m'])
    return {'interval': PROTOCOL['base_sampling_interval_seconds'][sensor] * rng.uniform(*PROTOCOL['sampling_interval_multiplier']), 'sigma_pos': PROTOCOL['base_position_sigma_m'][sensor] * noise, 'sigma_vel': PROTOCOL['base_velocity_sigma_mps'][sensor] * noise, 'bias': rng.normal(0, bias_sigma, 3), 'drift': rng.normal(0, 0.45 * bias_sigma, 3), 'velocity_bias': rng.normal(0, rng.uniform(*cfg['velocity_bias_sigma_mps']), 3), 'rcs_bias': rng.normal(0, PROTOCOL['rcs_sensor_bias_sigma_db']), 'dropout': rng.uniform(*cfg['point_dropout_probability']), 'absence': rng.uniform(*cfg['source_absence_probability']), 'outlier': rng.uniform(*cfg['outlier_probability']), 'outlier_scale': rng.uniform(*cfg['outlier_sigma_multiplier'])}

def _observe(rng: np.random.Generator, motion: Mapping[str, Any], sensor_parameters: Mapping[str, Any], duration: float, cfg: Mapping[str, Any], clutter: bool) -> tuple[list[dict], dict]:
    interval = sensor_parameters['interval']
    if clutter:
        lifetime = duration * rng.uniform(*PROTOCOL['clutter_lifetime_fraction'])
        start = rng.uniform(0, duration - lifetime)
        stop = start + lifetime
    else:
        start = duration * rng.uniform(*PROTOCOL['target_lifecycle_start_fraction'])
        stop = duration * (1 - rng.uniform(*PROTOCOL['target_lifecycle_end_trim_fraction']))
    times = np.arange(start + rng.uniform(0, interval), stop, interval)
    times += rng.uniform(-0.1, 0.1, len(times)) * interval
    times = times[(times >= start) & (times <= stop) & (times <= duration)]
    before_dropout = len(times)
    times = times[rng.random(len(times)) >= sensor_parameters['dropout']]
    p, v = _state(motion, times)
    sigma_p, sigma_v = (sensor_parameters['sigma_pos'], sensor_parameters['sigma_vel'])
    vertical_scale = np.array([1.0, 1.0, PROTOCOL['position_vertical_noise_multiplier']])
    p += rng.normal(0, sigma_p, p.shape) * vertical_scale
    p += sensor_parameters['bias'] + times[:, None] / duration * sensor_parameters['drift']
    v += rng.normal(0, sigma_v, v.shape) + sensor_parameters['velocity_bias']
    outliers = rng.random(len(times)) < sensor_parameters['outlier']
    count = int(outliers.sum())
    if count:
        p[outliers] += rng.standard_t(3, (count, 3)) * sigma_p * sensor_parameters['outlier_scale']
        v[outliers] += rng.standard_t(3, (count, 3)) * sigma_v * sensor_parameters['outlier_scale'] * 0.5
    rcs = motion['rcs'] + sensor_parameters['rcs_bias'] + rng.normal(0, PROTOCOL['rcs_observation_sigma_db'], len(times))
    break_count = 0 if clutter or len(times) < 12 else int(rng.choice(3, p=cfg['break_count_probabilities']))
    boundaries = []
    for index in range(break_count):
        fraction = (index + 1 + rng.uniform(-0.15, 0.15)) / (break_count + 1)
        mid = start + fraction * (stop - start)
        gap = rng.uniform(*PROTOCOL['break_gap_seconds'])
        boundaries.append((mid - gap / 2, mid + gap / 2))
    intervals = []
    cursor = start
    for left, right in boundaries:
        intervals.append((cursor, left))
        cursor = right
    intervals.append((cursor, stop))
    records = []
    discarded = 0
    for lower, upper in intervals:
        use = (times >= lower) & (times <= upper)
        if int(use.sum()) < PROTOCOL['minimum_reports_per_retained_tracklet']:
            discarded += int(use.sum())
            continue
        records.append({'t': times[use].copy(), 'p': p[use].copy(), 'v': v[use].copy(), 'sigma_pos': np.full(int(use.sum()), sigma_p), 'sigma_vel': np.full(int(use.sum()), sigma_v), 'rcs': rcs[use].copy()})
    return (records, {'before_dropout': before_dropout, 'after_dropout': len(times), 'outlier_reports_before_fragmentation': count, 'requested_breaks': break_count, 'retained_fragments': len(records), 'discarded_short_fragment_reports': discarded})

def _interpolate(history: Mapping[str, np.ndarray], times: np.ndarray, field: str) -> np.ndarray:
    return np.column_stack([np.interp(times, history['t'], history[field][:, k]) for k in range(3)])

def _pair_diagnostics(left: Mapping[str, np.ndarray], right: Mapping[str, np.ndarray], duration: float) -> np.ndarray:
    left_start, left_stop = (float(left['t'][0]), float(left['t'][-1]))
    right_start, right_stop = (float(right['t'][0]), float(right['t'][-1]))
    common_start, common_stop = (max(left_start, right_start), min(left_stop, right_stop))
    overlap = max(0.0, common_stop - common_start)
    gap = max(0.0, common_start - common_stop)
    if common_start <= common_stop:
        aligned = np.linspace(common_start, common_stop, 8)
        dp = _interpolate(left, aligned, 'p') - _interpolate(right, aligned, 'p')
        dv = _interpolate(left, aligned, 'v') - _interpolate(right, aligned, 'v')
    else:
        midpoint = (common_start + common_stop) / 2
        left_index = -1 if left_stop < right_start else 0
        right_index = 0 if left_stop < right_start else -1
        lp = left['p'][left_index] + (midpoint - left['t'][left_index]) * left['v'][left_index]
        rp = right['p'][right_index] + (midpoint - right['t'][right_index]) * right['v'][right_index]
        dp = (lp - rp)[None, :]
        dv = (left['v'][left_index] - right['v'][right_index])[None, :]
    sigma_pi = float(np.median(left['sigma_pos']))
    sigma_pj = float(np.median(right['sigma_pos']))
    sigma_vi = float(np.median(left['sigma_vel']))
    sigma_vj = float(np.median(right['sigma_vel']))
    dpos = np.mean(np.sum(dp ** 2, axis=1)) / (3 * (sigma_pi ** 2 + sigma_pj ** 2 + 16 + (0.8 * gap) ** 2))
    dvel = np.mean(np.sum(dv ** 2, axis=1)) / (3 * (sigma_vi ** 2 + sigma_vj ** 2 + 0.5 + (0.35 * gap) ** 2))
    union = max(left_stop, right_stop) - min(left_start, right_start)
    rcs = abs(float(np.median(left['rcs'])) - float(np.median(right['rcs']))) / 4
    support = min(1.0, min(len(left['t']), len(right['t'])) / 32)
    return np.array([dpos, dvel, overlap / max(union, 1e-09), gap / duration, rcs, support], dtype=np.float64)

def build_candidate_graph(histories: Sequence[Mapping[str, np.ndarray]], sensor: np.ndarray, cutoff: float) -> dict:
    cfg = PROTOCOL['candidate_policy']
    n = len(histories)
    eligible_count = 0
    gated = []
    neighbors: list[list[tuple[float, int]]] = [[] for _ in histories]
    for i in range(n):
        for j in range(i + 1, n):
            a, b = (histories[i], histories[j])
            nonoverlap = a['t'][-1] < b['t'][0] or b['t'][-1] < a['t'][0]
            if sensor[i] == sensor[j] and (not nonoverlap):
                continue
            eligible_count += 1
            gap = max(0.0, max(a['t'][0], b['t'][0]) - min(a['t'][-1], b['t'][-1]))
            if gap > min(8.0, 0.3 * cutoff):
                continue
            features = _pair_diagnostics(a, b, cutoff)
            if features[0] > cfg['position_d2_gate'] or features[1] > cfg['velocity_d2_gate']:
                continue
            score = float(features[0] + 0.6 * features[1])
            gated.append((i, j, features))
            neighbors[i].append((score, j))
            neighbors[j].append((score, i))
    top = [{j for _, j in sorted(options)[:cfg['mutual_top_k']]} for options in neighbors]
    kept = [(i, j, f) for i, j, f in gated if j in top[i] and i in top[j]]
    edges = np.asarray([(i, j) for i, j, _ in kept], dtype=np.int64).reshape(-1, 2)
    physics = np.asarray([f for _, _, f in kept], dtype=np.float32).reshape(-1, 6)
    logits = (3 - 0.5 * physics[:, 0] - 0.3 * physics[:, 1]).astype(np.float32)
    return {'edges': edges, 'physics': physics, 'physical_logits': logits, 'candidate_audit': {'eligible_pair_count': eligible_count, 'physical_gate_pair_count': len(gated), 'candidate_count': len(kept)}}

def generate_task(seed: int, split: str) -> dict:
    if not isinstance(seed, (int, np.integer)) or int(seed) < 0:
        raise ValueError('seed must be a nonnegative integer')
    if split not in {'train', 'tune', 'calib', 'calibration', 'test', 'ood'}:
        raise ValueError('unknown split')
    rng = np.random.default_rng(int(seed))
    ood = split == 'ood'
    cfg = PROTOCOL['ood' if ood else 'id']
    duration = float(rng.uniform(*PROTOCOL['duration_seconds']))
    target_count = int(rng.integers(3, 9))
    center = np.array([rng.uniform(-600, 600), rng.uniform(-600, 600), rng.uniform(100, 160)])
    motions = [_trajectory(rng, cfg, center, ood) for _ in range(target_count)]
    crossing = bool(rng.random() < PROTOCOL['crossing_pair_probability'])
    if crossing:
        crossing_time = duration * rng.uniform(0.35, 0.7)
        offset = rng.uniform(*PROTOCOL['crossing_offset_m'])
        destination = center + rng.normal(0, 25, 3)
        for index, sign in [(0, -1), (1, 1)]:
            pos, _ = _state(motions[index], np.array([crossing_time]))
            motions[index]['p0'] += destination + np.array([sign * offset / 2, 0.0, 0.0]) - pos[0]
    parallel = bool(target_count >= 4 and rng.random() < PROTOCOL['close_parallel_pair_probability'])
    if parallel:
        motions[3]['v0'] = motions[2]['v0'] + rng.normal(0, 0.65, 3)
        separation = rng.uniform(*PROTOCOL['parallel_separation_m'])
        motions[3]['p0'] = motions[2]['p0'] + separation * motions[2]['sideways']
    sensors = [_sensor_parameters(rng, k, cfg) for k in range(3)]
    histories, identities, sensor_ids, node_audit = ([], [], [], [])
    absent_sources = 0
    attempted_clutter, retained_clutter = (0, 0)
    requested_breaks = 0
    dropout_before, dropout_after, outliers = (0, 0, 0)
    for sensor_id, sensor_parameters in enumerate(sensors):
        sources = [(f'target-{index:03d}', motion, False) for index, motion in enumerate(motions)]
        clutter_count = int(rng.integers(0, 3))
        attempted_clutter += clutter_count
        sources += [(f'clutter-s{sensor_id}-{index:02d}', _trajectory(rng, cfg, center, ood), True) for index in range(clutter_count)]
        for identity, motion, clutter in sources:
            if not clutter and rng.random() < sensor_parameters['absence']:
                absent_sources += 1
                continue
            fragments, receipt = _observe(rng, motion, sensor_parameters, duration, cfg, clutter)
            requested_breaks += receipt['requested_breaks']
            dropout_before += receipt['before_dropout']
            dropout_after += receipt['after_dropout']
            outliers += receipt['outlier_reports_before_fragmentation']
            retained_clutter += len(fragments) if clutter else 0
            for fragment_index, history in enumerate(fragments):
                histories.append(history)
                identities.append(identity)
                sensor_ids.append(sensor_id)
                node_audit.append({'source_kind': 'clutter' if clutter else 'target', 'fragment_index': fragment_index, 'source_report_count': len(history['t']), 'motion_family': motion['family']})
    permutation = rng.permutation(len(histories))
    histories = [histories[int(i)] for i in permutation]
    identities = [identities[int(i)] for i in permutation]
    sensor = np.asarray([sensor_ids[int(i)] for i in permutation], dtype=np.int64)
    node_audit = [node_audit[int(i)] for i in permutation]
    n = len(histories)
    x = np.zeros((n, 32, 10), dtype=np.float32)
    mask = np.zeros((n, 32), dtype=np.bool_)
    for index, history in enumerate(histories):
        count = min(32, len(history['t']))
        selected = np.linspace(0, len(history['t']) - 1, count).astype(np.int64)
        features = np.column_stack([history['t'] - duration, history['p'], history['v'], np.log(history['sigma_pos']), np.log(history['sigma_vel']), history['rcs']])
        x[index, :count] = features[selected].astype(np.float32)
        mask[index, :count] = True
    graph = build_candidate_graph(histories, sensor, duration)
    y = np.asarray([int(identities[i] == identities[j]) for i, j in graph['edges']], dtype=np.int64)
    full_positive = sum((identities[i] == identities[j] for i in range(n) for j in range(i + 1, n)))
    candidate_positive = int(y.sum())
    sample_count = sum((len(h['t']) for h in histories))
    meta = {'schema': PROTOCOL['schema'], 'protocol_sha256': protocol_hash(), 'seed': int(seed), 'split': split, 'domain': 'ood' if ood else 'id', 'independence_group_id': f'enriched-v3-seed-{int(seed)}', 'decision_cutoff_s': duration, 'flight_duration_s': duration, 'generated_target_count': target_count, 'observed_target_count': len({v for v in identities if v.startswith('target-')}), 'node_count': n, 'source_report_count': sample_count, 'model_sample_count': int(mask.sum()), 'candidate_count': len(y), 'candidate_positive_count': candidate_positive, 'candidate_negative_count': int(len(y) - candidate_positive), 'full_pair_count': n * (n - 1) // 2, 'universe_positive_pairs': int(full_positive), 'candidate_recall': float(candidate_positive / full_positive) if full_positive else None, 'candidate_positive_fraction': float(candidate_positive / len(y)) if len(y) else None, 'absent_target_sensor_sources': absent_sources, 'attempted_clutter_tracks': attempted_clutter, 'retained_clutter_tracks': retained_clutter, 'requested_break_count': requested_breaks, 'extra_retained_target_fragments': sum((max(0, identities.count(v) - len({int(sensor[k]) for k, x_id in enumerate(identities) if x_id == v})) for v in set(identities) if v.startswith('target-'))), 'reports_before_dropout': dropout_before, 'reports_after_dropout_before_fragmentation': dropout_after, 'outlier_reports_before_fragmentation': outliers, 'crossing_pair_generated': crossing, 'close_parallel_pair_generated': parallel, 'node_audit': node_audit, 'sensor_parameters': [{k: v.tolist() if isinstance(v, np.ndarray) else float(v) for k, v in s.items()} for s in sensors], 'candidate_audit': graph['candidate_audit'], 'parameter_range_key': 'ood' if ood else 'id', 'no_future_observations': True}
    result = {'x': x, 'mask': mask, 'edges': graph['edges'], 'physics': graph['physics'], 'physical_logits': graph['physical_logits'], 'y': y, 'identities': identities, 'sensor': sensor, 'histories': histories, 'meta': meta}
    validate_task(result)
    return result

def validate_task(task: Mapping[str, Any]) -> None:
    x, mask, edges = (task['x'], task['mask'], task['edges'])
    n, e = (len(task['identities']), len(edges))
    assert x.shape == (n, 32, 10) and x.dtype == np.float32
    assert mask.shape == (n, 32) and mask.dtype == np.bool_
    assert edges.shape == (e, 2) and edges.dtype == np.int64
    assert task['physics'].shape == (e, 6) and task['physical_logits'].shape == (e,)
    assert task['y'].shape == (e,) and task['y'].dtype == np.int64
    assert task['sensor'].shape == (n,)
    assert np.all(np.isfinite(x)) and np.all(np.isfinite(task['physics']))
    assert np.all(np.isfinite(task['physical_logits']))
    assert np.all(x[~mask] == 0)
    assert np.all(x[..., 0][mask] <= 1e-06)
    assert not np.any(np.diff(mask.astype(np.int8), axis=1) > 0)
    assert np.all(edges[:, 0] < edges[:, 1]) and np.all((edges >= 0) & (edges < n))
    assert len({tuple(v) for v in edges.tolist()}) == e
    for i, history in enumerate(task['histories']):
        assert len(history['t']) >= 3 and np.all(np.diff(history['t']) > 0)
        assert np.all(history['t'] <= task['meta']['decision_cutoff_s'])
        assert int(mask[i].sum()) == min(32, len(history['t']))
    for k, (i, j) in enumerate(edges):
        assert int(task['y'][k]) == int(task['identities'][i] == task['identities'][j])
    assert task['meta']['candidate_positive_count'] == int(task['y'].sum())
    assert task['meta']['protocol_sha256'] == protocol_hash()
    json.dumps(task['meta'], allow_nan=False)
