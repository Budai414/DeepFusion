from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Mapping, Sequence
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.stats import chi2
from research.df_paag import reviewer_simulation_v3 as simulation
PROTOCOL = {'version': 'state-validation-v4-20261007', 'question': 'state accuracy/uncertainty consequences of frozen identity associations under one common backend', 'backend': 'causal constant-velocity propagation plus simultaneous equal-weight covariance intersection', 'scope': 'controlled 6D source-state fusion, not a reproduction of IMM-UKF or a raw-detection tracker', 'query_fractions': [0.25, 0.5, 0.75, 1.0], 'maximum_report_age_s': 5.0, 'per_component_source_rule': 'latest report per observed sensor, with node index breaking exact time ties', 'process_noise_q_m2_s3': 1.0, 'position_vertical_sigma_factor': 0.65, 'ci_weights': '1/k for every available source; no optimization or truth-based weighting', 'state_order': ['east_m', 'north_m', 'up_m', 'velocity_east_mps', 'velocity_north_mps', 'velocity_up_mps'], 'truth_population': 'all generated targets at every query; sensor visibility is not target death; clutter is not a target', 'matching': 'Hungarian on squared 150m-capped position distance; accept assigned pairs only when distance<150m', 'matching_scope': 'framewise unordered state sets, not an identity-switch metric; matched component identity contamination is reported separately and never excluded from RMSE', 'position_cutoff_m': 150.0, 'ospa_order': 2, 'error_definition': '3D Euclidean position/velocity RMSE conditional on accepted one-to-one matches', 'state_nll': 'matched 6D Gaussian negative log density in nats, fixed units m and m/s', 'nees': 'matched e.T inv(P) e with central chi-square(df=6) 95% interval', 'missing_false_outputs': 'always report truth count, output count, matches, misses, false outputs, coverage and OSPA; unmatched states do not have an invented NLL', 'empty_prefix_policy': 'if an export is absent, reconstruct empty predictions only after independently verifying no source has >=3 reports at that query; otherwise fail; every target remains missed', 'sensor_contribution': 'separate oracle-identity diagnostic for 012,01,02,12,0,1,2; retain clutter outputs and same full truth population', 'statistical_unit': 'independent task; paired tasks for method comparisons; 2000 fixed-seed bootstrap replicates', 'bootstrap_replicates': 2000, 'bootstrap_seed': 20261007, 'tuning': 'none; noise/age/cutoff/CI weights fixed before held-out state results', 'falsification': 'no universal benefit claim if OSPA/coverage or conditional error worsens; calibration not established if empirical NEES coverage departs from nominal'}

def canonical_hash(value) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def _plain(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {k: _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    return value

def observation_hash(histories, sensor) -> str:
    return canonical_hash({'histories': _plain(histories), 'sensor': _plain(sensor)})

def reconstruct_latent_truth(seed: int, split: str) -> dict:
    rng = np.random.default_rng(int(seed))
    ood = split == 'ood'
    cfg = simulation.PROTOCOL['ood' if ood else 'id']
    duration = float(rng.uniform(*simulation.PROTOCOL['duration_seconds']))
    target_count = int(rng.integers(3, 9))
    center = np.array([rng.uniform(-600, 600), rng.uniform(-600, 600), rng.uniform(100, 160)])
    motions = [simulation._trajectory(rng, cfg, center, ood) for _ in range(target_count)]
    crossing = bool(rng.random() < simulation.PROTOCOL['crossing_pair_probability'])
    if crossing:
        crossing_time = duration * rng.uniform(0.35, 0.7)
        offset = rng.uniform(*simulation.PROTOCOL['crossing_offset_m'])
        destination = center + rng.normal(0, 25, 3)
        for index, sign in [(0, -1), (1, 1)]:
            pos, _ = simulation._state(motions[index], np.array([crossing_time]))
            motions[index]['p0'] += destination + np.array([sign * offset / 2, 0.0, 0.0]) - pos[0]
    parallel = bool(target_count >= 4 and rng.random() < simulation.PROTOCOL['close_parallel_pair_probability'])
    if parallel:
        motions[3]['v0'] = motions[2]['v0'] + rng.normal(0, 0.65, 3)
        separation = rng.uniform(*simulation.PROTOCOL['parallel_separation_m'])
        motions[3]['p0'] = motions[2]['p0'] + separation * motions[2]['sideways']
    return {'seed': int(seed), 'split': split, 'duration_s': duration, 'target_ids': [f'target-{i:03d}' for i in range(target_count)], 'motions': motions, 'simulator_protocol_sha256': simulation.protocol_hash()}

def truth_states(truth: Mapping, time_s: float) -> np.ndarray:
    if not 0 <= time_s <= truth['duration_s'] + 1e-09:
        raise ValueError('Query must lie inside the declared simulated task')
    return np.array([np.concatenate([p[0], v[0]]) for p, v in [simulation._state(m, np.array([time_s])) for m in truth['motions']]], dtype=np.float64)

def verified_truth_for_task(task: Mapping) -> tuple[dict, dict]:
    seed, split = (int(task['meta']['seed']), str(task['meta']['split']))
    original = simulation.generate_task(seed, split)
    incoming = observation_hash(task['histories'], task['sensor'])
    regenerated = observation_hash(original['histories'], original['sensor'])
    if incoming != regenerated or list(task['identities']) != original['identities']:
        raise ValueError('Source observations differ from the untouched simulator')
    truth = reconstruct_latent_truth(seed, split)
    if truth['duration_s'] != original['meta']['decision_cutoff_s']:
        raise ValueError('Truth replay duration mismatch')
    if len(truth['motions']) != original['meta']['generated_target_count']:
        raise ValueError('Truth replay population mismatch')
    return (truth, {'seed': seed, 'split': split, 'observation_sha256': incoming, 'truth_sha256': canonical_hash(_plain(truth)), 'observation_replay_exact': True})

def verify_prefix(full_task: Mapping, prefix_task: Mapping, original_indices: Sequence[int], query_s: float) -> None:
    if len(original_indices) != len(prefix_task['histories']):
        raise ValueError('Prefix index mapping length mismatch')
    if len(set(map(int, original_indices))) != len(original_indices):
        raise ValueError('Duplicate source nodes in prefix mapping')
    for j, original in enumerate(original_indices):
        source = full_task['histories'][int(original)]
        use = np.asarray(source['t']) <= query_s + 1e-10
        if use.sum() < 3:
            raise ValueError('Prefix retained fewer than three reports')
        for key in source:
            if not np.array_equal(np.asarray(prefix_task['histories'][j][key]), np.asarray(source[key])[use]):
                raise ValueError(f'Altered/future prefix observation: {key}')
        if int(prefix_task['sensor'][j]) != int(full_task['sensor'][int(original)]):
            raise ValueError('Prefix sensor mapping mismatch')
        if prefix_task['identities'][j] != full_task['identities'][int(original)]:
            raise ValueError('Prefix identity evaluation mapping mismatch')

def selected_components(node_count: int, edges, selected) -> list[list[int]]:
    parents = list(range(node_count))

    def find(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i
    edges = np.asarray(edges, dtype=int).reshape(-1, 2)
    selected = np.asarray(selected, dtype=bool)
    if selected.shape != (len(edges),):
        raise ValueError('Decision vector does not match candidate graph')
    for (i, j), keep in zip(edges, selected):
        if keep:
            parents[find(int(i))] = find(int(j))
    groups = {}
    for i in range(node_count):
        groups.setdefault(find(i), []).append(i)
    return sorted(groups.values(), key=lambda group: group[0])

def oracle_identity_components(identities) -> list[list[int]]:
    groups = {}
    for i, identity in enumerate(identities):
        groups.setdefault(str(identity), []).append(i)
    return list(groups.values())

def propagate_report(history: Mapping, report_index: int, query_s: float) -> tuple[np.ndarray, np.ndarray]:
    t = float(history['t'][report_index])
    dt = query_s - t
    if dt < -1e-09:
        raise ValueError('Future report supplied to causal backend')
    dt = max(dt, 0.0)
    p, v = (np.asarray(history['p'][report_index], dtype=np.float64), np.asarray(history['v'][report_index], dtype=np.float64))
    sp, sv = (float(history['sigma_pos'][report_index]), float(history['sigma_vel'][report_index]))
    if sp <= 0 or sv <= 0:
        raise ValueError('Reported standard deviations must be positive')
    state = np.concatenate([p + dt * v, v])
    f = np.eye(6)
    f[:3, 3:] = np.eye(3) * dt
    covariance = np.diag([sp ** 2, sp ** 2, (PROTOCOL['position_vertical_sigma_factor'] * sp) ** 2] + [sv ** 2] * 3)
    q = PROTOCOL['process_noise_q_m2_s3']
    process = np.block([[np.eye(3) * dt ** 3 / 3, np.eye(3) * dt ** 2 / 2], [np.eye(3) * dt ** 2 / 2, np.eye(3) * dt]]) * q
    return (state, f @ covariance @ f.T + process)

def equal_weight_ci(states, covariances) -> tuple[np.ndarray, np.ndarray]:
    if not len(states):
        raise ValueError('CI needs at least one source')
    information = [np.linalg.inv(p) for p in covariances]
    mean_information = np.mean(information, axis=0)
    covariance = np.linalg.inv(mean_information)
    state = covariance @ np.mean([info @ x for info, x in zip(information, states)], axis=0)
    return (state, (covariance + covariance.T) / 2)

def fuse_partition(histories, sensor, groups, query_s: float, sensors=(0, 1, 2)) -> list[dict]:
    sensor = np.asarray(sensor, dtype=int)
    output = []
    allowed = set(map(int, sensors))
    for group in groups:
        latest = {}
        for node in group:
            sid = int(sensor[node])
            if sid not in allowed:
                continue
            history = histories[node]
            times = np.asarray(history['t'], dtype=float)
            eligible = np.flatnonzero(times <= query_s + 1e-10)
            if not len(eligible):
                continue
            k = int(eligible[-1])
            age = query_s - float(times[k])
            if age > PROTOCOL['maximum_report_age_s']:
                continue
            candidate = (float(times[k]), -int(node), k)
            if sid not in latest or candidate > latest[sid]:
                latest[sid] = candidate
        if not latest:
            continue
        states, covariances, used = ([], [], [])
        for sid in sorted(latest):
            timestamp, negative_node, k = latest[sid]
            node = -negative_node
            x, p = propagate_report(histories[node], k, query_s)
            states.append(x)
            covariances.append(p)
            used.append({'node': node, 'sensor': sid, 'report_index': k, 'report_time_s': timestamp})
        x, p = equal_weight_ci(states, covariances)
        output.append({'mean': x, 'covariance': p, 'used_reports': used, 'component_nodes': list(group)})
    return output

def evaluate_states(estimates: Sequence[Mapping], truth: np.ndarray, *, truth_ids=None, node_identities=None) -> dict:
    truth = np.asarray(truth, dtype=np.float64).reshape(-1, 6)
    n, m = (len(truth), len(estimates))
    cutoff = float(PROTOCOL['position_cutoff_m'])
    if n and m:
        predicted = np.array([e['mean'] for e in estimates])
        distances = np.linalg.norm(truth[:, None, :3] - predicted[None, :, :3], axis=2)
        rows, cols = linear_sum_assignment(np.minimum(distances, cutoff) ** 2)
        ospa_square = (np.minimum(distances[rows, cols], cutoff) ** 2).sum() + cutoff ** 2 * abs(n - m)
        pairs = [(int(i), int(j)) for i, j in zip(rows, cols) if distances[i, j] < cutoff]
    else:
        pairs = []
        ospa_square = cutoff ** 2 * abs(n - m)
    position_squared, velocity_squared, nees, nll = ([], [], [], [])
    for i, j in pairs:
        e = np.asarray(estimates[j]['mean'], dtype=np.float64) - truth[i]
        p = np.asarray(estimates[j]['covariance'], dtype=np.float64)
        sign, logdet = np.linalg.slogdet(p)
        if sign <= 0:
            raise ValueError('Fusion covariance must be positive definite')
        value = float(e @ np.linalg.solve(p, e))
        position_squared.append(float(e[:3] @ e[:3]))
        velocity_squared.append(float(e[3:] @ e[3:]))
        nees.append(value)
        nll.append(float(0.5 * (6 * np.log(2 * np.pi) + logdet + value)))
    low, high = chi2.ppf([0.025, 0.975], df=6)
    matched = len(pairs)
    identity_pure = None
    if truth_ids is not None and node_identities is not None:
        identity_pure = sum((all((node_identities[node] == truth_ids[i] for node in estimates[j]['component_nodes'])) for i, j in pairs))
    return {'truth_count': n, 'output_count': m, 'matched_count': matched, 'missed_count': n - matched, 'false_output_count': m - matched, 'target_coverage': matched / n if n else None, 'ospa_position_m': float(np.sqrt(ospa_square / max(n, m))) if max(n, m) else 0.0, 'position_rmse_m': float(np.sqrt(np.mean(position_squared))) if matched else None, 'velocity_rmse_mps': float(np.sqrt(np.mean(velocity_squared))) if matched else None, 'state_nll_nats': float(np.mean(nll)) if matched else None, 'nees_mean': float(np.mean(nees)) if matched else None, 'nees95_coverage': float(np.mean((np.array(nees) >= low) & (np.array(nees) <= high))) if matched else None, 'nees95_hits': int(np.sum((np.array(nees) >= low) & (np.array(nees) <= high))), 'identity_pure_matched_count': identity_pure, 'identity_mixed_or_wrong_matched_count': matched - identity_pure if identity_pure is not None else None, 'nees95_interval': [float(low), float(high)], 'matched_pairs': pairs, 'position_squared_errors': position_squared, 'velocity_squared_errors': velocity_squared, 'nees_values': nees, 'nll_values': nll}

def method_states(task, selected, query_s, *, sensors=(0, 1, 2), oracle=False):
    groups = oracle_identity_components(task['identities']) if oracle else selected_components(len(task['histories']), task['edges'], selected)
    return fuse_partition(task['histories'], task['sensor'], groups, query_s, sensors)

def source_receipt() -> dict:
    return {'state_module_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'simulator_source_sha256': hashlib.sha256(Path(simulation.__file__).read_bytes()).hexdigest(), 'simulation_protocol_sha256': simulation.protocol_hash()}
