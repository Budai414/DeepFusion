from __future__ import annotations
from itertools import combinations
from typing import Mapping
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
BEAM_WIDTH = 32
SEQUENCE_MAX_POINTS = 32
SEQUENCE_SCALE_M = 50.0
SEQUENCE_METHODS = ('DTW', 'discrete-Frechet', 'LCSS', 'LCS-quantized')

def _observations(history):
    times = np.asarray(history['t'], dtype=np.float64)
    positions = np.asarray(history['p'], dtype=np.float64)
    velocities = np.asarray(history['v'], dtype=np.float64)
    if len(times) == 0 or positions.shape != (len(times), 3) or velocities.shape != positions.shape or (not np.all(np.isfinite(times))) or (not np.all(np.isfinite(positions))) or (not np.all(np.isfinite(velocities))) or np.any(np.diff(times) <= 0):
        raise ValueError('History must contain finite, strictly ordered observed states')
    return (times, positions, velocities)

def _at_times(history, times):
    t, p, v = _observations(history)
    result = np.stack([np.interp(times, t, p[:, axis]) for axis in range(3)], axis=1)
    before, after = (times < t[0], times > t[-1])
    result[before] = p[0] + (times[before] - t[0])[:, None] * v[0]
    result[after] = p[-1] + (times[after] - t[-1])[:, None] * v[-1]
    return result

def _common_sequences(left, right):
    lt, _, _ = _observations(left)
    rt, _, _ = _observations(right)
    start, stop = (max(lt[0], rt[0]), min(lt[-1], rt[-1]))
    if start <= stop:
        count = min(SEQUENCE_MAX_POINTS, max(2, min(len(lt), len(rt))))
        times = np.linspace(start, stop, count)
    else:
        times = np.linspace(stop, start, min(8, SEQUENCE_MAX_POINTS))
    return (_at_times(left, times), _at_times(right, times))

def _distances(left, right, epsilon_m, quantization_m):
    distances = np.linalg.norm(left[:, None] - right[None, :], axis=2)
    rows, cols = distances.shape
    dtw = np.full((rows + 1, cols + 1), np.inf)
    dtw[0, 0] = 0.0
    frechet = np.full((rows + 1, cols + 1), np.inf)
    frechet[0, 0] = 0.0
    lcss = np.zeros((rows + 1, cols + 1), dtype=np.int32)
    lcs = np.zeros((rows + 1, cols + 1), dtype=np.int32)
    left_tokens = np.floor(left / quantization_m).astype(np.int64)
    right_tokens = np.floor(right / quantization_m).astype(np.int64)
    for i in range(1, rows + 1):
        for j in range(1, cols + 1):
            distance = distances[i - 1, j - 1]
            dtw[i, j] = distance + min(dtw[i - 1, j], dtw[i, j - 1], dtw[i - 1, j - 1])
            frechet[i, j] = max(distance, min(frechet[i - 1, j], frechet[i, j - 1], frechet[i - 1, j - 1]))
            lcss[i, j] = lcss[i - 1, j - 1] + 1 if distance <= epsilon_m else max(lcss[i - 1, j], lcss[i, j - 1])
            lcs[i, j] = lcs[i - 1, j - 1] + 1 if np.array_equal(left_tokens[i - 1], right_tokens[j - 1]) else max(lcs[i - 1, j], lcs[i, j - 1])
    return (-float(dtw[-1, -1]) / (max(rows, cols) * SEQUENCE_SCALE_M), -float(frechet[-1, -1]) / SEQUENCE_SCALE_M, float(lcss[-1, -1]) / min(rows, cols), float(lcs[-1, -1]) / min(rows, cols))

def sequence_scores(task: Mapping, *, lcss_epsilon_m=30.0, quantization_m=30.0):
    if lcss_epsilon_m <= 0 or quantization_m <= 0:
        raise ValueError('Sequence tolerance/quantization must be positive')
    output = {name: [] for name in SEQUENCE_METHODS}
    for left, right in np.asarray(task['edges'], dtype=np.int64).reshape(-1, 2):
        sequences = _common_sequences(task['histories'][left], task['histories'][right])
        for name, score in zip(SEQUENCE_METHODS, _distances(*sequences, lcss_epsilon_m, quantization_m)):
            output[name].append(score)
    return {name: np.asarray(values, dtype=np.float64) for name, values in output.items()}

def _overlap(left, right, histories):
    lt, rt = (histories[left]['t'], histories[right]['t'])
    return max(float(lt[0]), float(rt[0])) <= min(float(lt[-1]), float(rt[-1]))

def _ordered_nodes(nodes, task):
    return sorted(nodes, key=lambda n: (float(task['histories'][n]['t'][0]), float(task['histories'][n]['t'][-1]), tuple(map(float, task['histories'][n]['p'][0])), int(n)))

def _softmax(values, temperature):
    values = np.asarray(values, dtype=np.float64) / temperature
    values -= np.max(values)
    weights = np.exp(values)
    return weights / weights.sum()

def _lookup(task):
    return {tuple(sorted((int(a), int(b)))): (k, float(score)) for k, ((a, b), score) in enumerate(zip(task['edges'], task['physical_logits']))}

def _assignment_marginals(task, left_nodes, right_nodes, lookup, null_score, temperature, *, fragment_paths=False):
    candidates = []
    for left in left_nodes:
        for right in right_nodes:
            if left == right:
                continue
            if fragment_paths and float(task['histories'][left]['t'][-1]) >= float(task['histories'][right]['t'][0]):
                continue
            pair = tuple(sorted((left, right)))
            if pair in lookup:
                edge, score = lookup[pair]
                candidates.append((left, right, edge, score))
    candidates.sort(key=lambda item: (-item[3], min(item[0], item[1]), max(item[0], item[1])))
    conflicts = []
    for k, (left, right, _, _) in enumerate(candidates):
        forbidden = set()
        for previous, (old_left, old_right, _, _) in enumerate(candidates[:k]):
            if left == old_left and (fragment_paths or _overlap(right, old_right, task['histories'])) or (right == old_right and (fragment_paths or _overlap(left, old_left, task['histories']))):
                forbidden.add(previous)
        conflicts.append(forbidden)
    nodes = set(left_nodes) | set(right_nodes)
    beam = [(null_score * len(nodes), (), frozenset())]
    for position, (left, right, _, score) in enumerate(candidates):
        expanded = []
        for total, chosen, covered in beam:
            expanded.append((total, chosen, covered))
            if not conflicts[position].intersection(chosen):
                newly_covered = int(left not in covered) + int(right not in covered)
                expanded.append((total + score - null_score * newly_covered, chosen + (position,), covered | {left, right}))
        beam = sorted(expanded, key=lambda row: (-row[0], row[1]))[:BEAM_WIDTH]
    probabilities = np.zeros(len(task['edges']), dtype=np.float64)
    for (_, chosen, _), weight in zip(beam, _softmax([row[0] for row in beam], temperature)):
        probabilities[[candidates[position][2] for position in chosen]] += weight
    return probabilities

def _jpda_style(task, null_score, temperature):
    sensors = np.asarray(task['sensor'], dtype=np.int64)
    groups = [_ordered_nodes(np.flatnonzero(sensors == sensor), task) for sensor in sorted(set(sensors.tolist()))]
    lookup = _lookup(task)
    result = np.zeros(len(task['edges']), dtype=np.float64)
    for left, right in combinations(groups, 2):
        result += _assignment_marginals(task, left, right, lookup, null_score, temperature)
    for group in groups:
        if any(((a, b) in lookup for a, b in combinations(sorted(group), 2))):
            result += _assignment_marginals(task, group, group, lookup, null_score, temperature, fragment_paths=True)
    return result

def _mht_style(task, null_score, temperature):
    lookup = _lookup(task)
    sensors = task['sensor']
    beam = [(0.0, ())]
    for node in _ordered_nodes(range(len(sensors)), task):
        expanded = []
        for total, clusters in beam:
            expanded.append((total + null_score, clusters + ((node,),)))
            for cluster_index, cluster in enumerate(clusters):
                if any((sensors[node] == sensors[member] and _overlap(node, member, task['histories']) for member in cluster)):
                    continue
                pairs = [tuple(sorted((node, member))) for member in cluster]
                evidence = [lookup[pair] for pair in pairs if pair in lookup]
                if not evidence or any((pair not in lookup and _overlap(*pair, task['histories']) for pair in pairs)):
                    continue
                increment = sum((score for _, score in evidence))
                if len(cluster) == 1:
                    increment -= null_score
                updated = clusters[:cluster_index] + (cluster + (node,),) + clusters[cluster_index + 1:]
                expanded.append((total + increment, updated))
        beam = sorted(expanded, key=lambda row: (-row[0], row[1]))[:BEAM_WIDTH]
    result = np.zeros(len(task['edges']), dtype=np.float64)
    for (_, clusters), weight in zip(beam, _softmax([row[0] for row in beam], temperature)):
        for cluster in clusters:
            for left, right in combinations(cluster, 2):
                pair = tuple(sorted((left, right)))
                if pair in lookup:
                    result[lookup[pair][0]] += weight
    return result

def hypothesis_scores(task: Mapping, method: str, null_score: float=0.0, temperature: float=1.0):
    if not np.isfinite(null_score) or not np.isfinite(temperature) or temperature <= 0:
        raise ValueError('Finite null score and positive temperature are required')
    if not np.all(np.isfinite(task['physical_logits'])):
        raise ValueError('Physical scores must be finite')
    if method == 'JPDA-style':
        result = _jpda_style(task, null_score, temperature)
    elif method == 'MHT-beam32':
        result = _mht_style(task, null_score, temperature)
    else:
        raise ValueError(f'Unknown hypothesis baseline: {method}')
    return np.clip(result, 0.0, 1.0)

class GraphAssociationV3(nn.Module):

    def __init__(self, hetero: bool=False, hidden: int=32, input_size: int=10):
        super().__init__()
        self.hetero = bool(hetero)
        self.hidden = int(hidden)
        self.input = nn.Linear(input_size * 4 + 1, hidden)
        extra = 9 if hetero else 7
        self.messages = nn.ModuleList([nn.ModuleList([nn.Linear(hidden + extra, hidden) for _ in range(6)]) if hetero else nn.Linear(hidden + extra, hidden) for _ in range(2)])
        self.updates = nn.ModuleList([nn.Linear(2 * hidden, hidden) for _ in range(2)])
        self.norms = nn.ModuleList([nn.LayerNorm(hidden) for _ in range(2)])
        self.head = nn.Sequential(nn.Linear(2 * hidden + extra, hidden), nn.ReLU(), nn.Linear(hidden, 1))

    def forward(self, x, mask, edges, physics, physical_logits, sensor=None):
        valid = mask.to(dtype=x.dtype).unsqueeze(-1)
        count = valid.sum(dim=1).clamp_min(1.0)
        clean = torch.where(mask.unsqueeze(-1), x, torch.zeros_like(x))
        mean = clean.sum(dim=1) / count
        variance = ((clean - mean[:, None]) ** 2 * valid).sum(dim=1) / count
        last_index = mask.sum(dim=1).clamp_min(1).long() - 1
        last = clean[torch.arange(len(x), device=x.device), last_index]
        first = clean[:, 0]
        summary = torch.cat((mean, variance.clamp_min(1e-08).sqrt(), first, last, count / x.shape[1]), dim=1)
        h = F.relu(self.input(summary))
        source, destination = (edges[:, 0], edges[:, 1])
        edge_features = torch.cat((physics, physical_logits.reshape(-1, 1)), dim=1)
        relation = None
        if self.hetero:
            if sensor is None:
                raise ValueError('Heterogeneous graph requires observable sensor identities')
            if torch.any((sensor < 0) | (sensor > 2)):
                raise ValueError('The fixed v3 graph protocol uses three sensors (0,1,2)')
            low = torch.minimum(sensor[source], sensor[destination])
            high = torch.maximum(sensor[source], sensor[destination])
            relation = low * 3 - low * (low - 1) // 2 + high - low
            temporal = torch.stack((torch.abs(first[source, 0] - first[destination, 0]), torch.abs(last[source, 0] - last[destination, 0])), dim=1)
            edge_features = torch.cat((edge_features, temporal), dim=1)
        for layer in range(2):
            aggregate = torch.zeros_like(h)
            degree = torch.zeros((len(x), 1), dtype=x.dtype, device=x.device)
            for start, end in ((source, destination), (destination, source)):
                inputs = torch.cat((h[start], edge_features), dim=1)
                if self.hetero:
                    messages = torch.zeros((len(edges), self.hidden), dtype=x.dtype, device=x.device)
                    for relation_id, mapping in enumerate(self.messages[layer]):
                        selected = relation == relation_id
                        messages[selected] = mapping(inputs[selected])
                else:
                    messages = self.messages[layer](inputs)
                aggregate.index_add_(0, end, F.relu(messages))
                degree.index_add_(0, end, torch.ones((len(end), 1), dtype=x.dtype, device=x.device))
            update = self.updates[layer](torch.cat((h, aggregate / degree.clamp_min(1)), dim=1))
            h = F.relu(self.norms[layer](h + update))
        pair = torch.cat((torch.abs(h[source] - h[destination]), h[source] * h[destination], edge_features), dim=1)
        return self.head(pair).squeeze(-1)
