from __future__ import annotations
from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import json
import math
import re
from itertools import combinations
from typing import Dict, Iterable, List, Mapping, Optional, Sequence
import scipy
from real_fusion.tracking.identity import IdentityCandidateEdge, IdentityCandidateNode, IdentityCandidatePairSets, LocalTrackPairDiagnostic
TRUTH_MANIFEST_SCHEMA_VERSION = 'deepfusion.identity-truth-manifest.v2'
CANDIDATE_GRAPH_SNAPSHOT_SCHEMA_VERSION = 'deepfusion.candidate-graph-snapshot.v2'
CANDIDATE_COVERAGE_AUDIT_SCHEMA_VERSION = 'deepfusion.candidate-coverage-audit.v2'
LABEL_POLICY_VERSION = 'same-different-ambiguous-v1'
ELIGIBILITY_VERSION = 'cross-sensor-corrected-time-overlap-birth-window-v1'
FEASIBILITY_SEMANTICS_VERSION = 'truth-cluster-s0-connected-and-same-sensor-conflict-free-v1'
TIME_QUANTIZATION_VERSION = 'seconds-to-nearest-microsecond-v1'
PAIR_LABELS = ('same', 'different', 'ambiguous')
AGREEMENT_VALUES = ('unanimous', 'majority', 'adjudicated', 'unresolved', 'not_applicable')
S0_PROVENANCE_VALUES = ('cross_sensor_time_overlap_exhaustive', 'cross_sensor_bidirectional_kdtree_radius')
_SAFE_ID = re.compile('^[A-Za-z0-9][A-Za-z0-9_.:-]{0,255}$')
_SHA256 = re.compile('^[0-9a-f]{64}$')

class IdentityDataContractError(ValueError):

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = str(code)

def _canonical_bytes(value: object) -> bytes:
    try:
        rendered = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    except (TypeError, ValueError) as error:
        raise IdentityDataContractError('not_canonical_json', '对象不能确定性JSON序列化') from error
    return rendered.encode('utf-8')

def canonical_sha256(value: object) -> str:
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()

def _mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise IdentityDataContractError('mapping_required', f'{label}必须是对象')
    return value

def _exact_keys(value: Mapping[str, object], expected: Iterable[str], label: str) -> None:
    actual = set(value)
    required = set(expected)
    if actual != required:
        raise IdentityDataContractError('keys_invalid', f'{label}字段必须严格为{sorted(required)}，实际为{sorted(actual)}')

def _safe_id(value: object, label: str) -> str:
    if type(value) is not str or not _SAFE_ID.fullmatch(value):
        raise IdentityDataContractError('identifier_invalid', f'{label}必须是原生字符串稳定标识')
    return value

def _opaque_text(value: object, label: str, *, maximum: int=1024) -> str:
    if type(value) is not str or not value or value != value.strip():
        raise IdentityDataContractError('text_invalid', f'{label}必须是非空且无首尾空白的原生字符串')
    if len(value) > maximum or any((ord(character) < 32 for character in value)):
        raise IdentityDataContractError('text_invalid', f'{label}过长或包含控制字符')
    return value

def _strict_bool(value: object, label: str) -> bool:
    if type(value) is not bool:
        raise IdentityDataContractError('boolean_invalid', f'{label}必须是JSON布尔值')
    return value

def _integer(value: object, label: str, *, minimum: int=0) -> int:
    if type(value) is not int or value < minimum:
        raise IdentityDataContractError('integer_invalid', f'{label}必须是大于等于{minimum}的整数')
    return value

def _finite_float(value: object, label: str, *, minimum: float | None=None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise IdentityDataContractError('number_invalid', f'{label}必须是数值')
    normalized = float(value)
    if not math.isfinite(normalized) or (minimum is not None and normalized < minimum):
        raise IdentityDataContractError('number_invalid', f'{label}必须是有限数值且满足下界')
    return normalized

def _sha256(value: object, label: str) -> str:
    if type(value) is not str or not _SHA256.fullmatch(value):
        raise IdentityDataContractError('hash_invalid', f'{label}必须是小写64位SHA-256')
    return value

def _relative_posix_path(value: object, label: str) -> str:
    path = _opaque_text(value, label)
    if '\\' in path or path.startswith('/') or ':' in path.split('/')[0]:
        raise IdentityDataContractError('path_invalid', f'{label}必须是DeepFusion内POSIX相对路径')
    parts = path.split('/')
    if any((part in {'', '.', '..'} for part in parts)):
        raise IdentityDataContractError('path_invalid', f'{label}不得为空、绝对或包含目录回退')
    return path

def canonical_pair(left: object, right: object) -> tuple[str, str]:
    left_key = _opaque_text(left, 'left_local_track_key')
    right_key = _opaque_text(right, 'right_local_track_key')
    if left_key == right_key:
        raise IdentityDataContractError('pair_self_edge', '真值或候选边不能是自环')
    return tuple(sorted((left_key, right_key)))

def _normalize_evidence(value: object, label: str) -> Dict[str, object]:
    evidence = _mapping(value, label)
    _exact_keys(evidence, {'source_type', 'reviewer_ids', 'agreement', 'evidence_refs'}, label)
    source_type = _safe_id(evidence.get('source_type'), f'{label}.source_type')
    agreement = str(evidence.get('agreement'))
    if type(evidence.get('agreement')) is not str or agreement not in AGREEMENT_VALUES:
        raise IdentityDataContractError('agreement_invalid', f'{label}.agreement不在冻结枚举内')
    raw_reviewers = evidence.get('reviewer_ids')
    if not isinstance(raw_reviewers, list):
        raise IdentityDataContractError('reviewers_invalid', f'{label}.reviewer_ids必须是数组')
    reviewers = sorted((_safe_id(item, f'{label}.reviewer_ids') for item in raw_reviewers))
    if len(reviewers) != len(set(reviewers)):
        raise IdentityDataContractError('reviewers_duplicate', f'{label}.reviewer_ids不能重复')
    raw_refs = evidence.get('evidence_refs')
    if not isinstance(raw_refs, list) or not raw_refs:
        raise IdentityDataContractError('evidence_refs_invalid', f'{label}.evidence_refs必须是非空数组')
    refs = sorted((_opaque_text(item, f'{label}.evidence_refs') for item in raw_refs))
    if len(refs) != len(set(refs)):
        raise IdentityDataContractError('evidence_refs_duplicate', f'{label}.evidence_refs不能重复')
    return {'source_type': source_type, 'reviewer_ids': reviewers, 'agreement': agreement, 'evidence_refs': refs}

def _normalize_node(value: object, label: str) -> Dict[str, object]:
    node = _mapping(value, label)
    _exact_keys(node, {'local_track_key', 'sensor_id', 'report_count', 'first_corrected_time_us', 'last_corrected_time_us', 'history_sha256'}, label)
    first = _integer(node.get('first_corrected_time_us'), f'{label}.first_time', minimum=0)
    last = _integer(node.get('last_corrected_time_us'), f'{label}.last_time', minimum=0)
    if last < first:
        raise IdentityDataContractError('node_time_invalid', f'{label}末时刻不能早于首时刻')
    return {'local_track_key': _opaque_text(node.get('local_track_key'), f'{label}.local_track_key'), 'sensor_id': _opaque_text(node.get('sensor_id'), f'{label}.sensor_id'), 'report_count': _integer(node.get('report_count'), f'{label}.report_count', minimum=1), 'first_corrected_time_us': first, 'last_corrected_time_us': last, 'history_sha256': _sha256(node.get('history_sha256'), f'{label}.history_sha256')}

def _normalize_temporal_truth_ref(value: object, *, complete: bool, label: str) -> Optional[Dict[str, str]]:
    if not complete:
        if value is not None:
            raise IdentityDataContractError('temporal_truth_ref_invalid', f'{label}在temporal_identity_complete=false时必须为null')
        return None
    reference = _mapping(value, label)
    _exact_keys(reference, {'schema_version', 'path', 'file_sha256'}, label)
    return {'schema_version': _safe_id(reference.get('schema_version'), f'{label}.schema_version'), 'path': _relative_posix_path(reference.get('path'), f'{label}.path'), 'file_sha256': _sha256(reference.get('file_sha256'), f'{label}.file_sha256')}

class _DisjointSet:

    def __init__(self, nodes: Iterable[str]) -> None:
        self.parent = {node: node for node in nodes}

    def find(self, node: str) -> str:
        parent = self.parent[node]
        if parent != node:
            self.parent[node] = self.find(parent)
        return self.parent[node]

    def union(self, left: str, right: str) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root != right_root:
            self.parent[max(left_root, right_root)] = min(left_root, right_root)

def _normalize_partial_truth(value: Mapping[str, object], node_ids: set[str], label: str) -> Dict[str, object]:
    _exact_keys(value, {'kind', 'pairs'}, label)
    if value.get('kind') != 'partial_pairs':
        raise IdentityDataContractError('truth_kind_invalid', f'{label}.kind必须是partial_pairs')
    raw_pairs = value.get('pairs')
    if not isinstance(raw_pairs, list):
        raise IdentityDataContractError('truth_pairs_invalid', f'{label}.pairs必须是数组')
    normalized_pairs: List[Dict[str, object]] = []
    seen: Dict[tuple[str, str], str] = {}
    same_set = _DisjointSet(node_ids)
    for index, raw_pair in enumerate(raw_pairs):
        item_label = f'{label}.pairs[{index}]'
        pair = _mapping(raw_pair, item_label)
        _exact_keys(pair, {'left_local_track_key', 'right_local_track_key', 'label', 'evidence'}, item_label)
        left, right = canonical_pair(pair.get('left_local_track_key'), pair.get('right_local_track_key'))
        if left not in node_ids or right not in node_ids:
            raise IdentityDataContractError('pair_unknown_node', f'{item_label}引用了任务节点全集之外的航迹')
        relation = pair.get('label')
        if type(relation) is not str or relation not in PAIR_LABELS:
            raise IdentityDataContractError('pair_label_invalid', f'{item_label}.label必须严格为same/different/ambiguous')
        if (left, right) in seen:
            code = 'pair_label_conflict' if seen[left, right] != relation else 'pair_duplicate'
            raise IdentityDataContractError(code, f'{item_label}与已有无向对重复或冲突')
        seen[left, right] = relation
        normalized_pairs.append({'left_local_track_key': left, 'right_local_track_key': right, 'label': relation, 'evidence': _normalize_evidence(pair.get('evidence'), f'{item_label}.evidence')})
        if relation == 'same':
            same_set.union(left, right)
    for pair in normalized_pairs:
        if pair['label'] != 'same' and same_set.find(str(pair['left_local_track_key'])) == same_set.find(str(pair['right_local_track_key'])):
            raise IdentityDataContractError('partial_truth_transitive_conflict', 'different/ambiguous标签不能落在已知same传递闭包内部')
    normalized_pairs.sort(key=lambda item: (str(item['left_local_track_key']), str(item['right_local_track_key'])))
    return {'kind': 'partial_pairs', 'pairs': normalized_pairs}

def _normalize_complete_truth(value: Mapping[str, object], node_ids: set[str], label: str) -> Dict[str, object]:
    _exact_keys(value, {'kind', 'clusters'}, label)
    if value.get('kind') != 'complete_partition':
        raise IdentityDataContractError('truth_kind_invalid', f'{label}.kind必须是complete_partition')
    raw_clusters = value.get('clusters')
    if not isinstance(raw_clusters, list) or not raw_clusters:
        raise IdentityDataContractError('truth_partition_invalid', f'{label}.clusters必须是非空数组')
    normalized_clusters: List[Dict[str, object]] = []
    covered: List[str] = []
    truth_ids: set[str] = set()
    for index, raw_cluster in enumerate(raw_clusters):
        item_label = f'{label}.clusters[{index}]'
        cluster = _mapping(raw_cluster, item_label)
        _exact_keys(cluster, {'truth_identity_id', 'members', 'evidence'}, item_label)
        truth_id = _safe_id(cluster.get('truth_identity_id'), f'{item_label}.truth_identity_id')
        if truth_id in truth_ids:
            raise IdentityDataContractError('truth_identity_duplicate', f'truth_identity_id重复: {truth_id}')
        truth_ids.add(truth_id)
        raw_members = cluster.get('members')
        if not isinstance(raw_members, list) or not raw_members:
            raise IdentityDataContractError('truth_cluster_empty', f'{item_label}.members必须非空')
        members = sorted((_opaque_text(member, f'{item_label}.members') for member in raw_members))
        if len(members) != len(set(members)):
            raise IdentityDataContractError('truth_partition_duplicate_node', f'{item_label}内部节点重复')
        unknown = sorted(set(members) - node_ids)
        if unknown:
            raise IdentityDataContractError('truth_partition_unknown_node', f'{item_label}含未知节点: {unknown}')
        covered.extend(members)
        normalized_clusters.append({'truth_identity_id': truth_id, 'members': members, 'evidence': _normalize_evidence(cluster.get('evidence'), f'{item_label}.evidence')})
    if len(covered) != len(set(covered)):
        raise IdentityDataContractError('truth_partition_duplicate_node', '完整分区中的节点跨cluster重复')
    missing = sorted(node_ids - set(covered))
    if missing:
        raise IdentityDataContractError('truth_partition_missing_node', f'完整分区没有覆盖节点: {missing}')
    normalized_clusters.sort(key=lambda item: tuple(item['members']))
    return {'kind': 'complete_partition', 'clusters': normalized_clusters}

def _normalize_truth_task(value: object, label: str='task') -> Dict[str, object]:
    task = _mapping(value, label)
    _exact_keys(task, {'task_id', 'independence_group_id', 'domain', 'stratum', 'truth_level', 'partition_complete', 'temporal_identity_complete', 'label_version', 'truth_source', 'nodes', 'truth', 'temporal_truth_ref'}, label)
    task_id = _safe_id(task.get('task_id'), f'{label}.task_id')
    group_id = _safe_id(task.get('independence_group_id'), f'{label}.independence_group_id')
    domain = task.get('domain')
    if type(domain) is not str or domain not in {'in_distribution', 'ood'}:
        raise IdentityDataContractError('domain_invalid', f'{label}.domain必须是in_distribution或ood')
    stratum = _safe_id(task.get('stratum'), f'{label}.stratum')
    truth_level = task.get('truth_level')
    if type(truth_level) is not str or truth_level not in {'d1', 'd2', 'd3'}:
        raise IdentityDataContractError('truth_level_invalid', f'{label}.truth_level必须严格为d1/d2/d3')
    partition_complete = _strict_bool(task.get('partition_complete'), f'{label}.partition_complete')
    temporal_complete = _strict_bool(task.get('temporal_identity_complete'), f'{label}.temporal_identity_complete')
    if temporal_complete and (not partition_complete):
        raise IdentityDataContractError('truth_qualification_invalid', '逐时刻身份完整不能建立在不完整的任务分区上')
    raw_nodes = task.get('nodes')
    if not isinstance(raw_nodes, list) or not raw_nodes:
        raise IdentityDataContractError('nodes_invalid', f'{label}.nodes必须非空')
    nodes = [_normalize_node(item, f'{label}.nodes[{index}]') for index, item in enumerate(raw_nodes)]
    node_ids = [str(node['local_track_key']) for node in nodes]
    if len(node_ids) != len(set(node_ids)):
        raise IdentityDataContractError('node_duplicate', f'{label}.nodes键重复')
    nodes.sort(key=lambda item: str(item['local_track_key']))
    raw_truth = _mapping(task.get('truth'), f'{label}.truth')
    truth = _normalize_complete_truth(raw_truth, set(node_ids), f'{label}.truth') if partition_complete else _normalize_partial_truth(raw_truth, set(node_ids), f'{label}.truth')
    return {'task_id': task_id, 'independence_group_id': group_id, 'domain': domain, 'stratum': stratum, 'truth_level': truth_level, 'partition_complete': partition_complete, 'temporal_identity_complete': temporal_complete, 'label_version': _safe_id(task.get('label_version'), f'{label}.label_version'), 'truth_source': _safe_id(task.get('truth_source'), f'{label}.truth_source'), 'nodes': nodes, 'truth': truth, 'temporal_truth_ref': _normalize_temporal_truth_ref(task.get('temporal_truth_ref'), complete=temporal_complete, label=f'{label}.temporal_truth_ref')}

def validate_identity_truth_manifest(value: object) -> Dict[str, object]:
    root = _mapping(value, 'truth_manifest')
    _exact_keys(root, {'schema_version', 'manifest_id', 'dataset_id', 'label_policy_version', 'source_manifest_sha256', 'tasks'}, 'truth_manifest')
    if root.get('schema_version') != TRUTH_MANIFEST_SCHEMA_VERSION:
        raise IdentityDataContractError('truth_schema_mismatch', 'IdentityTruthManifest版本不兼容')
    if root.get('label_policy_version') != LABEL_POLICY_VERSION:
        raise IdentityDataContractError('label_policy_mismatch', '标签策略必须严格为v2三值策略')
    raw_tasks = root.get('tasks')
    if not isinstance(raw_tasks, list) or not raw_tasks:
        raise IdentityDataContractError('tasks_invalid', 'tasks必须是非空数组')
    tasks = [_normalize_truth_task(item, f'tasks[{index}]') for index, item in enumerate(raw_tasks)]
    task_ids = [str(task['task_id']) for task in tasks]
    if len(task_ids) != len(set(task_ids)):
        raise IdentityDataContractError('task_duplicate', 'task_id不能重复')
    group_domains: Dict[str, str] = {}
    for task in tasks:
        group_id = str(task['independence_group_id'])
        domain = str(task['domain'])
        previous = group_domains.setdefault(group_id, domain)
        if previous != domain:
            raise IdentityDataContractError('independence_group_inconsistent', f'独立组{group_id}不能跨in-distribution/OOD')
    tasks.sort(key=lambda task: str(task['task_id']))
    return {'schema_version': TRUTH_MANIFEST_SCHEMA_VERSION, 'manifest_id': _safe_id(root.get('manifest_id'), 'manifest_id'), 'dataset_id': _safe_id(root.get('dataset_id'), 'dataset_id'), 'label_policy_version': LABEL_POLICY_VERSION, 'source_manifest_sha256': _sha256(root.get('source_manifest_sha256'), 'source_manifest_sha256'), 'tasks': tasks}

def validate_truth_manifest_against_task_pool(truth_manifest: object, task_pool: object) -> Dict[str, object]:
    from research.df_paag.protocol_v2 import validate_task_pool
    truth = validate_identity_truth_manifest(truth_manifest)
    pool = validate_task_pool(task_pool)
    if truth['dataset_id'] != pool['dataset_id']:
        raise IdentityDataContractError('task_pool_dataset_mismatch', 'truth与task-pool的dataset_id不一致')
    truth_by_id = {str(task['task_id']): task for task in truth['tasks']}
    pool_by_id = {str(task['task_id']): task for task in pool['tasks']}
    if set(truth_by_id) != set(pool_by_id):
        raise IdentityDataContractError('task_pool_task_set_mismatch', 'truth与task-pool任务集合不一致')
    fields = ('independence_group_id', 'domain', 'stratum', 'truth_level', 'partition_complete', 'temporal_identity_complete', 'label_version')
    for task_id in sorted(truth_by_id):
        for field in fields:
            if truth_by_id[task_id][field] != pool_by_id[task_id][field]:
                raise IdentityDataContractError('task_pool_metadata_mismatch', f'任务{task_id}的{field}与冻结task-pool不一致')
    truth_hash = canonical_sha256(truth)
    if pool['source_manifest_sha256'] != truth['source_manifest_sha256']:
        raise IdentityDataContractError('task_pool_truth_hash_mismatch', 'task-pool与IdentityTruthManifest的原始来源清单哈希不一致')
    return {'status': 'valid', 'truth_manifest_canonical_sha256': truth_hash, 'task_count': len(truth_by_id)}

def _truth_pair_label_normalized(normalized: Mapping[str, object], pair: tuple[str, str]) -> str:
    node_ids = {str(node['local_track_key']) for node in normalized['nodes']}
    if pair[0] not in node_ids or pair[1] not in node_ids:
        raise IdentityDataContractError('pair_unknown_node', '查询对含未知节点')
    truth = normalized['truth']
    if truth['kind'] == 'complete_partition':
        cluster_by_node = {str(member): str(cluster['truth_identity_id']) for cluster in truth['clusters'] for member in cluster['members']}
        return 'same' if cluster_by_node[pair[0]] == cluster_by_node[pair[1]] else 'different'
    label_by_pair = {(str(item['left_local_track_key']), str(item['right_local_track_key'])): str(item['label']) for item in truth['pairs']}
    return label_by_pair.get(pair, 'unknown')

def truth_pair_label(task: object, left: object, right: object) -> str:
    normalized = _normalize_truth_task(task)
    return _truth_pair_label_normalized(normalized, canonical_pair(left, right))

def truth_pair_supervision(task: object) -> List[Dict[str, object]]:
    normalized = _normalize_truth_task(task)
    node_ids = [str(node['local_track_key']) for node in normalized['nodes']]
    if normalized['truth']['kind'] == 'complete_partition':
        cluster_by_node = {str(member): str(cluster['truth_identity_id']) for cluster in normalized['truth']['clusters'] for member in cluster['members']}
        labeled_pairs = [(left, right, 'same' if cluster_by_node[left] == cluster_by_node[right] else 'different') for left, right in combinations(node_ids, 2)]
    else:
        labeled_pairs = [(str(item['left_local_track_key']), str(item['right_local_track_key']), str(item['label'])) for item in normalized['truth']['pairs']]
    records = []
    for left, right, label in labeled_pairs:
        records.append({'left_local_track_key': left, 'right_local_track_key': right, 'label': label, 'binary_target': 1 if label == 'same' else 0 if label == 'different' else None, 'supervised_loss_eligible': label in {'same', 'different'}})
    return records

def _seconds_to_us(value: float) -> int:
    if not math.isfinite(float(value)):
        raise IdentityDataContractError('time_invalid', '候选节点时间必须有限')
    return int(round(float(value) * 1000000.0))

def _node_id(task_id: str, local_track_key: str) -> str:
    return canonical_sha256(['df-paag-node-v2', task_id, local_track_key])

def _edge_id(left_index: int, right_index: int) -> str:
    return canonical_sha256(['df-paag-edge-v2', left_index, right_index])

def _diagnostic_reason_code(item: LocalTrackPairDiagnostic) -> str:
    if item.compatible:
        return 'compatible'
    if item.temporal_pair_count == 0:
        return 'no_temporal_neighbor'
    if item.compatible_pair_count == 0:
        return 'no_joint_position_velocity_gate_pass'
    return 'insufficient_support_time_bins_or_fraction'

def _nullable_finite(value: float | None, label: str) -> float | None:
    if value is None:
        return None
    return _finite_float(value, label, minimum=0.0)

def _diagnostic_statistics(item: LocalTrackPairDiagnostic) -> Dict[str, object]:
    return {'temporal_pair_count': _integer(item.temporal_pair_count, 'temporal_pair_count'), 'compatible_pair_count': _integer(item.compatible_pair_count, 'compatible_pair_count'), 'compatible_time_bin_count': _integer(item.compatible_time_bin_count, 'compatible_time_bin_count'), 'compatible_fraction': _finite_float(item.compatible_fraction, 'compatible_fraction', minimum=0.0), 'minimum_position_distance_m': _nullable_finite(item.minimum_position_distance_m, 'minimum_position_distance_m'), 'median_position_mahalanobis_sq': _nullable_finite(item.median_position_mahalanobis_sq, 'median_position_mahalanobis_sq'), 'median_velocity_mahalanobis_sq': _nullable_finite(item.median_velocity_mahalanobis_sq, 'median_velocity_mahalanobis_sq'), 'position_gate_threshold': _finite_float(item.position_gate_threshold, 'position_gate_threshold', minimum=0.0), 'velocity_gate_threshold': _finite_float(item.velocity_gate_threshold, 'velocity_gate_threshold', minimum=0.0)}

def _components(node_count: int, edges: Iterable[tuple[int, int]]) -> List[List[int]]:
    adjacency = {index: set() for index in range(node_count)}
    for left, right in edges:
        adjacency[left].add(right)
        adjacency[right].add(left)
    remaining = set(adjacency)
    result: List[List[int]] = []
    while remaining:
        start = min(remaining)
        stack = [start]
        component = set()
        while stack:
            node = stack.pop()
            if node in component:
                continue
            component.add(node)
            stack.extend(sorted(adjacency[node] - component, reverse=True))
        remaining -= component
        result.append(sorted(component))
    return sorted(result, key=lambda item: tuple(item))

def _validate_bindings(value: object) -> Dict[str, str]:
    bindings = _mapping(value, 'bindings')
    keys = {'protocol_sha256', 'task_pool_sha256', 'split_manifest_sha256', 'config_file_sha256', 'source_input_set_sha256'}
    _exact_keys(bindings, keys, 'bindings')
    return {key: _sha256(bindings.get(key), f'bindings.{key}') for key in sorted(keys)}

def _candidate_node_records(task_id: str, candidates: IdentityCandidatePairSets, decision_cutoff_us: int) -> tuple[List[Dict[str, object]], Dict[str, int]]:
    records: List[Dict[str, object]] = []
    seen = set()
    for node in sorted(candidates.nodes, key=lambda item: (item.model_history_sha256, item.sensor_id, item.first_corrected_time_s, item.last_corrected_time_s, item.report_count, item.local_track_key)):
        key = _opaque_text(node.local_track_key, 'candidate.local_track_key')
        if key in seen:
            raise IdentityDataContractError('candidate_node_duplicate', '候选节点重复')
        seen.add(key)
        first = _seconds_to_us(node.first_corrected_time_s)
        last = _seconds_to_us(node.last_corrected_time_s)
        if last < first or last > decision_cutoff_us:
            raise IdentityDataContractError('candidate_cutoff_violation', '候选历史必须先截断到decision_cutoff再生成候选')
        records.append({'node_index': len(records), 'node_id': _node_id(task_id, key), 'local_track_key': key, 'sensor_id': _opaque_text(node.sensor_id, 'candidate.sensor_id'), 'history_sha256': _sha256(node.model_history_sha256, 'candidate.model_history_sha256'), 'report_count': _integer(node.report_count, 'candidate.report_count', minimum=1), 'first_corrected_time_us': first, 'last_corrected_time_us': last})
    return (records, {str(record['local_track_key']): int(record['node_index']) for record in records})

def _validate_candidate_edges(candidates: IdentityCandidatePairSets, node_index: Mapping[str, int]) -> tuple[Dict[tuple[str, str], IdentityCandidateEdge], Dict[tuple[str, str], IdentityCandidateEdge]]:
    model: Dict[tuple[str, str], IdentityCandidateEdge] = {}
    for edge in candidates.model_edges:
        pair = canonical_pair(edge.left_local_track_key, edge.right_local_track_key)
        if pair != edge.pair:
            raise IdentityDataContractError('candidate_edge_order', 'S0边端点必须规范排序')
        if pair[0] not in node_index or pair[1] not in node_index:
            raise IdentityDataContractError('candidate_edge_unknown_node', 'S0边含未知节点')
        provenance = tuple(sorted(edge.provenance))
        if not provenance or len(provenance) != len(set(provenance)):
            raise IdentityDataContractError('candidate_provenance_invalid', 'S0来源为空或重复')
        if any((item not in S0_PROVENANCE_VALUES for item in provenance)):
            raise IdentityDataContractError('candidate_provenance_invalid', 'S0来源含身份相关或未知枚举')
        if pair in model:
            raise IdentityDataContractError('candidate_edge_duplicate', 'S0边重复')
        model[pair] = edge
    mby: Dict[tuple[str, str], IdentityCandidateEdge] = {}
    for edge in candidates.mby_audit_edges:
        pair = canonical_pair(edge.left_local_track_key, edge.right_local_track_key)
        if pair != edge.pair or tuple(edge.provenance) != ('A-MBY',):
            raise IdentityDataContractError('mby_audit_edge_invalid', 'A-MBY边必须规范且只能带A-MBY来源')
        if pair[0] not in node_index or pair[1] not in node_index:
            raise IdentityDataContractError('candidate_edge_unknown_node', 'A-MBY边含未知节点')
        if pair in mby:
            raise IdentityDataContractError('candidate_edge_duplicate', 'A-MBY边重复')
        mby[pair] = edge
    return (model, mby)

def create_candidate_graph_snapshot(*, snapshot_id: str, task_id: str, decision_cutoff_s: float, bindings: object, candidate_pair_sets: IdentityCandidatePairSets, pair_diagnostics: Sequence[LocalTrackPairDiagnostic]) -> Dict[str, object]:
    normalized_snapshot_id = _safe_id(snapshot_id, 'snapshot_id')
    normalized_task_id = _safe_id(task_id, 'task_id')
    cutoff_us = _seconds_to_us(_finite_float(decision_cutoff_s, 'decision_cutoff_s'))
    normalized_bindings = _validate_bindings(bindings)
    nodes, node_index = _candidate_node_records(normalized_task_id, candidate_pair_sets, cutoff_us)
    model_by_pair, mby_by_pair = _validate_candidate_edges(candidate_pair_sets, node_index)
    sensor_by_key = {str(item['local_track_key']): str(item['sensor_id']) for item in nodes}
    for pair in set(model_by_pair) | set(mby_by_pair):
        if sensor_by_key[pair[0]] == sensor_by_key[pair[1]]:
            raise IdentityDataContractError('same_sensor_candidate_edge', '身份候选边必须跨装备')
    diagnostic_by_pair: Dict[tuple[str, str], LocalTrackPairDiagnostic] = {}
    for diagnostic in pair_diagnostics:
        pair = canonical_pair(diagnostic.left_local_track_key, diagnostic.right_local_track_key)
        if pair in diagnostic_by_pair:
            raise IdentityDataContractError('diagnostic_duplicate', '候选诊断重复')
        diagnostic_by_pair[pair] = diagnostic
    legacy_pairs = set(model_by_pair) | set(mby_by_pair)
    if set(diagnostic_by_pair) != legacy_pairs:
        raise IdentityDataContractError('diagnostic_candidate_mismatch', '冻结B0诊断必须精确覆盖S0与A-MBY的历史并集')
    model_edges = []
    indexed_pairs = []
    for pair in sorted(model_by_pair):
        left_index = node_index[pair[0]]
        right_index = node_index[pair[1]]
        left_index, right_index = sorted((left_index, right_index))
        indexed_pairs.append((left_index, right_index))
        diagnostic = diagnostic_by_pair[pair]
        model_edges.append({'edge_id': _edge_id(left_index, right_index), 'left_node_index': left_index, 'right_node_index': right_index, 'provenance': sorted(model_by_pair[pair].provenance), 'baseline_compatible': bool(diagnostic.compatible), 'baseline_reason_code': _diagnostic_reason_code(diagnostic), 'baseline_statistics': _diagnostic_statistics(diagnostic)})
    model_edges.sort(key=lambda item: (item['left_node_index'], item['right_node_index']))
    nodes_by_sensor: Dict[str, List[int]] = defaultdict(list)
    for node in nodes:
        nodes_by_sensor[str(node['sensor_id'])].append(int(node['node_index']))
    conflict_sets = sorted((sorted(indices) for indices in nodes_by_sensor.values() if len(indices) > 1), key=lambda item: tuple(item))
    model_s0 = {'domain': 'S0-model', 'version': candidate_pair_sets.candidate_domain_version, 'identity_independent': True, 'node_count': len(nodes), 'edges': model_edges, 'components': _components(len(nodes), indexed_pairs), 'same_sensor_conflict_sets': conflict_sets, 'physics_energy': {'version': None, 'values': None, 'strict_likelihood': False}, 'hard_physics_mask': None}
    audit_edges = []
    for pair in sorted(mby_by_pair):
        left_index, right_index = sorted((node_index[pair[0]], node_index[pair[1]]))
        audit_edges.append({'edge_id': _edge_id(left_index, right_index), 'left_node_index': left_index, 'right_node_index': right_index, 'also_in_s0': pair in model_by_pair, 'baseline_compatible': bool(diagnostic_by_pair[pair].compatible)})
    audit_edges.sort(key=lambda item: (item['left_node_index'], item['right_node_index']))
    audit_a_mby = {'domain': 'A-MBY', 'model_eligible': False, 'edges': audit_edges, 'audit_only_edge_count': sum((not item['also_in_s0'] for item in audit_edges))}
    search_modes = []
    for item in candidate_pair_sets.search_modes:
        search_modes.append({'left_sensor_id': _opaque_text(item.left_sensor_id, 'search_mode.left_sensor_id'), 'right_sensor_id': _opaque_text(item.right_sensor_id, 'search_mode.right_sensor_id'), 'mode': _safe_id(item.mode, 'search_mode.mode'), 'cartesian_pair_count': _integer(item.cartesian_pair_count, 'search_mode.cartesian_pair_count', minimum=1)})
    search_modes.sort(key=lambda item: (str(item['left_sensor_id']), str(item['right_sensor_id'])))
    generator = {'candidate_generator_version': candidate_pair_sets.candidate_domain_version, 'time_quantization_version': TIME_QUANTIZATION_VERSION, 'representative_position_rule': 'median_enu_over_causal_history_at_cutoff', 'temporal_overlap_rule': 'closed_track_ranges_plus_birth_window', 'birth_window_us': _seconds_to_us(candidate_pair_sets.birth_window_s), 'exhaustive_pair_limit': _integer(candidate_pair_sets.exhaustive_pair_limit, 'exhaustive_pair_limit'), 'maximum_candidates_per_other_sensor': _integer(candidate_pair_sets.maximum_candidates_per_other_sensor, 'maximum_candidates_per_other_sensor', minimum=1), 'candidate_search_radius_m': _finite_float(candidate_pair_sets.candidate_search_radius_m, 'candidate_search_radius_m', minimum=0.0), 'scipy_version': _opaque_text(scipy.__version__, 'scipy_version'), 'sensor_pair_search_modes': search_modes}
    model_node_projection = [{'node_index': item['node_index'], 'history_sha256': item['history_sha256'], 'report_count': item['report_count'], 'first_corrected_time_us': item['first_corrected_time_us'], 'last_corrected_time_us': item['last_corrected_time_us']} for item in nodes]
    model_generator_projection = {key: value for key, value in generator.items() if key not in {'sensor_pair_search_modes', 'scipy_version'}}
    model_graph_hash = canonical_sha256({'schema_version': CANDIDATE_GRAPH_SNAPSHOT_SCHEMA_VERSION, 'decision_cutoff_us': cutoff_us, 'generator': model_generator_projection, 'nodes': model_node_projection, 'model_s0': model_s0})
    audit_hash = canonical_sha256(audit_a_mby)
    record = {'schema_version': CANDIDATE_GRAPH_SNAPSHOT_SCHEMA_VERSION, 'snapshot_id': normalized_snapshot_id, 'task_id': normalized_task_id, 'decision_cutoff_us': cutoff_us, 'bindings': normalized_bindings, 'generator': generator, 'nodes': nodes, 'model_s0': model_s0, 'audit_a_mby': audit_a_mby, 'h1': {'enabled': False, 'version': None, 'mask': None}, 'model_graph_sha256': model_graph_hash, 'audit_sha256': audit_hash}
    record['record_sha256'] = canonical_sha256(record)
    return record

def _validate_snapshot_generator(value: object) -> Dict[str, object]:
    generator = _mapping(value, 'generator')
    keys = {'candidate_generator_version', 'time_quantization_version', 'representative_position_rule', 'temporal_overlap_rule', 'birth_window_us', 'exhaustive_pair_limit', 'maximum_candidates_per_other_sensor', 'candidate_search_radius_m', 'scipy_version', 'sensor_pair_search_modes'}
    _exact_keys(generator, keys, 'generator')
    version = _safe_id(generator.get('candidate_generator_version'), 'generator.candidate_generator_version')
    if generator.get('time_quantization_version') != TIME_QUANTIZATION_VERSION:
        raise IdentityDataContractError('time_quantization_mismatch', '候选时间量化版本不兼容')
    if generator.get('representative_position_rule') != 'median_enu_over_causal_history_at_cutoff':
        raise IdentityDataContractError('candidate_generator_invalid', '代表点规则不兼容')
    if generator.get('temporal_overlap_rule') != 'closed_track_ranges_plus_birth_window':
        raise IdentityDataContractError('candidate_generator_invalid', '时间重叠规则不兼容')
    birth_window_us = _integer(generator.get('birth_window_us'), 'generator.birth_window_us')
    exhaustive = _integer(generator.get('exhaustive_pair_limit'), 'generator.exhaustive_pair_limit')
    maximum = _integer(generator.get('maximum_candidates_per_other_sensor'), 'generator.maximum_candidates_per_other_sensor', minimum=1)
    radius = _finite_float(generator.get('candidate_search_radius_m'), 'generator.candidate_search_radius_m', minimum=0.0)
    scipy_version = _opaque_text(generator.get('scipy_version'), 'generator.scipy_version')
    raw_modes = generator.get('sensor_pair_search_modes')
    if not isinstance(raw_modes, list):
        raise IdentityDataContractError('search_modes_invalid', 'sensor_pair_search_modes必须是数组')
    modes = []
    seen_sensor_pairs = set()
    for index, raw_mode in enumerate(raw_modes):
        label = f'generator.sensor_pair_search_modes[{index}]'
        mode = _mapping(raw_mode, label)
        _exact_keys(mode, {'left_sensor_id', 'right_sensor_id', 'mode', 'cartesian_pair_count'}, label)
        left = _opaque_text(mode.get('left_sensor_id'), f'{label}.left_sensor_id')
        right = _opaque_text(mode.get('right_sensor_id'), f'{label}.right_sensor_id')
        if left >= right:
            raise IdentityDataContractError('search_modes_invalid', '装备对必须按文本升序且不能自配对')
        pair = (left, right)
        if pair in seen_sensor_pairs:
            raise IdentityDataContractError('search_modes_invalid', '装备对搜索模式重复')
        seen_sensor_pairs.add(pair)
        mode_name = _safe_id(mode.get('mode'), f'{label}.mode')
        if mode_name not in {'exhaustive_time_overlap', 'bidirectional_kdtree_radius'}:
            raise IdentityDataContractError('search_modes_invalid', '搜索模式未知')
        modes.append({'left_sensor_id': left, 'right_sensor_id': right, 'mode': mode_name, 'cartesian_pair_count': _integer(mode.get('cartesian_pair_count'), f'{label}.cartesian_pair_count', minimum=1)})
    if modes != sorted(modes, key=lambda item: (str(item['left_sensor_id']), str(item['right_sensor_id']))):
        raise IdentityDataContractError('search_modes_invalid', '搜索模式数组必须稳定排序')
    return {'candidate_generator_version': version, 'time_quantization_version': TIME_QUANTIZATION_VERSION, 'representative_position_rule': generator['representative_position_rule'], 'temporal_overlap_rule': generator['temporal_overlap_rule'], 'birth_window_us': birth_window_us, 'exhaustive_pair_limit': exhaustive, 'maximum_candidates_per_other_sensor': maximum, 'candidate_search_radius_m': radius, 'scipy_version': scipy_version, 'sensor_pair_search_modes': modes}

def _validate_snapshot_nodes(value: object, *, task_id: str, cutoff_us: int) -> List[Dict[str, object]]:
    if not isinstance(value, list) or not value:
        raise IdentityDataContractError('candidate_nodes_invalid', 'nodes必须是非空数组')
    records = []
    keys = set()
    node_ids = set()
    expected_fields = {'node_index', 'node_id', 'local_track_key', 'sensor_id', 'history_sha256', 'report_count', 'first_corrected_time_us', 'last_corrected_time_us'}
    for expected_index, raw_node in enumerate(value):
        label = f'nodes[{expected_index}]'
        node = _mapping(raw_node, label)
        _exact_keys(node, expected_fields, label)
        index = _integer(node.get('node_index'), f'{label}.node_index')
        if index != expected_index:
            raise IdentityDataContractError('candidate_node_index_invalid', 'node_index必须从0连续递增')
        key = _opaque_text(node.get('local_track_key'), f'{label}.local_track_key')
        sensor = _opaque_text(node.get('sensor_id'), f'{label}.sensor_id')
        if key in keys:
            raise IdentityDataContractError('candidate_node_duplicate', 'local_track_key重复')
        keys.add(key)
        node_id = _sha256(node.get('node_id'), f'{label}.node_id')
        if node_id != _node_id(task_id, key) or node_id in node_ids:
            raise IdentityDataContractError('candidate_node_id_invalid', 'node_id与task/key绑定不一致或重复')
        node_ids.add(node_id)
        first = _integer(node.get('first_corrected_time_us'), f'{label}.first_corrected_time_us')
        last = _integer(node.get('last_corrected_time_us'), f'{label}.last_corrected_time_us')
        if last < first or last > cutoff_us:
            raise IdentityDataContractError('candidate_cutoff_violation', '节点历史超出decision cutoff')
        records.append({'node_index': index, 'node_id': node_id, 'local_track_key': key, 'sensor_id': sensor, 'history_sha256': _sha256(node.get('history_sha256'), f'{label}.history_sha256'), 'report_count': _integer(node.get('report_count'), f'{label}.report_count', minimum=1), 'first_corrected_time_us': first, 'last_corrected_time_us': last})
    return records

def _validate_snapshot_statistics(value: object, label: str) -> Dict[str, object]:
    statistics = _mapping(value, label)
    expected = {'temporal_pair_count', 'compatible_pair_count', 'compatible_time_bin_count', 'compatible_fraction', 'minimum_position_distance_m', 'median_position_mahalanobis_sq', 'median_velocity_mahalanobis_sq', 'position_gate_threshold', 'velocity_gate_threshold'}
    _exact_keys(statistics, expected, label)
    temporal = _integer(statistics.get('temporal_pair_count'), f'{label}.temporal')
    compatible = _integer(statistics.get('compatible_pair_count'), f'{label}.compatible')
    if compatible > temporal:
        raise IdentityDataContractError('baseline_statistics_invalid', 'compatible_pair_count不能超过temporal_pair_count')
    fraction = _finite_float(statistics.get('compatible_fraction'), f'{label}.fraction', minimum=0.0)
    if fraction > 1.0:
        raise IdentityDataContractError('baseline_statistics_invalid', 'compatible_fraction不能超过1')
    return {'temporal_pair_count': temporal, 'compatible_pair_count': compatible, 'compatible_time_bin_count': _integer(statistics.get('compatible_time_bin_count'), f'{label}.time_bins'), 'compatible_fraction': fraction, 'minimum_position_distance_m': _nullable_finite(statistics.get('minimum_position_distance_m'), f'{label}.min_distance'), 'median_position_mahalanobis_sq': _nullable_finite(statistics.get('median_position_mahalanobis_sq'), f'{label}.position_nis'), 'median_velocity_mahalanobis_sq': _nullable_finite(statistics.get('median_velocity_mahalanobis_sq'), f'{label}.velocity_nis'), 'position_gate_threshold': _finite_float(statistics.get('position_gate_threshold'), f'{label}.position_gate', minimum=0.0), 'velocity_gate_threshold': _finite_float(statistics.get('velocity_gate_threshold'), f'{label}.velocity_gate', minimum=0.0)}

def validate_candidate_graph_snapshot(value: object) -> Dict[str, object]:
    root = _mapping(value, 'candidate_snapshot')
    expected = {'schema_version', 'snapshot_id', 'task_id', 'decision_cutoff_us', 'bindings', 'generator', 'nodes', 'model_s0', 'audit_a_mby', 'h1', 'model_graph_sha256', 'audit_sha256', 'record_sha256'}
    _exact_keys(root, expected, 'candidate_snapshot')
    if root.get('schema_version') != CANDIDATE_GRAPH_SNAPSHOT_SCHEMA_VERSION:
        raise IdentityDataContractError('candidate_schema_mismatch', 'CandidateGraphSnapshot版本不兼容')
    _safe_id(root.get('snapshot_id'), 'snapshot_id')
    task_id = _safe_id(root.get('task_id'), 'task_id')
    cutoff_us = _integer(root.get('decision_cutoff_us'), 'decision_cutoff_us')
    _validate_bindings(root.get('bindings'))
    h1 = _mapping(root.get('h1'), 'h1')
    _exact_keys(h1, {'enabled', 'version', 'mask'}, 'h1')
    if h1 != {'enabled': False, 'version': None, 'mask': None}:
        raise IdentityDataContractError('h1_not_frozen', 'H1实现前必须严格保持禁用null状态')
    generator = _validate_snapshot_generator(root.get('generator'))
    nodes = _validate_snapshot_nodes(root.get('nodes'), task_id=task_id, cutoff_us=cutoff_us)
    model_s0 = _mapping(root.get('model_s0'), 'model_s0')
    _exact_keys(model_s0, {'domain', 'version', 'identity_independent', 'node_count', 'edges', 'components', 'same_sensor_conflict_sets', 'physics_energy', 'hard_physics_mask'}, 'model_s0')
    if model_s0.get('domain') != 'S0-model' or model_s0.get('identity_independent') is not True:
        raise IdentityDataContractError('candidate_domain_invalid', '模型域必须是身份无关S0')
    if model_s0.get('version') != generator['candidate_generator_version']:
        raise IdentityDataContractError('candidate_domain_invalid', 'S0版本与生成器不一致')
    if _integer(model_s0.get('node_count'), 'model_s0.node_count') != len(nodes):
        raise IdentityDataContractError('candidate_nodes_invalid', 'S0 node_count不一致')
    if model_s0.get('hard_physics_mask') is not None:
        raise IdentityDataContractError('h1_not_frozen', 'H1前hard_physics_mask必须为null')
    physics = _mapping(model_s0.get('physics_energy'), 'model_s0.physics_energy')
    _exact_keys(physics, {'version', 'values', 'strict_likelihood'}, 'physics_energy')
    if physics != {'version': None, 'values': None, 'strict_likelihood': False}:
        raise IdentityDataContractError('physics_energy_not_frozen', '连续physics energy实现前必须保持null且不得称likelihood')
    raw_model_edges = model_s0.get('edges')
    if not isinstance(raw_model_edges, list):
        raise IdentityDataContractError('candidate_edges_invalid', 'model_s0.edges必须是数组')
    indexed_model_pairs = []
    for index, raw_edge in enumerate(raw_model_edges):
        label = f'model_s0.edges[{index}]'
        edge = _mapping(raw_edge, label)
        _exact_keys(edge, {'edge_id', 'left_node_index', 'right_node_index', 'provenance', 'baseline_compatible', 'baseline_reason_code', 'baseline_statistics'}, label)
        left = _integer(edge.get('left_node_index'), f'{label}.left')
        right = _integer(edge.get('right_node_index'), f'{label}.right')
        if left >= right or right >= len(nodes):
            raise IdentityDataContractError('candidate_edges_invalid', 'S0边索引越界或非规范')
        pair = (left, right)
        if pair in indexed_model_pairs:
            raise IdentityDataContractError('candidate_edge_duplicate', 'S0边重复')
        indexed_model_pairs.append(pair)
        if _sha256(edge.get('edge_id'), f'{label}.edge_id') != _edge_id(left, right):
            raise IdentityDataContractError('candidate_edge_id_invalid', 'S0 edge_id不匹配')
        provenance = edge.get('provenance')
        if not isinstance(provenance, list) or not provenance or provenance != sorted(set(provenance)) or any((item not in S0_PROVENANCE_VALUES for item in provenance)):
            raise IdentityDataContractError('candidate_provenance_invalid', 'model_s0中出现未知或身份相关来源')
        _strict_bool(edge.get('baseline_compatible'), f'{label}.baseline_compatible')
        _safe_id(edge.get('baseline_reason_code'), f'{label}.baseline_reason_code')
        _validate_snapshot_statistics(edge.get('baseline_statistics'), f'{label}.statistics')
    if indexed_model_pairs != sorted(indexed_model_pairs):
        raise IdentityDataContractError('candidate_edges_invalid', 'S0边必须稳定排序')
    expected_components = _components(len(nodes), indexed_model_pairs)
    if model_s0.get('components') != expected_components:
        raise IdentityDataContractError('candidate_components_invalid', 'S0连通分量不匹配')
    by_sensor: Dict[str, List[int]] = defaultdict(list)
    for node in nodes:
        by_sensor[str(node['sensor_id'])].append(int(node['node_index']))
    expected_conflicts = sorted((sorted(indices) for indices in by_sensor.values() if len(indices) > 1), key=lambda item: tuple(item))
    if model_s0.get('same_sensor_conflict_sets') != expected_conflicts:
        raise IdentityDataContractError('candidate_conflict_sets_invalid', 'same-sensor互斥集合不匹配')
    audit = _mapping(root.get('audit_a_mby'), 'audit_a_mby')
    _exact_keys(audit, {'domain', 'model_eligible', 'edges', 'audit_only_edge_count'}, 'audit_a_mby')
    if audit.get('domain') != 'A-MBY' or audit.get('model_eligible') is not False:
        raise IdentityDataContractError('mby_audit_invalid', 'A-MBY必须显式禁止模型使用')
    raw_audit_edges = audit.get('edges')
    if not isinstance(raw_audit_edges, list):
        raise IdentityDataContractError('mby_audit_invalid', 'A-MBY edges必须是数组')
    audit_pairs = []
    model_pair_set = set(indexed_model_pairs)
    audit_only_count = 0
    for index, raw_edge in enumerate(raw_audit_edges):
        label = f'audit_a_mby.edges[{index}]'
        edge = _mapping(raw_edge, label)
        _exact_keys(edge, {'edge_id', 'left_node_index', 'right_node_index', 'also_in_s0', 'baseline_compatible'}, label)
        left = _integer(edge.get('left_node_index'), f'{label}.left')
        right = _integer(edge.get('right_node_index'), f'{label}.right')
        if left >= right or right >= len(nodes):
            raise IdentityDataContractError('mby_audit_invalid', 'A-MBY边索引越界或非规范')
        pair = (left, right)
        if pair in audit_pairs:
            raise IdentityDataContractError('candidate_edge_duplicate', 'A-MBY边重复')
        audit_pairs.append(pair)
        if _sha256(edge.get('edge_id'), f'{label}.edge_id') != _edge_id(left, right):
            raise IdentityDataContractError('candidate_edge_id_invalid', 'A-MBY edge_id不匹配')
        also_in_s0 = _strict_bool(edge.get('also_in_s0'), f'{label}.also_in_s0')
        if also_in_s0 != (pair in model_pair_set):
            raise IdentityDataContractError('mby_audit_invalid', 'also_in_s0标志不匹配')
        _strict_bool(edge.get('baseline_compatible'), f'{label}.baseline_compatible')
        audit_only_count += int(not also_in_s0)
    if audit_pairs != sorted(audit_pairs):
        raise IdentityDataContractError('mby_audit_invalid', 'A-MBY边必须稳定排序')
    if _integer(audit.get('audit_only_edge_count'), 'audit_only_edge_count') != audit_only_count:
        raise IdentityDataContractError('mby_audit_invalid', 'A-MBY-only计数不匹配')
    if canonical_sha256(audit) != _sha256(root.get('audit_sha256'), 'audit_sha256'):
        raise IdentityDataContractError('audit_hash_mismatch', 'A-MBY审计哈希不匹配')
    model_node_projection = [{'node_index': item['node_index'], 'history_sha256': item['history_sha256'], 'report_count': item['report_count'], 'first_corrected_time_us': item['first_corrected_time_us'], 'last_corrected_time_us': item['last_corrected_time_us']} for item in nodes]
    model_generator_projection = {key: item for key, item in generator.items() if key not in {'sensor_pair_search_modes', 'scipy_version'}}
    expected_model_hash = canonical_sha256({'schema_version': CANDIDATE_GRAPH_SNAPSHOT_SCHEMA_VERSION, 'decision_cutoff_us': root['decision_cutoff_us'], 'generator': model_generator_projection, 'nodes': model_node_projection, 'model_s0': model_s0})
    if expected_model_hash != _sha256(root.get('model_graph_sha256'), 'model_graph_sha256'):
        raise IdentityDataContractError('model_graph_hash_mismatch', 'S0模型图哈希不匹配')
    without_self = dict(root)
    record_hash = without_self.pop('record_sha256')
    if canonical_sha256(without_self) != _sha256(record_hash, 'record_sha256'):
        raise IdentityDataContractError('record_hash_mismatch', '候选快照整记录哈希不匹配')
    return deepcopy(dict(root))

def _truth_task_nodes_match_snapshot(truth_task: Mapping[str, object], snapshot: Mapping[str, object]) -> None:
    truth_nodes = {str(item['local_track_key']): item for item in truth_task['nodes']}
    snapshot_nodes = {str(item['local_track_key']): item for item in snapshot['nodes']}
    if set(truth_nodes) != set(snapshot_nodes):
        raise IdentityDataContractError('truth_snapshot_node_set_mismatch', '真值与候选快照节点全集不一致')
    fields = ('sensor_id', 'report_count', 'first_corrected_time_us', 'last_corrected_time_us', 'history_sha256')
    for key in sorted(truth_nodes):
        for field in fields:
            if truth_nodes[key][field] != snapshot_nodes[key][field]:
                raise IdentityDataContractError('truth_snapshot_node_metadata_mismatch', f'节点{key}的{field}与候选快照不一致')

def _pair_temporally_eligible(left: Mapping[str, object], right: Mapping[str, object], birth_window_us: int) -> bool:
    return max(int(left['first_corrected_time_us']), int(right['first_corrected_time_us'])) <= min(int(left['last_corrected_time_us']), int(right['last_corrected_time_us'])) + birth_window_us

def _truth_clusters(task: Mapping[str, object]) -> List[List[str]]:
    truth = task['truth']
    if truth['kind'] != 'complete_partition':
        return []
    return [list(cluster['members']) for cluster in truth['clusters']]

def create_candidate_coverage_audit(*, audit_id: str, truth_manifest_canonical_sha256: str, truth_task: object, candidate_snapshot: object) -> Dict[str, object]:
    task = _normalize_truth_task(truth_task)
    snapshot = validate_candidate_graph_snapshot(candidate_snapshot)
    if task['task_id'] != snapshot['task_id']:
        raise IdentityDataContractError('truth_snapshot_task_mismatch', 'task_id不一致')
    _truth_task_nodes_match_snapshot(task, snapshot)
    node_by_key = {str(item['local_track_key']): item for item in snapshot['nodes']}
    key_by_index = {int(item['node_index']): str(item['local_track_key']) for item in snapshot['nodes']}
    s0_pairs = {canonical_pair(key_by_index[int(edge['left_node_index'])], key_by_index[int(edge['right_node_index'])]) for edge in snapshot['model_s0']['edges']}
    birth_window_us = int(snapshot['generator']['birth_window_us'])
    supervision = truth_pair_supervision(task)
    label_counts = Counter((str(item['label']) for item in supervision))
    total_pairs = len(node_by_key) * (len(node_by_key) - 1) // 2
    explicit_or_derived_pairs = {canonical_pair(item['left_local_track_key'], item['right_local_track_key']) for item in supervision}
    label_audit = {'same': int(label_counts.get('same', 0)), 'different': int(label_counts.get('different', 0)), 'ambiguous': int(label_counts.get('ambiguous', 0)), 'unknown': int(total_pairs - len(explicit_or_derived_pairs)), 'binary_supervised': int(label_counts.get('same', 0) + label_counts.get('different', 0)), 'ambiguous_excluded_from_binary_metrics': int(label_counts.get('ambiguous', 0))}
    eligible_same_pairs = []
    out_of_scope_same_count = 0
    for item in supervision:
        if item['label'] != 'same':
            continue
        pair = canonical_pair(item['left_local_track_key'], item['right_local_track_key'])
        left_node = node_by_key[pair[0]]
        right_node = node_by_key[pair[1]]
        if left_node['sensor_id'] == right_node['sensor_id'] or not _pair_temporally_eligible(left_node, right_node, birth_window_us):
            out_of_scope_same_count += 1
            continue
        eligible_same_pairs.append(pair)
    eligible_same_pairs = sorted(set(eligible_same_pairs))
    hits = sorted((pair for pair in eligible_same_pairs if pair in s0_pairs))
    misses = sorted((pair for pair in eligible_same_pairs if pair not in s0_pairs))
    search_mode_by_sensor_pair = {tuple(sorted((str(item['left_sensor_id']), str(item['right_sensor_id'])))): str(item['mode']) for item in snapshot['generator']['sensor_pair_search_modes']}
    miss_events = []
    for left, right in misses:
        sensor_pair = tuple(sorted((str(node_by_key[left]['sensor_id']), str(node_by_key[right]['sensor_id']))))
        mode = search_mode_by_sensor_pair.get(sensor_pair)
        reason_code = 'radius_or_topk_filtered' if mode == 'bidirectional_kdtree_radius' else 'generator_inconsistency'
        miss_events.append({'event_type': 'candidate_miss', 'left_local_track_key': left, 'right_local_track_key': right, 'truth_label': 'same', 'reason_code': reason_code})
    graph_edges = {tuple(sorted((int(edge['left_node_index']), int(edge['right_node_index'])))) for edge in snapshot['model_s0']['edges']}
    index_by_key = {str(item['local_track_key']): int(item['node_index']) for item in snapshot['nodes']}
    infeasible_events = []
    if task['partition_complete']:
        for cluster_index, members in enumerate(_truth_clusters(task)):
            indices = sorted((index_by_key[key] for key in members))
            member_set = set(indices)
            induced_edges = [edge for edge in graph_edges if edge[0] in member_set and edge[1] in member_set]
            induced_components = _components(len(snapshot['nodes']), induced_edges)
            induced_components = [sorted(member_set.intersection(component)) for component in induced_components if member_set.intersection(component)]
            induced_components.sort(key=lambda item: tuple(item))
            if len(induced_components) > 1:
                infeasible_events.append({'event_type': 'candidate_infeasible', 'reason_code': 'truth_cluster_disconnected_in_s0', 'truth_cluster_index': cluster_index, 'members': sorted(members), 's0_components': [sorted((key_by_index[index] for index in component)) for component in induced_components]})
            by_sensor: Dict[str, List[str]] = defaultdict(list)
            for member in members:
                by_sensor[str(node_by_key[member]['sensor_id'])].append(member)
            conflicts = sorted((sorted(values) for values in by_sensor.values() if len(values) > 1))
            if conflicts:
                infeasible_events.append({'event_type': 'candidate_infeasible', 'reason_code': 'truth_cluster_violates_same_sensor_constraint', 'truth_cluster_index': cluster_index, 'members': sorted(members), 'same_sensor_conflicts': conflicts})
        candidate_infeasible: bool | None = bool(infeasible_events)
        qualification_reason = 'complete_partition'
    else:
        candidate_infeasible = None
        qualification_reason = 'partition_incomplete'
    denominator = len(eligible_same_pairs)
    record = {'schema_version': CANDIDATE_COVERAGE_AUDIT_SCHEMA_VERSION, 'audit_id': _safe_id(audit_id, 'audit_id'), 'task_id': task['task_id'], 'truth_manifest_canonical_sha256': _sha256(truth_manifest_canonical_sha256, 'truth_manifest_canonical_sha256'), 'model_graph_sha256': snapshot['model_graph_sha256'], 'eligibility_version': ELIGIBILITY_VERSION, 'feasibility_semantics_version': FEASIBILITY_SEMANTICS_VERSION, 'truth_qualification': {'truth_level': task['truth_level'], 'partition_complete': task['partition_complete'], 'temporal_identity_complete': task['temporal_identity_complete'], 'label_version': task['label_version']}, 'label_audit': label_audit, 'eligible_known_same_pairs': [{'left_local_track_key': left, 'right_local_track_key': right} for left, right in eligible_same_pairs], 'candidate_same_hits': [{'left_local_track_key': left, 'right_local_track_key': right} for left, right in hits], 'candidate_miss_events': miss_events, 'candidate_recall': {'eligible_same_pair_count': denominator, 'candidate_same_hit_count': len(hits), 'candidate_miss_count': len(misses), 'same_pair_outside_candidate_scope_count': out_of_scope_same_count, 'recall': float(len(hits) / denominator) if denominator else None}, 'partition_feasibility': {'qualified': bool(task['partition_complete']), 'qualification_reason': qualification_reason, 'candidate_infeasible': candidate_infeasible}, 'candidate_infeasible_events': infeasible_events}
    record['record_sha256'] = canonical_sha256(record)
    return record

def validate_candidate_coverage_audit(value: object) -> Dict[str, object]:
    root = _mapping(value, 'candidate_coverage_audit')
    expected = {'schema_version', 'audit_id', 'task_id', 'truth_manifest_canonical_sha256', 'model_graph_sha256', 'eligibility_version', 'feasibility_semantics_version', 'truth_qualification', 'label_audit', 'eligible_known_same_pairs', 'candidate_same_hits', 'candidate_miss_events', 'candidate_recall', 'partition_feasibility', 'candidate_infeasible_events', 'record_sha256'}
    _exact_keys(root, expected, 'candidate_coverage_audit')
    if root.get('schema_version') != CANDIDATE_COVERAGE_AUDIT_SCHEMA_VERSION:
        raise IdentityDataContractError('coverage_schema_mismatch', 'CandidateCoverageAudit版本不兼容')
    _safe_id(root.get('audit_id'), 'audit_id')
    _safe_id(root.get('task_id'), 'task_id')
    _sha256(root.get('truth_manifest_canonical_sha256'), 'truth_manifest_hash')
    _sha256(root.get('model_graph_sha256'), 'model_graph_sha256')
    qualification = _mapping(root.get('truth_qualification'), 'truth_qualification')
    complete = _strict_bool(qualification.get('partition_complete'), 'partition_complete')
    feasibility = _mapping(root.get('partition_feasibility'), 'partition_feasibility')
    if complete:
        if type(feasibility.get('candidate_infeasible')) is not bool:
            raise IdentityDataContractError('candidate_infeasible_invalid', '完整分区必须给出布尔可行性')
    elif feasibility.get('candidate_infeasible') is not None:
        raise IdentityDataContractError('candidate_infeasible_invalid', '部分真值的candidate_infeasible必须为null')
    recall = _mapping(root.get('candidate_recall'), 'candidate_recall')
    denominator = _integer(recall.get('eligible_same_pair_count'), 'eligible_same_pair_count')
    hit_count = _integer(recall.get('candidate_same_hit_count'), 'candidate_same_hit_count')
    miss_count = _integer(recall.get('candidate_miss_count'), 'candidate_miss_count')
    if hit_count + miss_count != denominator:
        raise IdentityDataContractError('candidate_recall_accounting', 'candidate hit + miss必须等于分母')
    if denominator == 0 and recall.get('recall') is not None:
        raise IdentityDataContractError('candidate_recall_zero_denominator', '候选召回分母为0时必须为null')
    if denominator:
        expected_recall = hit_count / denominator
        actual = _finite_float(recall.get('recall'), 'candidate_recall', minimum=0.0)
        if not math.isclose(actual, expected_recall, rel_tol=0.0, abs_tol=1e-15):
            raise IdentityDataContractError('candidate_recall_accounting', '候选召回值与计数不一致')
    without_self = dict(root)
    record_hash = without_self.pop('record_sha256')
    if canonical_sha256(without_self) != _sha256(record_hash, 'record_sha256'):
        raise IdentityDataContractError('record_hash_mismatch', 'coverage整记录哈希不匹配')
    return deepcopy(dict(root))
__all__ = ['AGREEMENT_VALUES', 'CANDIDATE_COVERAGE_AUDIT_SCHEMA_VERSION', 'CANDIDATE_GRAPH_SNAPSHOT_SCHEMA_VERSION', 'ELIGIBILITY_VERSION', 'FEASIBILITY_SEMANTICS_VERSION', 'IdentityDataContractError', 'LABEL_POLICY_VERSION', 'PAIR_LABELS', 'TIME_QUANTIZATION_VERSION', 'TRUTH_MANIFEST_SCHEMA_VERSION', 'canonical_pair', 'canonical_sha256', 'create_candidate_coverage_audit', 'create_candidate_graph_snapshot', 'truth_pair_label', 'truth_pair_supervision', 'validate_candidate_coverage_audit', 'validate_candidate_graph_snapshot', 'validate_identity_truth_manifest', 'validate_truth_manifest_against_task_pool']
