from __future__ import annotations
from itertools import combinations
import math
import numpy as np
from scipy.optimize import linear_sum_assignment
METHODS = ('GNN-assignment', 'JPDA-exact-assignment')
DEFAULT_MAX_HYPOTHESES = 100000
DEFAULT_FALLBACK_BEAM = 256

def _check_matrix(log_scores, null_score, temperature):
    matrix = np.asarray(log_scores, dtype=np.float64)
    if matrix.ndim != 2 or np.isnan(matrix).any() or np.isposinf(matrix).any():
        raise ValueError('Scores must be a matrix of finite log weights or -inf gates')
    if not np.isfinite(null_score) or not np.isfinite(temperature) or temperature <= 0:
        raise ValueError('Null score must be finite and temperature positive')
    return matrix

def global_nearest_neighbor_assignment(log_scores, *, null_score=0.0):
    matrix = _check_matrix(log_scores, null_score, 1.0)
    nleft, nright = matrix.shape
    result = np.zeros_like(matrix)
    if not nleft or not nright:
        return result
    gain = matrix - 2.0 * null_score
    cost = np.concatenate((-gain, np.zeros((nleft, nleft))), axis=1)
    rows, cols = linear_sum_assignment(cost)
    for row, col in zip(rows, cols):
        if col < nright and np.isfinite(matrix[row, col]) and (gain[row, col] > 0):
            result[row, col] = 1.0
    return result

def _matrix_components(matrix):
    nleft, nright = matrix.shape
    parent = list(range(nleft + nright))

    def root(index):
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index
    for row, col in np.argwhere(np.isfinite(matrix)):
        parent[root(int(row))] = root(nleft + int(col))
    groups = {}
    for row, col in np.argwhere(np.isfinite(matrix)):
        key = root(int(row))
        left, right = groups.setdefault(key, (set(), set()))
        left.add(int(row))
        right.add(int(col))
    return [(sorted(left), sorted(right)) for left, right in groups.values()]

def _beam_marginals(gain, width):
    beam = [(0.0, (), frozenset())]
    for row in range(gain.shape[0]):
        expanded = []
        for score, chosen, used in beam:
            expanded.append((score, chosen, used))
            for col in np.flatnonzero(np.isfinite(gain[row])):
                col = int(col)
                if col not in used:
                    expanded.append((score + float(gain[row, col]), chosen + ((row, col),), used | {col}))
        beam = sorted(expanded, key=lambda item: (-item[0], item[1]))[:width]
    maximum = max((item[0] for item in beam))
    weights = np.exp(np.array([item[0] for item in beam]) - maximum)
    weights /= weights.sum()
    output = np.zeros_like(gain)
    for (_, chosen, _), weight in zip(beam, weights):
        for row, col in chosen:
            output[row, col] += weight
    return (output, len(beam))

def _exact_component(gain, max_hypotheses, fallback_beam):
    order = np.argsort(np.isfinite(gain).sum(axis=1), kind='stable')
    ordered = gain[order]
    options = [np.flatnonzero(np.isfinite(row)).tolist() for row in ordered]
    log_max = -math.inf
    total_weight = 0.0
    weighted_edges = np.zeros_like(ordered)
    count = 0

    class EnumerationOverflow(Exception):
        pass

    def visit(row, used, chosen, score):
        nonlocal log_max, total_weight, count, weighted_edges
        if row == len(ordered):
            count += 1
            if count > max_hypotheses:
                raise EnumerationOverflow
            if score > log_max:
                scale = math.exp(log_max - score) if math.isfinite(log_max) else 0.0
                total_weight *= scale
                weighted_edges *= scale
                log_max = score
            weight = math.exp(score - log_max)
            total_weight += weight
            for a, b in chosen:
                weighted_edges[a, b] += weight
            return
        visit(row + 1, used, chosen, score)
        for col in options[row]:
            if col not in used:
                visit(row + 1, used | {col}, chosen + ((row, col),), score + float(ordered[row, col]))
    overflow = False
    try:
        visit(0, frozenset(), (), 0.0)
        marginals = weighted_edges / total_weight
        returned_count = count
    except EnumerationOverflow:
        overflow = True
        marginals, returned_count = _beam_marginals(ordered, fallback_beam)
    output = np.zeros_like(gain)
    output[order] = marginals
    return (output, {'exact': not overflow, 'overflow': overflow, 'enumerated_hypotheses': count, 'retained_hypotheses': returned_count, 'left_count': gain.shape[0], 'right_count': gain.shape[1]})

def joint_assignment_marginals(log_scores, *, null_score=0.0, temperature=1.0, max_hypotheses=DEFAULT_MAX_HYPOTHESES, fallback_beam=DEFAULT_FALLBACK_BEAM, overflow_policy='beam'):
    matrix = _check_matrix(log_scores, null_score, temperature)
    if max_hypotheses < 1 or fallback_beam < 1 or overflow_policy not in ('beam', 'raise'):
        raise ValueError('Positive bounds and a supported overflow policy required')
    result = np.zeros_like(matrix)
    audits = []
    for left, right in _matrix_components(matrix):
        component = matrix[np.ix_(left, right)]
        marginals, audit = _exact_component((component - 2 * null_score) / temperature, int(max_hypotheses), int(fallback_beam))
        if audit['overflow'] and overflow_policy == 'raise':
            raise RuntimeError('Exact joint assignment exceeded preregistered hypothesis cap')
        result[np.ix_(left, right)] = marginals
        audits.append(audit)
    return (result, {'exact': all((a['exact'] for a in audits)), 'overflow_components': sum((a['overflow'] for a in audits)), 'component_count': len(audits), 'components': audits, 'max_hypotheses_per_component': int(max_hypotheses), 'fallback_beam': int(fallback_beam)})

def _validate_task(task):
    sensors = np.asarray(task['sensor'], dtype=np.int64)
    edges = np.asarray(task['edges'], dtype=np.int64).reshape(-1, 2)
    scores = np.asarray(task['physical_logits'], dtype=np.float64)
    if scores.shape != (len(edges),) or not np.isfinite(scores).all():
        raise ValueError('Candidate physical log scores are required and finite')
    if len(task['histories']) != len(sensors) or (len(edges) and (edges.min() < 0 or edges.max() >= len(sensors))):
        raise ValueError('Invalid candidate node indices')
    intervals = np.array([(float(h['t'][0]), float(h['t'][-1])) for h in task['histories']], dtype=float).reshape(-1, 2)
    if not np.isfinite(intervals).all() or np.any(intervals[:, 1] < intervals[:, 0]):
        raise ValueError('Observed track intervals must be finite and ordered')
    if len({tuple(sorted(pair)) for pair in edges.tolist()}) != len(edges):
        raise ValueError('Each undirected candidate edge must occur once')
    return (sensors, edges, scores, intervals)

def association_scores(task, method, null_score=0.0, temperature=1.0, *, return_audit=False, max_hypotheses=DEFAULT_MAX_HYPOTHESES, fallback_beam=DEFAULT_FALLBACK_BEAM, overflow_policy='beam'):
    if method not in METHODS:
        raise ValueError(f'Unknown v4 association baseline: {method}')
    _check_matrix(np.empty((0, 0)), null_score, temperature)
    sensors, edges, scores, intervals = _validate_task(task)
    total = np.zeros(len(edges), dtype=float)
    exposure = np.zeros(len(edges), dtype=float)
    audits = []
    cache = {}

    def solve(edge_indices, left_nodes, right_nodes, orientations):
        key = (tuple(edge_indices), tuple(left_nodes), tuple(right_nodes), tuple(orientations))
        if key in cache:
            return cache[key]
        left_map = {node: i for i, node in enumerate(left_nodes)}
        right_map = {node: i for i, node in enumerate(right_nodes)}
        matrix = np.full((len(left_nodes), len(right_nodes)), -np.inf)
        positions = []
        for edge, (left, right) in zip(edge_indices, orientations):
            index = (left_map[left], right_map[right])
            matrix[index] = scores[edge]
            positions.append(index)
        if method == 'GNN-assignment':
            values = global_nearest_neighbor_assignment(matrix, null_score=null_score)
            audit = {'exact': True, 'overflow_components': 0, 'component_count': len(_matrix_components(matrix))}
        else:
            values, audit = joint_assignment_marginals(matrix, null_score=null_score, temperature=temperature, max_hypotheses=max_hypotheses, fallback_beam=fallback_beam, overflow_policy=overflow_policy)
        audit['candidate_edges'] = len(edge_indices)
        audits.append(audit)
        result = np.array([values[index] for index in positions])
        cache[key] = result
        return result
    for sensor_a, sensor_b in combinations(sorted(set(sensors.tolist())), 2):
        nodes_a = np.flatnonzero(sensors == sensor_a).tolist()
        nodes_b = np.flatnonzero(sensors == sensor_b).tolist()
        relevant = [k for k, (a, b) in enumerate(edges) if {int(sensors[a]), int(sensors[b])} == {sensor_a, sensor_b} and max(intervals[a, 0], intervals[b, 0]) <= min(intervals[a, 1], intervals[b, 1])]
        if not relevant:
            continue
        boundaries = np.unique(intervals[nodes_a + nodes_b].ravel())
        slots = [(float(a + b) / 2, float(b - a)) for a, b in zip(boundaries[:-1], boundaries[1:]) if b > a]
        point_times = [float(t) for t in boundaries if any((intervals[n, 0] == intervals[n, 1] == t for n in nodes_a + nodes_b))]
        slots.extend(((t, 1.0) for t in point_times))
        for timestamp, duration in slots:
            left = [n for n in nodes_a if intervals[n, 0] <= timestamp <= intervals[n, 1]]
            right = [n for n in nodes_b if intervals[n, 0] <= timestamp <= intervals[n, 1]]
            selected = [k for k in relevant if all((intervals[n, 0] <= timestamp <= intervals[n, 1] for n in edges[k]))]
            if not selected:
                continue
            oriented = [tuple(map(int, edges[k])) if sensors[edges[k, 0]] == sensor_a else tuple(map(int, edges[k, ::-1])) for k in selected]
            values = solve(selected, left, right, oriented)
            total[selected] += values * duration
            exposure[selected] += duration
    disjoint = [k for k, (a, b) in enumerate(edges) if max(intervals[a, 0], intervals[b, 0]) > min(intervals[a, 1], intervals[b, 1])]
    if disjoint:
        oriented = [(int(a), int(b)) if intervals[a, 1] < intervals[b, 0] else (int(b), int(a)) for a, b in edges[disjoint]]
        left = sorted({a for a, _ in oriented})
        right = sorted({b for _, b in oriented})
        values = solve(disjoint, left, right, oriented)
        total[disjoint] = values
        exposure[disjoint] = 1.0
    result = np.divide(total, exposure, out=np.zeros_like(total), where=exposure > 0)
    audit = {'method': method, 'scope': 'pairwise_track_assignment_with_temporal_path_adapter', 'shared_candidate_graph': True, 'posterior_is_three_sensor_joint': False, 'exact_assignment_subproblems': all((a['exact'] for a in audits)), 'overflow_components': sum((a['overflow_components'] for a in audits)), 'unique_assignment_problems': len(audits), 'assignment_audits': audits, 'disjoint_candidate_count': len(disjoint), 'unsupported_same_sensor_overlap_edges': int(np.sum(exposure == 0)), 'null_score': float(null_score), 'temperature': float(temperature)}
    return (result, audit) if return_audit else result

def decode_conflict_free(task, probabilities, threshold=0.5):
    sensors, edges, _, intervals = _validate_task(task)
    values = np.asarray(probabilities, dtype=float)
    if values.shape != (len(edges),) or not np.isfinite(values).all():
        raise ValueError('One finite score per candidate required')
    parent = list(range(len(sensors)))
    members = {n: {n} for n in range(len(sensors))}

    def root(n):
        while parent[n] != n:
            parent[n] = parent[parent[n]]
            n = parent[n]
        return n
    selected = np.zeros(len(edges), dtype=bool)
    rejected = 0
    for k in sorted(np.flatnonzero(values >= threshold).tolist(), key=lambda i: (-values[i], i)):
        a, b = map(int, edges[k])
        ra, rb = (root(a), root(b))
        if ra == rb:
            selected[k] = True
            continue
        conflict = any((sensors[i] == sensors[j] and max(intervals[i, 0], intervals[j, 0]) <= min(intervals[i, 1], intervals[j, 1]) for i in members[ra] for j in members[rb]))
        if conflict:
            rejected += 1
            continue
        parent[rb] = ra
        members[ra] |= members.pop(rb)
        selected[k] = True
    return (selected, {'decoder': 'descending_score_temporal_exclusion', 'rejected_candidate_edges': rejected})
