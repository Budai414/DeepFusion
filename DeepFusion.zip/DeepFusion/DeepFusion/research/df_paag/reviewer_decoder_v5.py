from __future__ import annotations
from typing import Mapping
import numpy as np
DECODER_MODES = ('threshold_cc', 'constrained_agglomerative')

def _observed(task):
    sensors = np.asarray(task['sensor'])
    if sensors.ndim != 1:
        raise ValueError('sensor must be a one-dimensional source array')
    n = len(sensors)
    raw_edges = np.asarray(task['edges'])
    if raw_edges.size == 0:
        edges = np.empty((0, 2), dtype=np.int64)
    else:
        if raw_edges.ndim != 2 or raw_edges.shape[1] != 2:
            raise ValueError('edges must have shape (E, 2)')
        edges = raw_edges.astype(np.int64)
        if not np.array_equal(edges, raw_edges):
            raise ValueError('edge endpoints must be integers')
        if np.any(edges < 0) or np.any(edges >= n):
            raise ValueError('edge endpoint outside the source-track array')
        if np.any(edges[:, 0] == edges[:, 1]):
            raise ValueError('self edges are not association candidates')
        if len(np.unique(np.sort(edges, axis=1), axis=0)) != len(edges):
            raise ValueError('duplicate undirected candidate edges')
    histories = task['histories']
    if len(histories) != n:
        raise ValueError('one observed history is required per source track')
    intervals = np.empty((n, 2), dtype=np.float64)
    for i, history in enumerate(histories):
        times = np.asarray(history['t'], dtype=np.float64)
        if times.ndim != 1 or not len(times) or (not np.isfinite(times).all()):
            raise ValueError('every history needs finite observed timestamps')
        if np.any(np.diff(times) < 0):
            raise ValueError('observed timestamps must be nondecreasing')
        intervals[i] = (times[0], times[-1])
    return (sensors, edges, intervals)

def _probabilities(values, length, name):
    array = np.asarray(values, dtype=np.float64)
    if array.shape != (length,):
        raise ValueError(f'{name} must have shape ({length},)')
    if not np.isfinite(array).all() or np.any((array < 0) | (array > 1)):
        raise ValueError(f'{name} must contain finite probabilities in [0, 1]')
    return array

def _threshold(value, name='threshold'):
    value = float(value)
    if not np.isfinite(value) or not 0 <= value <= 1:
        raise ValueError(f'{name} must be finite and in [0, 1]')
    return value

class _UnionFind:

    def __init__(self, n):
        self.parent = list(range(n))
        self.members = [{i} for i in range(n)]

    def find(self, i):
        while self.parent[i] != i:
            self.parent[i] = self.parent[self.parent[i]]
            i = self.parent[i]
        return i

    def union(self, i, j):
        a, b = (self.find(i), self.find(j))
        if a != b:
            a, b = (min(a, b), max(a, b))
            self.parent[b] = a
            self.members[a].update(self.members[b])
            self.members[b].clear()
        return a

def partition_labels(n, edges, selected):
    edges = np.asarray(edges, dtype=np.int64).reshape(-1, 2)
    selected = np.asarray(selected, dtype=bool)
    if selected.shape != (len(edges),):
        raise ValueError('selected must have one entry per edge')
    if np.any(edges < 0) or np.any(edges >= n):
        raise ValueError('edge endpoint outside partition node array')
    uf = _UnionFind(n)
    for i, j in edges[selected]:
        uf.union(int(i), int(j))
    return np.asarray([uf.find(i) for i in range(n)], dtype=np.int64)

def _conflicts(sensors, intervals):
    return (sensors[:, None] == sensors[None, :]) & (intervals[:, None, 0] <= intervals[None, :, 1]) & (intervals[None, :, 0] <= intervals[:, None, 1]) & ~np.eye(len(sensors), dtype=bool)

def constraint_violations(task, selected):
    sensors, edges, intervals = _observed(task)
    labels = partition_labels(len(sensors), edges, selected)
    bad = _conflicts(sensors, intervals) & (labels[:, None] == labels[None, :])
    return [tuple(map(int, pair)) for pair in np.argwhere(np.triu(bad, k=1))]

def decode(task, p, threshold=0.5, mode='threshold_cc'):
    sensors, edges, intervals = _observed(task)
    p = _probabilities(p, len(edges), 'p')
    threshold = _threshold(threshold)
    if mode not in DECODER_MODES:
        raise ValueError(f'unknown decoder {mode!r}; expected {DECODER_MODES}')
    accepted = p >= threshold
    if mode == 'threshold_cc':
        return accepted
    accepted = np.zeros(len(edges), dtype=bool)
    conflicts = _conflicts(sensors, intervals)
    uf = _UnionFind(len(sensors))
    order = sorted(range(len(edges)), key=lambda k: (-float(p[k]), min(map(int, edges[k])), max(map(int, edges[k]))))
    for k in order:
        if p[k] < threshold:
            break
        i, j = map(int, edges[k])
        a, b = (uf.find(i), uf.find(j))
        if a != b and conflicts[np.ix_(sorted(uf.members[a]), sorted(uf.members[b]))].any():
            continue
        accepted[k] = True
        uf.union(a, b)
    return accepted

def risk_values(p, members, b0p):
    p = np.asarray(p, dtype=np.float64)
    if p.ndim != 1:
        raise ValueError('p must be one-dimensional')
    p = _probabilities(p, len(p), 'p')
    b0p = _probabilities(b0p, len(p), 'b0p')
    if members is None:
        members = p[None, :]
    members = np.asarray(members, dtype=np.float64)
    if members.ndim == 1:
        members = members[None, :]
    if members.ndim != 2 or members.shape[0] < 1 or members.shape[1] != len(p):
        raise ValueError('members must have shape (M, E), with M >= 1')
    if not np.isfinite(members).all() or np.any((members < 0) | (members > 1)):
        raise ValueError('members must contain finite probabilities in [0, 1]')
    clipped = np.clip(p, 1e-15, 1 - 1e-15)
    entropy = -(clipped * np.log(clipped) + (1 - clipped) * np.log1p(-clipped)) / np.log(2)
    entropy[(p == 0) | (p == 1)] = 0.0
    return np.maximum.reduce((entropy, members.var(axis=0) / 0.25, np.abs(p - b0p)))

def _candidate_components(n, edges):
    labels = partition_labels(n, edges, np.ones(len(edges), dtype=bool))
    grouped = {}
    for k, (i, _) in enumerate(edges):
        grouped.setdefault(int(labels[i]), []).append(k)
    return (labels, [np.asarray(grouped[key], dtype=np.int64) for key in sorted(grouped)])

def _partition_cost(edges, indices, labels, q, fp_cost):
    connected = labels[edges[indices, 0]] == labels[edges[indices, 1]]
    merge = float(np.mean(fp_cost * (1 - q[indices]) * connected))
    split = float(np.mean(q[indices] * ~connected))
    return {'total': merge + split, 'false_merge': merge, 'false_split': split}

def route(task, p, members, threshold, policy: Mapping, b0p):
    policy = dict(policy)
    sensors, edges, intervals = _observed(task)
    p = _probabilities(p, len(edges), 'p')
    b0p = _probabilities(b0p, len(edges), 'b0p')
    mode = policy.get('mode', 'none')
    if mode not in ('none', 'cost_aware'):
        raise ValueError("route mode must be 'none' or 'cost_aware'")
    decoder = policy.get('decoder', 'threshold_cc')
    selected = decode(task, p, threshold, decoder)
    candidate_labels, groups = _candidate_components(len(sensors), edges)
    audit = {'mode': mode, 'decoder': decoder, 'components': len(groups), 'fallback_components': 0, 'fallback_edges': 0, 'takeover_components': len(groups), 'takeover_edges': len(edges), 'cost_scope': 'mean expected cost on candidate-pair partition closure only', 'component_details': []}
    audit['component_audit'] = audit['component_details']
    if mode == 'none':
        return (selected, audit)
    aggregation = policy.get('aggregation', 'mean')
    if aggregation not in ('max', 'q90', 'mean'):
        raise ValueError('aggregation must be max, q90, or mean')
    risk_threshold = _threshold(policy.get('threshold', policy.get('risk_threshold', 0.8)), 'risk threshold')
    fp_cost = float(policy.get('cost', policy.get('fp_cost', 5.0)))
    min_gain = float(policy.get('min_gain', policy.get('min_cost_gain', 0.0)))
    if not np.isfinite(fp_cost) or fp_cost <= 0:
        raise ValueError('fp_cost must be positive and finite')
    if not np.isfinite(min_gain) or min_gain < 0:
        raise ValueError('min_cost_gain must be nonnegative and finite')
    reference = policy.get('cost_reference', 'mean')
    if reference not in ('neural', 'mean'):
        raise ValueError('cost_reference must be neural or mean')
    reference_weight = _threshold(policy.get('reference_weight', 0.0 if reference == 'neural' else 0.5), 'reference_weight')
    q = (1 - reference_weight) * p + reference_weight * b0p
    logits = np.asarray(task['physical_logits'], dtype=np.float64)
    if logits.shape != (len(edges),) or not np.isfinite(logits).all():
        raise ValueError('finite native physical_logits are required for B0 routing')
    b0selected = logits >= 0
    learned_labels = partition_labels(len(sensors), edges, selected)
    b0labels = partition_labels(len(sensors), edges, b0selected)
    conflicts = _conflicts(sensors, intervals)
    risks = risk_values(p, members, b0p)
    audit['cost_reference'] = 'common_neural_physical_probability_mixture'
    audit['reference_weight'] = reference_weight
    audit['fp_cost'] = fp_cost
    for indices in groups:
        nodes = np.flatnonzero(candidate_labels == candidate_labels[edges[indices[0], 0]])
        values = risks[indices]
        risk = float(np.max(values) if aggregation == 'max' else np.quantile(values, 0.9) if aggregation == 'q90' else np.mean(values))
        b0_conflict = bool((conflicts[np.ix_(nodes, nodes)] & (b0labels[nodes, None] == b0labels[None, nodes])).any())
        learned_cost = _partition_cost(edges, indices, learned_labels, q, fp_cost)
        b0cost = _partition_cost(edges, indices, b0labels, q, fp_cost)
        gain = learned_cost['total'] - b0cost['total']
        merge_nonincrease = b0cost['false_merge'] <= learned_cost['false_merge'] + 1e-12
        changed = bool(np.any(selected[indices] != b0selected[indices]))
        if risk < risk_threshold:
            reason = 'low_risk'
        elif b0_conflict:
            reason = 'b0_source_time_conflict'
        elif not changed:
            reason = 'same_edge_decisions'
        elif gain <= min_gain + 1e-12:
            reason = 'insufficient_expected_cost_gain'
        elif policy.get('require_merge_nonincrease', True) and (not merge_nonincrease):
            reason = 'expected_false_merge_increase'
        else:
            reason = 'fallback_expected_cost_reduction'
            selected[indices] = b0selected[indices]
            audit['fallback_components'] += 1
            audit['fallback_edges'] += len(indices)
        audit['component_audit'].append({'nodes': nodes.tolist(), 'edge_indices': indices.tolist(), 'edges': indices.tolist(), 'candidate_count': len(indices), 'unscored_pair_count': int(len(nodes) * (len(nodes) - 1) // 2 - len(indices)), 'risk': risk, 'risk_threshold': risk_threshold, 'learned_cost': learned_cost, 'b0_cost': b0cost, 'expected_learned_loss': learned_cost['total'], 'expected_b0_loss': b0cost['total'], 'expected_learned_fp': learned_cost['false_merge'] / fp_cost, 'expected_b0_fp': b0cost['false_merge'] / fp_cost, 'expected_cost_gain': gain, 'b0_constraint_valid': not b0_conflict, 'fallback': reason == 'fallback_expected_cost_reduction', 'reason': reason})
    audit['takeover_components'] -= audit['fallback_components']
    audit['takeover_edges'] -= audit['fallback_edges']
    return (selected, audit)
