from __future__ import annotations
import os
from pathlib import Path
import sys
from typing import Dict, Optional

class DeepFusionRuntimeGuardError(ValueError):

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = str(code)

def expected_venv_python(project_root: str | Path, *, platform_name: Optional[str]=None) -> Path:
    platform = os.name if platform_name is None else str(platform_name)
    relative = Path('Scripts/python.exe') if platform == 'nt' else Path('bin/python')
    return Path(project_root).absolute() / '.venv' / relative

def _lexical(path: str | Path) -> str:
    return os.path.normcase(os.path.abspath(os.fspath(path)))

def verify_deepfusion_runtime(project_root: str | Path, package_file: str | Path, *, executable: Optional[str | Path]=None, prefix: Optional[str | Path]=None, platform_name: Optional[str]=None) -> Dict[str, str]:
    root = Path(project_root).resolve()
    expected_prefix = (root / '.venv').resolve()
    expected_python = expected_venv_python(root, platform_name=platform_name)
    actual_python = Path(sys.executable if executable is None else executable)
    actual_prefix = Path(sys.prefix if prefix is None else prefix).resolve()
    if actual_prefix != expected_prefix or _lexical(actual_python) != _lexical(expected_python):
        raise DeepFusionRuntimeGuardError('wrong_python_interpreter', f'必须使用DeepFusion/.venv中的独立解释器: expected_prefix={expected_prefix}, actual_prefix={actual_prefix}, expected_python={expected_python}, actual_python={actual_python}')
    package_path = Path(package_file).resolve()
    try:
        package_path.relative_to(root)
    except ValueError as error:
        raise DeepFusionRuntimeGuardError('wrong_real_fusion_import', f'实际导入的real_fusion不在DeepFusion: {package_path}') from error
    return {'project_root': str(root), 'environment_prefix': str(actual_prefix), 'python_executable': str(actual_python), 'real_fusion_file': str(package_path)}
__all__ = ['DeepFusionRuntimeGuardError', 'expected_venv_python', 'verify_deepfusion_runtime']
